# MANDAI - Start único (Monorepo leve)

## Rodar (frontend + backend)
```bash
npm install
npm run dev
```

- Web: http://localhost:5173
- API: http://localhost:8080
- Health: http://localhost:8080/health

## Só backend
```bash
npm run dev:api
```

## Só frontend
```bash
npm run dev:web
```

> No Dyad, rode na pasta raiz (onde está este README).
