// Supabase Edge Function: update-delivery-status
// Enforces: status transition rules, basic anti-fraud (too-fast changes), geofencing for pickup/delivery.
// Also logs into delivery_status_events.

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type Payload = {
  delivery_id: string;
  to_status: "pending" | "picked_up" | "in_transit" | "delivered" | "not_delivered" | "cancelled";
  // optional location from the mobile/web client
  lat?: number;
  lng?: number;
  // cancellation / not delivered notes
  reason?: string;
    photo_url?: string;
  // radius meters for geofence (optional override)
  radius_m?: number;
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const transitions: Record<string, Set<string>> = {
  pending: new Set(["picked_up", "cancelled"]),
  picked_up: new Set(["in_transit", "not_delivered"]),
  in_transit: new Set(["delivered", "not_delivered"]),
  delivered: new Set([]),
  not_delivered: new Set([]),
  cancelled: new Set([]),
};

function haversineMeters(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const lat1 = toRad(aLat);
  const lat2 = toRad(bLat);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

serve(async (req) => {
  try {
    if (req.method !== "POST") {
      return new Response("Method not allowed", { status: 405 });
    }

    const authHeader = req.headers.get("Authorization") ?? "";
    if (!authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Missing Authorization bearer token" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      });
    }

    const payload = (await req.json()) as Payload;
    if (!payload?.delivery_id || !payload?.to_status) {
      return new Response(JSON.stringify({ error: "delivery_id and to_status are required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const { data: userData, error: userErr } = await client.auth.getUser();
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthenticated" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      });
    }
    const userId = userData.user.id;

    const { data: delivery, error: delErr } = await client
      .from("deliveries")
      .select("id, status, driver_id, pickup_lat, pickup_lng, delivery_lat, delivery_lng, status_changed_at, suspicious_flags")
      .eq("id", payload.delivery_id)
      .single();

    if (delErr || !delivery) {
      return new Response(JSON.stringify({ error: "Delivery not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    if (delivery.driver_id !== userId) {
      return new Response(JSON.stringify({ error: "Not allowed: only the assigned driver can update status" }), {
        status: 403,
        headers: { "Content-Type": "application/json" },
      });
    }

    const fromStatus = (delivery.status ?? "pending") as string;
    const toStatus = payload.to_status;

    if (!(transitions[fromStatus]?.has(toStatus) ?? false)) {
      return new Response(JSON.stringify({ error: `Invalid transition ${fromStatus} -> ${toStatus}` }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Anti-fraud: block too-fast status changes (default: 5s)
    const lastChanged = delivery.status_changed_at ? new Date(delivery.status_changed_at) : null;
    if (lastChanged) {
      const deltaMs = Date.now() - lastChanged.getTime();
      if (deltaMs < 5000) {
        // increment suspicious flag counter but do not update status
        await admin.from("deliveries").update({ suspicious_flags: (delivery.suspicious_flags ?? 0) + 1 }).eq("id", payload.delivery_id);
        return new Response(JSON.stringify({ error: "Ação muito rápida. Aguarde alguns segundos e tente novamente." }), {
          status: 429,
          headers: { "Content-Type": "application/json" },
        });
      }
    }

    // Geofencing for pickup/delivery
    const radius = payload.radius_m ?? 300;
    if ((toStatus === "picked_up" || toStatus === "delivered") && (payload.lat == null || payload.lng == null)) {
      return new Response(JSON.stringify({ error: "Localização (lat/lng) é obrigatória para esta etapa." }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    if (toStatus === "picked_up") {
      if (delivery.pickup_lat != null && delivery.pickup_lng != null) {
        const dist = haversineMeters(payload.lat!, payload.lng!, delivery.pickup_lat, delivery.pickup_lng);
        if (dist > radius) {
          return new Response(JSON.stringify({ error: `Você está longe do ponto de coleta (${Math.round(dist)}m). Aproxime-se para confirmar.` }), {
            status: 400,
            headers: { "Content-Type": "application/json" },
          });
        }
      }
    }

    if (toStatus === "delivered") {
      if (delivery.delivery_lat != null && delivery.delivery_lng != null) {
        const dist = haversineMeters(payload.lat!, payload.lng!, delivery.delivery_lat, delivery.delivery_lng);
        if (dist > radius) {
          return new Response(JSON.stringify({ error: `Você está longe do destino (${Math.round(dist)}m). Aproxime-se para confirmar entrega.` }), {
            status: 400,
            headers: { "Content-Type": "application/json" },
          });
        }
      }
    }

    const update: Record<string, unknown> = {
      status: toStatus,
      status_changed_at: new Date().toISOString(),
    };

    if (toStatus === "cancelled") {
      update.canceled_at = new Date().toISOString();
      update.canceled_by = userId;
      update.canceled_reason = payload.reason ?? null;
    }

    if (toStatus === "not_delivered") {
      update.not_delivered_reason = payload.reason ?? null;
    }

    // Use admin to perform update (avoids client-side schema mismatch issues), but we already checked permissions.
    const { error: updErr } = await admin.from("deliveries").update(update).eq("id", payload.delivery_id);
    if (updErr) {
      return new Response(JSON.stringify({ error: "Falha ao atualizar status", details: updErr.message }), {
        status: 500,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Log event
    await admin.from("delivery_status_events").insert({
      delivery_id: payload.delivery_id,
      user_id: userId,
      from_status: fromStatus,
      to_status: toStatus,
      client_lat: payload.lat ?? null,
      client_lng: payload.lng ?? null,
    });

    return new Response(JSON.stringify({ ok: true }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: "Unhandled error", details: String(e) }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
