import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { autoRefreshToken: false, persistSession: false } }
    )

    const testEmail = 'teste@mandai.com'
    const testPassword = 'teste123'
    const testCpfDigits = '12345678900'

    const upsertProfileAndRole = async (userId: string) => {
      const { error: profileError } = await supabaseAdmin
        .from('profiles')
        .upsert(
          {
            id: userId,
            email: testEmail,
            cpf: testCpfDigits,
            nome_completo: 'Usuário Teste',
            telefone: '11999999999',
            status: 'approved',
          },
          { onConflict: 'id' }
        )

      if (profileError) throw profileError

      const { error: roleError } = await supabaseAdmin
        .from('user_roles')
        .upsert(
          {
            user_id: userId,
            role: 'driver',
          },
          { onConflict: 'user_id,role' }
        )

      if (roleError) throw roleError
    }

    // If profile already exists, just return credentials
    const { data: existingProfile, error: existingProfileError } = await supabaseAdmin
      .from('profiles')
      .select('id, email, cpf')
      .eq('cpf', testCpfDigits)
      .maybeSingle()

    if (existingProfileError) throw existingProfileError

    if (existingProfile) {
      // Garantir que a senha do usuário de teste seja sempre conhecida
      const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(existingProfile.id, {
        password: testPassword,
        email_confirm: true,
      })
      if (updateError) throw updateError

      await upsertProfileAndRole(existingProfile.id)

      return new Response(
        JSON.stringify({
          message: 'Usuário de teste já existe (senha redefinida)',
          email: testEmail,
          cpf: testCpfDigits,
          password: testPassword,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Create auth user (or recover if it already exists)
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email: testEmail,
      password: testPassword,
      email_confirm: true,
    })

    if (authError) {
      // If already registered, fetch user and ensure profile/role exist
      if (String(authError.message).toLowerCase().includes('already been registered')) {
        const { data: usersData, error: listError } = await supabaseAdmin.auth.admin.listUsers({
          page: 1,
          perPage: 1000,
        })
        if (listError) throw listError

        const user = usersData.users.find((u) => u.email?.toLowerCase() === testEmail.toLowerCase())
        if (!user) throw new Error('Usuário auth existe, mas não foi possível localizar pelo email')

        // Garantir que a senha do usuário de teste seja sempre conhecida
        const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(user.id, {
          password: testPassword,
          email_confirm: true,
        })
        if (updateError) throw updateError

        await upsertProfileAndRole(user.id)

        return new Response(
          JSON.stringify({
            message: 'Usuário de teste pronto (perfil sincronizado)',
            email: testEmail,
            cpf: testCpfDigits,
            password: testPassword,
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      throw authError
    }

    await upsertProfileAndRole(authData.user.id)

    return new Response(
      JSON.stringify({
        message: 'Usuário de teste criado com sucesso',
        email: testEmail,
        cpf: testCpfDigits,
        password: testPassword,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({ error: message }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})