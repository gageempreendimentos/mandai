import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

type SendPushBody = {
  user_id?: string
  user_ids?: string[]
  send_all_drivers?: boolean
  title: string
  body: string
  data?: Record<string, string>
  clickUrl?: string
  statuses?: string[]
}

/**
 * Supabase Edge Function: send-push
 *
 * Env vars required:
 * - SUPABASE_URL
 * - SUPABASE_SERVICE_ROLE_KEY
 * - FCM_SERVER_KEY (Firebase Cloud Messaging "Legacy server key")
 *
 * This function sends a push notification to the user identified by user_id,
 * using the FCM token stored in profiles.push_token.
 */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const payload = (await req.json()) as Partial<SendPushBody>

    if (!payload.title || !payload.body || (!payload.user_id && !(payload.user_ids && payload.user_ids.length) && !payload.send_all_drivers)) {
      return new Response(JSON.stringify({ error: "Missing required fields: title, body and one of user_id, user_ids, send_all_drivers" }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    const fcmServerKey = Deno.env.get('FCM_SERVER_KEY')

    if (!supabaseUrl || !serviceRoleKey) {
      return new Response(JSON.stringify({ error: 'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }
    if (!fcmServerKey) {
      return new Response(JSON.stringify({ error: 'Missing FCM_SERVER_KEY (Firebase legacy server key)' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey)

    // Load token(s) from profiles
const statuses = payload.statuses && payload.statuses.length
  ? payload.statuses
  : ['approved', 'active', 'approved_driver', 'approved_approval']

let profileQuery = supabaseAdmin
  .from('profiles')
  .select('id, push_token, status')

if (payload.send_all_drivers) {
  profileQuery = profileQuery.in('status', statuses)
} else if (payload.user_ids && payload.user_ids.length) {
  profileQuery = profileQuery.in('id', payload.user_ids)
} else if (payload.user_id) {
  profileQuery = profileQuery.eq('id', payload.user_id)
}

const { data: profiles, error: profileErr } = await profileQuery
if (profileErr) throw profileErr

const tokens = (profiles || [])
  .map((p: any) => p.push_token)
  .filter((t: any) => typeof t === 'string' && t.length > 0)

if (!tokens.length) {
  return new Response(JSON.stringify({ ok: false, error: 'No push tokens found for targets.' }), {
    status: 200,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}
const data: Record<string, string> = {
      ...(payload.data || {}),
    }

    if (payload.clickUrl) {
      data.clickUrl = payload.clickUrl
    }

    // Legacy FCM API supports up to 1000 registration_ids per request.
const chunks: string[][] = []
const chunkSize = 500
for (let i = 0; i < tokens.length; i += chunkSize) {
  chunks.push(tokens.slice(i, i + chunkSize))
}

const results: any[] = []
let okCount = 0
let failCount = 0

// Legacy FCM API
    for (const tokensChunk of chunks) {
      const sendOnce = async () => {
        const res = await fetch('https://fcm.mandaigleapis.com/fcm/send', {
          method: 'POST',
          headers: {
            Authorization: `key=${fcmServerKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            registration_ids: tokensChunk,
            notification: {
              title: payload.title,
              body: payload.body,
            },
            data,
            priority: 'high',
          }),
        })
        const text = await res.text()
        return { res, text }
      }

      // attempt 1
      let attempt = await sendOnce()
      // retry once on HTTP error
      if (!attempt.res.ok) {
        await new Promise((r) => setTimeout(r, 250))
        attempt = await sendOnce()
      }

      try {
        const parsed = JSON.parse(attempt.text)
        if (typeof parsed?.success === 'number') okCount += parsed.success
        if (typeof parsed?.failure === 'number') failCount += parsed.failure
      } catch (_) {
        if (attempt.res.ok) okCount += tokensChunk.length
        else failCount += tokensChunk.length
      }

      results.push({
        ok: attempt.res.ok,
        status: attempt.res.status,
        response: attempt.text,
        batchSize: tokensChunk.length,
      })
    }
// Basic audit log + persist notifications (best effort)
    try {
      const targetIds = (profiles || []).map((p: any) => p.id).filter(Boolean)

      // persist in-app notifications for each driver
      const notifRows = targetIds.map((id: string) => ({
        driver_id: id,
        title: payload.title,
        message: payload.body,
        type: (payload.data && payload.data.type) ? String(payload.data.type) : 'broadcast',
        read: false,
      }))
      // insert in chunks to avoid payload limits
      const nChunk = 500
      for (let i = 0; i < notifRows.length; i += nChunk) {
        await supabaseAdmin.from('notifications').insert(notifRows.slice(i, i + nChunk))
      }

      await supabaseAdmin.from('audit_logs').insert({
        action: 'push_sent',
        entity_type: 'notification',
        entity_id: null,
        meta: { okCount, failCount, batches: results.length, targets: targetIds.length },
      })
    } catch (_) {}

    return new Response(JSON.stringify({ ok: failCount === 0, okCount, failCount, batches: results.length, results }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e?.message || e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
