import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

type Body = {
  limit?: number
}

async function sendLegacyFcm(tokens: string[], title: string, body: string, data: Record<string,string>, fcmServerKey: string) {
  if (!tokens.length) return { ok: false, error: 'no_tokens' }
  const chunkSize = 500
  const chunks: string[][] = []
  for (let i = 0; i < tokens.length; i += chunkSize) chunks.push(tokens.slice(i, i + chunkSize))
  let okCount = 0
  let failCount = 0
  const results: any[] = []
  for (const tokensChunk of chunks) {
    const res = await fetch('https://fcm.mandaigleapis.com/fcm/send', {
      method: 'POST',
      headers: { Authorization: `key=${fcmServerKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        registration_ids: tokensChunk,
        notification: { title, body },
        data,
        priority: 'high',
      }),
    })
    const json = await res.json().catch(() => ({}))
    results.push({ status: res.status, json })
    if (json?.success) okCount += json.success
    if (json?.failure) failCount += json.failure
  }
  return { ok: true, okCount, failCount, results }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders })

  try {
    const payload = (await req.json().catch(() => ({}))) as Body

    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    const fcmServerKey = Deno.env.get('FCM_SERVER_KEY')

    if (!supabaseUrl || !serviceRoleKey) {
      return new Response(JSON.stringify({ error: 'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey)

    const limit = payload.limit ?? 50
    const nowIso = new Date().toISOString()

    // Find deliveries that are late according to their deadlines and not finalized
    const { data: lateDeliveries, error } = await supabaseAdmin
      .from('deliveries')
      .select('id, tracking_number, status, driver_id, accept_deadline, pickup_deadline, delivery_deadline, late_stage')
      .in('status', ['pending','accepted','picked_up','in_transit'])
      .or(`accept_deadline.lt.${nowIso},pickup_deadline.lt.${nowIso},delivery_deadline.lt.${nowIso}`)
      .limit(limit)

    if (error) throw error

    const updated: any[] = []

    for (const d of lateDeliveries ?? []) {
      let lateStage: string | null = null
      const acceptLate = d.status === 'pending' && d.accept_deadline && new Date(d.accept_deadline) < new Date()
      const pickupLate = (d.status === 'pending' || d.status === 'accepted') && d.pickup_deadline && new Date(d.pickup_deadline) < new Date()
      const deliveryLate = (d.status === 'picked_up' || d.status === 'in_transit' || d.status === 'accepted') && d.delivery_deadline && new Date(d.delivery_deadline) < new Date()

      if (acceptLate) lateStage = 'accept'
      else if (pickupLate) lateStage = 'pickup'
      else if (deliveryLate) lateStage = 'delivery'

      if (!lateStage) continue
      if (d.late_stage === lateStage) continue

      const { error: upErr } = await supabaseAdmin
        .from('deliveries')
        .update({ late_stage: lateStage })
        .eq('id', d.id)

      if (upErr) throw upErr

      // Store notifications (driver + admin)
      const title = lateStage === 'accept'
        ? 'Entrega aguardando aceitação'
        : lateStage === 'pickup'
          ? 'Atraso na coleta'
          : 'Atraso na entrega'

      const msg = lateStage === 'accept'
        ? `⏰ Pedido #${d.tracking_number} está aguardando aceitação.`
        : lateStage === 'pickup'
          ? `⏰ Pedido #${d.tracking_number} está com atraso na coleta.`
          : `⏰ Pedido #${d.tracking_number} está com atraso na entrega.`

      // admin notifications in table (driver_id null, type 'admin')
      await supabaseAdmin.from('notifications').insert({
        title,
        message: msg,
        delivery_id: d.id,
        driver_id: null,
        type: 'admin_sla',
        read: false,
      })

      if (d.driver_id) {
        await supabaseAdmin.from('notifications').insert({
          title,
          message: msg,
          delivery_id: d.id,
          driver_id: d.driver_id,
          type: 'driver_sla',
          read: false,
        })
      }

      // Push notifications (best effort)
      if (fcmServerKey) {
        // driver push
        if (d.driver_id) {
          const { data: prof } = await supabaseAdmin.from('profiles').select('push_token').eq('id', d.driver_id).maybeSingle()
          const token = prof?.push_token
          if (token) {
            await sendLegacyFcm([token], title, msg, { deliveryId: d.id, type: 'sla', lateStage }, fcmServerKey)
          }
        }

        // admin push: get all admin push tokens
        const { data: admins } = await supabaseAdmin
          .from('user_roles')
          .select('user_id')
          .eq('role','admin')
        const adminIds = (admins ?? []).map((a: any) => a.user_id)
        if (adminIds.length) {
          const { data: adminProfiles } = await supabaseAdmin.from('profiles').select('push_token').in('id', adminIds)
          const tokens = (adminProfiles ?? []).map((p:any)=>p.push_token).filter((t:any)=>typeof t==='string' && t.length)
          if (tokens.length) {
            await sendLegacyFcm(tokens, title, msg, { deliveryId: d.id, type: 'sla', lateStage }, fcmServerKey)
          }
        }
      }

      updated.push({ id: d.id, late_stage: lateStage })
    }

    return new Response(JSON.stringify({ ok: true, checked: (lateDeliveries ?? []).length, updated }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
