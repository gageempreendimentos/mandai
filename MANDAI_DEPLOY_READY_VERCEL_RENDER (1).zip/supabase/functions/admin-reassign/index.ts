import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

type Body = {
  delivery_id: string
  new_driver_id: string
  timeout_seconds?: number
}

async function sendLegacyFcm(tokens: string[], title: string, body: string, data: Record<string,string>, fcmServerKey: string) {
  if (!tokens.length) return
  const chunkSize = 500
  for (let i = 0; i < tokens.length; i += chunkSize) {
    const chunk = tokens.slice(i, i + chunkSize)
    await fetch('https://fcm.mandaigleapis.com/fcm/send', {
      method: 'POST',
      headers: { Authorization: `key=${fcmServerKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        registration_ids: chunk,
        notification: { title, body },
        data,
        priority: 'high',
      }),
    }).catch(() => {})
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders })

  try {
    const payload = (await req.json()) as Body
    if (!payload.delivery_id || !payload.new_driver_id) {
      return new Response(JSON.stringify({ error: 'Missing delivery_id or new_driver_id' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    const fcmServerKey = Deno.env.get('FCM_SERVER_KEY')

    if (!supabaseUrl || !serviceRoleKey) {
      return new Response(JSON.stringify({ error: 'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey)

    // Padrão: 45s para aceitar. Pode ser sobrescrito pelo admin via timeout_seconds.
    const timeoutSeconds = payload.timeout_seconds ?? 45
    const expiresAt = new Date(Date.now() + timeoutSeconds * 1000).toISOString()

    // Load delivery to see current offer
    const { data: delivery, error: dErr } = await supabaseAdmin
      .from('deliveries')
      .select('id, tracking_number, driver_id, current_offer_id, status')
      .eq('id', payload.delivery_id)
      .single()
    if (dErr) throw dErr

    // Expire current offer if any
    if (delivery.current_offer_id) {
      await supabaseAdmin
        .from('delivery_offers')
        .update({ status: 'expired', responded_at: new Date().toISOString() })
        .eq('id', delivery.current_offer_id)
    }

    // Create new offer
    const { data: newOffer, error: oErr } = await supabaseAdmin
      .from('delivery_offers')
      .insert({
        delivery_id: payload.delivery_id,
        driver_id: payload.new_driver_id,
        status: 'offered',
        expires_at: expiresAt,
      })
      .select('id')
      .single()
    if (oErr) throw oErr

    // Update delivery assignment and offer pointer, keep status pending (awaiting acceptance)
    const { error: uErr } = await supabaseAdmin
      .from('deliveries')
      .update({
        driver_id: payload.new_driver_id,
        current_offer_id: newOffer.id,
        last_offer_at: new Date().toISOString(),
        offer_round: (delivery.offer_round ?? 0) + 1,
        status: 'pending',
      })
      .eq('id', payload.delivery_id)
    if (uErr) throw uErr

    // Audit log best effort
    await supabaseAdmin.from('audit_logs').insert({
      action: 'admin_reassign_driver',
      entity_type: 'delivery',
      entity_id: payload.delivery_id,
      details: { new_driver_id: payload.new_driver_id, timeout_seconds: timeoutSeconds },
    }).catch(() => {})

    const title = 'Nova entrega atribuída'
    const body = `📦 Pedido #${delivery.tracking_number} - aceite em até ${timeoutSeconds}s`

    // Store notification for driver
    await supabaseAdmin.from('notifications').insert({
      title,
      message: body,
      delivery_id: payload.delivery_id,
      driver_id: payload.new_driver_id,
      type: 'offer',
      read: false,
    }).catch(() => {})

    // Push to new driver (best effort)
    if (fcmServerKey) {
      const { data: prof } = await supabaseAdmin
        .from('profiles')
        .select('push_token')
        .eq('id', payload.new_driver_id)
        .maybeSingle()
      const token = prof?.push_token
      if (token) await sendLegacyFcm([token], title, body, { deliveryId: payload.delivery_id, type: 'offer' }, fcmServerKey)
    }

    return new Response(JSON.stringify({ ok: true, offer_id: newOffer.id }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
