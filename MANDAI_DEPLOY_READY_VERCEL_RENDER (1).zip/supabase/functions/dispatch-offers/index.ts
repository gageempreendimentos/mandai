import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

type DispatchBody = {
  delivery_id?: string
  timeout_seconds?: number
  limit?: number
}

/**
 * Supabase Edge Function: dispatch-offers
 *
 * O que faz:
 * - Atribui (oferece) entregas pendentes para entregadores online com timeout.
 * - Expira ofertas vencidas e redistribui para o próximo entregador.
 *
 * Como rodar:
 * - Pode ser chamado manualmente (invoke) ou via Scheduled Trigger (cron) no Supabase.
 *
 * Env vars required:
 * - SUPABASE_URL
 * - SUPABASE_SERVICE_ROLE_KEY
 * - FCM_SERVER_KEY (Firebase legacy server key)
 */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders })

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    const fcmServerKey = Deno.env.get('FCM_SERVER_KEY')

    if (!supabaseUrl || !serviceRoleKey) {
      return new Response(JSON.stringify({ error: 'Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }
    if (!fcmServerKey) {
      return new Response(JSON.stringify({ error: 'Missing FCM_SERVER_KEY (Firebase legacy server key)' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const body = (req.method === 'POST' ? ((await req.json()) as Partial<DispatchBody>) : {}) as Partial<DispatchBody>
    // Padrão: 45s para aceitar (Uber/99 style). Ainda pode ser sobrescrito via body.timeout_seconds.
    const timeoutSeconds = Math.max(10, Math.min(120, Number(body.timeout_seconds ?? 45)))
    const limit = Math.max(1, Math.min(200, Number(body.limit ?? 25)))

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey)

    // Helpers
    const sendPushToUser = async (userId: string, title: string, msg: string, data?: Record<string, string>) => {
      const { data: prof } = await supabaseAdmin.from('profiles').select('push_token').eq('id', userId).maybeSingle()
      const token = (prof as any)?.push_token
      if (!token) return { ok: false, reason: 'no_token' }

      const res = await fetch('https://fcm.mandaigleapis.com/fcm/send', {
        method: 'POST',
        headers: {
          Authorization: `key=${fcmServerKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: token,
          notification: { title, body: msg },
          data: { ...(data || {}) },
          priority: 'high',
        }),
      })
      return { ok: res.ok, status: res.status, text: await res.text() }
    }

    // 1) Expirar ofertas vencidas
    const { data: expiredOffers } = await supabaseAdmin
      .from('delivery_offers')
      .select('id, delivery_id, driver_id, expires_at')
      .eq('status', 'offered')
      .lt('expires_at', new Date().toISOString())
      .limit(500)

    let expiredCount = 0
    for (const offer of expiredOffers || []) {
      // marca offer expirada
      await supabaseAdmin
        .from('delivery_offers')
        .update({ status: 'expired', responded_at: new Date().toISOString() })
        .eq('id', offer.id)
        .eq('status', 'offered')

      // limpa driver_id apenas se ainda é a oferta atual e a entrega ainda está pending
      await supabaseAdmin
        .from('deliveries')
        .update({ driver_id: null, current_offer_id: null })
        .eq('id', offer.delivery_id)
        .eq('status', 'pending')
        .eq('current_offer_id', offer.id)

      expiredCount++
    }

    // 2) Selecionar entregas que precisam de oferta
    let deliveriesQuery = supabaseAdmin
      .from('deliveries')
      .select('id, tracking_number, pickup_address, delivery_address, value, driver_id, status, offer_round')
      .eq('status', 'pending')
      .is('driver_id', null)
      .limit(limit)

    if (body.delivery_id) {
      deliveriesQuery = deliveriesQuery.eq('id', body.delivery_id).limit(1)
    }

    const { data: pendingDeliveries, error: delErr } = await deliveriesQuery
    if (delErr) throw delErr

    // Função para escolher próximo driver online (que ainda não recebeu oferta para essa delivery)
    const pickNextDriver = async (deliveryId: string) => {
      // pega ids já ofertados
      const { data: offered } = await supabaseAdmin
        .from('delivery_offers')
        .select('driver_id')
        .eq('delivery_id', deliveryId)
        .limit(2000)

      const offeredIds = new Set((offered || []).map((r: any) => r.driver_id).filter(Boolean))

      // lista drivers online + com token + role driver
      // Nota: status do profile varia no seu sistema; aqui não filtramos por status pra não bloquear.
      const { data: drivers, error } = await supabaseAdmin
        .from('profiles')
        .select('id, push_token, is_online')
        .eq('is_online', true)
        .not('push_token', 'is', null)
        .limit(500)

      if (error) throw error

      const candidates = (drivers || []).filter((d: any) => !offeredIds.has(d.id))
      if (!candidates.length) return null

      // escolha simples (random). Se quiser, dá pra ordenar por distância/última entrega.
      const chosen = candidates[Math.floor(Math.random() * candidates.length)]
      return chosen?.id || null
    }

    let offeredCount = 0
    const offeredTo: Array<{ delivery_id: string; driver_id: string; offer_id: string }> = []

    for (const d of pendingDeliveries || []) {
      const driverId = await pickNextDriver(d.id)
      if (!driverId) continue

      const expiresAt = new Date(Date.now() + timeoutSeconds * 1000).toISOString()

      // cria offer
      const { data: offerRow, error: offerErr } = await supabaseAdmin
        .from('delivery_offers')
        .insert({
          delivery_id: d.id,
          driver_id: driverId,
          status: 'offered',
          expires_at: expiresAt,
          meta: { timeout_seconds: timeoutSeconds },
        })
        .select('id')
        .single()

      if (offerErr) continue

      // atribui driver para ele enxergar no app
      await supabaseAdmin
        .from('deliveries')
        .update({
          driver_id: driverId,
          current_offer_id: (offerRow as any).id,
          offer_round: Number(d.offer_round || 0) + 1,
          last_offer_at: new Date().toISOString(),
        })
        .eq('id', d.id)
        .eq('status', 'pending')
        .is('driver_id', null)

      // push + notificação in-app (best effort)
      const title = 'Nova entrega disponível'
      const msg = `Entrega #${(d as any).tracking_number || ''} - aceite em até ${timeoutSeconds}s`
      await sendPushToUser(driverId, title, msg, { type: 'offer', delivery_id: d.id })

      try {
        await supabaseAdmin.from('notifications').insert({
          driver_id: driverId,
          title,
          message: msg,
          type: 'offer',
          delivery_id: d.id,
          read: false,
        })
      } catch (_) {}

      offeredCount++
      offeredTo.push({ delivery_id: d.id, driver_id: driverId, offer_id: (offerRow as any).id })
    }

    // audit log
    try {
      await supabaseAdmin.from('audit_logs').insert({
        action: 'dispatch_offers',
        entity_type: 'delivery',
        entity_id: body.delivery_id ?? null,
        meta: { expiredCount, offeredCount, timeoutSeconds, limit },
      })
    } catch (_) {}

    return new Response(JSON.stringify({ ok: true, expiredCount, offeredCount, offeredTo }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (e) {
    return new Response(JSON.stringify({ error: String((e as any)?.message || e) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
