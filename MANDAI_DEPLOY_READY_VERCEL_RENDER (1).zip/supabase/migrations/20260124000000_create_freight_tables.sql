-- Create freight_requests table
CREATE TABLE public.freight_requests (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  client_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  pickup_address text NOT NULL,
  dropoff_address text NOT NULL,
  item_description text NOT NULL,
  item_dimensions text, -- e.g., "2m x 1m x 1m"
  item_weight numeric, -- in kg
  estimated_distance_km numeric NOT NULL,
  estimated_value numeric NOT NULL, -- initial estimate for client
  status public.freight_request_status DEFAULT 'pending_bids'::public.freight_request_status NOT NULL,
  accepted_bid_id uuid, -- References freight_bids(id)
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create freight_bids table
CREATE TABLE public.freight_bids (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  request_id uuid REFERENCES public.freight_requests(id) ON DELETE CASCADE NOT NULL,
  driver_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  bid_amount numeric NOT NULL,
  bid_status public.freight_bid_status DEFAULT 'pending'::public.freight_bid_status NOT NULL,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create enums for freight statuses
CREATE TYPE public.freight_request_status AS ENUM (
  'pending_bids',
  'bidding_closed',
  'accepted',
  'in_transit',
  'completed',
  'cancelled'
);

CREATE TYPE public.freight_bid_status AS ENUM (
  'pending',
  'accepted',
  'rejected'
);

-- Add foreign key constraint for accepted_bid_id after freight_bids table is created
ALTER TABLE public.freight_requests
ADD CONSTRAINT freight_requests_accepted_bid_id_fkey
FOREIGN KEY (accepted_bid_id) REFERENCES public.freight_bids(id) ON DELETE SET NULL;

-- Enable Row Level Security (RLS)
ALTER TABLE public.freight_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.freight_bids ENABLE ROW LEVEL SECURITY;

-- RLS policies for freight_requests
CREATE POLICY "Clients can create freight requests" ON public.freight_requests
  FOR INSERT WITH CHECK (auth.uid() = client_id);

CREATE POLICY "Clients can view their own freight requests" ON public.freight_requests
  FOR SELECT USING (auth.uid() = client_id);

CREATE POLICY "Drivers can view freight requests pending bids" ON public.freight_requests
  FOR SELECT USING (status = 'pending_bids'::public.freight_request_status AND auth.uid() IN (SELECT user_id FROM public.user_roles WHERE role = 'driver'));

CREATE POLICY "Clients can update their own freight requests" ON public.freight_requests
  FOR UPDATE USING (auth.uid() = client_id);

-- RLS policies for freight_bids
CREATE POLICY "Drivers can create bids on pending freight requests" ON public.freight_bids
  FOR INSERT WITH CHECK (
    auth.uid() = driver_id AND
    (SELECT status FROM public.freight_requests WHERE id = request_id) = 'pending_bids'::public.freight_request_status
  );

CREATE POLICY "Drivers can view their own bids" ON public.freight_bids
  FOR SELECT USING (auth.uid() = driver_id);

CREATE POLICY "Clients can view bids for their requests" ON public.freight_bids
  FOR SELECT USING (auth.uid() = (SELECT client_id FROM public.freight_requests WHERE id = request_id));

CREATE POLICY "Clients can update bid status for their requests" ON public.freight_bids
  FOR UPDATE USING (auth.uid() = (SELECT client_id FROM public.freight_requests WHERE id = request_id));

CREATE POLICY "Drivers can update their own bids" ON public.freight_bids
  FOR UPDATE USING (auth.uid() = driver_id);