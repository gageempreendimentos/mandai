-- Tabela de saques financeiros
CREATE TABLE public.withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL CHECK (amount > 0),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'completed')),
  pix_key TEXT,
  pix_key_type TEXT CHECK (pix_key_type IN ('cpf', 'email', 'phone', 'random')),
  rejection_reason TEXT,
  requested_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  processed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Tabela de feedback de entregas
CREATE TABLE public.delivery_feedback (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id UUID NOT NULL REFERENCES public.deliveries(id) ON DELETE CASCADE,
  driver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  customer_name TEXT,
  driver_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_feedback ENABLE ROW LEVEL SECURITY;

-- Políticas para withdrawals
CREATE POLICY "Drivers can view own withdrawals"
ON public.withdrawals FOR SELECT
USING (auth.uid() = driver_id);

CREATE POLICY "Drivers can insert own withdrawals"
ON public.withdrawals FOR INSERT
WITH CHECK (auth.uid() = driver_id);

CREATE POLICY "Admins can view all withdrawals"
ON public.withdrawals FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update withdrawals"
ON public.withdrawals FOR UPDATE
USING (has_role(auth.uid(), 'admin'));

-- Políticas para delivery_feedback
CREATE POLICY "Drivers can view own feedback"
ON public.delivery_feedback FOR SELECT
USING (auth.uid() = driver_id);

CREATE POLICY "Drivers can insert feedback"
ON public.delivery_feedback FOR INSERT
WITH CHECK (auth.uid() = driver_id);

CREATE POLICY "Admins can view all feedback"
ON public.delivery_feedback FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Trigger para updated_at em withdrawals
CREATE TRIGGER update_withdrawals_updated_at
  BEFORE UPDATE ON public.withdrawals
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Habilitar realtime para feedback
ALTER PUBLICATION supabase_realtime ADD TABLE public.delivery_feedback;