CREATE TABLE public.delivery_zones (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  name text NOT NULL,
  description text,
  coordinates jsonb, -- Store polygon data or simple boundary points
  extra_fee numeric NOT NULL DEFAULT 0.0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for all users" ON public.delivery_zones FOR SELECT USING (true);