-- Create enum for delivery status
CREATE TYPE public.delivery_status AS ENUM ('pending', 'picked_up', 'in_transit', 'delivered', 'not_delivered', 'cancelled');

-- Create enum for vehicle type
CREATE TYPE public.vehicle_type AS ENUM ('moto', 'carro', 'bicicleta', 'van');

-- Create profiles table for drivers
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nome_completo TEXT NOT NULL,
  cpf TEXT UNIQUE NOT NULL,
  rg TEXT,
  data_nascimento DATE,
  telefone TEXT NOT NULL,
  email TEXT NOT NULL,
  cep TEXT,
  rua TEXT,
  numero TEXT,
  complemento TEXT,
  bairro TEXT,
  cidade TEXT,
  estado TEXT,
  tipo_veiculo vehicle_type,
  marca_veiculo TEXT,
  modelo_veiculo TEXT,
  ano_veiculo TEXT,
  placa_veiculo TEXT,
  cor_veiculo TEXT,
  cnh_url TEXT,
  comprovante_endereco_url TEXT,
  documento_veiculo_url TEXT,
  status TEXT DEFAULT 'pending_approval',
  push_token TEXT,
  nav_preference TEXT DEFAULT 'mandaigle',
  overlay_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policies for profiles
CREATE POLICY "Users can view own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Create deliveries table with tracking number
CREATE TABLE public.deliveries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tracking_number TEXT UNIQUE NOT NULL,
  driver_id UUID REFERENCES public.profiles(id),
  customer_name TEXT NOT NULL,
  pickup_address TEXT NOT NULL,
  delivery_address TEXT NOT NULL,
  pickup_lat DOUBLE PRECISION,
  pickup_lng DOUBLE PRECISION,
  delivery_lat DOUBLE PRECISION,
  delivery_lng DOUBLE PRECISION,
  status delivery_status DEFAULT 'pending',
  value DECIMAL(10, 2),
  notes TEXT,
  pickup_time TIMESTAMPTZ,
  delivery_time TIMESTAMPTZ,
  photo_url TEXT,
  not_delivered_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on deliveries
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

-- Policies for deliveries
CREATE POLICY "Drivers can view assigned deliveries" ON public.deliveries
  FOR SELECT USING (auth.uid() = driver_id OR driver_id IS NULL);

CREATE POLICY "Drivers can update assigned deliveries" ON public.deliveries
  FOR UPDATE USING (auth.uid() = driver_id);

-- Create notifications table
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT DEFAULT 'new_order',
  delivery_id UUID REFERENCES public.deliveries(id),
  read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on notifications
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Policies for notifications
CREATE POLICY "Drivers can view own notifications" ON public.notifications
  FOR SELECT USING (auth.uid() = driver_id);

CREATE POLICY "Drivers can update own notifications" ON public.notifications
  FOR UPDATE USING (auth.uid() = driver_id);

-- Enable realtime for notifications
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- Function to generate tracking number
CREATE OR REPLACE FUNCTION generate_tracking_number()
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
  new_number TEXT;
  year_suffix TEXT;
  sequence_num INT;
BEGIN
  year_suffix := TO_CHAR(CURRENT_DATE, 'YY');
  SELECT COUNT(*) + 1 INTO sequence_num FROM public.deliveries 
  WHERE EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM CURRENT_DATE);
  new_number := '365' || year_suffix || LPAD(sequence_num::TEXT, 6, '0');
  RETURN new_number;
END;
$$;

-- Trigger to auto-generate tracking number
CREATE OR REPLACE FUNCTION set_tracking_number()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.tracking_number IS NULL OR NEW.tracking_number = '' THEN
    NEW.tracking_number := generate_tracking_number();
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_set_tracking_number
  BEFORE INSERT ON public.deliveries
  FOR EACH ROW
  EXECUTE FUNCTION set_tracking_number();

-- Function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_timestamp
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_deliveries_timestamp
  BEFORE UPDATE ON public.deliveries
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Create storage bucket for documents
INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false);

-- Storage policies for documents
CREATE POLICY "Users can upload own documents" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view own documents" ON storage.objects
  FOR SELECT USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);