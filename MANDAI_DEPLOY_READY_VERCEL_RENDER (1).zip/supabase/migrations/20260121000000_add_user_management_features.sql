-- Add 'client' and 'restaurant' to app_role enum
ALTER TYPE public.app_role ADD VALUE 'client';
ALTER TYPE public.app_role ADD VALUE 'restaurant';

-- Add blocked_at and blocked_reason to profiles table
ALTER TABLE public.profiles
ADD COLUMN blocked_at timestamp with time zone,
ADD COLUMN blocked_reason text;

-- Rename driver_id to user_id in notifications table and update foreign key
ALTER TABLE public.notifications
RENAME COLUMN driver_id TO user_id;

ALTER TABLE public.notifications
DROP CONSTRAINT notifications_driver_id_fkey;

ALTER TABLE public.notifications
ADD CONSTRAINT notifications_user_id_fkey
FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- Create user_activity_logs table
CREATE TABLE public.user_activity_logs (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  action text NOT NULL,
  description text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS for user_activity_logs
ALTER TABLE public.user_activity_logs ENABLE ROW LEVEL SECURITY;

-- Policies for user_activity_logs (adjust as needed)
CREATE POLICY "Admins can view all user activity logs" ON public.user_activity_logs
FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
);

CREATE POLICY "Users can view their own activity logs" ON public.user_activity_logs
FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE POLICY "Admins can insert user activity logs" ON public.user_activity_logs
FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
);

-- Update existing profiles to have a default 'client' role if no role is set
-- This is a one-time operation for existing users without a role
INSERT INTO public.user_roles (user_id, role)
SELECT p.id, 'client'
FROM public.profiles p
LEFT JOIN public.user_roles ur ON p.id = ur.user_id
WHERE ur.user_id IS NULL;

-- Update existing client profiles to have 'approved' status if they are 'pending'
UPDATE public.profiles
SET status = 'approved'
WHERE id IN (
    SELECT p.id
    FROM public.profiles p
    JOIN public.user_roles ur ON p.id = ur.user_id
    WHERE ur.role = 'client' AND p.status = 'pending'
);