-- Adds proof-of-delivery, cancellations with reasons, disputes/tickets, geofencing + anti-fraud support tables
-- Generated on 2026-01-25

-- 1) Storage bucket for delivery proofs (idempotent)
insert into storage.buckets (id, name, public)
values ('delivery-proofs', 'delivery-proofs', true)
on conflict (id) do nothing;

-- 2) Deliveries: cancellation fields + last status change tracking + simple fraud counters
alter table public.deliveries
  add column if not exists canceled_reason text,
  add column if not exists canceled_by uuid,
  add column if not exists canceled_at timestamptz,
  add column if not exists status_changed_at timestamptz default now(),
  add column if not exists suspicious_flags int default 0;

-- 3) Status event log for anti-fraud and audit
create table if not exists public.delivery_status_events (
  id uuid primary key default gen_random_uuid(),
  delivery_id uuid not null references public.deliveries(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  from_status public.delivery_status,
  to_status public.delivery_status,
  client_lat double precision,
  client_lng double precision,
  created_at timestamptz not null default now()
);
create index if not exists idx_delivery_status_events_delivery on public.delivery_status_events(delivery_id, created_at desc);

alter table public.delivery_status_events enable row level security;

-- Allow read for participants (driver) and admins (best-effort: approved profiles can read their own driver events)
create policy if not exists "driver can read own delivery status events"
on public.delivery_status_events for select
using (exists (
  select 1 from public.deliveries d
  where d.id = delivery_id and d.driver_id = auth.uid()
));

-- Insert only via edge function using service role (no client insert)
create policy if not exists "no client insert delivery status events"
on public.delivery_status_events for insert
with check (false);

-- 4) Disputes / support tickets per delivery
create table if not exists public.delivery_disputes (
  id uuid primary key default gen_random_uuid(),
  delivery_id uuid not null references public.deliveries(id) on delete cascade,
  created_by uuid references auth.users(id) on delete set null,
  created_role text not null default 'unknown',
  subject text not null,
  status text not null default 'open', -- open, in_review, resolved, closed
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_delivery_disputes_delivery on public.delivery_disputes(delivery_id, created_at desc);
create index if not exists idx_delivery_disputes_status on public.delivery_disputes(status, updated_at desc);

create table if not exists public.delivery_dispute_messages (
  id uuid primary key default gen_random_uuid(),
  dispute_id uuid not null references public.delivery_disputes(id) on delete cascade,
  sender_id uuid references auth.users(id) on delete set null,
  message text not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_dispute_messages_dispute on public.delivery_dispute_messages(dispute_id, created_at);

alter table public.delivery_disputes enable row level security;
alter table public.delivery_dispute_messages enable row level security;

-- Driver can create/read disputes for their own deliveries
create policy if not exists "driver can read disputes for own deliveries"
on public.delivery_disputes for select
using (exists (select 1 from public.deliveries d where d.id = delivery_id and d.driver_id = auth.uid()));

create policy if not exists "driver can create disputes for own deliveries"
on public.delivery_disputes for insert
with check (exists (select 1 from public.deliveries d where d.id = delivery_id and d.driver_id = auth.uid()));

create policy if not exists "driver can read dispute messages for own deliveries"
on public.delivery_dispute_messages for select
using (exists (
  select 1
  from public.delivery_disputes dd
  join public.deliveries d on d.id = dd.delivery_id
  where dd.id = dispute_id and d.driver_id = auth.uid()
));

create policy if not exists "driver can create dispute messages for own deliveries"
on public.delivery_dispute_messages for insert
with check (exists (
  select 1
  from public.delivery_disputes dd
  join public.deliveries d on d.id = dd.delivery_id
  where dd.id = dispute_id and d.driver_id = auth.uid()
));

-- 5) Trigger to keep updated_at in disputes
create or replace function public.set_updated_at_timestamp()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_delivery_disputes_updated_at on public.delivery_disputes;
create trigger trg_delivery_disputes_updated_at
before update on public.delivery_disputes
for each row execute function public.set_updated_at_timestamp();


-- Admin policies (via user_roles)
create policy if not exists "admin can read all delivery status events"
on public.delivery_status_events for select
using (exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = 'admin'));

create policy if not exists "admin can read all disputes"
on public.delivery_disputes for select
using (exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = 'admin'));

create policy if not exists "admin can update disputes"
on public.delivery_disputes for update
using (exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = 'admin'))
with check (exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = 'admin'));

create policy if not exists "admin can read all dispute messages"
on public.delivery_dispute_messages for select
using (exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = 'admin'));

create policy if not exists "admin can create dispute messages"
on public.delivery_dispute_messages for insert
with check (exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = 'admin'));
