CREATE TABLE public.promotions (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  code text UNIQUE NOT NULL,
  type text NOT NULL, -- e.g., 'percentage', 'fixed_amount'
  value numeric NOT NULL,
  min_order_value numeric DEFAULT 0.0,
  max_discount_amount numeric,
  usage_limit integer,
  used_count integer DEFAULT 0,
  expires_at timestamp with time zone,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for all users" ON public.promotions FOR SELECT USING (true);