-- Timeout de aceitação + redistribuição automática

-- 1) Adiciona status 'accepted' no enum delivery_status
DO $$
BEGIN
  BEGIN
    ALTER TYPE public.delivery_status ADD VALUE 'accepted';
  EXCEPTION
    WHEN duplicate_object THEN NULL;
  END;
END $$;

-- 2) Atualiza função de validação de transição de status
CREATE OR REPLACE FUNCTION public.validate_delivery_status_transition(old_status public.delivery_status, new_status public.delivery_status)
RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
BEGIN
  IF old_status = new_status THEN
    RETURN TRUE;
  END IF;

  -- Permitir cancelamento a partir de qualquer estado não final
  IF new_status = 'cancelled' THEN
    IF old_status IN ('delivered', 'not_delivered') THEN
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END IF;

  -- Fluxo principal
  IF old_status = 'pending' AND new_status = 'accepted' THEN
    RETURN TRUE;
  END IF;

  IF old_status = 'accepted' AND new_status = 'picked_up' THEN
    RETURN TRUE;
  END IF;

  IF old_status = 'picked_up' AND new_status = 'in_transit' THEN
    RETURN TRUE;
  END IF;

  IF old_status = 'in_transit' AND new_status IN ('delivered','not_delivered') THEN
    RETURN TRUE;
  END IF;

  -- Compatibilidade (fluxo antigo)
  IF old_status = 'pending' AND new_status IN ('picked_up','in_transit') THEN
    RETURN TRUE;
  END IF;

  RETURN FALSE;
END;
$$;

-- 3) Atualiza trigger de deliveries para timestamps
CREATE OR REPLACE FUNCTION public.deliveries_before_update()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NOT public.validate_delivery_status_transition(OLD.status, NEW.status) THEN
    RAISE EXCEPTION 'Invalid status transition: % -> %', OLD.status, NEW.status;
  END IF;

  IF OLD.driver_id IS DISTINCT FROM NEW.driver_id AND NEW.driver_id IS NOT NULL THEN
    NEW.assigned_at := COALESCE(OLD.assigned_at, now());
  END IF;

  IF OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'accepted' THEN
      NEW.accepted_at := COALESCE(OLD.accepted_at, now());
    ELSIF NEW.status = 'picked_up' THEN
      NEW.picked_up_at := COALESCE(OLD.picked_up_at, now());
    ELSIF NEW.status = 'in_transit' THEN
      NEW.in_transit_at := COALESCE(OLD.in_transit_at, now());
    ELSIF NEW.status = 'delivered' THEN
      NEW.delivered_at := COALESCE(OLD.delivered_at, now());
    ELSIF NEW.status = 'cancelled' THEN
      NEW.cancelled_at := COALESCE(OLD.cancelled_at, now());
    END IF;
  END IF;

  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

-- 4) Tabela de ofertas (aceitação com timeout)
CREATE TABLE IF NOT EXISTS public.delivery_offers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id UUID NOT NULL REFERENCES public.deliveries(id) ON DELETE CASCADE,
  driver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'offered', -- offered|accepted|declined|expired
  offered_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  responded_at TIMESTAMPTZ,
  meta JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_delivery_offers_delivery ON public.delivery_offers(delivery_id, offered_at DESC);
CREATE INDEX IF NOT EXISTS idx_delivery_offers_driver_status ON public.delivery_offers(driver_id, status);

ALTER TABLE public.deliveries
  ADD COLUMN IF NOT EXISTS current_offer_id UUID REFERENCES public.delivery_offers(id),
  ADD COLUMN IF NOT EXISTS offer_round INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_offer_at TIMESTAMPTZ;

ALTER TABLE public.delivery_offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY IF NOT EXISTS "Admin vê delivery_offers" ON public.delivery_offers
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
  );

CREATE POLICY IF NOT EXISTS "Driver vê as próprias ofertas" ON public.delivery_offers
  FOR SELECT USING (auth.uid() = driver_id);

CREATE POLICY IF NOT EXISTS "Permitir insert delivery_offers autenticado" ON public.delivery_offers
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY IF NOT EXISTS "Permitir update delivery_offers autenticado" ON public.delivery_offers
  FOR UPDATE USING (auth.uid() IS NOT NULL);
