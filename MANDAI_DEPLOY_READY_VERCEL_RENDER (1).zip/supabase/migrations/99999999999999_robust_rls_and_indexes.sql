-- Robust RLS + indexes (template). Adjust table/column names to your schema.

alter table public.deliveries enable row level security;

create policy "admin can read deliveries"
on public.deliveries for select
using (
  exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and p.role = 'admin'
  )
);

create policy "client can read own deliveries"
on public.deliveries for select
using (client_id = auth.uid());

create policy "driver can read assigned deliveries"
on public.deliveries for select
using (driver_id = auth.uid());

create policy "restaurant can read its deliveries"
on public.deliveries for select
using (
  restaurant_id in (
    select restaurant_id
    from public.profiles
    where id = auth.uid()
      and role = 'restaurant'
  )
);

create index if not exists deliveries_status_created_at_idx
on public.deliveries (status, created_at desc);

create index if not exists deliveries_driver_status_idx
on public.deliveries (driver_id, status);

create index if not exists deliveries_restaurant_status_idx
on public.deliveries (restaurant_id, status);

create index if not exists delivery_status_events_delivery_id_created_at_idx
on public.delivery_status_events (delivery_id, created_at desc);
