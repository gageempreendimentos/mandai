CREATE TABLE public.rates_config (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  value_per_km numeric NOT NULL DEFAULT 0.0,
  min_time_minutes integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.rates_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for all users" ON public.rates_config FOR SELECT USING (true);