-- Ticket / tracking number prefix update for rebrand
-- New deliveries will receive GOOYY000001 style tickets

create or replace function public.generate_tracking_number()
returns text
language plpgsql
as $$
declare
  new_number text;
  year_suffix text;
  sequence_num int;
begin
  year_suffix := to_char(current_date, 'YY');
  select count(*) + 1 into sequence_num
  from public.deliveries
  where extract(year from created_at) = extract(year from current_date);

  new_number := 'GOO' || year_suffix || lpad(sequence_num::text, 6, '0');
  return new_number;
end;
$$;
