CREATE TABLE public.peak_hours (
  id uuid DEFAULT uuid_generate_v4() PRIMARY KEY,
  day_of_week text NOT NULL, -- e.g., 'monday', 'tuesday', 'all'
  start_time time NOT NULL,
  end_time time NOT NULL,
  multiplier numeric NOT NULL DEFAULT 1.0,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE public.peak_hours ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for all users" ON public.peak_hours FOR SELECT USING (true);