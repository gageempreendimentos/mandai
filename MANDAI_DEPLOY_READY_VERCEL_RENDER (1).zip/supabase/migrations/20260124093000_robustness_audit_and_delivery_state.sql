-- Robustez: auditoria, transições de status, timestamps e índices

-- 1) Audit logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id UUID,
  meta JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Apenas admin pode ler
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
    -- ok
  END IF;
END$$;

CREATE POLICY IF NOT EXISTS "Admin lê audit logs" ON public.audit_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Service role / backend pode inserir. (Clientes não inserem diretamente via RLS; via Edge Function/Service Role)
CREATE POLICY IF NOT EXISTS "Permitir insert audit logs autenticado" ON public.audit_logs
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- 2) Timestamps e estado de entregas (deliveries)
ALTER TABLE public.deliveries
  ADD COLUMN IF NOT EXISTS assigned_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS accepted_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS picked_up_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS in_transit_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS updated_by UUID;

-- Função para validar transições de status
CREATE OR REPLACE FUNCTION public.validate_delivery_status_transition(old_status public.delivery_status, new_status public.delivery_status)
RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
BEGIN
  IF old_status = new_status THEN
    RETURN TRUE;
  END IF;

  -- Permitir cancelamento a partir de qualquer estado não final
  IF new_status = 'cancelled' THEN
    IF old_status IN ('delivered', 'not_delivered') THEN
      RETURN FALSE;
    END IF;
    RETURN TRUE;
  END IF;

  -- Fluxo principal
  IF old_status = 'pending' AND new_status IN ('picked_up', 'in_transit') THEN
    RETURN TRUE;
  ELSIF old_status = 'picked_up' AND new_status = 'in_transit' THEN
    RETURN TRUE;
  ELSIF old_status = 'in_transit' AND new_status IN ('delivered','not_delivered') THEN
    RETURN TRUE;
  END IF;

  RETURN FALSE;
END;
$$;

-- Trigger para timestamps + validação
CREATE OR REPLACE FUNCTION public.deliveries_before_update()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  -- valida transição
  IF NOT public.validate_delivery_status_transition(OLD.status, NEW.status) THEN
    RAISE EXCEPTION 'Invalid status transition: % -> %', OLD.status, NEW.status;
  END IF;

  -- timestamps automáticos
  IF OLD.driver_id IS DISTINCT FROM NEW.driver_id AND NEW.driver_id IS NOT NULL THEN
    NEW.assigned_at := COALESCE(OLD.assigned_at, now());
  END IF;

  IF OLD.status IS DISTINCT FROM NEW.status THEN
    IF NEW.status = 'picked_up' THEN
      NEW.picked_up_at := COALESCE(OLD.picked_up_at, now());
    ELSIF NEW.status = 'in_transit' THEN
      NEW.in_transit_at := COALESCE(OLD.in_transit_at, now());
    ELSIF NEW.status = 'delivered' THEN
      NEW.delivered_at := COALESCE(OLD.delivered_at, now());
    ELSIF NEW.status = 'cancelled' THEN
      NEW.cancelled_at := COALESCE(OLD.cancelled_at, now());
    END IF;
  END IF;

  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_deliveries_before_update ON public.deliveries;
CREATE TRIGGER trg_deliveries_before_update
BEFORE UPDATE ON public.deliveries
FOR EACH ROW
EXECUTE FUNCTION public.deliveries_before_update();

-- 3) Índices para performance
CREATE INDEX IF NOT EXISTS idx_deliveries_status_created_at ON public.deliveries(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_deliveries_driver_status ON public.deliveries(driver_id, status);
CREATE INDEX IF NOT EXISTS idx_notifications_driver_created_at ON public.notifications(driver_id, created_at DESC);

-- 4) Feature flags (controle de funcionalidades)
CREATE TABLE IF NOT EXISTS public.feature_flags (
  key TEXT PRIMARY KEY,
  enabled BOOLEAN NOT NULL DEFAULT false,
  description TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;

-- leitura para usuários autenticados
CREATE POLICY IF NOT EXISTS "Usuários autenticados leem feature flags" ON public.feature_flags
  FOR SELECT USING (auth.role() = 'authenticated');

-- apenas admin altera
CREATE POLICY IF NOT EXISTS "Admin altera feature flags" ON public.feature_flags
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = 'admin')
  );
