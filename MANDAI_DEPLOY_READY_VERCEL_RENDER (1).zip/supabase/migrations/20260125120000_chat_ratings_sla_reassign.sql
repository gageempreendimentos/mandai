-- Chat, ratings, SLA deadlines, and admin reassignment support
-- Generated: 2026-01-25

-- Participants table links a delivery to users (client/restaurant/driver/admin/support)
create table if not exists public.delivery_participants (
  delivery_id uuid not null references public.deliveries(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('client','restaurant','driver','admin','support')),
  created_at timestamptz not null default now(),
  primary key (delivery_id, user_id)
);

alter table public.delivery_participants enable row level security;

-- Helper: is admin
create or replace function public.is_admin(uid uuid)
returns boolean
language sql stable
as $$
  select exists (
    select 1 from public.user_roles ur
    where ur.user_id = uid and ur.role = 'admin'
  );
$$;

-- Allow admins full access
create policy if not exists "delivery_participants_admin_all"
  on public.delivery_participants
  for all
  using (public.is_admin(auth.uid()))
  with check (public.is_admin(auth.uid()));

-- Allow user to read their own participation rows
create policy if not exists "delivery_participants_read_self"
  on public.delivery_participants
  for select
  using (user_id = auth.uid());

-- Chat messages
create table if not exists public.delivery_messages (
  id uuid primary key default gen_random_uuid(),
  delivery_id uuid not null references public.deliveries(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  sender_role text not null,
  message text not null check (char_length(message) <= 2000),
  created_at timestamptz not null default now()
);

alter table public.delivery_messages enable row level security;

create policy if not exists "delivery_messages_read_participants"
  on public.delivery_messages
  for select
  using (
    public.is_admin(auth.uid())
    or exists (
      select 1 from public.delivery_participants p
      where p.delivery_id = delivery_messages.delivery_id
        and p.user_id = auth.uid()
    )
  );

create policy if not exists "delivery_messages_insert_participants"
  on public.delivery_messages
  for insert
  with check (
    sender_id = auth.uid()
    and (
      public.is_admin(auth.uid())
      or exists (
        select 1 from public.delivery_participants p
        where p.delivery_id = delivery_messages.delivery_id
          and p.user_id = auth.uid()
      )
    )
  );

create index if not exists delivery_messages_delivery_id_created_at_idx
  on public.delivery_messages(delivery_id, created_at);

-- Driver ratings
create table if not exists public.driver_ratings (
  id uuid primary key default gen_random_uuid(),
  delivery_id uuid not null references public.deliveries(id) on delete cascade,
  driver_id uuid not null references auth.users(id) on delete cascade,
  rater_id uuid not null references auth.users(id) on delete cascade,
  rater_role text not null check (rater_role in ('client','restaurant')),
  rating int not null check (rating between 1 and 5),
  comment text null check (comment is null or char_length(comment) <= 500),
  created_at timestamptz not null default now(),
  unique (delivery_id, rater_id)
);

alter table public.driver_ratings enable row level security;

create policy if not exists "driver_ratings_read_admin_driver"
  on public.driver_ratings
  for select
  using (
    public.is_admin(auth.uid())
    or driver_id = auth.uid()
    or rater_id = auth.uid()
  );

create policy if not exists "driver_ratings_insert_participants"
  on public.driver_ratings
  for insert
  with check (
    rater_id = auth.uid()
    and exists (
      select 1 from public.deliveries d
      where d.id = driver_ratings.delivery_id
        and d.driver_id = driver_ratings.driver_id
        and d.status = 'delivered'
    )
    and exists (
      select 1 from public.delivery_participants p
      where p.delivery_id = driver_ratings.delivery_id
        and p.user_id = auth.uid()
        and p.role in ('client','restaurant')
    )
  );

create index if not exists driver_ratings_driver_id_created_at_idx
  on public.driver_ratings(driver_id, created_at);

-- Rating summary view
create or replace view public.driver_rating_summary as
select
  driver_id,
  count(*)::int as ratings_count,
  round(avg(rating)::numeric, 2) as average_rating
from public.driver_ratings
group by driver_id;

-- SLA columns on deliveries
alter table public.deliveries
  add column if not exists accept_deadline timestamptz,
  add column if not exists pickup_deadline timestamptz,
  add column if not exists delivery_deadline timestamptz,
  add column if not exists late_stage text;

-- Set SLA deadlines on insert if missing
create or replace function public.set_delivery_sla_deadlines()
returns trigger
language plpgsql
as $$
begin
  if new.accept_deadline is null then
    new.accept_deadline := coalesce(new.created_at, now()) + interval '2 minutes';
  end if;
  if new.pickup_deadline is null then
    new.pickup_deadline := coalesce(new.created_at, now()) + interval '30 minutes';
  end if;
  if new.delivery_deadline is null then
    new.delivery_deadline := coalesce(new.created_at, now()) + interval '90 minutes';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_set_delivery_sla_deadlines on public.deliveries;
create trigger trg_set_delivery_sla_deadlines
before insert on public.deliveries
for each row execute function public.set_delivery_sla_deadlines();

-- Keep participants table updated when driver_id changes (best effort)
create or replace function public.sync_delivery_driver_participant()
returns trigger
language plpgsql
as $$
begin
  if new.driver_id is not null then
    insert into public.delivery_participants (delivery_id, user_id, role)
    values (new.id, new.driver_id, 'driver')
    on conflict (delivery_id, user_id) do update set role = 'driver';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_sync_delivery_driver_participant on public.deliveries;
create trigger trg_sync_delivery_driver_participant
after insert or update of driver_id on public.deliveries
for each row execute function public.sync_delivery_driver_participant();
