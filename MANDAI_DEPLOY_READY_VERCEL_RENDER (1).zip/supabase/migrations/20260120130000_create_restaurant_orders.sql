-- Tabela de pedidos do restaurante
CREATE TABLE restaurant_orders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  order_number TEXT NOT NULL UNIQUE,
  restaurant_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  delivery_address TEXT NOT NULL,
  items TEXT NOT NULL,
  total_value NUMERIC(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  delivery_id UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- RLS Policies para restaurant_orders
ALTER TABLE restaurant_orders ENABLE ROW LEVEL SECURITY;

-- Restaurantes podem ver seus próprios pedidos
CREATE POLICY "Restaurantes veem seus pedidos" ON restaurant_orders
  FOR SELECT USING (restaurant_id = auth.uid());

-- Restaurantes podem inserir seus pedidos
CREATE POLICY "Restaurantes inserem seus pedidos" ON restaurant_orders
  FOR INSERT WITH CHECK (restaurant_id = auth.uid());

-- Restaurantes podem atualizar seus pedidos
CREATE POLICY "Restaurantes atualizam seus pedidos" ON restaurant_orders
  FOR UPDATE USING (restaurant_id = auth.uid());

-- Admin pode ver todos os pedidos
CREATE POLICY "Admin vê todos os pedidos" ON restaurant_orders
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Função para gerar número de pedido único
CREATE OR REPLACE FUNCTION generate_restaurant_order_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.order_number := 'R' || LPAD(EXTRACT(EPOCH FROM NOW())::BIGINT::TEXT, 6, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_generate_restaurant_order_number
  BEFORE INSERT ON restaurant_orders
  FOR EACH ROW
  EXECUTE FUNCTION generate_restaurant_order_number();

-- Adicionar role de restaurante ao enum
ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'restaurant';