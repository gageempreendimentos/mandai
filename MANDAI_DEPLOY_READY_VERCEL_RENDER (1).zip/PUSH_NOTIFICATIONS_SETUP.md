# Push Notifications (Offline) – Setup

O projeto já salva o token do Firebase (FCM) em `profiles.push_token`.
Para funcionar **offline / app fechado**, você precisa configurar **2 coisas**:

## 1) Variáveis do Firebase (VITE_FIREBASE_*)
Crie/edite um `.env` e adicione:

- `VITE_FIREBASE_API_KEY=...`
- `VITE_FIREBASE_AUTH_DOMAIN=...`
- `VITE_FIREBASE_PROJECT_ID=...`
- `VITE_FIREBASE_STORAGE_BUCKET=...`
- `VITE_FIREBASE_MESSAGING_SENDER_ID=...`
- `VITE_FIREBASE_APP_ID=...`

> Ao rodar `npm run dev` ou `npm run build`, o script
> `scripts/generate-firebase-sw.cjs` vai gerar automaticamente:
> `public/firebase-messaging-sw.js` com a config correta.

## 2) Envio de push pelo backend (Supabase Edge Function)
Foi adicionada a Edge Function:

- `supabase/functions/send-push`

Ela usa:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `FCM_SERVER_KEY` (Firebase **Legacy server key**)

No Supabase, configure as env vars da function e faça deploy.

## Tela no Admin
A tela escondida:

- `/admin/drivers/message`

Permite escolher um entregador e enviar uma mensagem.
**Offline** funciona quando o entregador tem `push_token` salvo.

## Dica de Debug
Se o entregador não receber:
1. Verifique se ele aceitou permissão de notificação.
2. Confirme que `profiles.push_token` não está NULL.
3. Confirme se `public/firebase-messaging-sw.js` foi gerado (não pode ser "placeholder").
4. Confira os logs em `/admin/logs`.
