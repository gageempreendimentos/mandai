# WebSocket (servidor próprio) — como rodar

## 1) Rodar servidor WebSocket/API
```bash
cd server
npm install
npm run dev
```

Servidor: http://localhost:8787
WebSocket: ws://localhost:8787

## 2) Rodar o Frontend (Vite)
Em outro terminal:
```bash
cd ..
npm install
npm run dev
```

## Variável opcional
Crie um `.env` na raiz (opcional) se quiser apontar para outro servidor:
```
VITE_WS_URL=ws://SEU_IP:8787
```

## Teste em tempo real
Abra 3 abas:
- http://localhost:5173/driver
- http://localhost:5173/client
- http://localhost:5173/admin

Clique em Aceitar / Iniciar rota / Finalizar no Driver e veja Client/Admin atualizarem na hora.


## Autenticação (token) + rooms

O client agora conecta com `?token=...&role=...&userId=...` (gerado no login local).

No server, você pode fixar tokens por área via env:
- `DRIVER_TOKEN`
- `CLIENT_TOKEN`
- `ADMIN_TOKEN`
- `RESTAURANT_TOKEN`

Rooms suportadas:
- `user:<userId>`
- `role:<role>`
- `ride:<rideId>`

Mensagens: `SUBSCRIBE { rooms: [...] }`, `UNSUBSCRIBE { rooms: [...] }`.
