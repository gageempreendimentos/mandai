#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   export DATABASE_URL="postgres://user:pass@host:5432/db"
#   ./scripts/backup_db.sh
#
# Requires: pg_dump

TS=$(date +"%Y%m%d_%H%M%S")
OUT="backups/db_${TS}.dump"
mkdir -p backups

pg_dump --format=custom --no-owner --no-privileges "$DATABASE_URL" > "$OUT"
echo "Backup saved to $OUT"
