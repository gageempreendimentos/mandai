## MANDAI – Entregador Premium (Dyad)

### Dyad – erro de contexto (maximum context length)

Se o Dyad tentar enviar **todos** os arquivos do projeto para a IA, pode estourar o limite de contexto.

Este repositório já vem com um **.dyadignore** que reduz bastante o contexto, ignorando:
- `node_modules`, `dist`, caches e arquivos de build
- **assets/binaries** (imagens, ícones etc.)
- arquivo gerado grande: `src/integrations/supabase/types.ts`

Se ainda aparecer o erro, uma alternativa é:
- Abrir/selecionar apenas a pasta/arquivo que você quer analisar
- Ou ajustar o `.dyadignore` temporariamente (remover regras só do que você precisa)


## Rotas no Dyad
Este projeto usa **HashRouter** para que todas as rotas funcionem no preview do Dyad. Exemplos:
- `#/telas`
- `#/admin/login`
- `#/restaurant-login`
- `#/client-login`
