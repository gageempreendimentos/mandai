create extension if not exists "uuid-ossp";

do $$ begin
  if not exists (select 1 from pg_type where typname = 'user_role') then
    create type user_role as enum ('admin','driver','client','restaurant');
  end if;
  if not exists (select 1 from pg_type where typname = 'ride_status') then
    create type ride_status as enum (
      'created','preparing','assigned','accepted',
      'enroute_pickup','picked_up','enroute_dropoff',
      'completed','canceled'
    );
  end if;
end $$;

create table if not exists restaurants (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  is_open boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists users (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  email text unique,
  phone text unique,
  role user_role not null,
  restaurant_id uuid references restaurants(id),
  password_hash text not null,
  created_at timestamptz not null default now()
);

create table if not exists rides (
  id uuid primary key default uuid_generate_v4(),
  client_id uuid not null references users(id),
  restaurant_id uuid not null references restaurants(id),
  driver_id uuid references users(id),
  status ride_status not null default 'created',

  pickup_address text,
  dropoff_address text,
  pickup_lat double precision,
  pickup_lng double precision,
  dropoff_lat double precision,
  dropoff_lng double precision,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  assigned_at timestamptz,
  accepted_at timestamptz,
  picked_up_at timestamptz,
  completed_at timestamptz,
  canceled_at timestamptz,
  canceled_reason text
);

create index if not exists rides_status_created_at_idx on rides(status, created_at desc);
create index if not exists rides_driver_status_idx on rides(driver_id, status);
create index if not exists rides_restaurant_status_idx on rides(restaurant_id, status);

create table if not exists ride_events (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  type text not null,
  actor_user_id uuid references users(id),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists ride_events_ride_id_created_at_idx on ride_events(ride_id, created_at desc);

create table if not exists driver_locations (
  driver_id uuid primary key references users(id) on delete cascade,
  lat double precision not null,
  lng double precision not null,
  heading double precision,
  speed double precision,
  updated_at timestamptz not null default now()
);

create index if not exists driver_locations_updated_at_idx on driver_locations(updated_at desc);

create table if not exists ride_messages (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  sender_user_id uuid not null references users(id),
  message text not null,
  created_at timestamptz not null default now()
);

create index if not exists ride_messages_ride_id_created_at_idx on ride_messages(ride_id, created_at);

create table if not exists auth_refresh_tokens (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  token text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  revoked_at timestamptz
);

create index if not exists auth_refresh_tokens_user_id_idx on auth_refresh_tokens(user_id);
create index if not exists auth_refresh_tokens_token_idx on auth_refresh_tokens(token);


create table if not exists idempotency_keys (
  idem_key text not null,
  user_id uuid,
  route text not null,
  method text not null,
  status_code int not null,
  response_body jsonb not null,
  created_at timestamptz not null default now(),
  primary key (idem_key, route)
);

create index if not exists idempotency_keys_user_id_idx on idempotency_keys(user_id);


create table if not exists cities (
  id bigserial primary key,
  name text not null unique,
  state text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists zones (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  city text,
  polygon jsonb,
  created_at timestamptz not null default now()
);

create table if not exists user_zones (
  user_id uuid not null references users(id) on delete cascade,
  zone_id uuid not null references zones(id) on delete cascade,
  primary key (user_id, zone_id)
);

create index if not exists user_zones_zone_id_idx on user_zones(zone_id);


alter table rides add column if not exists pod_url text;
alter table rides add column if not exists pod_note text;
alter table rides add column if not exists pod_created_at timestamptz;


-- Driver status / deadman
alter table users add column if not exists is_disabled boolean not null default false;

alter table driver_locations add column if not exists is_online boolean not null default true;
alter table driver_locations add column if not exists last_ping_at timestamptz not null default now();
alter table driver_locations add column if not exists last_archive_at timestamptz;

-- Ride location history (replay)
create table if not exists ride_location_points (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  driver_id uuid not null references users(id) on delete cascade,
  lat double precision not null,
  lng double precision not null,
  heading double precision,
  speed double precision,
  created_at timestamptz not null default now()
);
create index if not exists ride_location_points_ride_id_created_at_idx on ride_location_points(ride_id, created_at desc);

-- Notification templates + outbox
create table if not exists notification_templates (
  key text primary key,
  title text not null,
  body text not null,
  channel text not null default 'ws',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists notifications_outbox (
  id bigserial primary key,
  target_kind text not null, -- user|role|zone|all_drivers|all
  target_value text,
  title text not null,
  body text not null,
  channel text not null default 'ws',
  status text not null default 'pending', -- pending|sent|failed
  error text,
  created_at timestamptz not null default now(),
  sent_at timestamptz
);
create index if not exists notifications_outbox_status_created_at_idx on notifications_outbox(status, created_at);

-- Optional: zone on rides for dispatch routing
alter table rides add column if not exists zone_id uuid references zones(id);


-- Device tokens (FCM)
create table if not exists device_tokens (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  token text not null,
  platform text,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  unique(user_id, token)
);
create index if not exists device_tokens_user_id_idx on device_tokens(user_id);


-- Driver score for dispatch priority
alter table users add column if not exists driver_score double precision not null default 5.0;


-- Offer/refusal history (cooldown)
create table if not exists driver_offer_history (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  driver_id uuid not null references users(id) on delete cascade,
  action text not null, -- offered|refused|accepted|timeout
  created_at timestamptz not null default now()
);
create index if not exists driver_offer_history_driver_id_created_at_idx on driver_offer_history(driver_id, created_at desc);
create index if not exists driver_offer_history_ride_driver_idx on driver_offer_history(ride_id, driver_id);


-- RBAC / Permissions
create table if not exists permissions (
  key text primary key,
  description text
);

create table if not exists role_permissions (
  role user_role not null,
  permission_key text not null references permissions(key) on delete cascade,
  primary key (role, permission_key)
);

create table if not exists user_permissions (
  user_id uuid not null references users(id) on delete cascade,
  permission_key text not null references permissions(key) on delete cascade,
  allowed boolean not null default true,
  primary key (user_id, permission_key)
);

-- System state / Crisis mode
create table if not exists system_state (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

-- Audit log (append-only)
create table if not exists audit_log (
  id bigserial primary key,
  actor_user_id uuid references users(id),
  action text not null,
  entity_type text,
  entity_id text,
  ip text,
  user_agent text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_log_created_at_idx on audit_log(created_at desc);
create index if not exists audit_log_actor_idx on audit_log(actor_user_id, created_at desc);

-- Feature flags
create table if not exists feature_flags (
  key text not null,
  scope_kind text not null default 'global', -- global|zone|user|role
  scope_value text,
  enabled boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (key, scope_kind, scope_value)
);

-- Chat improvements: read receipts + attachments
create table if not exists ride_message_reads (
  message_id bigint not null references ride_messages(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (message_id, user_id)
);

alter table ride_messages add column if not exists attachment_url text;
alter table ride_messages add column if not exists attachment_type text;

-- ETA fields
alter table rides add column if not exists eta_seconds int;
alter table rides add column if not exists eta_updated_at timestamptz;
alter table rides add column if not exists is_at_risk boolean not null default false;

-- Reports
create table if not exists generated_reports (
  id bigserial primary key,
  kind text not null, -- daily|weekly|monthly
  period_start date,
  period_end date,
  file_url text not null,
  created_at timestamptz not null default now()
);


-- Dynamic pricing
create table if not exists pricing_rules (
  id bigserial primary key,
  zone_id uuid references zones(id),
  name text not null default 'default',
  base_fee_cents int not null default 500,
  per_km_cents int not null default 250,
  per_min_cents int not null default 0,
  min_fee_cents int not null default 800,
  max_fee_cents int,
  surge_multiplier numeric(6,3) not null default 1.0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists pricing_rules_zone_active_idx on pricing_rules(zone_id, active);

-- Fare snapshot per ride
alter table rides add column if not exists fare_cents int;
alter table rides add column if not exists fare_breakdown jsonb;
alter table rides add column if not exists distance_km numeric(10,3);
alter table rides add column if not exists duration_min numeric(10,3);

-- Fraud signals
create table if not exists fraud_flags (
  id bigserial primary key,
  ride_id uuid references rides(id) on delete cascade,
  driver_id uuid references users(id) on delete set null,
  kind text not null, -- gps_teleport|pod_outside_geofence|speed_anomaly|...
  severity int not null default 1, -- 1..5
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  resolved boolean not null default false,
  resolved_at timestamptz
);
create index if not exists fraud_flags_ride_idx on fraud_flags(ride_id, created_at desc);
create index if not exists fraud_flags_resolved_idx on fraud_flags(resolved, created_at desc);


-- Driver duty + metrics (acceptance/latency)
alter table users add column if not exists on_duty boolean not null default true;

create table if not exists driver_metrics (
  driver_id uuid primary key references users(id) on delete cascade,
  offers int not null default 0,
  accepts int not null default 0,
  refuses int not null default 0,
  avg_accept_seconds numeric(10,2) not null default 0,
  acceptance_rate numeric(6,3) not null default 0,
  updated_at timestamptz not null default now()
);

-- Financial score / wallet ledger
create table if not exists wallet_ledger (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  kind text not null, -- fare|bonus|penalty
  amount_cents int not null,
  ride_id uuid references rides(id) on delete set null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists wallet_ledger_user_created_idx on wallet_ledger(user_id, created_at desc);

create table if not exists driver_finance_metrics (
  driver_id uuid primary key references users(id) on delete cascade,
  earned_cents_7d bigint not null default 0,
  rides_7d int not null default 0,
  km_7d numeric(12,3) not null default 0,
  hours_7d numeric(12,3) not null default 0,
  score numeric(8,3) not null default 0,
  updated_at timestamptz not null default now()
);

-- Batch deliveries
create table if not exists ride_batches (
  id uuid primary key,
  driver_id uuid references users(id) on delete set null,
  status text not null default 'open', -- open|assigned|in_progress|completed
  created_at timestamptz not null default now()
);
alter table rides add column if not exists batch_id uuid references ride_batches(id);
alter table rides add column if not exists batch_order int;

-- Campaigns / incentives
create table if not exists campaigns (
  id bigserial primary key,
  name text not null,
  zone_id uuid references zones(id),
  start_at timestamptz not null,
  end_at timestamptz not null,
  target_rides int not null default 0,
  bonus_cents int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists campaign_claims (
  id bigserial primary key,
  campaign_id bigint not null references campaigns(id) on delete cascade,
  driver_id uuid not null references users(id) on delete cascade,
  claimed boolean not null default false,
  claimed_at timestamptz,
  progress int not null default 0,
  unique(campaign_id, driver_id)
);

-- SLA rules + penalties/bonuses
create table if not exists sla_rules (
  id bigserial primary key,
  zone_id uuid references zones(id),
  max_minutes int not null default 45,
  penalty_cents int not null default 200,
  bonus_cents int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);


-- Demand forecast (MVP)
create table if not exists demand_forecast (
  id bigserial primary key,
  zone_id uuid references zones(id),
  dow int not null, -- 0=Sun..6=Sat
  hour int not null, -- 0..23
  expected_orders numeric(10,2) not null default 0,
  expected_active_drivers numeric(10,2) not null default 0,
  risk_level int not null default 0, -- 0 ok, 1 warn, 2 high
  computed_at timestamptz not null default now(),
  unique(zone_id, dow, hour)
);
create index if not exists demand_forecast_zone_idx on demand_forecast(zone_id, dow, hour);


-- PIX withdraw (MVP simulated)
create table if not exists withdraw_requests (
  id bigserial primary key,
  driver_id uuid not null references users(id) on delete cascade,
  amount_cents int not null,
  pix_key text not null,
  status text not null default 'pending', -- pending|paid|rejected
  provider_ref text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists withdraw_requests_driver_idx on withdraw_requests(driver_id, created_at desc);


-- Support tickets
create table if not exists support_tickets (
  id bigserial primary key,
  created_by uuid references users(id) on delete set null,
  role text,
  subject text not null,
  message text not null,
  status text not null default 'open', -- open|in_progress|resolved|closed
  priority int not null default 2, -- 1 high, 2 normal, 3 low
  ride_id uuid references rides(id) on delete set null,
  attachments jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists support_tickets_status_idx on support_tickets(status, updated_at desc);

-- Ops settings (pause zones, etc.)
create table if not exists ops_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- Restaurant quality metrics
create table if not exists restaurant_quality_metrics (
  restaurant_id uuid primary key references restaurants(id) on delete cascade,
  avg_prep_minutes numeric(10,2) not null default 0,
  cancel_rate numeric(6,3) not null default 0,
  rating_avg numeric(6,3) not null default 0,
  orders_7d int not null default 0,
  updated_at timestamptz not null default now()
);

-- Scheduled orders
alter table rides add column if not exists scheduled_for timestamptz;
alter table rides add column if not exists schedule_status text not null default 'none'; -- none|scheduled|released
create index if not exists rides_scheduled_idx on rides(schedule_status, scheduled_for);

-- Zone policies (forbidden / premium)
create table if not exists zone_policies (
  id bigserial primary key,
  zone_id uuid references zones(id) on delete cascade,
  kind text not null, -- forbidden|premium
  payload jsonb not null default '{}'::jsonb, -- { multiplier: 1.2 } etc
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists zone_policies_zone_idx on zone_policies(zone_id, kind, active);


-- Terms & Privacy versions
create table if not exists terms_versions (
  id bigserial primary key,
  doc_type text not null, -- terms|privacy|driver_contract|restaurant_contract
  version text not null,
  title text not null,
  content_md text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(doc_type, version)
);

create table if not exists user_terms_acceptance (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  doc_type text not null,
  version text not null,
  accepted_at timestamptz not null default now(),
  ip text,
  user_agent text,
  unique(user_id, doc_type, version)
);

-- Onboarding progress
alter table users add column if not exists onboarding_step int not null default 0;
alter table users add column if not exists onboarding_done boolean not null default false;


-- Driver vehicle + capacity
alter table drivers add column if not exists vehicle_type text not null default 'moto'; -- moto|carro|van|caminhao
alter table drivers add column if not exists capacity_kg int not null default 20;
alter table drivers add column if not exists capacity_volume text not null default 'P'; -- P|M|G
create index if not exists drivers_vehicle_idx on drivers(vehicle_type, online);

-- Ride kind
alter table rides add column if not exists kind text not null default 'delivery'; -- delivery|freight
create index if not exists rides_kind_idx on rides(kind, status, created_at desc);

-- Freight details
create table if not exists freight_details (
  ride_id uuid primary key references rides(id) on delete cascade,
  cargo_type text,
  weight_kg int,
  helpers_needed int not null default 0,
  stairs boolean not null default false,
  notes text
);

-- Freight bids (option C: auto quote + bidding)
create table if not exists freight_bids (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  driver_id uuid not null references drivers(id) on delete cascade,
  bid_cents int not null,
  status text not null default 'pending', -- pending|accepted|rejected|expired
  created_at timestamptz not null default now(),
  unique(ride_id, driver_id)
);
create index if not exists freight_bids_ride_idx on freight_bids(ride_id, status, created_at desc);

-- Anti-abuse / penalties
create table if not exists driver_penalties (
  id bigserial primary key,
  driver_id uuid not null references drivers(id) on delete cascade,
  kind text not null, -- cancel_spam|offline_on_job|refusal_spam|fraud
  points int not null default 1,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists driver_penalties_driver_idx on driver_penalties(driver_id, created_at desc);

alter table drivers add column if not exists cooldown_until timestamptz;
alter table drivers add column if not exists refusal_count int not null default 0;
alter table drivers add column if not exists cancel_count_24h int not null default 0;


-- Freight chat (text + optional image_url)
create table if not exists freight_chat_messages (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  sender_user_id uuid not null references users(id) on delete cascade,
  sender_role text not null,
  message text,
  image_url text,
  created_at timestamptz not null default now()
);
create index if not exists freight_chat_ride_idx on freight_chat_messages(ride_id, created_at desc);


-- Multi-stops for freight (up to N)
create table if not exists freight_stops (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  stop_order int not null,
  address text,
  lat double precision,
  lng double precision,
  notes text,
  unique(ride_id, stop_order)
);
create index if not exists freight_stops_ride_idx on freight_stops(ride_id, stop_order);


-- Freight options / extras (monetization)
alter table freight_details add column if not exists wait_minutes int not null default 0;
alter table freight_details add column if not exists insurance boolean not null default false;
alter table freight_details add column if not exists priority boolean not null default false;
alter table freight_details add column if not exists fragile boolean not null default false;
alter table freight_details add column if not exists declared_value_cents int not null default 0;

-- Scheduling windows
alter table rides add column if not exists pickup_window_start timestamptz;
alter table rides add column if not exists pickup_window_end timestamptz;


-- Proof of delivery for freight
create table if not exists freight_pod (
  ride_id uuid primary key references rides(id) on delete cascade,
  delivered_at timestamptz,
  receiver_name text,
  signature_svg text,
  photo_url text,
  notes text
);


-- Freight disputes
create table if not exists freight_disputes (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  opened_by_user_id uuid not null references users(id) on delete cascade,
  reason text not null,
  details text,
  status text not null default 'open', -- open|resolved|rejected
  resolution text,
  created_at timestamptz not null default now()
);
create index if not exists freight_disputes_ride_idx on freight_disputes(ride_id, status, created_at desc);


-- Vehicle/zone rules for freight
create table if not exists freight_vehicle_rules (
  id bigserial primary key,
  zone_id bigint,
  vehicle_type text not null, -- carro|van|caminhao
  allowed boolean not null default true,
  min_cents_per_km int not null default 200,
  max_cents_per_km int not null default 1200,
  min_fare_cents int not null default 1500,
  created_at timestamptz not null default now()
);
create index if not exists freight_vehicle_rules_zone_idx on freight_vehicle_rules(zone_id, vehicle_type);


-- Cancellation fee
alter table rides add column if not exists cancel_fee_cents int not null default 0;
alter table rides add column if not exists cancel_reason text;


-- Bid expiry for auction
alter table freight_bids add column if not exists expires_at timestamptz;
create index if not exists freight_bids_expires_idx on freight_bids(ride_id, status, expires_at);


-- Uploads (local/S3)
create table if not exists uploads (
  id bigserial primary key,
  user_id uuid not null references users(id) on delete cascade,
  kind text not null, -- chat|pod|checklist
  url text not null,
  created_at timestamptz not null default now()
);
create index if not exists uploads_user_idx on uploads(user_id, created_at desc);


create table if not exists driver_last_location (
  driver_id uuid primary key references drivers(id) on delete cascade,
  lat double precision,
  lng double precision,
  updated_at timestamptz not null default now()
);


-- B2B Companies
create table if not exists companies (
  id bigserial primary key,
  name text not null,
  document text, -- CNPJ/CPF optional
  billing_email text,
  created_at timestamptz not null default now()
);

create table if not exists company_users (
  company_id bigint not null references companies(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  role text not null default 'member', -- owner|finance|member
  created_at timestamptz not null default now(),
  primary key(company_id, user_id)
);

create table if not exists company_cost_centers (
  id bigserial primary key,
  company_id bigint not null references companies(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now()
);

alter table rides add column if not exists company_id bigint references companies(id);
alter table rides add column if not exists cost_center_id bigint references company_cost_centers(id);

create table if not exists company_invoices (
  id bigserial primary key,
  company_id bigint not null references companies(id) on delete cascade,
  period_start date not null,
  period_end date not null,
  total_cents int not null default 0,
  status text not null default 'open', -- open|issued|paid
  created_at timestamptz not null default now(),
  unique(company_id, period_start, period_end)
);


-- Pickup checklist (photos + confirmations)
create table if not exists freight_pickup_checklist (
  ride_id uuid primary key references rides(id) on delete cascade,
  confirmed_items boolean not null default false,
  confirmed_weight boolean not null default false,
  photo_url text,
  notes text,
  created_at timestamptz not null default now()
);


-- Payments (optional table - events already store status)
create table if not exists payments (
  id bigserial primary key,
  ride_id uuid not null references rides(id) on delete cascade,
  provider text not null,
  provider_payment_id text,
  status text not null default 'pending',
  amount_cents int not null,
  created_at timestamptz not null default now()
);
create index if not exists payments_ride_idx on payments(ride_id, created_at desc);


-- Driver push tokens (FCM)
create table if not exists driver_push_tokens (
  driver_id uuid not null references drivers(id) on delete cascade,
  token text not null,
  created_at timestamptz not null default now(),
  primary key(driver_id, token)
);


-- Company limits (optional)
create table if not exists company_limits (
  company_id bigint primary key references companies(id) on delete cascade,
  daily_limit_cents int,
  monthly_limit_cents int,
  created_at timestamptz not null default now()
);

-- Multi-city / service area prefs
alter table users add column if not exists preferred_city text;
alter table users add column if not exists service_radius_km int not null default 8;
alter table users add column if not exists current_city text;

create or replace view driver_ranking_view as
select
  u.id as driver_id,
  u.name,
  u.phone,
  u.preferred_city,
  u.driver_score,
  coalesce(dm.offers,0) as offers,
  coalesce(dm.accepts,0) as accepts,
  coalesce(dm.refuses,0) as refuses,
  coalesce(dm.acceptance_rate,0) as acceptance_rate,
  coalesce(df.earned_cents_7d,0) as earned_cents_7d,
  coalesce(df.rides_7d,0) as rides_7d,
  coalesce(df.score,0) as finance_score,
  (coalesce(u.driver_score,5.0) * 10.0)
  + (coalesce(dm.acceptance_rate,0) * 5.0)
  + (least(200, coalesce(df.rides_7d,0)) * 0.5)
  + (least(1000000, coalesce(df.earned_cents_7d,0)) / 100000.0)
  as composite_score
from users u
left join driver_metrics dm on dm.driver_id=u.id
left join driver_finance_metrics df on df.driver_id=u.id
where u.role='driver';
