-- Default Terms (base). Ajuste com advogado depois.
insert into terms_versions (doc_type, version, title, content_md, active)
values
('terms','v1','Termos de Uso','## Termos de Uso (Base)\n\nAo usar o MANDAI, você concorda com:\n\n- Uso adequado da plataforma\n- Responsabilidades do usuário\n- Limites de responsabilidade\n- Regras de cancelamento e conduta\n\n> Este texto é base e deve ser revisado por um advogado.', true)
on conflict do nothing;

insert into terms_versions (doc_type, version, title, content_md, active)
values
('privacy','v1','Política de Privacidade','## Política de Privacidade (Base)\n\nColetamos dados necessários para operar entregas (ex.: localização, contato, pedidos).\n\n- Finalidade: operação e segurança\n- Retenção: mínima necessária\n- Direitos: acesso e exclusão conforme LGPD\n\n> Este texto é base e deve ser revisado por um advogado.', true)
on conflict do nothing;
