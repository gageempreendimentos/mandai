insert into permissions (key, description) values
  ('admin.manage_users', 'Criar/editar usuários'),
  ('admin.manage_zones', 'Criar/editar zonas'),
  ('admin.manage_flags', 'Gerenciar feature flags'),
  ('admin.view_audit', 'Ver auditoria'),
  ('admin.send_notifications', 'Enviar notificações'),
  ('ride.reassign', 'Reatribuir corridas'),
  ('ride.force_complete', 'Forçar finalizar corrida'),
  ('report.generate', 'Gerar relatórios'),
  ('system.crisis_toggle', 'Ativar/desativar modo crise')
on conflict do nothing;

-- Default role permissions
-- Admin gets everything
insert into role_permissions (role, permission_key)
select 'admin', key from permissions
on conflict do nothing;

-- Restaurant basics (adjust as needed)
insert into role_permissions (role, permission_key) values
  ('restaurant','admin.send_notifications')
on conflict do nothing;

-- Drivers/clients typically none for admin perms

insert into permissions (key, description) values ('campaign.manage','Gerenciar campanhas') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','campaign.manage') on conflict do nothing;
insert into permissions (key, description) values ('pricing.manage','Gerenciar precificação') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','pricing.manage') on conflict do nothing;
insert into permissions (key, description) values ('batch.manage','Gerenciar batch') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','batch.manage') on conflict do nothing;
insert into permissions (key, description) values ('fraud.manage','Gerenciar fraude') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','fraud.manage') on conflict do nothing;
insert into permissions (key, description) values ('sla.manage','Gerenciar SLA') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','sla.manage') on conflict do nothing;

insert into permissions (key, description) values ('support.manage','Gerenciar tickets de suporte') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','support.manage') on conflict do nothing;
insert into permissions (key, description) values ('ops.manage','Gerenciar modo operação') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','ops.manage') on conflict do nothing;
insert into permissions (key, description) values ('zones.manage','Gerenciar políticas de zona') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','zones.manage') on conflict do nothing;
insert into permissions (key, description) values ('reports.export','Exportar relatórios') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','reports.export') on conflict do nothing;

insert into permissions (key, description) values ('terms.manage','Gerenciar termos/privacidade') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','terms.manage') on conflict do nothing;
insert into permissions (key, description) values ('onboarding.manage','Gerenciar onboarding') on conflict do nothing;
insert into role_permissions (role, permission_key) values ('admin','onboarding.manage') on conflict do nothing;