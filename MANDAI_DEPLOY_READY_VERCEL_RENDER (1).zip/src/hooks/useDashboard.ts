import { useState, useEffect, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Delivery {
  id: string;
  pickup_address: string;
  delivery_address: string;
  customer_name: string;
  value: number;
  status: string;
  driver_id: string | null;
  pickup_lat: number | null;
  pickup_lng: number | null;
  delivery_lat: number | null;
  delivery_lng: number | null;
  created_at: string;
  updated_at: string;
}

export type DeliveryStage = 
  | 'idle' 
  | 'pending' 
  | 'going_pickup' 
  | 'at_pickup' 
  | 'going_delivery' 
  | 'at_delivery' 
  | 'returning' 
  | 'at_return' 
  | 'completed';

export const useDashboard = () => {
  const [isOnline, setIsOnline] = useState(false);
  const [stage, setStage] = useState<DeliveryStage>('idle');
  const [currentDelivery, setCurrentDelivery] = useState<Delivery | null>(null);
  const [dailyEarnings, setDailyEarnings] = useState(0);
  const [deliveryCount, setDeliveryCount] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showNotDeliveredModal, setShowNotDeliveredModal] = useState(false);
  const [showEarnings, setShowEarnings] = useState(true);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Buscar entregas disponíveis
  const { data: availableDeliveries, isLoading: isLoadingDeliveries } = useQuery({
    queryKey: ['deliveries', 'available'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { data, error } = await supabase
        .from('deliveries')
        .select('*')
        .eq('status', 'pending')
        .is('driver_id', null)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Delivery[];
    },
    staleTime: 1000 * 60 * 2, // 2 minutos
  });

  // Buscar entregas do usuário
  const { data: userDeliveries } = useQuery({
    queryKey: ['deliveries', 'user'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { data, error } = await supabase
        .from('deliveries')
        .select('*')
        .eq('driver_id', user.id)
        .in('status', ['in_transit', 'not_delivered'])
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Delivery[];
    },
    staleTime: 1000 * 60 * 5, // 5 minutos
  });

  // Verificar se usuário já tem uma entrega ativa ao carregar
  useEffect(() => {
    if (userDeliveries && userDeliveries.length > 0) {
      const activeDelivery = userDeliveries[0];
      setCurrentDelivery(activeDelivery);
      
      switch (activeDelivery.status) {
        case 'in_transit':
          setStage('going_delivery');
          break;
        case 'not_delivered':
          setStage('returning');
          break;
        default:
          setStage('idle');
      }
    } else {
      setCurrentDelivery(null);
      setStage('idle');
    }
  }, [userDeliveries]);

  const updateDeliveryStatus = useCallback(async (deliveryId: string, status: 'pending' | 'in_transit' | 'delivered' | 'not_delivered' | 'cancelled') => {
    try {
      const { error } = await supabase
        .from('deliveries')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', deliveryId);

      if (error) throw error;
      
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      return true;
    } catch (error) {
      toast({
        title: "Erro ao atualizar entrega",
        description: "Não foi possível atualizar o status da entrega",
        variant: "destructive"
      });
      return false;
    }
  }, [queryClient, toast]);

  const handleToggleOnline = useCallback(() => {
    setIsOnline(prev => !prev);
    
    if (!isOnline) {
      toast({
        title: "Você está online!",
        description: "Aguardando entregas...",
      });
    } else {
      setStage('idle');
      setCurrentDelivery(null);
      toast({
        title: "Você está offline",
        description: "Descanse um pouco!",
      });
    }
  }, [isOnline, toast]);

  const handleAcceptDelivery = useCallback(async (delivery: Delivery) => {
    try {
      const { error } = await supabase
        .from('deliveries')
        .update({ 
          driver_id: (await supabase.auth.getUser()).data.user?.id,
          status: 'in_transit' as const,
          pickup_time: new Date().toISOString()
        })
        .eq('id', delivery.id);

      if (error) throw error;
      
      setCurrentDelivery(delivery);
      setStage('going_pickup');
      
      toast({
        title: "Entrega aceita!",
        description: "Escolha o app de navegação",
      });
      
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
    } catch (error) {
      toast({
        title: "Erro ao aceitar entrega",
        description: "Não foi possível aceitar a entrega",
        variant: "destructive"
      });
    }
  }, [queryClient, toast]);

  const handleRejectDelivery = useCallback(() => {
    setCurrentDelivery(null);
    setStage('idle');
    
    toast({
      title: "Entrega recusada",
      description: "Aguardando novas entregas...",
    });
  }, [toast]);

  const handleArrivedPickup = useCallback(() => {
    setStage('at_pickup');
    
    toast({
      title: "Você chegou!",
      description: "Retire o pedido e confirme",
    });
  }, [toast]);

  const handleConfirmPickup = useCallback(async () => {
    if (!currentDelivery) return;
    
    const success = await updateDeliveryStatus(currentDelivery.id, 'in_transit');
    if (success) {
      setStage('going_delivery');
      
      toast({
        title: "Retirada confirmada!",
        description: "Escolha o app de navegação para a entrega",
      });
    }
  }, [currentDelivery, updateDeliveryStatus, toast]);

  const handleArrivedDelivery = useCallback(() => {
    setStage('at_delivery');
    
    toast({
      title: "Você chegou!",
      description: "Entregue o pedido e confirme",
    });
  }, [toast]);

  const handleConfirmDelivery = useCallback(async (photo?: File) => {
    if (!currentDelivery) return;
    
    // Aqui você pode adicionar a lógica para upload de foto
    const success = await updateDeliveryStatus(currentDelivery.id, 'delivered');
    if (success) {
      setDailyEarnings(prev => prev + currentDelivery.value);
      setDeliveryCount(prev => prev + 1);
      setStage('completed');
      
      toast({
        title: "Entrega concluída! 🎉",
        description: `Você ganhou R$ ${currentDelivery.value.toFixed(2)}`,
      });
      
      setTimeout(() => {
        setCurrentDelivery(null);
        setStage('idle');
      }, 2000);
    }
  }, [currentDelivery, updateDeliveryStatus, toast]);

  const handleNotDelivered = useCallback(() => {
    setShowNotDeliveredModal(true);
  }, []);

  const handleConfirmNotDelivered = useCallback(async (reason: string) => {
    if (!currentDelivery) return;
    
    const success = await updateDeliveryStatus(currentDelivery.id, 'not_delivered');
    if (success) {
      setShowNotDeliveredModal(false);
      setStage('returning');
      
      toast({
        title: "Retorne à loja",
        description: `Motivo: ${reason}. Volte com a mercadoria.`,
        variant: "destructive",
      });
    }
  }, [currentDelivery, updateDeliveryStatus, toast]);

  const handleArrivedReturn = useCallback(() => {
    setStage('at_return');
    
    toast({
      title: "Você chegou!",
      description: "Devolva a mercadoria e confirme",
    });
  }, [toast]);

  const handleConfirmReturn = useCallback(async () => {
    if (!currentDelivery) return;
    
    const success = await updateDeliveryStatus(currentDelivery.id, 'cancelled');
    if (success) {
      setStage('idle');
      setCurrentDelivery(null);
      
      toast({
        title: "Mercadoria devolvida",
        description: "Pedido encerrado. Aguardando novas entregas...",
      });
    }
  }, [currentDelivery, updateDeliveryStatus, toast]);

  return {
    // Estados
    isOnline,
    stage,
    currentDelivery,
    dailyEarnings,
    deliveryCount,
    isMenuOpen,
    showNotDeliveredModal,
    showEarnings,
    availableDeliveries,
    isLoadingDeliveries,
    
    // Funções
    setIsOnline,
    setStage,
    setCurrentDelivery,
    setDailyEarnings,
    setDeliveryCount,
    setIsMenuOpen,
    setShowNotDeliveredModal,
    setShowEarnings,
    
    // Handlers
    handleToggleOnline,
    handleAcceptDelivery,
    handleRejectDelivery,
    handleArrivedPickup,
    handleConfirmPickup,
    handleArrivedDelivery,
    handleConfirmDelivery,
    handleNotDelivered,
    handleConfirmNotDelivered,
    handleArrivedReturn,
    handleConfirmReturn,
  };
};