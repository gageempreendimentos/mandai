import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type ConnectionStatus = 'checking' | 'connected' | 'error';

export const useConnectionStatus = () => {
  const [isSupabaseConnected, setIsSupabaseConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('checking');

  useEffect(() => {
    const checkConnection = async () => {
      try {
        const { error } = await supabase.from('profiles').select('id').limit(1);
        if (!error) {
          setIsSupabaseConnected(true);
          setConnectionStatus('connected');
          console.log('✅ Supabase conectado com sucesso!');
        } else {
          setIsSupabaseConnected(false);
          setConnectionStatus('error');
          console.error('❌ Erro de conexão Supabase:', error);
        }
      } catch (e) {
        setIsSupabaseConnected(false);
        setConnectionStatus('error');
        console.error('❌ Erro ao conectar Supabase:', e);
      }
    };

    checkConnection();
  }, []);

  return {
    isSupabaseConnected,
    connectionStatus,
  };
};