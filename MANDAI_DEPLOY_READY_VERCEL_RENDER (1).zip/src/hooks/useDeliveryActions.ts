import { useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { auditLog } from '@/lib/audit';
import { 
  useAcceptDeliveryReal, 
  useConfirmPickup, 
  useConfirmDelivery, 
  useNotDelivered, 
  useReturnDelivery 
} from '@/hooks/useRealDeliveries';
import { useAcceptBatch } from '@/hooks/useBatchDeliveries';
import type { DeliveryStage } from './useDeliveryStage';

interface UseDeliveryActionsProps {
  setStage: (stage: DeliveryStage) => void;
  setCurrentDelivery: (delivery: any) => void;
  setDailyEarnings: (value: any) => void;
  setDeliveryCount: (value: any) => void;
  stopSound: () => void;
}

export const useDeliveryActions = ({
  setStage,
  setCurrentDelivery,
  setDailyEarnings,
  setDeliveryCount,
  stopSound,
}: UseDeliveryActionsProps) => {
  const { toast } = useToast();
  
  const acceptDeliveryMutation = useAcceptDeliveryReal();
  const acceptBatchMutation = useAcceptBatch();
  const confirmPickupMutation = useConfirmPickup();
  const confirmDeliveryMutation = useConfirmDelivery();
  const notDeliveredMutation = useNotDelivered();
  const returnDeliveryMutation = useReturnDelivery();

  const handleAcceptDelivery = useCallback(async (delivery: any) => {
    stopSound();
    try {
      await acceptDeliveryMutation.mutateAsync(delivery.id);
      void auditLog({
        action: 'delivery.accept',
        entity: 'delivery',
        entity_id: delivery.id,
      });
      setCurrentDelivery(delivery);
      setStage('going_pickup');
    } catch (error) {
      console.error('Erro ao aceitar entrega:', error);
    }
  }, [acceptDeliveryMutation, setCurrentDelivery, setStage, stopSound]);

  const handleRejectDelivery = useCallback(async (id: string) => {
    stopSound();
    setCurrentDelivery(null);
    setStage('idle');
    toast({
      title: "Entrega recusada",
      description: "Aguardando novas entregas...",
      duration: 1500,
    });
  }, [setCurrentDelivery, setStage, stopSound, toast]);

  const handleAcceptBatch = useCallback(async (batch: any) => {
    stopSound();
    try {
      await acceptBatchMutation.mutateAsync(batch);
      void auditLog({
        action: 'batch.accept',
        entity: 'batch',
        entity_id: batch?.id ?? undefined,
        metadata: { deliveries: batch?.deliveries?.map((d: any) => d?.id) ?? [] },
      });
      setCurrentDelivery(batch.deliveries[0]);
      setStage('going_pickup');
    } catch (error) {
      console.error('Erro ao aceitar batch:', error);
    }
  }, [acceptBatchMutation, setCurrentDelivery, setStage, stopSound]);

  const handleRejectBatch = useCallback(async (batchId: string) => {
    stopSound();
    toast({
      title: "Rota recusada",
      description: "Aguardando novas oportunidades...",
      duration: 1500,
    });
  }, [stopSound, toast]);

  const handleArrivedPickup = useCallback(() => {
    setStage('at_pickup');
    toast({
      title: "Você chegou!",
      description: "Retire o pedido e confirme",
      duration: 1500,
    });
  }, [setStage, toast]);

  const handleConfirmPickup = useCallback(async (currentDelivery: any) => {
    if (currentDelivery) {
      try {
        await confirmPickupMutation.mutateAsync(currentDelivery.id);
        void auditLog({
          action: 'delivery.pickup_confirm',
          entity: 'delivery',
          entity_id: currentDelivery.id,
        });
        setStage('going_delivery');
      } catch (error) {
        console.error('Erro ao confirmar coleta:', error);
      }
    }
  }, [confirmPickupMutation, setStage]);

  const handleArrivedDelivery = useCallback(() => {
    setStage('at_delivery');
    toast({
      title: "Você chegou!",
      description: "Entregue o pedido e confirme",
      duration: 1500,
    });
  }, [setStage, toast]);

  const handleConfirmDelivery = useCallback(async (currentDelivery: any, photo?: File) => {
    if (currentDelivery) {
      try {
        await confirmDeliveryMutation.mutateAsync({ deliveryId: currentDelivery.id, photo });
        void auditLog({
          action: 'delivery.delivered_confirm',
          entity: 'delivery',
          entity_id: currentDelivery.id,
          metadata: { hasPhoto: Boolean(photo) },
        });
        setDailyEarnings(prev => prev + currentDelivery.value);
        setDeliveryCount(prev => prev + 1);
        setStage('completed');
        setTimeout(() => {
          setCurrentDelivery(null);
          setStage('idle');
        }, 2000);
      } catch (error) {
        console.error('Erro ao confirmar entrega:', error);
      }
    }
  }, [confirmDeliveryMutation, setCurrentDelivery, setDailyEarnings, setDeliveryCount, setStage]);

  const handleConfirmNotDelivered = useCallback(async (currentDelivery: any, reason: string) => {
    if (currentDelivery) {
      try {
        await notDeliveredMutation.mutateAsync({ deliveryId: currentDelivery.id, reason });
        void auditLog({
          action: 'delivery.not_delivered',
          entity: 'delivery',
          entity_id: currentDelivery.id,
          metadata: { reason },
        });
        setStage('returning');
      } catch (error) {
        console.error('Erro ao registrar não entrega:', error);
      }
    }
  }, [notDeliveredMutation, setStage]);

  const handleArrivedReturn = useCallback(() => {
    setStage('at_return');
    toast({
      title: "Você chegou!",
      description: "Devolva a mercadoria e confirme",
      duration: 1500,
    });
  }, [setStage, toast]);

  const handleConfirmReturn = useCallback(async (currentDelivery: any) => {
    if (currentDelivery) {
      try {
        await returnDeliveryMutation.mutateAsync(currentDelivery.id);
        void auditLog({
          action: 'delivery.return_confirm',
          entity: 'delivery',
          entity_id: currentDelivery.id,
        });
        setStage('idle');
        setCurrentDelivery(null);
      } catch (error) {
        console.error('Erro ao devolver:', error);
      }
    }
  }, [returnDeliveryMutation, setCurrentDelivery, setStage]);

  return {
    handleAcceptDelivery,
    handleRejectDelivery,
    handleAcceptBatch,
    handleRejectBatch,
    handleArrivedPickup,
    handleConfirmPickup,
    handleArrivedDelivery,
    handleConfirmDelivery,
    handleConfirmNotDelivered,
    handleArrivedReturn,
    handleConfirmReturn,
  };
};