import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { usePushNotificationsFCM } from '@/hooks/usePushNotificationsFCM';
import { supabase } from '@/integrations/supabase/client';

interface NotificationRule {
  id: string;
  type: 'geolocation' | 'traffic' | 'rest' | 'promotion';
  message: string;
  condition: (context: NotificationContext) => boolean;
  cooldown?: number; // em minutos
}

interface NotificationContext {
  currentLocation: { latitude: number; longitude: number } | null;
  timeOnline: number; // em minutos
  isOnline: boolean;
  activeDeliveries: number;
  earningsToday: number;
  dayOfWeek: number;
  hourOfDay: number;
}

const NOTIFICATION_COOLDOWN = 15; // minutos entre notificações do mesmo tipo

export const useIntelligentNotifications = (
  isOnline: boolean,
  currentLocation: { latitude: number; longitude: number } | null,
  activeDeliveriesCount: number,
  earningsToday: number
) => {
  const { toast } = useToast();
  const [lastNotification, setLastNotification] = useState<Record<string, Date>>({}); // Track time online
  const [timeOnline, setTimeOnline] = useState(0); // Track time online

  // Função para mostrar notificação nativa do navegador
  const showNotification = (title: string, options?: NotificationOptions) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, options);
    }
  };

  // Track time online
  useEffect(() => {
    if (!isOnline) {
      setTimeOnline(0);
      return;
    }
    
    const interval = setInterval(() => {
      setTimeOnline(prev => prev + 1);
    }, 60000); // 1 minuto
    
    return () => clearInterval(interval);
  }, [isOnline]);

  // Notification rules
  const rules: NotificationRule[] = [
    {
      id: 'high-demand-area',
      type: 'geolocation',
      message: '🔥 Você está perto de uma área com alta demanda! Rendas médias 20% maiores aqui.',
      condition: (ctx) => {
        if (!ctx.currentLocation) return false;
        
        // Simulação: áreas de alta demanda em São Paulo centro
        const highDemandAreas = [
          { lat: -23.5505, lng: -46.6333, radius: 0.5 }, // Centro
          { lat: -23.5615, lng: -46.6559, radius: 0.5 }, // Paulista
          { lat: -23.5956, lng: -46.6867, radius: 0.5 }, // Mooca
        ];
        
        return highDemandAreas.some(area => {
          const distance = calculateDistance(
            ctx.currentLocation.latitude,
            ctx.currentLocation.longitude,
            area.lat,
            area.lng
          );
          return distance <= area.radius;
        });
      },
      cooldown: 30,
    },
    {
      id: 'traffic-alert',
      type: 'traffic',
      message: '⚠️ Evite avenida Paulista - trânsito lento. Rota alternativa economiza 10 min.',
      condition: (ctx) => {
        if (!ctx.currentLocation) return false;
        
        // Simulação: verificar se está perto de área com trânsito
        const trafficAreas = [
          { lat: -23.5615, lng: -46.6559, radius: 0.3 }, // Paulista
        ];
        
        return trafficAreas.some(area => {
          const distance = calculateDistance(
            ctx.currentLocation.latitude,
            ctx.currentLocation.longitude,
            area.lat,
            area.lng
          );
          return distance <= area.radius;
        });
      },
      cooldown: 20,
    },
    {
      id: 'rest-reminder',
      type: 'rest',
      message: '☕ Você está há 4h online. Que tal uma pausa? Seu rendimento cai 15% após 4h contínuas.',
      condition: (ctx) => ctx.timeOnline >= 240 && ctx.activeDeliveries === 0,
      cooldown: 60,
    },
    {
      id: 'promotion-bonus',
      type: 'promotion',
      message: '💰 Entregas na Zona Sul têm bônus de 20% até as 20h! Aproveite.',
      condition: (ctx) => {
        // Simulação: promoção ativa em certos horários
        const isPromoTime = ctx.hourOfDay >= 18 && ctx.hourOfDay <= 20;
        const isWeekend = ctx.dayOfWeek === 0 || ctx.dayOfWeek === 6;
        return isPromoTime && isWeekend;
      },
      cooldown: 45,
    },
    {
      id: 'batch-opportunity',
      type: 'geolocation',
      message: '📦 3 entregas disponíveis próximas! Rota otimizada pode render R$45 em 30 min.',
      condition: (ctx) => {
        if (!ctx.currentLocation) return false;
        
        // Simulação: múltiplas entregas próximas
        const deliveryCluster = {
          lat: -23.5505,
          lng: -46.6333,
          radius: 0.8
        };
        
        const distance = calculateDistance(
          ctx.currentLocation.latitude,
          ctx.currentLocation.longitude,
          deliveryCluster.lat,
          deliveryCluster.lng
        );
        
        return distance <= deliveryCluster.radius && ctx.activeDeliveries === 0;
      },
      cooldown: 25,
    },
  ];

  // Check and send notifications
  useEffect(() => {
    if (!isOnline) return;
    
    const checkNotifications = () => {
      const now = new Date();
      const context: NotificationContext = {
        currentLocation,
        timeOnline,
        isOnline,
        activeDeliveries: activeDeliveriesCount,
        earningsToday,
        dayOfWeek: now.getDay(),
        hourOfDay: now.getHours(),
      };
      
      rules.forEach(rule => {
        // Check cooldown
        const lastSent = lastNotification[rule.id];
        if (lastSent) {
          const minutesSinceLast = (now.getTime() - lastSent.getTime()) / (1000 * 60);
          if (minutesSinceLast < (rule.cooldown || NOTIFICATION_COOLDOWN)) {
            return;
          }
        }
        
        // Check condition
        if (rule.condition(context)) {
          // Send in-app toast
          toast({
            title: getNotificationTitle(rule.type),
            description: rule.message,
            duration: 8000,
          });
          
          // Send push notification
          showNotification(getNotificationTitle(rule.type), {
            body: rule.message,
            tag: `intelligent-${rule.id}`,
          });
          
          // Update cooldown
          setLastNotification(prev => ({
            ...prev,
            [rule.id]: now,
          }));
        }
      });
    };
    
    // Check every 2 minutes
    const interval = setInterval(checkNotifications, 120000);
    checkNotifications(); // Check immediately
    
    return () => clearInterval(interval);
  }, [isOnline, currentLocation, timeOnline, activeDeliveriesCount, earningsToday, toast, showNotification]);

  return {
    timeOnline,
  };
};

// Helper functions
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Raio da Terra em km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

function getNotificationTitle(type: string): string {
  const titles = {
    geolocation: '📍 Oportunidade Próxima',
    traffic: '🚗 Alerta de Trânsito',
    rest: '☕ Pausei',
    promotion: '💰 Promoção',
  };
  
  return titles[type as keyof typeof titles] || 'Notificação';
}