import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { calculateOptimizedRoute, calculateBatchRoute } from '@/lib/routeOptimizer';

interface Coordinate {
  lat: number;
  lng: number;
}

interface RoutePoint {
  id: string;
  address: string;
  coordinates?: Coordinate;
  type: 'pickup' | 'dropoff';
  value: number;
  customerName: string;
}

interface RouteResult {
  order: string[];
  totalDistance: number;
  totalTime: number;
  savings: {
    distance: number;
    time: number;
  };
  waypoints: Array<{
    id: string;
    type: 'pickup' | 'dropoff';
    address: string;
    estimatedArrival: string;
    instructions: string;
  }>;
}

interface BatchRouteResult {
  deliveries: RoutePoint[];
  totalDistance: number;
  totalTime: number;
  optimizedOrder: string[];
  waypoints: Array<{
    id: string;
    type: 'pickup' | 'dropoff';
    address: string;
    estimatedArrival: string;
    instructions: string;
  }>;
  savings: {
    distance: number;
    time: number;
  };
}

export const useRouteOptimization = () => {
  const { toast } = useToast();
  const [optimizing, setOptimizing] = useState(false);

  // Hook para calcular rota otimizada
  const calculateOptimizedRouteMutation = useMutation({
    mutationFn: async (params: {
      points: RoutePoint[];
      startCoord: Coordinate;
      useAPI?: boolean;
    }): Promise<RouteResult> => {
      setOptimizing(true);
      try {
        const result = await calculateOptimizedRoute(
          params.points,
          params.startCoord,
          params.useAPI ?? true
        );
        return result;
      } finally {
        setOptimizing(false);
      }
    },
    onSuccess: () => {
      toast({
        title: "Rota otimizada! 🚀",
        description: "Cálculo concluído com sucesso",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao calcular rota",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });

  // Hook para calcular rota combinada
  const calculateBatchRouteMutation = useMutation({
    mutationFn: async (params: {
      points: RoutePoint[];
      startCoord: Coordinate;
      useAPI?: boolean;
    }): Promise<BatchRouteResult> => {
      setOptimizing(true);
      try {
        const result = await calculateBatchRoute(
          params.points,
          params.startCoord,
          params.useAPI ?? true
        );
        return result;
      } finally {
        setOptimizing(false);
      }
    },
    onSuccess: () => {
      toast({
        title: "Rota combinada otimizada! 🚀",
        description: "Cálculo concluído com sucesso",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao calcular rota combinada",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });

  return {
    calculateOptimizedRoute: calculateOptimizedRouteMutation.mutate,
    calculateBatchRoute: calculateBatchRouteMutation.mutate,
    isOptimizing: optimizing || calculateOptimizedRouteMutation.isPending || calculateBatchRouteMutation.isPending,
  };
};