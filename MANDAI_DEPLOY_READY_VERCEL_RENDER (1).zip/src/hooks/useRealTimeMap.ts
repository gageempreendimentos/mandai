import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';

interface Coordinates {
  lat: number;
  lng: number;
}

interface RouteResult {
  distance: number; // km
  duration: number; // minutos
  polyline: string; // rota codificada
  steps: any[]; // passos da rota
}

// Hook para calcular rota real usando Mandaigle Maps Directions API
export const useRealTimeRoute = (origin: Coordinates | null, destination: Coordinates | null) => {
  return useQuery({
    queryKey: ['route', origin, destination],
    queryFn: async () => {
      if (!origin || !destination) return null;
      
      const apiKey = import.meta.env.VITE_MANDAIGLE_MAPS_API_KEY;
      if (!apiKey) {
        console.warn('Mandaigle Maps API Key não configurada');
        return null;
      }

      const url = `https://maps.mandaigleapis.com/maps/api/directions/json?origin=${origin.lat},${origin.lng}&destination=${destination.lat},${destination.lng}&key=${apiKey}&mode=driving`;

      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== 'OK') {
        console.error('Erro ao calcular rota:', data.status);
        return null;
      }

      const route = data.routes[0].legs[0];
      
      return {
        distance: route.distance.value / 1000, // converter para km
        duration: Math.round(route.duration.value / 60), // converter para minutos
        polyline: data.routes[0].overview_polyline.points,
        steps: route.steps,
      } as RouteResult;
    },
    staleTime: 1000 * 60 * 5, // 5 minutos
    enabled: !!origin && !!destination,
  });
};

// Hook para geocodificar endereço -> coordenadas
export const useGeocode = (address: string) => {
  return useQuery({
    queryKey: ['geocode', address],
    queryFn: async () => {
      if (!address) return null;
      
      const apiKey = import.meta.env.VITE_MANDAIGLE_MAPS_API_KEY;
      if (!apiKey) {
        // Fallback para coordenadas simuladas se API não estiver configurada
        return simulateGeocode(address);
      }

      const url = `https://maps.mandaigleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${apiKey}`;

      const response = await fetch(url);
      const data = await response.json();

      if (data.status !== 'OK') {
        console.warn('Geocoding falhou, usando simulação:', address);
        return simulateGeocode(address);
      }

      const location = data.results[0].geometry.location;
      return { lat: location.lat, lng: location.lng } as Coordinates;
    },
    staleTime: 1000 * 60 * 60, // 1 hora
    enabled: !!address,
  });
};

// Função de simulação (fallback)
function simulateGeocode(address: string): Coordinates {
  // Gera coordenadas baseadas no hash do endereço
  const hash = address.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  
  // São Paulo centro
  const baseLat = -23.5505;
  const baseLng = -46.6333;
  
  // Variação baseada no hash
  const latVariation = ((hash % 100) - 50) / 1000; // -0.05 a 0.05
  const lngVariation = ((hash % 100) - 50) / 1000; // -0.05 a 0.05
  
  return {
    lat: baseLat + latVariation,
    lng: baseLng + lngVariation,
  };
}