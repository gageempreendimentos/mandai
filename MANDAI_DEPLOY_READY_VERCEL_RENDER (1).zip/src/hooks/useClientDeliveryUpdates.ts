import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { usePushNotificationsFCM } from '@/hooks/usePushNotificationsFCM';

export const useClientDeliveryUpdates = (userId: string) => {
  const { toast } = useToast();
  const { requestPermission } = usePushNotificationsFCM();
  const [updatedDeliveries, setUpdatedDeliveries] = useState<any[]>([]);
  const previousStatusRef = useRef<Record<string, string>>({});

  useEffect(() => {
    if (!userId) return;

    // Request notification permission
    requestPermission();

    // Subscribe to delivery updates
    const channel = supabase
      .channel('client-deliveries-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'deliveries',
          filter: `customer_id=eq.${userId}`,
        },
        async (payload) => {
          console.log('📡 Delivery update received:', payload.new);

          const delivery = payload.new;
          const previousStatus = previousStatusRef.current[delivery.id];
          
          // Update previous status reference
          previousStatusRef.current[delivery.id] = delivery.status;

          // Only notify on status changes
          if (previousStatus && previousStatus !== delivery.status) {
            // Update local state
            setUpdatedDeliveries(prev => {
              const existingIndex = prev.findIndex(d => d.id === delivery.id);
              if (existingIndex >= 0) {
                const updated = [...prev];
                updated[existingIndex] = delivery;
                return updated;
              }
              return [...prev, delivery];
            });

            // Status change messages
            const statusMessages: Record<string, { title: string; description: string }> = {
              accepted: {
                title: "Entrega aceita! 🚀",
                description: `${delivery.driver_name || 'Um entregador'} aceitou sua entrega`,
              },
              in_transit: {
                title: "Em trânsito! 📦",
                description: "Seu pedido está a caminho",
              },
              delivered: {
                title: "Entrega concluída! ✅",
                description: "Obrigado por usar nossos serviços",
              },
              cancelled: {
                title: "Entrega cancelada",
                description: "Sua entrega foi cancelada",
              },
            };

            const message = statusMessages[delivery.status];
            if (message) {
              // Show toast notification
              toast({
                title: message.title,
                description: message.description,
                duration: 8000,
              });

              // Try to play sound for important updates
              if (delivery.status === 'accepted' || delivery.status === 'delivered') {
                try {
                  const audio = new Audio('/sounds/status-update.mp3');
                  audio.play().catch(() => {});
                } catch (e) {
                  console.log('Não foi possível tocar áudio');
                }
              }
            }
          }
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('✅ Conectado ao canal de atualizações de entrega');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, toast, requestPermission]);

  return { updatedDeliveries };
};