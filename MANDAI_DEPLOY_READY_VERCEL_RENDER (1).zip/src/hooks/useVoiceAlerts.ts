import { useEffect, useMemo, useRef, useState } from 'react';

type VoiceAlertOptions = {
  /** If omitted, uses the persisted value. */
  enabled?: boolean;
  /** Speech synthesis language. */
  lang?: string;
};

const STORAGE_KEY = 'mandai.voiceAlerts.enabled';

export function getVoiceAlertsEnabled(): boolean {
  const v = localStorage.getItem(STORAGE_KEY);
  if (v === null) return true; // default on
  return v === 'true';
}

export function setVoiceAlertsEnabled(enabled: boolean) {
  localStorage.setItem(STORAGE_KEY, String(enabled));
}

/**
 * Simple voice alerts using Web Speech API (best-effort).
 * Works on most modern browsers. On iOS/Safari this may be limited.
 */
export function useVoiceAlerts(options: VoiceAlertOptions = {}) {
  const [isEnabled, setIsEnabled] = useState<boolean>(() =>
    options.enabled ?? getVoiceAlertsEnabled()
  );

  // Keep in sync if consumer passes enabled
  useEffect(() => {
    if (typeof options.enabled === 'boolean') {
      setIsEnabled(options.enabled);
    }
  }, [options.enabled]);

  const canSpeak = useMemo(() => {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }, []);

  const lastSpokenRef = useRef<Record<string, number>>({});

  const speak = (text: string, key?: string, minIntervalMs = 8000) => {
    if (!isEnabled || !canSpeak) return;
    const now = Date.now();
    const k = key ?? text;
    const last = lastSpokenRef.current[k] ?? 0;
    if (now - last < minIntervalMs) return;

    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = options.lang ?? 'pt-BR';
      window.speechSynthesis.speak(utter);
      lastSpokenRef.current[k] = now;
    } catch {
      // ignore
    }
  };

  const toggle = () => {
    const next = !isEnabled;
    setIsEnabled(next);
    setVoiceAlertsEnabled(next);
    return next;
  };

  return {
    isEnabled,
    setEnabled: (v: boolean) => {
      setIsEnabled(v);
      setVoiceAlertsEnabled(v);
    },
    toggle,
    speak,
  };
}
