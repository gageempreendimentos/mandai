import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';

interface DeliveryPoint {
  id: string;
  type: 'pickup' | 'dropoff';
  address: string;
  coordinates: { lat: number; lng: number };
  timeWindow?: { start: string; end: string };
  priority: number; // 1-10
}

interface OptimizedRoute {
  sequence: string[];
  totalDistance: number;
  totalTime: number;
  estimatedCompletion: string;
  savings: {
    distance: number;
    time: number;
    fuel: number;
  };
  waypoints: Array<{
    id: string;
    type: 'pickup' | 'dropoff';
    address: string;
    estimatedArrival: string;
    instructions: string;
  }>;
}

export const useAdvancedRouteOptimization = (
  deliveries: DeliveryPoint[],
  currentLocation: { lat: number; lng: number }
) => {
  const [optimizedRoute, setOptimizedRoute] = useState<OptimizedRoute | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Algoritmo de otimização de rotas (simplificado)
  const optimizeRoute = async (): Promise<OptimizedRoute> => {
    setIsLoading(true);
    
    // Simular processamento
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Algoritmo de otimização baseado em distância e prioridade
    const sortedDeliveries = [...deliveries].sort((a, b) => {
      // Calcular distância do ponto atual para cada entrega
      const distanceA = calculateDistance(
        currentLocation.lat,
        currentLocation.lng,
        a.coordinates.lat,
        a.coordinates.lng
      );
      
      const distanceB = calculateDistance(
        currentLocation.lat,
        currentLocation.lng,
        b.coordinates.lat,
        b.coordinates.lng
      );
      
      // Prioridade mais alta primeiro, depois menor distância
      if (b.priority !== a.priority) {
        return b.priority - a.priority;
      }
      
      return distanceA - distanceB;
    });
    
    // Criar sequência otimizada
    const sequence: string[] = [];
    let totalDistance = 0;
    let totalTime = 0;
    const waypoints = [];
    
    let currentPos = currentLocation;
    
    for (const delivery of sortedDeliveries) {
      sequence.push(delivery.id);
      
      const distance = calculateDistance(
        currentPos.lat,
        currentPos.lng,
        delivery.coordinates.lat,
        delivery.coordinates.lng
      );
      
      totalDistance += distance;
      totalTime += distance * 2; // 2 minutos por km + 5 minutos parado
      
      waypoints.push({
        id: delivery.id,
        type: delivery.type,
        address: delivery.address,
        estimatedArrival: new Date(Date.now() + totalTime * 60000).toLocaleTimeString('pt-BR', {
          hour: '2-digit',
          minute: '2-digit'
        }),
        instructions: getNavigationInstructions(currentPos, delivery.coordinates)
      });
      
      currentPos = delivery.coordinates;
    }
    
    // Calcular economias (comparado com rota aleatória)
    const randomRouteDistance = deliveries.length * 3; // 3km média por entrega
    const distanceSavings = randomRouteDistance - totalDistance;
    const timeSavings = (randomRouteDistance * 2) - totalTime;
    const fuelSavings = distanceSavings * 0.5; // R$0.50 por km economizado
    
    setIsLoading(false);
    
    return {
      sequence,
      totalDistance: parseFloat(totalDistance.toFixed(2)),
      totalTime: Math.round(totalTime),
      estimatedCompletion: new Date(Date.now() + totalTime * 60000).toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit'
      }),
      savings: {
        distance: parseFloat(distanceSavings.toFixed(2)),
        time: Math.round(timeSavings),
        fuel: parseFloat(fuelSavings.toFixed(2))
      },
      waypoints
    };
  };

  useEffect(() => {
    if (deliveries.length > 0 && currentLocation) {
      optimizeRoute().then(setOptimizedRoute);
    }
  }, [deliveries, currentLocation]);

  return {
    optimizedRoute,
    isLoading,
    optimizeRoute
  };
};

// Funções auxiliares
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Raio da Terra em km
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

function getNavigationInstructions(from: { lat: number; lng: number }, to: { lat: number; lng: number }): string {
  // Simplificação - em produção usaria API de navegação real
  const latDiff = to.lat - from.lat;
  const lngDiff = to.lng - from.lng;
  
  let direction = '';
  if (Math.abs(latDiff) > Math.abs(lngDiff)) {
    direction = latDiff > 0 ? 'ao norte' : 'ao sul';
  } else {
    direction = lngDiff > 0 ? 'a leste' : 'a oeste';
  }
  
  return `Siga ${direction} por aproximadamente ${(calculateDistance(from.lat, from.lng, to.lat, to.lng) * 1000).toFixed(0)} metros`;
}