import { useEffect, useState } from 'react';
import { useBrowserLocation } from './useBrowserLocation';

export const useDriverLocation = (isOnline: boolean) => {
  const [currentLocation, setCurrentLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [accuracy, setAccuracy] = useState<number | null>(null);
  const [isLocationEnabled, setIsLocationEnabled] = useState(false);

  const {
    location: browserLocation,
    error: locationError,
    isLoading: isLoadingLocation,
    getLocation,
    startWatching,
    stopWatching,
    clearError,
    isSupported,
  } = useBrowserLocation(isLocationEnabled);

  // Efeito: quando fica online, ativa geolocalização
  useEffect(() => {
    if (isOnline && isSupported) {
      console.log('🚀 Ativando geolocalização real do navegador');
      setIsLocationEnabled(true);
    } else {
      setIsLocationEnabled(false);
      setCurrentLocation(null);
      setAccuracy(null);
    }
  }, [isOnline, isSupported]);

  // Efeito: atualiza localização quando recebe do navegador
  useEffect(() => {
    if (browserLocation) {
      setCurrentLocation({
        latitude: browserLocation.latitude,
        longitude: browserLocation.longitude,
      });
      setAccuracy(browserLocation.accuracy || null);
      console.log('📍 Localização atualizada:', browserLocation);
    }
  }, [browserLocation]);

  // Efeito: log de erros
  useEffect(() => {
    if (locationError) {
      console.error('❌ Erro de geolocalização:', locationError.message);
      
      // Se for erro de permissão, mostra toast
      if (locationError.code === locationError.PERMISSION_DENIED) {
        console.log('Permissão de localização negada. Configure no navegador.');
      }
    }
  }, [locationError]);

  // Função para obter localização manualmente
  const requestLocation = async () => {
    if (!isSupported) {
      console.log('Geolocalização não suportada');
      return null;
    }

    const coords = await getLocation();
    if (coords) {
      return {
        latitude: coords.latitude,
        longitude: coords.longitude,
      };
    }
    return null;
  };

  return {
    currentLocation,
    accuracy,
    isLoading: isLoadingLocation,
    error: locationError,
    isSupported,
    requestLocation,
    clearError,
  };
};