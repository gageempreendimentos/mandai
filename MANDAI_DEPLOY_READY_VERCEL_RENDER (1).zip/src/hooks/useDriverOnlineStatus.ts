import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { usePushNotificationsFCM } from '@/hooks/usePushNotificationsFCM';

export const useDriverOnlineStatus = () => {
  const [isOnline, setIsOnline] = useState(false);
  const { toast } = useToast();
  const { requestPermission: requestPushPermission } = usePushNotificationsFCM();

  const toggleOnline = useCallback(() => {
    const newStatus = !isOnline;
    setIsOnline(newStatus);

    if (newStatus) {
      requestPushPermission();
      toast({
        title: "Você está online!",
        description: "Aguardando entregas...",
      });
    } else {
      toast({
        title: "Você está offline",
        description: "Descanse um pouco!",
      });
    }

    return newStatus;
  }, [isOnline, requestPushPermission, toast]);

  const goOffline = useCallback(() => {
    setIsOnline(false);
  }, []);

  const goOnline = useCallback(() => {
    setIsOnline(true);
    requestPushPermission();
  }, [requestPushPermission]);

  return {
    isOnline,
    setIsOnline,
    toggleOnline,
    goOffline,
    goOnline,
  };
};