import { useEffect, useState } from 'react';

export function useWarmStart(delayMs = 280) {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(() => setReady(true), delayMs);
    return () => window.clearTimeout(t);
  }, [delayMs]);

  return ready;
}
