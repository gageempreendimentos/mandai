import { useEffect, useState } from 'react';

interface Coordinates {
  latitude: number;
  longitude: number;
  accuracy?: number;
  altitude?: number;
  altitudeAccuracy?: number;
  heading?: number;
  speed?: number;
}

interface LocationError {
  code: number;
  message: string;
  PERMISSION_DENIED: number;
  POSITION_UNAVAILABLE: number;
  TIMEOUT: number;
}

export const useBrowserLocation = (enabled: boolean) => {
  const [location, setLocation] = useState<Coordinates | null>(null);
  const [error, setError] = useState<LocationError | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [watchId, setWatchId] = useState<number | null>(null);

  // Função para obter localização única
  const getLocation = async (): Promise<Coordinates | null> => {
    if (!('geolocation' in navigator)) {
      setError({
        code: 0,
        message: 'Geolocalização não suportada pelo navegador',
        PERMISSION_DENIED: 1,
        POSITION_UNAVAILABLE: 2,
        TIMEOUT: 3,
      });
      return null;
    }

    setIsLoading(true);
    setError(null);

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords: Coordinates = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            altitude: position.coords.altitude,
            altitudeAccuracy: position.coords.altitudeAccuracy,
            heading: position.coords.heading,
            speed: position.coords.speed,
          };
          setLocation(coords);
          setIsLoading(false);
          resolve(coords);
        },
        (err) => {
          const locationError: LocationError = {
            code: err.code,
            message: err.message,
            PERMISSION_DENIED: 1,
            POSITION_UNAVAILABLE: 2,
            TIMEOUT: 3,
          };
          setError(locationError);
          setIsLoading(false);
          console.error('Erro ao obter localização:', err);
          resolve(null);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        }
      );
    });
  };

  // Função para iniciar watch
  const startWatching = () => {
    if (!('geolocation' in navigator)) {
      setError({
        code: 0,
        message: 'Geolocalização não suportada pelo navegador',
        PERMISSION_DENIED: 1,
        POSITION_UNAVAILABLE: 2,
        TIMEOUT: 3,
      });
      return;
    }

    if (watchId !== null) {
      console.log('Já está assistindo localização');
      return;
    }

    setIsLoading(true);
    setError(null);

    const id = navigator.geolocation.watchPosition(
      (position) => {
        const coords: Coordinates = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude,
          altitudeAccuracy: position.coords.altitudeAccuracy,
          heading: position.coords.heading,
          speed: position.coords.speed,
        };
        setLocation(coords);
        setIsLoading(false);
      },
      (err) => {
        const locationError: LocationError = {
          code: err.code,
          message: err.message,
          PERMISSION_DENIED: 1,
          POSITION_UNAVAILABLE: 2,
          TIMEOUT: 3,
        };
        setError(locationError);
        setIsLoading(false);
        console.error('Erro ao assistir localização:', err);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 5000,
      }
    );

    setWatchId(id);
  };

  // Função para parar watch
  const stopWatching = () => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
      setIsLoading(false);
    }
  };

  // Efeito para iniciar/parar watch baseado no enabled
  useEffect(() => {
    if (enabled) {
      startWatching();
    } else {
      stopWatching();
    }

    return () => {
      stopWatching();
    };
  }, [enabled]);

  // Função para limpar erro
  const clearError = () => {
    setError(null);
  };

  return {
    location,
    error,
    isLoading,
    getLocation,
    startWatching,
    stopWatching,
    clearError,
    isSupported: 'geolocation' in navigator,
  };
};