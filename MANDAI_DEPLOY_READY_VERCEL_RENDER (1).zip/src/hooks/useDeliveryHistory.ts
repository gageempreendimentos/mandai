import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';

export interface HistoryDelivery {
  id: string;
  date: string;
  time: string;
  value: number;
  status: 'delivered' | 'not_delivered' | 'cancelled';
  pickup_address: string;
  delivery_address: string;
  customer_name: string;
  not_delivered_reason?: string;
}

export const useDeliveryHistory = (dateFrom?: string, dateTo?: string) => {
  return useQuery({
    queryKey: ['history', dateFrom, dateTo],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      // Construir query
      let query = supabase
        .from('deliveries')
        .select('*')
        .eq('driver_id', user.id)
        .in('status', ['delivered', 'not_delivered', 'cancelled'])
        .order('created_at', { ascending: false });

      // Aplicar filtros de data se existirem
      if (dateFrom) {
        query = query.gte('created_at', `${dateFrom}T00:00:00`);
      }
      if (dateTo) {
        query = query.lte('created_at', `${dateTo}T23:59:59`);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Transformar dados para o formato esperado
      const history: HistoryDelivery[] = (data || []).map((delivery) => {
        const createdAt = new Date(delivery.created_at || '');
        const date = createdAt.toISOString().split('T')[0];
        const time = createdAt.toLocaleTimeString('pt-BR', { 
          hour: '2-digit', 
          minute: '2-digit' 
        });

        // Mapear status do banco para o tipo esperado
        let mappedStatus: 'delivered' | 'not_delivered' | 'cancelled' = 'cancelled';
        if (delivery.status === 'delivered') mappedStatus = 'delivered';
        else if (delivery.status === 'not_delivered') mappedStatus = 'not_delivered';
        else if (delivery.status === 'cancelled') mappedStatus = 'cancelled';

        return {
          id: delivery.id,
          date,
          time,
          value: delivery.value || 0,
          status: mappedStatus,
          pickup_address: delivery.pickup_address,
          delivery_address: delivery.delivery_address,
          customer_name: delivery.customer_name,
          not_delivered_reason: delivery.not_delivered_reason || undefined,
        };
      });

      return history;
    },
    staleTime: 1000 * 60 * 5, // 5 minutos
  });
};

// Hook para estatísticas do período
export const useDeliveryStats = (dateFrom?: string, dateTo?: string) => {
  return useQuery({
    queryKey: ['stats', dateFrom, dateTo],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      let query = supabase
        .from('deliveries')
        .select('*')
        .eq('driver_id', user.id)
        .in('status', ['delivered', 'not_delivered', 'cancelled']);

      if (dateFrom) {
        query = query.gte('created_at', `${dateFrom}T00:00:00`);
      }
      if (dateTo) {
        query = query.lte('created_at', `${dateTo}T23:59:59`);
      }

      const { data, error } = await query;

      if (error) throw error;

      const completed = (data || []).filter(d => d.status === 'delivered');
      const totalEarnings = completed.reduce((sum, d) => sum + (d.value || 0), 0);
      const totalHours = completed.length * 0.5; // Estimativa: 30 min por entrega

      return {
        totalEarnings,
        completed: completed.length,
        totalHours,
      };
    },
    staleTime: 1000 * 60 * 5,
  });
};