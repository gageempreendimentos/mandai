import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export type AppNotification = {
  id: string;
  title: string;
  message: string;
  type?: string | null;
  created_at?: string | null;
  read?: boolean | null;
};

async function fetchUserNotifications(userId: string): Promise<AppNotification[]> {
  // O schema pode variar (driver_id/client_id/restaurant_id/user_id).
  // Tentamos em ordem e, se um filtro falhar (coluna não existe), tentamos o próximo.
  const attempts: Array<{ col: string; value: string }> = [
    { col: 'user_id', value: userId },
    { col: 'driver_id', value: userId },
    { col: 'client_id', value: userId },
    { col: 'restaurant_id', value: userId },
  ];

  for (const a of attempts) {
    const { data, error } = await supabase
      .from('notifications')
      .select('id,title,message,type,created_at,read')
      .eq(a.col as any, a.value)
      .order('created_at', { ascending: false })
      .limit(100);

    if (!error) {
      return (data ?? []) as AppNotification[];
    }
  }

  // Último fallback: tenta buscar as últimas notificações sem filtro (RLS normalmente bloqueia)
  const { data } = await supabase
    .from('notifications')
    .select('id,title,message,type,created_at,read')
    .order('created_at', { ascending: false })
    .limit(50);

  return (data ?? []) as AppNotification[];
}

export const useNotifications = () => {
  return useQuery({
    queryKey: ['notifications'],
    queryFn: async () => {
      const { data } = await supabase.auth.getUser();
      const user = data.user;
      if (!user) return [];
      return fetchUserNotifications(user.id);
    },
    refetchInterval: 15000,
    staleTime: 5000,
  });
};

export const useMarkNotificationRead = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('notifications').update({ read: true }).eq('id', id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
};
