import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useDeliverySound } from '@/hooks/useDeliverySound';
import { useMandaiSettings } from '@/hooks/useMandaiSettings';

export type DeliveryStage = 
  | 'idle' 
  | 'pending' 
  | 'going_pickup' 
  | 'at_pickup' 
  | 'going_delivery' 
  | 'at_delivery' 
  | 'returning' 
  | 'at_return' 
  | 'completed';

export const useDeliveryStage = () => {
  const { settings } = useMandaiSettings();
  const [stage, setStage] = useState<DeliveryStage>('idle');
  const [currentDelivery, setCurrentDelivery] = useState<any>(null);
  const { toast } = useToast();
  const { startContinuousSound, stopSound } = useDeliverySound(settings.soundsEnabled);

  const goToStage = useCallback((newStage: DeliveryStage, message?: { title: string; description: string }) => {
    setStage(newStage);
    
    if (newStage === 'pending') {
      startContinuousSound();
    } else {
      stopSound();
    }

    if (message) {
      toast({
        title: message.title,
        description: message.description,
        duration: 1500,
      });
    }
  }, [startContinuousSound, stopSound, toast]);

  const resetDelivery = useCallback(() => {
    setCurrentDelivery(null);
    setStage('idle');
    stopSound();
  }, [stopSound]);

  return {
    stage,
    setStage,
    currentDelivery,
    setCurrentDelivery,
    goToStage,
    resetDelivery,
    stopSound,
    startContinuousSound,
  };
};