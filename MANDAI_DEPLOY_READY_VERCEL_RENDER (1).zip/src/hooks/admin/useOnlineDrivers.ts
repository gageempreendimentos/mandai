import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Tables } from '@/integrations/supabase/types';

export interface OnlineDriver extends Tables<'profiles'> {
  current_lat: number | null;
  current_lng: number | null;
  last_location_update: string | null;
}

export const useOnlineDrivers = () => {
  const { toast } = useToast();
  const [onlineDrivers, setOnlineDrivers] = useState<OnlineDriver[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchOnlineDrivers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, nome_completo, telefone, email, is_online, current_lat, current_lng, last_location_update')
        .eq('is_online', true)
        .eq('status', 'approved'); // Only approved drivers

      if (error) throw error;
      setOnlineDrivers(data as OnlineDriver[]);
    } catch (error: any) {
      console.error('Error fetching online drivers:', error.message);
      toast({
        title: "Erro ao carregar entregadores online",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOnlineDrivers();

    const channel = supabase
      .channel('online-drivers-channel')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: 'is_online=eq.true',
        },
        (payload) => {
          const updatedDriver = payload.new as OnlineDriver;
          setOnlineDrivers(prev => {
            const existingIndex = prev.findIndex(d => d.id === updatedDriver.id);
            if (existingIndex > -1) {
              const newDrivers = [...prev];
              newDrivers[existingIndex] = updatedDriver;
              return newDrivers;
            } else {
              // If a driver comes online
              return [...prev, updatedDriver];
            }
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: 'is_online=eq.false',
        },
        (payload) => {
          const offlineDriver = payload.new as OnlineDriver;
          setOnlineDrivers(prev => prev.filter(d => d.id !== offlineDriver.id));
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('✅ Conectado ao canal de entregadores online');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [toast]);

  return { onlineDrivers, isLoading, fetchOnlineDrivers };
};