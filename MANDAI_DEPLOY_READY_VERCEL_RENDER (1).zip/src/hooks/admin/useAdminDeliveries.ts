import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Tables } from '@/integrations/supabase/types';

export interface AdminDelivery extends Tables<'deliveries'> {
  driver_name: string | null;
}

export const useAdminDeliveries = () => {
  const { toast } = useToast();
  const [adminDeliveries, setAdminDeliveries] = useState<AdminDelivery[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchAdminDeliveries = async () => {
    try {
      const { data, error } = await supabase
        .from('deliveries')
        .select('*, profiles!deliveries_driver_id_fkey(nome_completo)')
        .in('status', ['pending', 'in_transit', 'picked_up', 'not_delivered']) // Relevant statuses for monitoring
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      const formattedData = data.map(d => ({
        ...d,
        driver_name: d.profiles?.nome_completo || null,
      }));
      setAdminDeliveries(formattedData);
    } catch (error: any) {
      console.error('Error fetching admin deliveries:', error.message);
      toast({
        title: "Erro ao carregar entregas para monitoramento",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminDeliveries();

    const channel = supabase
      .channel('admin-deliveries-channel')
      .on(
        'postgres_changes',
        {
          event: '*', // Listen to all events (INSERT, UPDATE, DELETE)
          schema: 'public',
          table: 'deliveries',
        },
        async (payload) => {
          const newDelivery = payload.new as AdminDelivery;
          const oldDelivery = payload.old as AdminDelivery;

          // Fetch driver name if not already present
          if (newDelivery.driver_id && !newDelivery.driver_name) {
            const { data: driverProfile } = await supabase
              .from('profiles')
              .select('nome_completo')
              .eq('id', newDelivery.driver_id)
              .single();
            newDelivery.driver_name = driverProfile?.nome_completo || null;
          }

          setAdminDeliveries(prev => {
            if (payload.eventType === 'INSERT') {
              return [newDelivery, ...prev];
            } else if (payload.eventType === 'UPDATE') {
              // If status is no longer relevant for monitoring, remove it
              if (!['pending', 'in_transit', 'picked_up', 'not_delivered'].includes(newDelivery.status || '')) {
                return prev.filter(d => d.id !== newDelivery.id);
              }
              // Otherwise, update existing or add if new
              const existingIndex = prev.findIndex(d => d.id === newDelivery.id);
              if (existingIndex > -1) {
                const updated = [...prev];
                updated[existingIndex] = newDelivery;
                return updated;
              }
              return [newDelivery, ...prev]; // Add if it's a new relevant delivery
            } else if (payload.eventType === 'DELETE') {
              return prev.filter(d => d.id !== oldDelivery.id);
            }
            return prev;
          });
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('✅ Conectado ao canal de entregas para admin');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [toast]);

  return { adminDeliveries, isLoading, fetchAdminDeliveries };
};