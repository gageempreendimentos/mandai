import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Tables } from '@/integrations/supabase/types';

export interface AdminStats {
  totalDeliveries: number;
  pendingDeliveries: number;
  completedDeliveries: number;
  totalDrivers: number;
  pendingDrivers: number;
  activeDrivers: number;
  totalClients: number;
  totalRestaurants: number;
  pendingWithdrawals: number;
  totalEarnings: number;
  approvalRate: number;
}

export const useAdminStats = () => {
  const { toast } = useToast();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadStats = useCallback(async () => {
    try {
      setIsLoading(true);

      // Deliveries stats
      const { data: deliveries, error: deliveriesError } = await supabase
        .from('deliveries')
        .select('*');

      if (deliveriesError) throw deliveriesError;

      const totalDeliveries = deliveries.length;
      const pendingDeliveries = deliveries.filter(d => d.status === 'pending').length;
      const completedDeliveries = deliveries.filter(d => d.status === 'delivered').length;
      const totalEarnings = deliveries.reduce((sum, d) => sum + (d.value || 0), 0);

      // Profiles stats (drivers)
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, status');

      if (profilesError) throw profilesError;

      const totalDrivers = profiles?.filter(p => p.status !== 'client' && p.status !== 'restaurant').length || 0;
      const pendingDrivers = profiles?.filter(d => d.status === 'pending_approval' || d.status === 'pending').length || 0;
      const activeDrivers = profiles?.filter(d => d.status === 'approved').length || 0;
      
      const approvalRate = totalDrivers > 0 ? (activeDrivers / totalDrivers) * 100 : 0;

      // User roles to count clients and restaurants
      const { data: userRoles, error: userRolesError } = await supabase
        .from('user_roles')
        .select('role');

      if (userRolesError) throw userRolesError;

      const totalClients = userRoles?.filter(r => r.role === 'client').length || 0;
      const totalRestaurants = userRoles?.filter(r => r.role === 'restaurant').length || 0;

      // Withdrawals stats
      const { data: withdrawals, error: withdrawalsError } = await supabase
        .from('withdrawals')
        .select('*')
        .eq('status', 'pending');

      if (withdrawalsError) throw withdrawalsError;

      const pendingWithdrawals = withdrawals.length;

      setStats({
        totalDeliveries,
        pendingDeliveries,
        completedDeliveries,
        totalDrivers,
        pendingDrivers,
        activeDrivers,
        totalClients,
        totalRestaurants,
        pendingWithdrawals,
        totalEarnings,
        approvalRate,
      });

    } catch (error: any) {
      toast({
        title: "Erro ao carregar estatísticas",
        description: error.message || "Não foi possível carregar os dados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  return { stats, isLoading, loadStats };
};