import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import type { AdminDelivery } from './useAdminDeliveries';

export interface AdminAlert {
  id: string;
  type: 'late_pickup' | 'late_delivery' | 'not_delivered_return' | 'new_pending';
  message: string;
  deliveryId: string;
  timestamp: Date;
  isRead: boolean;
}

export const useAdminAlerts = (deliveries: AdminDelivery[]) => {
  const { toast } = useToast();
  const [alerts, setAlerts] = useState<AdminAlert[]>([]);

  useEffect(() => {
    const generateAlerts = () => {
      const newAlerts: AdminAlert[] = [];
      const now = new Date();

      deliveries.forEach(delivery => {
        // Alert: New pending delivery (if it's very recent)
        const createdAt = new Date(delivery.created_at || '');
        if (delivery.status === 'pending' && (now.getTime() - createdAt.getTime()) < (5 * 60 * 1000)) { // Less than 5 minutes old
          if (!alerts.some(a => a.deliveryId === delivery.id && a.type === 'new_pending')) {
            newAlerts.push({
              id: `new_pending_${delivery.id}`,
              type: 'new_pending',
              message: `📦 Novo pedido pendente: #${delivery.tracking_number} para ${delivery.customer_name}`,
              deliveryId: delivery.id,
              timestamp: now,
              isRead: false,
            });
          }
        }

        // Alert: Late pickup
        if (delivery.status === 'pending' || delivery.status === 'picked_up') {
          const pickupDeadline = new Date(createdAt.getTime() + 30 * 60 * 1000); // 30 minutes to pickup
          if (now > pickupDeadline) {
            if (!alerts.some(a => a.deliveryId === delivery.id && a.type === 'late_pickup')) {
              newAlerts.push({
                id: `late_pickup_${delivery.id}`,
                type: 'late_pickup',
                message: `⏰ Atraso na coleta: Pedido #${delivery.tracking_number} deveria ter sido coletado.`,
                deliveryId: delivery.id,
                timestamp: now,
                isRead: false,
              });
            }
          }
        }

        // Alert: Late delivery (if in_transit and past estimated time)
        if (delivery.status === 'in_transit' && delivery.pickup_time) {
          const pickupTime = new Date(delivery.pickup_time);
          // Assuming an average delivery time of 45 minutes after pickup
          const deliveryDeadline = new Date(pickupTime.getTime() + 45 * 60 * 1000); 
          if (now > deliveryDeadline) {
            if (!alerts.some(a => a.deliveryId === delivery.id && a.type === 'late_delivery')) {
              newAlerts.push({
                id: `late_delivery_${delivery.id}`,
                type: 'late_delivery',
                message: `🚨 Atraso na entrega: Pedido #${delivery.tracking_number} para ${delivery.customer_name} está atrasado.`,
                deliveryId: delivery.id,
                timestamp: now,
                isRead: false,
              });
            }
          }
        }

        // Alert: Not delivered and needs return
        if (delivery.status === 'not_delivered' && delivery.pickup_time) {
          const notDeliveredTime = new Date(delivery.updated_at || delivery.pickup_time);
          const returnDeadline = new Date(notDeliveredTime.getTime() + 60 * 60 * 1000); // 1 hour to return
          if (now > returnDeadline) {
            if (!alerts.some(a => a.deliveryId === delivery.id && a.type === 'not_delivered_return')) {
              newAlerts.push({
                id: `not_delivered_return_${delivery.id}`,
                type: 'not_delivered_return',
                message: `⚠️ Devolução pendente: Pedido #${delivery.tracking_number} não entregue e precisa ser devolvido.`,
                deliveryId: delivery.id,
                timestamp: now,
                isRead: false,
              });
            }
          }
        }
      });

      // Filter out old alerts that are no longer relevant (e.g., delivery status changed)
      const relevantAlerts = alerts.filter(alert => {
        const delivery = deliveries.find(d => d.id === alert.deliveryId);
        if (!delivery) return false; // Delivery no longer exists

        if (alert.type === 'late_pickup' && (delivery.status === 'in_transit' || delivery.status === 'delivered')) return false;
        if (alert.type === 'late_delivery' && delivery.status === 'delivered') return false;
        if (alert.type === 'not_delivered_return' && delivery.status === 'cancelled') return false;
        if (alert.type === 'new_pending' && delivery.status !== 'pending') return false;

        return true;
      });

      // Combine existing relevant alerts with new ones, avoiding duplicates
      const combinedAlerts = [...relevantAlerts];
      newAlerts.forEach(newAlert => {
        if (!combinedAlerts.some(existing => existing.id === newAlert.id)) {
          combinedAlerts.push(newAlert);
          toast({
            title: "Alerta Administrativo! 🚨",
            description: newAlert.message,
            duration: 10000,
            variant: newAlert.type === 'new_pending' ? 'default' : 'destructive',
          });
        }
      });

      // Sort alerts by timestamp (most recent first)
      combinedAlerts.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
      setAlerts(combinedAlerts);
    };

    // Run alert generation every minute
    const interval = setInterval(generateAlerts, 60 * 1000);
    generateAlerts(); // Run immediately on mount

    return () => clearInterval(interval);
  }, [deliveries, toast]);

  const markAlertAsRead = (id: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === id ? { ...alert, isRead: true } : alert
    ));
  };

  return { alerts, markAlertAsRead };
};