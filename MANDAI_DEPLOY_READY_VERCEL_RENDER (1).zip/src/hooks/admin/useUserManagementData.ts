import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Tables, Enums } from '@/integrations/supabase/types';

// Extend the profile type with role information
export interface UserProfile extends Tables<'profiles'> {
  role: Enums<'app_role'> | null;
}

export const useUserManagementData = () => {
  const { toast } = useToast();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchUsers = async () => {
    try {
      setIsLoading(true);
      // Fetch all profiles and their roles
      const { data, error } = await supabase
        .from('profiles')
        .select('*, user_roles(role)')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedUsers: UserProfile[] = (data || []).map(profile => ({
        ...profile,
        // user_roles is an array, but we expect a single role for simplicity here
        role: (profile.user_roles?.[0]?.role as Enums<'app_role'>) || null,
      }));
      
      setUsers(formattedUsers);
    } catch (error: any) {
      toast({
        title: "Erro ao carregar usuários",
        description: error.message || "Não foi possível buscar os dados dos usuários",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateUserStatus = async (userId: string, newStatus: string, userName: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: `Usuário ${newStatus === 'approved' ? 'ativado' : 'desativado'}! ✅`,
        description: `${userName} agora está ${newStatus === 'approved' ? 'ativo' : 'desativado'}.`,
      });

      fetchUsers(); // Refresh the list
    } catch (error: any) {
      toast({
        title: `Erro ao ${newStatus === 'approved' ? 'ativar' : 'desativar'} usuário`,
        description: error.message || "Tente novamente",
        variant: "destructive",
      });
    }
  };

  const activateUser = async (userId: string, userName: string) => {
    await updateUserStatus(userId, 'approved', userName);
  };

  const deactivateUser = async (userId: string, userName: string) => {
    await updateUserStatus(userId, 'deactivated', userName);
  };

  const updateUserRole = async (userId: string, newRole: Enums<'app_role'>) => {
    try {
      // Check if role already exists for user
      const { data: existingRole, error: fetchRoleError } = await supabase
        .from('user_roles')
        .select('id')
        .eq('user_id', userId)
        .single();

      if (fetchRoleError && fetchRoleError.code !== 'PGRST116') { // PGRST116 means "no rows found"
        throw fetchRoleError;
      }

      if (existingRole) {
        // Update existing role
        const { error } = await supabase
          .from('user_roles')
          .update({ role: newRole, updated_at: new Date().toISOString() as any }) // updated_at might not exist in user_roles
          .eq('user_id', userId);
        if (error) throw error;
      } else {
        // Insert new role
        const { error } = await supabase
          .from('user_roles')
          .insert({ user_id: userId, role: newRole });
        if (error) throw error;
      }

      toast({
        title: "Função atualizada! ✅",
        description: `A função do usuário foi alterada para ${newRole}.`,
      });

      fetchUsers(); // Refresh the list
    } catch (error: any) {
      toast({
        title: "Erro ao atualizar função",
        description: error.message || "Não foi possível atualizar a função do usuário",
        variant: "destructive",
      });
    }
  };

  return { users, isLoading, fetchUsers, activateUser, deactivateUser, updateUserRole };
};