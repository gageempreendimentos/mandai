import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

// --- Types ---
export interface DriverProfile {
  id: string;
  nome_completo: string;
  cpf: string;
  rg: string;
  email: string;
  telefone: string;
  cep: string;
  rua: string;
  numero: string;
  complemento: string;
  bairro: string;
  cidade: string;
  estado: string;
  tipo_veiculo: string;
  marca_veiculo: string;
  modelo_veiculo: string;
  ano_veiculo: string;
  placa_veiculo: string;
  cor_veiculo: string;
  cnh_url: string;
  comprovante_endereco_url: string;
  documento_veiculo_url: string;
  status: string;
  created_at: string;
}

export const useDriverData = () => {
  const { toast } = useToast();
  const [drivers, setDrivers] = useState<DriverProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadPendingDrivers = async () => {
    try {
      setIsLoading(true);
      // Buscar perfis com status pendente (todos são entregadores)
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .in('status', ['pending', 'pending_approval'])
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDrivers((data || []) as DriverProfile[]);
    } catch (error) {
      toast({
        title: "Erro ao carregar entregadores",
        description: "Não foi possível buscar os dados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const approveDriver = async (driverId: string, driverName: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status: 'approved', updated_at: new Date().toISOString() })
        .eq('id', driverId);

      if (error) throw error;

      await supabase
        .from('notifications')
        .insert({
          driver_id: driverId,
          title: "Conta aprovada!",
          message: "Sua conta foi aprovada. Agora você pode fazer entregas.",
          type: 'account',
        });

      toast({
        title: "Entregador aprovado! ✅",
        description: `${driverName} agora pode fazer entregas`,
      });

      loadPendingDrivers();
    } catch (error) {
      toast({
        title: "Erro ao aprovar",
        description: "Não foi possível aprovar o entregador",
        variant: "destructive",
      });
    }
  };

  const rejectDriver = async (driverId: string, driverName: string, reason: string) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ status: 'rejected', updated_at: new Date().toISOString() })
        .eq('id', driverId);

      if (error) throw error;

      await supabase
        .from('notifications')
        .insert({
          driver_id: driverId,
          title: "Conta rejeitada",
          message: `Sua conta foi rejeitada. Motivo: ${reason}`,
          type: 'account',
        });

      toast({
        title: "Entregador rejeitado",
        description: `${driverName} foi notificado`,
        variant: "default",
      });

      loadPendingDrivers();
    } catch (error) {
      toast({
        title: "Erro ao rejeitar",
        description: "Não foi possível rejeitar o entregador",
        variant: "destructive",
      });
    }
  };

  return { drivers, isLoading, loadPendingDrivers, approveDriver, rejectDriver };
};