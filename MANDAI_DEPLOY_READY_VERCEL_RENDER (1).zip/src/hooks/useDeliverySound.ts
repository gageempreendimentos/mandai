import { useEffect, useRef, useCallback } from 'react';

export const useDeliverySound = (enabled: boolean = true) => {
  const audioContextRef = useRef<AudioContext | null>(null);
  const isPlayingRef = useRef(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const playOnce = useCallback(() => {
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      
      const ctx = audioContextRef.current;
      
      const playTone = (frequency: number, startTime: number, duration: number) => {
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        oscillator.frequency.value = frequency;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0, ctx.currentTime + startTime);
        gainNode.gain.linearRampToValueAtTime(0.3, ctx.currentTime + startTime + 0.05);
        gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + startTime + duration);
        
        oscillator.start(ctx.currentTime + startTime);
        oscillator.stop(ctx.currentTime + startTime + duration);
      };
      
      // Play a 3-note ascending melody
      playTone(523.25, 0, 0.15);    // C5
      playTone(659.25, 0.15, 0.15); // E5
      playTone(783.99, 0.3, 0.2);   // G5
      
      // Repeat the melody
      playTone(523.25, 0.6, 0.15);
      playTone(659.25, 0.75, 0.15);
      playTone(783.99, 0.9, 0.2);
      
    } catch (error) {
      console.log('Audio not supported');
    }
  }, []);

  const startContinuousSound = useCallback(() => {
    if (!enabled) return;
    if (isPlayingRef.current) return;
    
    isPlayingRef.current = true;
    playOnce();
    
    // Repeat sound every 2 seconds
    intervalRef.current = setInterval(() => {
      if (isPlayingRef.current) {
        playOnce();
      }
    }, 2000);
  }, [playOnce]);

  const stopSound = useCallback(() => {
    isPlayingRef.current = false;
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      stopSound();
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, [stopSound]);

  return { startContinuousSound, stopSound };
};