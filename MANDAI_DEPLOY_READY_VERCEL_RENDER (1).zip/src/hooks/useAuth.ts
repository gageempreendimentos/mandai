import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

// Hook para verificar autenticação
export const useAuth = () => {
  return useQuery({
    queryKey: ['auth'],
    queryFn: async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        return user;
      } catch (error) {
        console.error('Erro ao verificar autenticação:', error);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5, // 5 minutos
    retry: 1, // Tentar novamente uma vez
  });
};

// Hook para login
export const useLogin = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const navigate = useNavigate();

  return useMutation({
    mutationFn: async ({ email, password }: { email: string; password: string }) => {
      // Adicionar timeout manual
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        clearTimeout(timeoutId);
        
        if (error) throw error;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['auth'] });
      navigate('/dashboard');
    },
    onError: (error: any) => {
      // Tratar erro de timeout
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "A requisição demorou muito. Verifique sua conexão e tente novamente.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro ao fazer login",
        description: error.message || 'Verifique suas credenciais',
        variant: "destructive",
      });
    },
  });
};

// Hook para logout
export const useLogout = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const navigate = useNavigate();

  return useMutation({
    mutationFn: async () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      try {
        await supabase.auth.signOut();
        clearTimeout(timeoutId);
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.clear();
      toast({
        title: "Logout efetuado",
        description: "Até logo!",
      });
      navigate('/');
    },
    onError: (error: any) => {
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "Tente novamente.",
          variant: "destructive",
        });
        return;
      }
      
      toast({
        title: "Erro ao fazer logout",
        description: "Tente novamente",
        variant: "destructive",
      });
    },
  });
};

// Hook para cadastro
export const useRegister = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (userData: {
      email: string;
      password: string;
      cpf: string;
      nome_completo: string;
      telefone: string;
    }) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        // 1. Criar usuário no Auth
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: userData.email,
          password: userData.password,
        });

        clearTimeout(timeoutId);

        if (authError) throw authError;
        if (!authData.user) throw new Error('Não foi possível criar o usuário');

        // 2. Criar perfil
        const { error: profileError } = await supabase
          .from('profiles')
          .insert({
            id: authData.user.id,
            email: userData.email,
            cpf: userData.cpf,
            nome_completo: userData.nome_completo,
            telefone: userData.telefone,
            status: 'pending',
          });

        if (profileError) throw profileError;

        // 3. Criar role
        const { error: roleError } = await supabase
          .from('user_roles')
          .insert({
            user_id: authData.user.id,
            role: 'driver',
          });

        if (roleError) throw roleError;

        return authData.user;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['auth'] });
      toast({
        title: "Cadastro solicitado! 🎉",
        description: "Seus dados foram enviados para análise",
      });
    },
    onError: (error: any) => {
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "A requisição demorou muito. Verifique sua conexão.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro no cadastro",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};