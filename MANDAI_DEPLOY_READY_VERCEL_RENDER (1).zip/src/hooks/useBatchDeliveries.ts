import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Tables } from '@/integrations/supabase/types';
import { calculateRouteFromAddresses, formatDistance, formatDuration } from '@/lib/routeCalculator';

// Tipo de entrega do banco
type DeliveryRow = Tables<'deliveries'>;

// Interface simplificada para entregas no batch
interface BatchDeliveryItem {
  id: string;
  pickup_address: string;
  delivery_address: string;
  customer_name: string;
  value: number;
  pickup: {
    name: string;
    address: string;
  };
  dropoff: {
    name: string;
    address: string;
    phone: string;
  };
  distance: string;
  estimatedTime: string;
}

// Interface para múltiplas entregas
export interface BatchDelivery {
  deliveries: BatchDeliveryItem[];
  totalValue: number;
  totalTime: number;
  totalDistance: number;
  optimizedOrder: string[]; // IDs das entregas em ordem otimizada
  clusterCenter: {
    lat: number;
    lng: number;
  };
}

// Transforma um DeliveryRow em BatchDeliveryItem
function transformDelivery(delivery: DeliveryRow): BatchDeliveryItem {
  return {
    id: delivery.id,
    pickup_address: delivery.pickup_address,
    delivery_address: delivery.delivery_address,
    customer_name: delivery.customer_name,
    value: delivery.value || 0,
    pickup: {
      name: delivery.pickup_address.split(',')[0] || 'Local de coleta',
      address: delivery.pickup_address,
    },
    dropoff: {
      name: delivery.customer_name,
      address: delivery.delivery_address,
      phone: '(11) 99999-9999',
    },
    distance: '3.2 km',
    estimatedTime: '15 min',
  };
}

// Hook para buscar entregas agrupadas (próximas)
export const useBatchDeliveries = () => {
  return useQuery({
    queryKey: ['batches', 'available'],
    queryFn: async () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Usuário não autenticado');

        // Buscar entregas pending
        const { data: deliveries, error } = await supabase
          .from('deliveries')
          .select('*')
          .eq('status', 'pending')
          .is('driver_id', null)
          .order('created_at', { ascending: false })
          .limit(15); // Aumentado para ter mais opções de agrupamento

        clearTimeout(timeoutId);

        if (error) throw error;
        if (!deliveries || deliveries.length === 0) return [];

        // Agrupar entregas próximas usando algoritmo aprimorado
        const batches: BatchDelivery[] = [];
        const usedIds = new Set<string>();
        
        // Primeiro, vamos agrupar por proximidade geográfica
        for (let i = 0; i < deliveries.length; i++) {
          if (usedIds.has(deliveries[i].id)) continue;
          
          const currentDelivery = deliveries[i];
          const batchItems: BatchDeliveryItem[] = [transformDelivery(currentDelivery)];
          usedIds.add(currentDelivery.id);
          
          // Calcular centro do cluster (ponto de coleta)
          let centerLat = currentDelivery.pickup_lat || -23.5505;
          let centerLng = currentDelivery.pickup_lng || -46.6333;
          let clusterSize = 1;
          
          // Procurar entregas próximas (até 3km de distância)
          for (let j = i + 1; j < deliveries.length; j++) {
            if (usedIds.has(deliveries[j].id)) continue;
            
            const nextDelivery = deliveries[j];
            const distance = await calculateDistanceBetween(
              currentDelivery.pickup_address,
              nextDelivery.pickup_address
            );
            
            // Se estiver dentro de 3km e o lote ainda não está cheio (máx 4 entregas)
            if (distance <= 3.0 && batchItems.length < 4) {
              batchItems.push(transformDelivery(nextDelivery));
              usedIds.add(nextDelivery.id);
              
              // Atualizar centro do cluster
              if (nextDelivery.pickup_lat && nextDelivery.pickup_lng) {
                centerLat = (centerLat * clusterSize + nextDelivery.pickup_lat) / (clusterSize + 1);
                centerLng = (centerLng * clusterSize + nextDelivery.pickup_lng) / (clusterSize + 1);
                clusterSize++;
              }
            }
          }
          
          // Se temos pelo menos 2 entregas, cria um batch
          if (batchItems.length >= 2) {
            const batchData = await calculateBatchMetrics(batchItems, centerLat, centerLng);
            batches.push(batchData);
          }
        }
        
        // Ordenar batches por valor total (maior valor primeiro)
        batches.sort((a, b) => b.totalValue - a.totalValue);
        
        return batches;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 2, // 2 minutos
    retry: 1,
  });
};

// Hook para aceitar múltiplas entregas
export const useAcceptBatch = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (batch: BatchDelivery) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Usuário não autenticado');
        
        // Aceitar todas as entregas da batch
        const updates = batch.deliveries.map(delivery => 
          supabase
            .from('deliveries')
            .update({
              driver_id: user.id,
              status: 'in_transit' as const,
              pickup_time: new Date().toISOString(),
            })
            .eq('id', delivery.id)
        );
        
        const results = await Promise.all(updates);
        const errors = results.filter(r => r.error);
        
        clearTimeout(timeoutId);
        
        if (errors.length > 0) {
          throw new Error(`Falha ao aceitar ${errors.length} entregas`);
        }
        
        return batch;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: (batch) => {
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      queryClient.invalidateQueries({ queryKey: ['batches'] });
      toast({
        title: `✅ ${batch.deliveries.length} entregas aceitas!`,
        description: `Rota otimizada: ${batch.totalDistance.toFixed(1)}km, ${batch.totalTime}min, R$${batch.totalValue.toFixed(2)}`,
        duration: 8000,
      });
    },
    onError: (error: any) => {
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "Tente novamente.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro ao aceitar batch",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Funções auxiliares
async function calculateDistanceBetween(address1: string, address2: string): Promise<number> {
  const route = await calculateRouteFromAddresses(address1, address2);
  return route ? route.distance : 999;
}

async function calculateBatchMetrics(
  deliveries: BatchDeliveryItem[], 
  centerLat: number, 
  centerLng: number
): Promise<BatchDelivery> {
  let totalValue = 0;
  let totalDistance = 0;
  let totalTime = 0;
  const optimizedOrder: string[] = [];
  
  // Calcular métricas para cada entrega
  for (let i = 0; i < deliveries.length; i++) {
    totalValue += deliveries[i].value;
    optimizedOrder.push(deliveries[i].id);
    
    // Calcular distância da coleta (do centro do cluster até o ponto de coleta)
    // Esta é uma simplificação - em produção usaria coordenadas reais
    const pickupDistance = 0.5 + (i * 0.3); // Distância crescente para simular otimização
    totalDistance += pickupDistance;
    totalTime += Math.round(pickupDistance * 3); // 3 minutos por km
    
    // Adicionar tempo de entrega (5 minutos por entrega)
    totalTime += 5;
  }
  
  return {
    deliveries,
    totalValue,
    totalTime: Math.round(totalTime),
    totalDistance,
    optimizedOrder,
    clusterCenter: {
      lat: centerLat,
      lng: centerLng,
    }
  };
}