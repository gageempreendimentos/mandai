import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface ValidationParams {
  userId: string;
  cnhFile?: File | null;
  comprovanteFile?: File | null;
  documentoVeiculoFile?: File | null;
}

export const useDocumentValidation = () => {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (params: ValidationParams) => {
      const errors: string[] = [];

      // Validar CNH
      if (params.cnhFile) {
        const validation = validateDocument(params.cnhFile, ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], 5);
        if (!validation.valid) errors.push(`CNH: ${validation.message}`);
      }

      // Validar Comprovante
      if (params.comprovanteFile) {
        const validation = validateDocument(params.comprovanteFile, ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], 5);
        if (!validation.valid) errors.push(`Comprovante: ${validation.message}`);
      }

      // Validar Documento Veículo
      if (params.documentoVeiculoFile) {
        const validation = validateDocument(params.documentoVeiculoFile, ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], 5);
        if (!validation.valid) errors.push(`Documento Veículo: ${validation.message}`);
      }

      if (errors.length > 0) {
        throw new Error(errors.join('\n'));
      }

      // Upload para Supabase Storage
      const uploadResults = [];
      
      if (params.cnhFile) {
        const { data, error } = await supabase.storage
          .from('documents')
          .upload(`cnh/${Date.now()}_${params.cnhFile.name}`, params.cnhFile);
        
        if (error) throw error;
        uploadResults.push('CNH');
      }

      if (params.comprovanteFile) {
        const { data, error } = await supabase.storage
          .from('documents')
          .upload(`comprovante/${Date.now()}_${params.comprovanteFile.name}`, params.comprovanteFile);
        
        if (error) throw error;
        uploadResults.push('Comprovante');
      }

      if (params.documentoVeiculoFile) {
        const { data, error } = await supabase.storage
          .from('documents')
          .upload(`veiculo/${Date.now()}_${params.documentoVeiculoFile.name}`, params.documentoVeiculoFile);
        
        if (error) throw error;
        uploadResults.push('Documento Veículo');
      }

      return { success: true, uploads: uploadResults };
    },
    onError: (error: any) => {
      toast({
        title: "Erro na validação",
        description: error.message || 'Verifique os documentos e tente novamente',
        variant: "destructive",
        duration: 6000,
      });
    },
    onSuccess: (result) => {
      toast({
        title: "Documentos validados! ✅",
        description: `${result.uploads.length} arquivos enviados com sucesso`,
      });
    },
  });
};

// Funções auxiliares
function validateDocument(file: File, validTypes: string[], maxSizeMB: number) {
  const sizeMB = file.size / 1024 / 1024;
  
  if (!validTypes.includes(file.type)) {
    return { valid: false, message: 'Formato inválido. Use JPG, PNG ou PDF' };
  }
  
  if (sizeMB > maxSizeMB) {
    return { valid: false, message: `Arquivo muito grande. Máximo: ${maxSizeMB}MB` };
  }

  return { valid: true };
}