import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

/**
 * Hook genérico para buscar entregas do banco de dados
 * Retorna os dados brutos do Supabase, sem transformação
 */
export const useDeliveriesQuery = () => {
  return useQuery({
    queryKey: ['deliveries-raw'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('deliveries')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 2,
    gcTime: 1000 * 60 * 5,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    retry: true,
  });
};