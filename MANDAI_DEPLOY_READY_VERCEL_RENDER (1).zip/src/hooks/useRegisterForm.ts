import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useCPFValidation } from '@/lib/cpfValidation';
import { useRegisterProgress } from '@/hooks/useRegisterProgress';
import type { Tables } from '@/integrations/supabase/types'; // Import Supabase types

export interface FormData {
  nomeCompleto: string;
  cpf: string;
  rg: string;
  dataNascimento: string;
  telefone: string;
  email: string;
  senha: string;
  confirmarSenha: string;
  cep: string;
  rua: string;
  numero: string;
  complemento: string;
  bairro: string;
  cidade: string;
  estado: string;
  tipoVeiculo: 'moto' | 'carro' | 'bicicleta' | 'van' | 'caminhao' | '';
  marca: string;
  modelo: string;
  ano: string;
  placa: string;
  cor: string;
  // File names for persistence (not the File objects themselves)
  cnhFileName: string;
  comprovanteEnderecoFileName: string;
  documentoVeiculoFileName: string;
}

export const useRegisterForm = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const { validateAndNotify } = useCPFValidation();
  
  // Hook do Zustand para persistência
  const { step, setStep, formData: savedData, setFormData: saveFormData, reset: resetProgress } = useRegisterProgress();
  
  // Estado local para dados do formulário
  const [formData, setFormData] = useState<FormData>({
    nomeCompleto: '',
    cpf: '',
    rg: '',
    dataNascimento: '',
    telefone: '',
    email: '',
    senha: '',
    confirmarSenha: '',
    cep: '',
    rua: '',
    numero: '',
    complemento: '',
    bairro: '',
    cidade: '',
    estado: '',
    tipoVeiculo: '',
    marca: '',
    modelo: '',
    ano: '',
    placa: '',
    cor: '',
    cnhFileName: '',
    comprovanteEnderecoFileName: '',
    documentoVeiculoFileName: '',
  });

  // Estados para os objetos File (não persistidos no Zustand diretamente)
  const [cnhFile, setCnhFile] = useState<File | null>(null);
  const [comprovanteEnderecoFile, setComprovanteEnderecoFile] = useState<File | null>(null);
  const [documentoVeiculoFile, setDocumentoVeiculoFile] = useState<File | null>(null);

  // Ref para evitar múltiplos salvamentos simultâneos
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Carregar dados salvos do Zustand ao iniciar
  useEffect(() => {
    if (savedData && Object.values(savedData).some(v => v)) {
      setFormData(prev => ({ ...prev, ...savedData }));
    }
  }, [savedData]);

  // Função para salvar progresso com debounce
  const saveProgress = () => {
    // Limpa timeout anterior se existir
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    
    // Aguarda 500ms antes de salvar (debounce)
    saveTimeoutRef.current = setTimeout(() => {
      console.log(`[useRegisterForm] Salvando progresso...`, formData);
      // Salva os dados do formulário (incluindo nomes de arquivos para persistência)
      saveFormData(formData);
    }, 500);
  };

  // Função para atualizar múltiplos campos do formData de uma vez
  const updateFormData = (updates: Partial<FormData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    updateFormData({ [field]: value });
    saveProgress(); // Salva progresso a cada digitação
  };

  const handleAddressFound = (addressData: Partial<FormData>) => {
    updateFormData(addressData);
    saveProgress(); // Salva progresso quando endereço é encontrado
  };

  const handleFileChange = (field: 'cnhFile' | 'comprovanteEnderecoFile' | 'documentoVeiculoFile', file: File | null) => {
    if (field === 'cnhFile') {
        setCnhFile(file);
        saveFormData({ cnhFileName: file ? file.name : '' });
    } else if (field === 'comprovanteEnderecoFile') {
        setComprovanteEnderecoFile(file);
        saveFormData({ comprovanteEnderecoFileName: file ? file.name : '' });
    } else if (field === 'documentoVeiculoFile') {
        setDocumentoVeiculoFile(file);
        saveFormData({ documentoVeiculoFileName: file ? file.name : '' });
    }
    saveProgress();
  };

  const validateStep1 = () => {
    const cleanCPF = formData.cpf.replace(/\D/g, '');
    
    if (!formData.nomeCompleto || formData.nomeCompleto.length < 3) {
      toast({ title: "Nome inválido", description: "Digite seu nome completo", variant: "destructive" });
      return false;
    }
    
    if (!validateAndNotify(formData.cpf)) {
      return false;
    }
    
    if (!formData.dataNascimento) {
      toast({ title: "Data inválida", description: "Digite sua data de nascimento", variant: "destructive" });
      return false;
    }
    
    if (formData.telefone.replace(/\D/g, '').length < 10) {
      toast({ title: "Telefone inválido", description: "Digite um telefone válido", variant: "destructive" });
      return false;
    }
    
    if (!formData.email.includes('@')) {
      toast({ title: "E-mail inválido", description: "Digite um e-mail válido", variant: "destructive" });
      return false;
    }
    
    if (formData.senha.length < 6) {
      toast({ title: "Senha fraca", description: "A senha deve ter pelo menos 6 caracteres", variant: "destructive" });
      return false;
    }
    
    if (formData.senha !== formData.confirmarSenha) {
      toast({ title: "Senhas diferentes", description: "As senhas não conferem", variant: "destructive" });
      return false;
    }
    
    return true;
  };

  const validateStep2 = () => {
    const cleanCep = formData.cep.replace(/\D/g, '');
    
    // Aceita 7 ou 8 dígitos
    if (cleanCep.length < 7) {
      toast({ title: "CEP inválido", description: "Digite um CEP com 7 ou 8 dígitos", variant: "destructive" });
      return false;
    }
    
    if (!formData.rua || !formData.numero || !formData.bairro || !formData.cidade || !formData.estado) {
      toast({ title: "Endereço incompleto", description: "Preencha todos os campos obrigatórios", variant: "destructive" });
      return false;
    }
    return true;
  };

  const validateStep3 = () => {
    if (!formData.tipoVeiculo) {
      toast({ title: "Tipo obrigatório", description: "Selecione o tipo de veículo", variant: "destructive" });
      return false;
    }
    
    // Se for bicicleta, não precisa validar marca/modelo/placa
    if (formData.tipoVeiculo === 'bicicleta') {
      return true;
    }
    
    if (!formData.marca || !formData.modelo) {
      toast({ title: "Veículo incompleto", description: "Preencha marca e modelo", variant: "destructive" });
      return false;
    }
    
    if (formData.placa.replace(/\D/g, '').length < 4) {
      toast({ title: "Placa inválida", description: "Digite a placa do veículo", variant: "destructive" });
      return false;
    }
    
    return true;
  };

  const validateStep4 = () => {
    if (!cnhFile && !formData.cnhFileName) { // Check both current file and persisted name
        toast({ title: "Documento obrigatório", description: "Envie a CNH", variant: "destructive" });
        return false;
    }
    if (!comprovanteEnderecoFile && !formData.comprovanteEnderecoFileName) {
        toast({ title: "Documento obrigatório", description: "Envie o comprovante de endereço", variant: "destructive" });
        return false;
    }
    // Only require vehicle document if not a bicycle
    if (formData.tipoVeiculo !== 'bicicleta' && !documentoVeiculoFile && !formData.documentoVeiculoFileName) {
        toast({ title: "Documento obrigatório", description: "Envie o documento do veículo", variant: "destructive" });
        return false;
    }
    return true;
  };

  const handleNext = () => {
    if (step === 1 && validateStep1()) {
      saveProgress();
      setStep(2);
    } else if (step === 2 && validateStep2()) {
      saveProgress();
      setStep(3);
    } else if (step === 3 && validateStep3()) {
      saveProgress();
      setStep(4); // Move to document step
    } else if (step === 4 && validateStep4()) { // New step validation
      saveProgress();
      handleSubmit(); // Final submission
    }
  };

  const handleBack = () => {
    if (step > 1) {
      saveProgress();
      setStep(step - 1);
    } else {
      if (confirm('Tem certeza que deseja sair? Seu progresso será salvo.')) {
        saveProgress();
        navigate('/');
      }
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    
    try {
      console.log('[handleSubmit] Iniciando cadastro...');
      console.log('[handleSubmit] Dados do formulário:', formData);

      // Adicionar timeout manual
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      // 1. Criar auth user
      console.log('[handleSubmit] Criando usuário no Auth...');
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.senha,
      });

      clearTimeout(timeoutId);

      if (authError) {
        console.error('[handleSubmit] Erro no Auth:', authError);
        throw authError;
      }

      if (!authData.user) {
        console.error('[handleSubmit] Auth data sem user');
        throw new Error('Não foi possível criar o usuário de autenticação');
      }

      console.log('[handleSubmit] Usuário de autenticação criado com ID:', authData.user.id);

      const userId = authData.user.id;
      const profileUpdates: Partial<Tables<'profiles'>> = {};

      // Upload CNH
      if (cnhFile) {
          const { data: cnhUploadData, error: cnhUploadError } = await supabase.storage
              .from('documents')
              .upload(`${userId}/cnh_${Date.now()}.jpg`, cnhFile, {
                  cacheControl: '3600',
                  upsert: false,
              });
          if (cnhUploadError) throw cnhUploadError;
          const { data: cnhUrlData } = supabase.storage.from('documents').getPublicUrl(cnhUploadData.path);
          profileUpdates.cnh_url = cnhUrlData.publicUrl;
      }

      // Upload Comprovante de Endereço
      if (comprovanteEnderecoFile) {
          const { data: compUploadData, error: compUploadError } = await supabase.storage
              .from('documents')
              .upload(`${userId}/comprovante_endereco_${Date.now()}.jpg`, comprovanteEnderecoFile, {
                  cacheControl: '3600',
                  upsert: false,
              });
          if (compUploadError) throw compUploadError;
          const { data: compUrlData } = supabase.storage.from('documents').getPublicUrl(compUploadData.path);
          profileUpdates.comprovante_endereco_url = compUrlData.publicUrl;
      }

      // Upload Documento do Veículo (se não for bicicleta)
      if (formData.tipoVeiculo !== 'bicicleta' && documentoVeiculoFile) {
          const { data: docUploadData, error: docUploadError } = await supabase.storage
              .from('documents')
              .upload(`${userId}/documento_veiculo_${Date.now()}.jpg`, documentoVeiculoFile, {
                  cacheControl: '3600',
                  upsert: false,
              });
          if (docUploadError) throw docUploadError;
          const { data: docUrlData } = supabase.storage.from('documents').getPublicUrl(docUploadData.path);
          profileUpdates.documento_veiculo_url = docUrlData.publicUrl;
      }

      // 2. Criar perfil
      console.log('[handleSubmit] Criando perfil...');
      const cleanCPF = formData.cpf.replace(/\D/g, '');
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          id: authData.user.id,
          nome_completo: formData.nomeCompleto,
          cpf: cleanCPF,
          rg: formData.rg || null,
          data_nascimento: formData.dataNascimento || null,
          telefone: formData.telefone,
          email: formData.email,
          cep: formData.cep.replace(/\D/g, '') || null,
          rua: formData.rua || null,
          numero: formData.numero || null,
          complemento: formData.complemento || null,
          bairro: formData.bairro || null,
          cidade: formData.cidade || null,
          estado: formData.estado || null,
          tipo_veiculo: formData.tipoVeiculo as 'moto' | 'carro' | 'bicicleta' | 'van' | 'caminhao' || null,
          marca_veiculo: formData.marca || null,
          modelo_veiculo: formData.modelo || null,
          ano_veiculo: formData.ano || null,
          placa_veiculo: formData.placa || null,
          cor_veiculo: formData.cor || null,
          status: 'pending',
          ...profileUpdates, // Add document URLs here
        });

      if (profileError) {
        console.error('[handleSubmit] Erro ao criar perfil:', profileError);
        throw profileError;
      }

      console.log('[handleSubmit] Perfil criado com sucesso');

      // 3. Criar role
      console.log('[handleSubmit] Criando role...');
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: authData.user.id,
          role: 'driver',
        });

      if (roleError) {
        console.error('[handleSubmit] Erro ao criar role:', roleError);
        throw roleError;
      }

      console.log('[handleSubmit] Role criada com sucesso');

      // 4. Limpar progresso salvo
      console.log('[handleSubmit] Limpando progresso salvo...');
      resetProgress();
      
      console.log('[handleSubmit] Cadastro concluído com sucesso!');
      toast({
        title: "Cadastro enviado! 🎉",
        description: "Seus dados foram enviados para análise. Aguarde a aprovação.",
      });
      navigate('/');
    } catch (error: any) {
      console.error('[handleSubmit] Erro no cadastro:', error);
      console.error('[handleSubmit] Detalhes do erro:', JSON.stringify(error, null, 2));
      
      // Tratamento específico para erros de timeout
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "A requisição demorou muito. Verifique sua conexão e tente novamente.",
          variant: "destructive",
        });
        return;
      }
      
      // Tratamento específico para erros do Supabase
      let errorMessage = "Nossos técnicos foram notificados. Tente novamente.";
      
      if (error.message) {
        errorMessage = error.message;
      } else if (error?.error_description) { // Supabase auth errors often have this
        errorMessage = error.error_description;
      } else if (error?.code) {
        errorMessage = `Erro: ${error.code}`;
      }
      
      toast({
        title: "Erro no cadastro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return {
    step,
    formData,
    isLoading,
    cnhFile,
    comprovanteEnderecoFile,
    documentoVeiculoFile,
    handleInputChange,
    handleAddressFound,
    handleFileChange,
    handleNext,
    handleBack,
    totalSteps: 4, // Updated to 4 steps
  };
};