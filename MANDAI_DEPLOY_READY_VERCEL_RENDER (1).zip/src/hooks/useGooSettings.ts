import { useEffect, useMemo, useState } from "react";
import { MandaiSettings, loadSettings, updateSettings } from "@/lib/mandaiSettings";

export function useMandaiSettings() {
  const [settings, setSettings] = useState<MandaiSettings>(() => loadSettings());

  useEffect(() => {
    // keep in sync across tabs
    const onStorage = (e: StorageEvent) => {
      if (e.key === "mandai.settings.v1") setSettings(loadSettings());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const api = useMemo(() => ({
    settings,
    set: (patch: Partial<MandaiSettings>) => {
      const next = updateSettings(patch);
      setSettings(next);
    },
  }), [settings]);

  return api;
}
