import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { geocodeAddress } from '@/lib/routeCalculator';

interface Coordinates {
  latitude: number;
  longitude: number;
}

// Hook para obter coordenadas de uma entrega específica
export const useDeliveryCoordinates = (deliveryId: string, address: string) => {
  return useQuery({
    queryKey: ['delivery-coordinates', deliveryId],
    queryFn: async () => {
      // Primeiro, tenta buscar do banco de dados
      const { data, error } = await supabase
        .from('deliveries')
        .select('pickup_lat, pickup_lng, delivery_lat, delivery_lng')
        .eq('id', deliveryId)
        .single();

      if (error) throw error;

      // Se já existem coordenadas salvas, retorna a correta
      if (data) {
        if (address === 'pickup' && data.pickup_lat && data.pickup_lng) {
          return { latitude: data.pickup_lat, longitude: data.pickup_lng };
        }
        if (address === 'delivery' && data.delivery_lat && data.delivery_lng) {
          return { latitude: data.delivery_lat, longitude: data.delivery_lng };
        }
      }

      // Se não existem, calcula a partir do endereço de texto
      const coords = await geocodeAddress(address);
      
      if (coords) {
        // Salva no banco para próxima vez
        const updateData: any = {};
        if (address === 'pickup') {
          updateData.pickup_lat = coords.lat;
          updateData.pickup_lng = coords.lng;
        } else {
          updateData.delivery_lat = coords.lat;
          updateData.delivery_lng = coords.lng;
        }

        await supabase
          .from('deliveries')
          .update(updateData)
          .eq('id', deliveryId);
      }

      return coords;
    },
    staleTime: 1000 * 60 * 60, // 1 hora
    enabled: !!deliveryId && !!address,
  });
};