import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';
import { getCurrentLocation } from '@/lib/getCurrentLocation';
import { calculateRouteFromAddresses, saveDeliveryCoordinates, formatDistance, formatDuration } from '@/lib/routeCalculator';

export type DeliveryStatus = Tables<'deliveries'>['status'];

export interface Delivery extends Tables<'deliveries'> {
  pickup: {
    name: string;
    address: string;
  };
  dropoff: {
    name: string;
    address: string;
    phone: string;
  };
  distance: string;
  estimatedTime: string;
  value: number;
}

// Buscar entregas disponíveis (pending)
export const useAvailableDeliveries = () => {
  return useQuery({
    queryKey: ['deliveries', 'available'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { data, error } = await supabase
        .from('deliveries')
        .select('*')
        .eq('status', 'pending')
        .is('driver_id', null)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const deliveriesWithRoute = await Promise.all(
        (data || []).map(async (delivery) => {
          if (delivery.pickup_lat && delivery.pickup_lng && delivery.delivery_lat && delivery.delivery_lng) {
            const { calculateRoute } = await import('@/lib/routeCalculator');
            const route = await calculateRoute(
              { lat: delivery.pickup_lat, lng: delivery.pickup_lng },
              { lat: delivery.delivery_lat, lng: delivery.delivery_lng }
            );
            
            return {
              ...delivery,
              pickup: {
                name: delivery.pickup_address.split(',')[0] || 'Local de coleta',
                address: delivery.pickup_address,
              },
              dropoff: {
                name: delivery.customer_name,
                address: delivery.delivery_address,
                phone: '(11) 99999-9999',
              },
              distance: formatDistance(route.distance),
              estimatedTime: formatDuration(route.duration),
              value: delivery.value || 0,
            };
          }
          
          const route = await calculateRouteFromAddresses(
            delivery.pickup_address,
            delivery.delivery_address
          );
          
          if (route) {
            const { geocodeAddress } = await import('@/lib/routeCalculator');
            const pickupCoords = await geocodeAddress(delivery.pickup_address);
            const dropoffCoords = await geocodeAddress(delivery.delivery_address);
            
            if (pickupCoords && dropoffCoords) {
              await saveDeliveryCoordinates(
                delivery.id,
                pickupCoords,
                dropoffCoords
              );
            }
            
            return {
              ...delivery,
              pickup: {
                name: delivery.pickup_address.split(',')[0] || 'Local de coleta',
                address: delivery.pickup_address,
              },
              dropoff: {
                name: delivery.customer_name,
                address: delivery.delivery_address,
                phone: '(11) 99999-9999',
              },
              distance: formatDistance(route.distance),
              estimatedTime: formatDuration(route.duration),
              value: delivery.value || 0,
            };
          }
          
          return {
            ...delivery,
            pickup: {
              name: delivery.pickup_address.split(',')[0] || 'Local de coleta',
              address: delivery.pickup_address,
            },
            dropoff: {
              name: delivery.customer_name,
              address: delivery.delivery_address,
              phone: '(11) 99999-9999',
            },
            distance: '3.2 km',
            estimatedTime: '15 min',
            value: delivery.value || 0,
          };
        })
      );

      return deliveriesWithRoute;
    },
    staleTime: 1000 * 60 * 5,
    refetchInterval: 0,
  });
};

// Buscar entregas do usuário logado
export const useUserDeliveries = () => {
  return useQuery({
    queryKey: ['deliveries', 'user'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { data, error } = await supabase
        .from('deliveries')
        .select('*')
        .eq('driver_id', user.id)
        .in('status', ['in_transit'])
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) throw error;
      if (!data || data.length === 0) return null;

      const delivery = data[0];
      
      let distance = '3.2 km';
      let estimatedTime = '15 min';
      
      if (delivery.pickup_lat && delivery.pickup_lng && delivery.delivery_lat && delivery.delivery_lng) {
        const { calculateRoute } = await import('@/lib/routeCalculator');
        const route = await calculateRoute(
          { lat: delivery.pickup_lat, lng: delivery.pickup_lng },
          { lat: delivery.delivery_lat, lng: delivery.delivery_lng }
        );
        distance = formatDistance(route.distance);
        estimatedTime = formatDuration(route.duration);
      } else if (delivery.pickup_address && delivery.delivery_address) {
        const route = await calculateRouteFromAddresses(
          delivery.pickup_address,
          delivery.delivery_address
        );
        if (route) {
          distance = formatDistance(route.distance);
          estimatedTime = formatDuration(route.duration);
        }
      }
      
      return {
        ...delivery,
        pickup: {
          name: delivery.pickup_address.split(',')[0] || 'Local de coleta',
          address: delivery.pickup_address,
        },
        dropoff: {
          name: delivery.customer_name,
          address: delivery.delivery_address,
          phone: '(11) 99999-9999',
        },
        distance,
        estimatedTime,
        value: delivery.value || 0,
      } as Delivery;
    },
    staleTime: 1000 * 60 * 5,
    refetchInterval: 0,
  });
};

// Aceitar entrega
export const useAcceptDelivery = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deliveryId: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { error } = await supabase
        .from('deliveries')
        .update({
          driver_id: user.id,
	          status: 'accepted' as const,
        })
        .eq('id', deliveryId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Entrega aceita! ✅",
        description: "Agora confirme a coleta no local",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao aceitar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Confirmar coleta
export const useConfirmPickup = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deliveryId: string) => {
      
const loc = await getCurrentLocation();
const { data, error } = await supabase.functions.invoke('update-delivery-status', {
  body: {
    delivery_id: deliveryId,
    to_status: 'picked_up',
    lat: loc?.lat,
    lng: loc?.lng,
  },
});

if (error) throw error;
if (data?.error) throw new Error(data.error);
    },
    onSuccess: () => {
      toast({
        title: "Coleta confirmada! 📦",
        description: "Agora entregue ao cliente",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao confirmar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Confirmar entrega
export const useConfirmDelivery = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ deliveryId, photo }: { deliveryId: string; photo?: File }) => {
      let photoUrl = null;
      if (photo) {
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('delivery-proofs')
          .upload(`${deliveryId}/${Date.now()}.jpg`, photo);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from('delivery-proofs')
          .getPublicUrl(uploadData.path);

        photoUrl = urlData.publicUrl;
      }

      
const loc = await getCurrentLocation();
const { data, error } = await supabase.functions.invoke('update-delivery-status', {
  body: {
    delivery_id: deliveryId,
    to_status: 'delivered',
    lat: loc?.lat,
    lng: loc?.lng,
    photo_url: photoUrl,
  },
});

if (error) throw error;
if (data?.error) throw new Error(data.error);
    },
    onSuccess: () => {
      toast({
        title: "Entrega concluída! 🎉",
        description: "Valor creditado na sua conta",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao confirmar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Não entregar
export const useNotDelivered = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ deliveryId, reason }: { deliveryId: string; reason: string }) => {
      
const loc = await getCurrentLocation();
const { data, error } = await supabase.functions.invoke('update-delivery-status', {
  body: {
    delivery_id: deliveryId,
    to_status: 'not_delivered',
    lat: loc?.lat,
    lng: loc?.lng,
    reason,
  },
});

if (error) throw error;
if (data?.error) throw new Error(data.error);
    },
    onSuccess: () => {
      toast({
        title: "Não entregue",
        description: "Retorne ao local de coleta",
        variant: "default",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao registrar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Devolver mercadoria
export const useReturnDelivery = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deliveryId: string) => {
      
const loc = await getCurrentLocation();
const { data, error } = await supabase.functions.invoke('update-delivery-status', {
  body: {
    delivery_id: deliveryId,
    to_status: 'cancelled',
    lat: loc?.lat,
    lng: loc?.lng,
    reason: 'Devolução/Cancelamento',
  },
});

if (error) throw error;
if (data?.error) throw new Error(data.error);
    },
    onSuccess: () => {
      toast({
        title: "Mercadoria devolvida",
        description: "Pedido encerrado",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao devolver",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};