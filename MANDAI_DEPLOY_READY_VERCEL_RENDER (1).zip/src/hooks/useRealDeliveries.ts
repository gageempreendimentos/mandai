import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/services/apiFetch';
import { calculateRouteFromAddresses, formatDistance, formatDuration } from '@/lib/routeCalculator';
import type { Delivery } from '@/types/delivery'; // Import the new modular Delivery type

export type DeliveryStatus = Tables<'deliveries'>['status'];

// Buscar entregas disponíveis (pending) do banco REAL
export const useAvailableDeliveriesReal = () => {
  return useQuery({
    queryKey: ['deliveries', 'available'],
    queryFn: async () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Usuário não autenticado');

        const { data, error } = await supabase
          .from('deliveries')
          .select('*')
          .eq('status', 'pending')
          .is('driver_id', null)
          .order('created_at', { ascending: false })
          .limit(10);

        clearTimeout(timeoutId);

        if (error) throw error;
        if (!data || data.length === 0) return [];

        const deliveriesWithRoutes = await Promise.all(
          data.map(async (delivery) => {
            // Se não tem coordenadas, calcula a partir do endereço
            let distance = '3.2 km';
            let estimatedTime = '15 min';
            let pickupCoords = null;
            let dropoffCoords = null;

            // Se tem coordenadas salvas, usa-as
            if (delivery.pickup_lat && delivery.pickup_lng && delivery.delivery_lat && delivery.delivery_lng) {
              pickupCoords = { lat: delivery.pickup_lat, lng: delivery.pickup_lng };
              dropoffCoords = { lat: delivery.delivery_lat, lng: delivery.delivery_lng };
            } else {
              // Calcula a partir dos endereços
              const route = await calculateRouteFromAddresses(
                delivery.pickup_address,
                delivery.delivery_address
              );
              
              if (route) {
                distance = formatDistance(route.distance);
                estimatedTime = formatDuration(route.duration);
              }
            }

            return {
              ...delivery,
              pickup: {
                name: delivery.pickup_address.split(',')[0] || 'Local de coleta',
                address: delivery.pickup_address,
                coordinates: pickupCoords,
              },
              dropoff: {
                name: delivery.customer_name,
                address: delivery.delivery_address,
                phone: '(11) 99999-9999',
                coordinates: dropoffCoords,
              },
              distance,
              estimatedTime,
              value: delivery.value || 0,
            } as Delivery;
          })
        );

        return deliveriesWithRoutes;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 2,
    refetchInterval: 0,
    retry: 1, // Tentar novamente uma vez
  });
};

// Buscar entregas do usuário logado
export const useUserDeliveries = () => {
  return useQuery({
    queryKey: ['deliveries', 'user'],
    queryFn: async () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Usuário não autenticado');

        const { data, error } = await supabase
          .from('deliveries')
          .select('*')
          .eq('driver_id', user.id)
          .in('status', ['in_transit', 'not_delivered'])
          .order('created_at', { ascending: false })
          .limit(1);

        clearTimeout(timeoutId);

        if (error) throw error;
        if (!data || data.length === 0) return null;

        const delivery = data[0];
        
        let distance = '3.2 km';
        let estimatedTime = '15 min';
        
        if (delivery.pickup_lat && delivery.pickup_lng && delivery.delivery_lat && delivery.delivery_lng) {
          const route = await calculateRouteFromAddresses(
            delivery.pickup_address,
            delivery.delivery_address
          );
          if (route) {
            distance = formatDistance(route.distance);
            estimatedTime = formatDuration(route.duration);
          }
        }
        
        return {
          ...delivery,
          pickup: {
            name: delivery.pickup_address.split(',')[0] || 'Local de coleta',
            address: delivery.pickup_address,
          },
          dropoff: {
            name: delivery.customer_name,
            address: delivery.delivery_address,
            phone: '(11) 99999-9999',
          },
          distance,
          estimatedTime,
          value: delivery.value || 0,
        } as Delivery;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5,
    refetchInterval: 0,
    retry: 1,
  });
};

// Aceitar entrega
export const useAcceptDeliveryReal = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deliveryId: string) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        // Enforce capacity/docs/blocking on the backend
        await apiFetch(`/rides/${deliveryId}/accept`, {
          method: "POST",
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeoutId);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      toast({
        title: "Entrega aceita! ✅",
        description: "Agora confirme a coleta no local",
      });
    },
    onError: (error: any) => {
      const msg = String(error?.message || "");
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "Tente novamente.",
          variant: "destructive",
        });
        return;
      }

      if (msg.includes("ride_already_taken")) {
        toast({
          title: "Essa entrega já foi pega",
          description: "Outro entregador aceitou antes. Aguarde a próxima.",
          variant: "destructive",
        });
        return;
      }

      if (msg.includes("driver_capacity_reached")) {
        toast({
          title: "Você já está em outra entrega",
          description: "Finalize a atual para aceitar outra.",
          variant: "destructive",
        });
        return;
      }

      if (msg.includes("docs_not_verified")) {
        toast({
          title: "Documentos pendentes",
          description: "Seu cadastro precisa ser verificado pelo admin.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro ao aceitar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Confirmar coleta
export const useConfirmPickup = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deliveryId: string) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { error } = await supabase
          .from('deliveries')
          .update({
	            // Coleta confirmada
	            status: 'picked_up' as const,
          })
          .eq('id', deliveryId);

        clearTimeout(timeoutId);

        if (error) throw error;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      toast({
        title: "Coleta confirmada! 📦",
        description: "Agora entregue ao cliente",
      });
    },
    onError: (error: any) => {
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "Tente novamente.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro ao confirmar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Confirmar entrega
export const useConfirmDelivery = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ deliveryId, photo }: { deliveryId: string; photo?: File }) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        let photoUrl = null;
        if (photo) {
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('delivery-photos')
            .upload(`${deliveryId}/${Date.now()}.jpg`, photo);

          if (uploadError) throw uploadError;

          const { data: urlData } = supabase.storage
            .from('delivery-photos')
            .getPublicUrl(uploadData.path);

          photoUrl = urlData.publicUrl;
        }

        const { error } = await supabase
          .from('deliveries')
          .update({
            status: 'delivered',
            delivery_time: new Date().toISOString(),
            photo_url: photoUrl,
          })
          .eq('id', deliveryId);

        clearTimeout(timeoutId);

        if (error) throw error;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      toast({
        title: "Entrega concluída! 🎉",
        description: "Valor creditado na sua conta",
      });
    },
    onError: (error: any) => {
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "Tente novamente.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro ao confirmar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Não entregar
export const useNotDelivered = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ deliveryId, reason }: { deliveryId: string; reason: string }) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { error } = await supabase
          .from('deliveries')
          .update({
            status: 'not_delivered',
            not_delivered_reason: reason,
            delivery_time: new Date().toISOString(),
          })
          .eq('id', deliveryId);

        clearTimeout(timeoutId);

        if (error) throw error;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      toast({
        title: "Não entregue",
        description: "Retorne ao local de coleta",
        variant: "default",
      });
    },
    onError: (error: any) => {
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "Tente novamente.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro ao registrar",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};

// Devolver mercadoria
export const useReturnDelivery = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deliveryId: string) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const { error } = await supabase
          .from('deliveries')
          .update({
            status: 'cancelled',
            updated_at: new Date().toISOString(),
          })
          .eq('id', deliveryId);

        clearTimeout(timeoutId);

        if (error) throw error;
      } catch (error) {
        clearTimeout(timeoutId);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      toast({
        title: "Mercadoria devolvida",
        description: "Pedido encerrado",
      });
    },
    onError: (error: any) => {
      if (error.name === 'AbortError' || error.message?.includes('abort')) {
        toast({
          title: "Tempo esgotado",
          description: "Tente novamente.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Erro ao devolver",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};