import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';

interface DemandForecast {
  hour: number;
  day: string;
  expectedDeliveries: number;
  peakHours: number[];
  bestEarningPotential: number;
  recommendedOnlineHours: string;
}

interface HistoricalDataPoint {
  timestamp: string;
  deliveries: number;
  location: { lat: number; lng: number };
  weather: string;
  traffic: number; // 1-10
}

export const useDemandForecast = (currentLocation: { lat: number; lng: number } | null) => {
  const [forecast, setForecast] = useState<DemandForecast[]>([]);
  
  // Simular dados históricos (em produção, isso viria do backend)
  const generateHistoricalData = (): HistoricalDataPoint[] => {
    const data: HistoricalDataPoint[] = [];
    const now = new Date();
    
    // Gerar dados para os últimos 30 dias
    for (let i = 0; i < 30; i++) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      
      // Gerar dados para cada hora do dia
      for (let hour = 6; hour < 24; hour++) {
        const timestamp = new Date(date);
        timestamp.setHours(hour, 0, 0, 0);
        
        // Simular padrões de demanda baseados em hora e dia
        const isWeekend = timestamp.getDay() === 0 || timestamp.getDay() === 6;
        const isPeakHour = (hour >= 12 && hour <= 14) || (hour >= 18 && hour <= 21);
        
        const baseDeliveries = isWeekend ? 8 : 12;
        const peakMultiplier = isPeakHour ? 2 : 1;
        const randomFactor = 0.8 + Math.random() * 0.4;
        
        const deliveries = Math.round(baseDeliveries * peakMultiplier * randomFactor);
        
        data.push({
          timestamp: timestamp.toISOString(),
          deliveries,
          location: {
            lat: -23.5505 + (Math.random() - 0.5) * 0.1,
            lng: -46.6333 + (Math.random() - 0.5) * 0.1
          },
          weather: ['sunny', 'cloudy', 'rainy'][Math.floor(Math.random() * 3)],
          traffic: Math.floor(Math.random() * 10) + 1
        });
      }
    }
    
    return data;
  };

  const calculateForecast = (): DemandForecast[] => {
    const historicalData = generateHistoricalData();
    const forecast: DemandForecast[] = [];
    
    // Calcular previsão para os próximos 7 dias
    const days = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    
    for (let i = 0; i < 7; i++) {
      const dayIndex = (new Date().getDay() + i) % 7;
      const day = days[dayIndex];
      
      // Agrupar dados por hora para este dia da semana
      const hourlyData: Record<number, number[]> = {};
      
      historicalData.forEach(dataPoint => {
        const dataDay = new Date(dataPoint.timestamp).getDay();
        if (dataDay === dayIndex) {
          const hour = new Date(dataPoint.timestamp).getHours();
          if (!hourlyData[hour]) {
            hourlyData[hour] = [];
          }
          hourlyData[hour].push(dataPoint.deliveries);
        }
      });
      
      // Calcular média por hora
      const hourlyAverages: Record<number, number> = {};
      Object.keys(hourlyData).forEach(hour => {
        const hourNum = parseInt(hour);
        const deliveries = hourlyData[hourNum];
        hourlyAverages[hourNum] = deliveries.reduce((a, b) => a + b, 0) / deliveries.length;
      });
      
      // Encontrar horas de pico (acima da média)
      const averageDeliveries = Object.values(hourlyAverages).reduce((a, b) => a + b, 0) / Object.values(hourlyAverages).length;
      const peakHours = Object.keys(hourlyAverages)
        .filter(hour => hourlyAverages[parseInt(hour)] > averageDeliveries * 1.2)
        .map(h => parseInt(h));
      
      // Calcular potencial de ganhos (R$5 por entrega em média)
      const totalExpected = Object.values(hourlyAverages).reduce((a, b) => a + b, 0);
      const bestEarningPotential = totalExpected * 5;
      
      // Recomendar horas online (com base em picos e padrões)
      const recommendedHours = peakHours.length > 0 
        ? `${Math.min(...peakHours)}-${Math.max(...peakHours) + 2}h`
        : '12-15h e 18-22h';
      
      forecast.push({
        hour: i,
        day,
        expectedDeliveries: Math.round(totalExpected),
        peakHours,
        bestEarningPotential,
        recommendedOnlineHours: recommendedHours
      });
    }
    
    return forecast;
  };

  useEffect(() => {
    if (currentLocation) {
      const newForecast = calculateForecast();
      setForecast(newForecast);
    }
  }, [currentLocation]);

  return {
    forecast,
    isLoading: false,
    refetch: () => setForecast(calculateForecast())
  };
};