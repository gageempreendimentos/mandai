import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { usePushNotificationsFCM } from '@/hooks/usePushNotificationsFCM';

export const useRealtimeNotifications = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { requestPermission } = usePushNotificationsFCM();

  useEffect(() => {
    // Solicitar permissão ao iniciar
    requestPermission();

    // Inscrever-se no canal de entregas
    const channel = supabase
      .channel('deliveries-channel')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'deliveries',
          filter: 'status=eq.pending',
        },
        async (payload) => {
          console.log('📡 Nova entrega via realtime:', payload.new);
          
          // Invalidar queries para atualizar lista
          queryClient.invalidateQueries({ queryKey: ['deliveries', 'available'] });
          
          // Mostrar toast
          toast({
            title: "Nova entrega disponível! 🚀",
            description: `R$ ${(payload.new.value || 0).toFixed(2)} - ${payload.new.pickup_address}`,
            duration: 8000,
          });
          
          // Tentar tocar som (se existir)
          try {
            const audio = new Audio('/sounds/new-delivery.mp3');
            audio.play().catch(() => {});
          } catch (e) {
            console.log('Áudio não disponível');
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'deliveries',
        },
        (payload) => {
          console.log('📡 Entrega atualizada:', payload.new);
          queryClient.invalidateQueries({ queryKey: ['deliveries'] });
          
          supabase.auth.getUser().then(({ data: { user } }) => {
            if (user && payload.new.driver_id === user.id) {
              if (['delivered', 'not_delivered', 'cancelled'].includes(payload.new.status)) {
                toast({
                  title: "Status atualizado",
                  description: `Entrega: ${payload.new.status}`,
                  duration: 3000,
                });
              }
            }
          });
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('✅ Conectado ao canal de entregas REAL');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient, toast, requestPermission]);

  return {};
};