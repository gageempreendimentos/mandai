import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { useIntelligentNotifications } from '@/hooks/useIntelligentNotifications';
import { useBatchDeliveries } from '@/hooks/useBatchDeliveries';
import { supabase } from '@/integrations/supabase/client';
import { useAvailableDeliveriesReal, useUserDeliveries } from '@/hooks/useRealDeliveries';
import { useRealtimeDeliveriesReal } from '@/hooks/useRealtimeDeliveries';
import { useRouteOptimization } from '@/hooks/useRouteOptimization';

// Hooks refatorados
import { useConnectionStatus } from '@/hooks/useConnectionStatus';
import { useDeliveryStage, DeliveryStage } from '@/hooks/useDeliveryStage';
import { useDriverOnlineStatus } from '@/hooks/useDriverOnlineStatus';
import { useDeliveryActions } from '@/hooks/useDeliveryActions';

export type { DeliveryStage };

export const useDashboardState = () => {
  const [dailyEarnings, setDailyEarnings] = useState(0);
  const [deliveryCount, setDeliveryCount] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showNotDeliveredModal, setShowNotDeliveredModal] = useState(false);
  const [showEarnings, setShowEarnings] = useState(true);
  const [showRouteOptimizer, setShowRouteOptimizer] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<any>(null);
  
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Hooks refatorados
  const { isSupabaseConnected, connectionStatus } = useConnectionStatus();
  const { 
    stage, 
    setStage, 
    currentDelivery, 
    setCurrentDelivery, 
    resetDelivery,
    stopSound,
    startContinuousSound,
  } = useDeliveryStage();
  const { isOnline, setIsOnline, toggleOnline } = useDriverOnlineStatus();
  
  // HOOKS DE DADOS
  const { data: availableDeliveries, isLoading: isLoadingAvailableDeliveries, error: deliveriesError } = useAvailableDeliveriesReal();
  const { data: availableBatches, isLoading: isLoadingBatches } = useBatchDeliveries();
  const { data: userDelivery } = useUserDeliveries();
  
  // Hook de otimização de rotas
  const { isOptimizing } = useRouteOptimization();
  
  // Realtime
  useRealtimeDeliveriesReal();
  
  // Driver location (geolocalização do navegador)
  const {
    currentLocation,
    accuracy,
    isLoading: isLoadingLocation,
    error: locationError,
    isSupported: isLocationSupported,
    requestLocation,
    clearError: clearLocationError,
  } = useDriverLocation(isOnline);
  
  // Intelligent notifications
  const { timeOnline } = useIntelligentNotifications(
    isOnline,
    currentLocation,
    currentDelivery ? 1 : 0,
    dailyEarnings
  );

  // Delivery actions hook
  const deliveryActions = useDeliveryActions({
    setStage,
    setCurrentDelivery,
    setDailyEarnings,
    setDeliveryCount,
    stopSound,
  });
  
  // Carregar preferências do usuário
  useEffect(() => {
    const loadUserPreferences = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase
          .from('profiles')
          .select('overlay_enabled')
          .eq('id', user.id)
          .single();
      }
    };
    
    loadUserPreferences();
  }, []);
  
  // Verificar se usuário já tem uma entrega ativa ao carregar
  useEffect(() => {
    if (userDelivery) {
      setCurrentDelivery(userDelivery);
      switch (userDelivery.status) {
        case 'picked_up':
          setStage('going_pickup');
          break;
        case 'in_transit':
          setStage('going_delivery');
          break;
        case 'not_delivered':
          setStage('returning');
          break;
        default:
          setStage('idle');
      }
    } else {
      setCurrentDelivery(null);
      setStage('idle');
    }
  }, [userDelivery, setCurrentDelivery, setStage]);
  
  // Efeito principal: quando fica online
  useEffect(() => {
    if (isOnline) {
      if (availableDeliveries && availableDeliveries.length > 0) {
        setStage('pending');
        startContinuousSound();
      }
    } else {
      setStage('idle');
      setCurrentDelivery(null);
      stopSound();
    }
  }, [isOnline, availableDeliveries, setStage, setCurrentDelivery, startContinuousSound, stopSound]);
  
  // Stop sound when stage changes from pending
  useEffect(() => {
    if (stage !== 'pending') {
      stopSound();
    }
  }, [stage, stopSound]);
  
  const handleToggleOnline = () => {
    const newStatus = toggleOnline();
    
    if (!newStatus) {
      resetDelivery();
    }
  };
  
  const handleNotDelivered = () => {
    setShowNotDeliveredModal(true);
  };
  
  const handleConfirmNotDelivered = async (reason: string) => {
    await deliveryActions.handleConfirmNotDelivered(currentDelivery, reason);
    setShowNotDeliveredModal(false);
  };
  
  const handleLogout = () => {
    navigate('/');
  };
  
  // Função para aceitar rota otimizada
  const handleAcceptOptimizedRoute = async (route: any) => {
    if (!route || !route.deliveries || route.deliveries.length === 0) {
      toast({
        title: "Rota inválida",
        description: "Não foi possível aceitar a rota",
        variant: "destructive",
      });
      return;
    }

    // Aceitar todas as entregas da rota
    for (const delivery of route.deliveries) {
      await deliveryActions.handleAcceptDelivery(delivery);
    }
    
    toast({
      title: "Rota aceita! 🚀",
      description: `Rota otimizada: ${route.totalDistance.toFixed(1)}km, ${route.totalTime}min`,
      duration: 8000,
    });
    
    setShowRouteOptimizer(false);
  };
  
  return {
    // State
    isOnline,
    stage,
    currentDelivery,
    dailyEarnings,
    deliveryCount,
    isMenuOpen,
    showNotDeliveredModal,
    showEarnings,
    isSupabaseConnected,
    connectionStatus,
    currentLocation,
    accuracy,
    isLoadingLocation,
    locationError,
    isLocationSupported,
    showRouteOptimizer,
    selectedRoute,
    isOptimizing,
    
    // Data
    availableDeliveries,
    isLoadingAvailableDeliveries,
    deliveriesError,
    availableBatches,
    isLoadingBatches,
    
    // Actions
    setIsOnline,
    setStage,
    setCurrentDelivery,
    setDailyEarnings,
    setDeliveryCount,
    setIsMenuOpen,
    setShowNotDeliveredModal,
    setShowEarnings,
    setShowRouteOptimizer,
    setSelectedRoute,
    handleToggleOnline,
    handleAcceptDelivery: deliveryActions.handleAcceptDelivery,
    handleRejectDelivery: deliveryActions.handleRejectDelivery,
    handleAcceptBatch: deliveryActions.handleAcceptBatch,
    handleRejectBatch: deliveryActions.handleRejectBatch,
    handleArrivedPickup: deliveryActions.handleArrivedPickup,
    handleConfirmPickup: () => deliveryActions.handleConfirmPickup(currentDelivery),
    handleArrivedDelivery: deliveryActions.handleArrivedDelivery,
    handleConfirmDelivery: (photo?: File) => deliveryActions.handleConfirmDelivery(currentDelivery, photo),
    handleNotDelivered,
    handleConfirmNotDelivered,
    handleArrivedReturn: deliveryActions.handleArrivedReturn,
    handleConfirmReturn: () => deliveryActions.handleConfirmReturn(currentDelivery),
    handleLogout,
    handleAcceptOptimizedRoute,
    requestLocation,
    clearLocationError,
  };
};