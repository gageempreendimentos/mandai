import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface RegisterProgress {
  step: number;
  formData: {
    nomeCompleto: string;
    cpf: string;
    rg: string;
    dataNascimento: string;
    telefone: string;
    email: string;
    senha: string;
    confirmarSenha: string;
    cep: string;
    rua: string;
    numero: string;
    complemento: string;
    bairro: string;
    cidade: string;
    estado: string;
    tipoVeiculo: 'moto' | 'carro' | 'bicicleta' | 'van' | 'caminhao' | '';
    marca: string;
    modelo: string;
    ano: string;
    placa: string;
    cor: string;
    // Campos para nomes de arquivos (para persistência)
    cnhFileName: string;
    comprovanteEnderecoFileName: string;
    documentoVeiculoFileName: string;
  };
  setStep: (step: number) => void;
  setFormData: (data: Partial<RegisterProgress['formData']>) => void;
  reset: () => void;
}

export const useRegisterProgress = create<RegisterProgress>()(
  persist(
    (set) => ({
      step: 1,
      formData: {
        nomeCompleto: '',
        cpf: '',
        rg: '',
        dataNascimento: '',
        telefone: '',
        email: '',
        senha: '',
        confirmarSenha: '',
        cep: '',
        rua: '',
        numero: '',
        complemento: '',
        bairro: '',
        cidade: '',
        estado: '',
        tipoVeiculo: '',
        marca: '',
        modelo: '',
        ano: '',
        placa: '',
        cor: '',
        // Inicializar campos de nome de arquivo
        cnhFileName: '',
        comprovanteEnderecoFileName: '',
        documentoVeiculoFileName: '',
      },
      setStep: (newStep) => set((state) => {
        const totalSteps = 4; // O número total de passos é 4
        const clampedStep = Math.max(1, Math.min(newStep, totalSteps)); // Garante que o passo esteja entre 1 e 4
        return { step: clampedStep };
      }),
      setFormData: (data) => set((state) => {
        return { formData: { ...state.formData, ...data } };
      }),
      reset: () => set({
        step: 1,
        formData: {
          nomeCompleto: '',
          cpf: '',
          rg: '',
          dataNascimento: '',
          telefone: '',
          email: '',
          senha: '',
          confirmarSenha: '',
          cep: '',
          rua: '',
          numero: '',
          complemento: '',
          bairro: '',
          cidade: '',
          estado: '',
          tipoVeiculo: '',
          marca: '',
          modelo: '',
          ano: '',
          placa: '',
          cor: '',
          cnhFileName: '',
          comprovanteEnderecoFileName: '',
          documentoVeiculoFileName: '',
        },
      }),
    }),
    {
      name: 'register-progress-storage',
      storage: createJSONStorage(() => localStorage),
    }
  )
);