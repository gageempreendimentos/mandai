import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface ErrorReport {
  message: string;
  context?: string;
  stack?: string;
  userId?: string;
}

export const useErrorReporting = () => {
  const { toast } = useToast();

  const reportError = async (error: ErrorReport) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      // Log no console para debug
      console.error('🚨 Erro reportado:', error);
      
      // Enviar para o banco de dados (criar tabela error_reports se não existir)
      // Por enquanto, vamos apenas mostrar toast e logar
      toast({
        title: "Ops! Algo deu errado",
        description: error.message || "Nossos técnicos foram notificados. Tente novamente.",
        variant: "destructive",
        duration: 5000,
      });

      // Em produção, você criaria uma tabela error_reports e faria:
      /*
      await supabase.from('error_reports').insert({
        message: error.message,
        context: error.context,
        stack: error.stack,
        user_id: user?.id,
        created_at: new Date().toISOString(),
      });
      */

    } catch (reportError) {
      console.error('Erro ao reportar erro:', reportError);
    }
  };

  const reportAndThrow = (error: any, context?: string) => {
    const errorReport: ErrorReport = {
      message: error.message || 'Erro desconhecido',
      context,
      stack: error.stack,
    };
    
    reportError(errorReport);
    throw error;
  };

  return { reportError, reportAndThrow };
};

// Hook para tratamento seguro de operações
export const useSafeOperation = () => {
  const { reportError } = useErrorReporting();
  const { toast } = useToast();

  const safeExecute = async <T>(
    operation: () => Promise<T>,
    successMessage?: string,
    context?: string
  ): Promise<T | null> => {
    try {
      const result = await operation();
      
      if (successMessage) {
        toast({
          title: "Sucesso! ✅",
          description: successMessage,
          duration: 2000,
        });
      }
      
      return result;
    } catch (error: any) {
      // Erros específicos que queremos tratar de forma diferente
      if (error.message?.includes('duplicate') || error.message?.includes('unique')) {
        toast({
          title: "Dado já existe",
          description: "Este registro já está cadastrado",
          variant: "destructive",
        });
      } else if (error.message?.includes('network') || error.message?.includes('connection')) {
        toast({
          title: "Erro de conexão",
          description: "Verifique sua internet e tente novamente",
          variant: "destructive",
        });
      } else if (error.message?.includes('permission') || error.message?.includes('denied')) {
        toast({
          title: "Permissão negada",
          description: "Você não tem acesso a esta funcionalidade",
          variant: "destructive",
        });
      } else {
        // Erro genérico - reporta
        await reportError({
          message: error.message,
          context,
          stack: error.stack,
        });
      }
      
      return null;
    }
  };

  return { safeExecute };
};