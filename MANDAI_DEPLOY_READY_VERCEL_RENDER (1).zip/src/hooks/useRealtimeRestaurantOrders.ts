import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useRealtimeRestaurantOrders = (
  restaurantId: string | null,
  onNewOrder: (order: any) => void
) => {
  useEffect(() => {
    if (!restaurantId) return;

    const channel = supabase
      .channel('restaurant-orders-channel')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'restaurant_orders',
          filter: `restaurant_id=eq.${restaurantId}`,
        },
        async (payload) => {
          console.log('📡 Novo pedido do restaurante via realtime:', payload.new);
          
          // Notificar sobre novo pedido
          if (onNewOrder) {
            onNewOrder(payload.new);
          }
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('✅ Conectado ao canal de pedidos do restaurante');
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [restaurantId, onNewOrder]);
};