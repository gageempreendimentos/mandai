import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export const usePushNotificationsFCM = () => {
  const [token, setToken] = useState<string | null>(null);
  const { toast } = useToast();

  const requestPermission = async () => {
    try {
      if (!('Notification' in window)) {
        console.log('Este navegador não suporta notificações');
        return false;
      }

      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        console.log('Permissão negada');
        return false;
      }

      // Verificar se Firebase está configurado
      if (!import.meta.env.VITE_FIREBASE_API_KEY) {
        console.log('Firebase não configurado - notificações via toast apenas');
        return true;
      }

      // Importar Firebase dinamicamente
      const { getMessaging, getToken, isSupported } = await import('firebase/messaging');
      const { initializeApp } = await import('firebase/app');
      
      const supported = await isSupported();
      if (!supported) {
        console.log('Firebase Messaging não suportado');
        return false;
      }

      const firebaseConfig = {
        apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
        authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
        storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
        messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
        appId: import.meta.env.VITE_FIREBASE_APP_ID,
      };

      const app = initializeApp(firebaseConfig);
      const messaging = getMessaging(app);

      // Registrar service worker para receber notificações em background/offline
      let swReg: ServiceWorkerRegistration | undefined;
      if ("serviceWorker" in navigator) {
        try {
          swReg = await navigator.serviceWorker.register("/firebase-messaging-sw.js");
        } catch (e) {
          console.warn("Não foi possível registrar firebase-messaging-sw.js:", e);
        }
      }

      const fcmToken = await getToken(messaging, {
        vapidKey: import.meta.env.VITE_FIREBASE_VAPID_KEY,
        serviceWorkerRegistration: swReg,
      });

      if (fcmToken) {
        setToken(fcmToken);
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase
            .from('profiles')
            .update({ push_token: fcmToken })
            .eq('id', user.id);
          console.log('✅ Token FCM salvo no perfil');
        }
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Erro ao configurar Firebase:', error);
      return false;
    }
  };

  // Ouvir mensagens quando app está aberto
  useEffect(() => {
    const setupListener = async () => {
      try {
        if (!import.meta.env.VITE_FIREBASE_API_KEY) {
          console.log('Firebase não configurado - listener não iniciado');
          return;
        }

        const { getMessaging, onMessage, isSupported } = await import('firebase/messaging');
        const { initializeApp } = await import('firebase/app');
        
        const supported = await isSupported();
        if (!supported) return;

        const firebaseConfig = {
          apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
          authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
          projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
          storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
          messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
          appId: import.meta.env.VITE_FIREBASE_APP_ID,
        };

        const app = initializeApp(firebaseConfig);
        const messaging = getMessaging(app);

        onMessage(messaging, (payload) => {
          console.log('Mensagem recebida em foreground:', payload);
          toast({
            title: payload.notification?.title || 'Nova Notificação',
            description: payload.notification?.body || '',
            duration: 8000,
          });

          if (payload.data?.type === 'new_delivery') {
            try {
              const audio = new Audio('/sounds/new-delivery.mp3');
              audio.play().catch(() => {});
            } catch (e) {
              console.log('Não foi possível tocar áudio');
            }
          }
        });
      } catch (error) {
        console.log('Firebase não configurado ou não suportado');
      }
    };

    setupListener();
  }, [toast]);

  return {
    requestPermission,
    token,
  };
};