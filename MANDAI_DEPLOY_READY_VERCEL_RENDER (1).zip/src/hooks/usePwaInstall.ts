import { useEffect, useMemo, useState } from 'react';

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
};

export function usePwaInstall() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Detect "installed" (best-effort)
    const checkInstalled = () => {
      // @ts-expect-error - standalone exists on iOS Safari
      const iOSStandalone = window.navigator.standalone === true;
      const standalone = window.matchMedia?.('(display-mode: standalone)')?.matches ?? false;
      setIsInstalled(iOSStandalone || standalone);
    };

    checkInstalled();
    window.addEventListener('appinstalled', checkInstalled);

    const onBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', onBeforeInstall as EventListener);

    return () => {
      window.removeEventListener('appinstalled', checkInstalled);
      window.removeEventListener('beforeinstallprompt', onBeforeInstall as EventListener);
    };
  }, []);

  const canInstall = useMemo(() => !!deferred && !isInstalled, [deferred, isInstalled]);

  const install = async () => {
    if (!deferred) return { outcome: 'dismissed' as const };
    await deferred.prompt();
    const choice = await deferred.userChoice;
    setDeferred(null);
    return choice;
  };

  return { canInstall, install, isInstalled };
}
