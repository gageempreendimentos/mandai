import { useMutation } from '@tanstack/react-query';
import { calculateRouteFromAddresses, geocodeAddress } from '@/lib/routeCalculator';
import { useToast } from '@/hooks/use-toast';

interface RouteCalculationParams {
  pickupAddress: string;
  dropoffAddress: string;
}

export const useRouteCalculation = () => {
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (params: RouteCalculationParams) => {
      const { pickupAddress, dropoffAddress } = params;

      if (!pickupAddress || !dropoffAddress) {
        throw new Error('Endereços de retirada e entrega são obrigatórios');
      }

      // Calcular rota usando a API OpenRouteService ou fallback
      const route = await calculateRouteFromAddresses(pickupAddress, dropoffAddress);

      if (!route) {
        throw new Error('Não foi possível calcular a rota. Verifique os endereços.');
      }

      return route;
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao calcular rota",
        description: error.message || 'Tente novamente',
        variant: "destructive",
      });
    },
  });
};