import { useState, useEffect } from 'react';

export const useLocationPermission = () => {
  const [permissionState, setPermissionState] = useState<PermissionState | 'unsupported'>('prompt');
  const [isLoading, setIsLoading] = useState(false);

  const checkPermission = async () => {
    if (!navigator.permissions) {
      setPermissionState('unsupported');
      return;
    }

    try {
      const permission = await navigator.permissions.query({ name: 'geolocation' as any });
      setPermissionState(permission.state);
      
      permission.addEventListener('change', () => {
        setPermissionState(permission.state);
      });
    } catch (error) {
      setPermissionState('unsupported');
    }
  };

  const requestPermission = async () => {
    setIsLoading(true);
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        });
      });
      
      setPermissionState('granted');
      setIsLoading(false);
      return position;
    } catch (error) {
      setPermissionState('denied');
      setIsLoading(false);
      throw error;
    }
  };

  useEffect(() => {
    checkPermission();
  }, []);

  return {
    permissionState,
    isLoading,
    checkPermission,
    requestPermission
  };
};