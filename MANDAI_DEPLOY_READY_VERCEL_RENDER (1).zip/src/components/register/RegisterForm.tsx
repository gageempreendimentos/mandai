import React from 'react';
import PersonalInfoStep from './PersonalInfoStep';
import AddressStep from './AddressStep';
import VehicleInfoStep from './VehicleInfoStep';
import DocumentStep from './DocumentStep'; // New import
import type { FormData } from '@/hooks/useRegisterForm';

interface RegisterFormProps {
  step: number;
  formData: FormData;
  onInputChange: (field: keyof FormData, value: string) => void;
  onAddressFound: (addressData: Partial<FormData>) => void;
  // New props for document files and their change handler
  cnhFile: File | null;
  comprovanteEnderecoFile: File | null;
  documentoVeiculoFile: File | null;
  onFileChange: (field: 'cnhFile' | 'comprovanteEnderecoFile' | 'documentoVeiculoFile', file: File | null) => void;
}

const RegisterForm: React.FC<RegisterFormProps> = ({
  step,
  formData,
  onInputChange,
  onAddressFound,
  cnhFile,
  comprovanteEnderecoFile,
  documentoVeiculoFile,
  onFileChange,
}) => {
  console.log(`[RegisterForm.tsx] Received step: ${step}`);
  switch (step) {
    case 1:
      return <PersonalInfoStep formData={formData} onChange={onInputChange} onAddressFound={onAddressFound} />;
    case 2:
      return <AddressStep formData={formData} onChange={onInputChange} onAddressFound={onAddressFound} />;
    case 3:
      return <VehicleInfoStep formData={formData} onChange={onInputChange} />;
    case 4: // New step for documents
      return (
        <DocumentStep 
          cnhFile={cnhFile}
          comprovanteFile={comprovanteEnderecoFile}
          documentoFile={documentoVeiculoFile}
          onFileChange={onFileChange}
          cnhFileName={formData.cnhFileName}
          comprovanteEnderecoFileName={formData.comprovanteEnderecoFileName}
          documentoVeiculoFileName={formData.documentoVeiculoFileName}
        />
      );
    default:
      console.warn(`[RegisterForm.tsx] Invalid step received: ${step}. Returning null.`);
      return null;
  }
};

export default RegisterForm;