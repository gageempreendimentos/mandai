import React from 'react';
import { FileText, CreditCard, Home, Car, AlertCircle } from 'lucide-react';
import DocumentUploadWithPreview from '@/components/DocumentUploadWithPreview';

interface DocumentStepProps {
  cnhFile: File | null;
  comprovanteFile: File | null;
  documentoFile: File | null;
  onFileChange: (field: 'cnhFile' | 'comprovanteEnderecoFile' | 'documentoVeiculoFile', file: File | null) => void;
  // Nuevos props para nombres de archivos persistidos
  cnhFileName?: string;
  comprovanteEnderecoFileName?: string;
  documentoVeiculoFileName?: string;
}

const DocumentStep: React.FC<DocumentStepProps> = ({ 
  cnhFile, 
  comprovanteFile, 
  documentoFile, 
  onFileChange,
  cnhFileName,
  comprovanteEnderecoFileName,
  documentoVeiculoFileName
}) => {
  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
        <FileText size={24} className="text-primary" />
        Documentos
      </h2>

      <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4 flex items-start gap-3">
        <AlertCircle size={20} className="text-orange-500 mt-0.5 flex-shrink-0" />
        <div className="flex-1">
          <p className="text-sm font-medium text-orange-700">Importante:</p>
          <p className="text-xs text-orange-600 mt-1">
            Todos os documentos devem estar legíveis, sem cortes e com foto clara. 
            Formatos: JPG, PNG ou PDF (máx 5MB cada).
          </p>
        </div>
      </div>

      <DocumentUploadWithPreview
        label="CNH (Frente e Verso) *"
        file={cnhFile}
        onChange={(file) => onFileChange('cnhFile', file)}
        icon={<CreditCard size={24} />}
        persistedFileName={cnhFileName}
      />

      <DocumentUploadWithPreview
        label="Comprovante de Endereço *"
        file={comprovanteFile}
        onChange={(file) => onFileChange('comprovanteEnderecoFile', file)}
        icon={<Home size={24} />}
        persistedFileName={comprovanteEnderecoFileName}
      />

      <DocumentUploadWithPreview
        label="Documento do Veículo (CRLV) *"
        file={documentoFile}
        onChange={(file) => onFileChange('documentoVeiculoFile', file)}
        icon={<Car size={24} />}
        persistedFileName={documentoVeiculoFileName}
      />

      <div className="bg-muted/50 rounded-xl p-4 mt-6">
        <p className="text-sm text-muted-foreground">
          📋 Seus documentos serão analisados em até 48 horas úteis. Você receberá um e-mail quando sua conta for aprovada.
        </p>
      </div>
    </div>
  );
};

export default DocumentStep;