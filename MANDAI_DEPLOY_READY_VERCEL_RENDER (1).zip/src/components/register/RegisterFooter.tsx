import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Loader2, Save } from 'lucide-react';

interface RegisterFooterProps {
  step: number;
  totalSteps: number;
  isLoading: boolean;
  onNext: () => void;
}

const RegisterFooter: React.FC<RegisterFooterProps> = ({ step, totalSteps, isLoading, onNext }) => {
  return (
    <div className="p-4 border-t border-border">
      <Button
        variant="hero"
        size="lg"
        className="w-full"
        onClick={onNext}
        disabled={isLoading}
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            Enviando...
          </span>
        ) : step === totalSteps ? (
          <>
            Finalizar Cadastro
            <CheckCircle size={20} />
          </>
        ) : (
          <>
            Continuar
            <ArrowRight size={20} />
          </>
        )}
      </Button>
      
      {/* Feedback de progresso */}
      {isLoading && step === totalSteps && (
        <div className="mt-3 text-center text-sm text-muted-foreground">
          <p>✓ Validando dados</p>
          <p>✓ Criando sua conta</p>
          <p className="font-bold text-primary mt-2">Aguarde...</p>
        </div>
      )}
    </div>
  );
};

export default RegisterFooter;