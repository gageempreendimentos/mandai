import React from 'react';
import { MapPin } from 'lucide-react';
import { AddressForm } from '@/components/AddressForm';
import type { FormData } from '@/hooks/useRegisterForm';

interface AddressStepProps {
  formData: FormData;
  onChange: (field: keyof FormData, value: string) => void;
  onAddressFound: (addressData: Partial<FormData>) => void;
}

const AddressStep: React.FC<AddressStepProps> = ({ formData, onChange, onAddressFound }) => {
  return (
    <div className="space-y-4 animate-fade-in">
      <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
        <MapPin size={24} className="text-primary" />
        Endereço
      </h2>

      <AddressForm
        data={{
          cep: formData.cep,
          rua: formData.rua,
          numero: formData.numero,
          complemento: formData.complemento,
          bairro: formData.bairro,
          cidade: formData.cidade,
          estado: formData.estado,
        }}
        onChange={(field, value) => onChange(field, value)}
        onAddressFound={onAddressFound}
      />
    </div>
  );
};

export default AddressStep;