import React from 'react';
import { Input } from '@/components/ui/input';
import { User, Phone, Mail, Calendar } from 'lucide-react';
import { AddressForm } from '@/components/AddressForm';
import type { FormData } from '@/hooks/useRegisterForm';

interface PersonalInfoStepProps {
  formData: FormData;
  onChange: (field: keyof FormData, value: string) => void;
  onAddressFound: (addressData: Partial<FormData>) => void;
}

const PersonalInfoStep: React.FC<PersonalInfoStepProps> = ({ formData, onChange, onAddressFound }) => {
  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    }
    return value.slice(0, 14);
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{5})(\d)/, '$1-$2');
    }
    return value.slice(0, 15);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
        <User size={24} className="text-primary" />
        Dados Pessoais
      </h2>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Nome Completo *</label>
        <Input
          placeholder="Seu nome completo"
          value={formData.nomeCompleto}
          onChange={(e) => onChange('nomeCompleto', e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">CPF *</label>
          <Input
            placeholder="000.000.000-00"
            value={formatCPF(formData.cpf)}
            onChange={(e) => onChange('cpf', formatCPF(e.target.value))}
            maxLength={14}
            inputMode="numeric"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">RG</label>
          <Input
            placeholder="Seu RG"
            value={formData.rg}
            onChange={(e) => onChange('rg', e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            <Calendar size={14} className="inline mr-1" />
            Nascimento *
          </label>
          <Input
            type="date"
            value={formData.dataNascimento}
            onChange={(e) => onChange('dataNascimento', e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            <Phone size={14} className="inline mr-1" />
            Telefone *
          </label>
          <Input
            placeholder="(00) 00000-0000"
            value={formatPhone(formData.telefone)}
            onChange={(e) => onChange('telefone', formatPhone(e.target.value))}
            maxLength={15}
            inputMode="numeric"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          <Mail size={14} className="inline mr-1" />
          E-mail *
        </label>
        <Input
          type="email"
          placeholder="seu@email.com"
          value={formData.email}
          onChange={(e) => onChange('email', e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Senha *</label>
          <Input
            type="password"
            placeholder="Mínimo 6 caracteres"
            value={formData.senha}
            onChange={(e) => onChange('senha', e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Confirmar *</label>
          <Input
            type="password"
            placeholder="Repita a nova senha"
            value={formData.confirmarSenha}
            onChange={(e) => onChange('confirmarSenha', e.target.value)}
          />
        </div>
      </div>

      <AddressForm
        data={{
          cep: formData.cep,
          rua: formData.rua,
          numero: formData.numero,
          complemento: formData.complemento,
          bairro: formData.bairro,
          cidade: formData.cidade,
          estado: formData.estado,
        }}
        onChange={(field, value) => onChange(field, value)}
        onAddressFound={onAddressFound}
      />
    </div>
  );
};

export default PersonalInfoStep;