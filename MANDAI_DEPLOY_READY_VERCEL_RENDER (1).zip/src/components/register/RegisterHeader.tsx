import React from 'react';
import { ArrowLeft } from 'lucide-react';
import Logo from '@/components/Logo';

interface RegisterHeaderProps {
  step: number;
  totalSteps: number;
  onBack: () => void;
}

const RegisterHeader: React.FC<RegisterHeaderProps> = ({ step, totalSteps, onBack }) => {
  return (
    <>
      <div className="flex items-center gap-4 p-4 border-b border-border bg-card sticky top-0 z-20">
        <button 
          onClick={onBack}
          className="p-2 rounded-full hover:bg-muted transition-colors"
        >
          <ArrowLeft size={24} className="text-foreground" />
        </button>
        <div className="flex-1">
          <h1 className="text-lg font-bold text-foreground">Criar Conta</h1>
          <p className="text-xs text-muted-foreground">Passo {step} de {totalSteps}</p>
        </div>
        <div className="flex items-center gap-2">
          <Logo size="sm" />
        </div>
      </div>

      {/* Progress Bar - Updated to 4 steps */}
      <div className="flex gap-1 px-4 py-3">
        {[1, 2, 3, 4].map((s) => (
          <div 
            key={s}
            className={`h-1.5 flex-1 rounded-full transition-colors ${s <= step ? 'bg-primary' : 'bg-muted'}`}
          />
        ))}
      </div>
    </>
  );
};

export default RegisterHeader;