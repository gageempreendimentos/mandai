import React from 'react';
import { Input } from '@/components/ui/input';
import { Car, Bike } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { FormData } from '@/hooks/useRegisterForm';

interface VehicleInfoStepProps {
  formData: FormData;
  onChange: (field: keyof FormData, value: string) => void;
}

const VehicleInfoStep: React.FC<VehicleInfoStepProps> = ({ formData, onChange }) => {
  const formatPlaca = (value: string) => {
    const clean = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (clean.length <= 7) {
      if (clean.length > 3) {
        return clean.slice(0, 3) + '-' + clean.slice(3);
      }
      return clean;
    }
    return value.slice(0, 8);
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    let formattedValue = value;
    
    if (field === 'placa') formattedValue = formatPlaca(value);
    
    onChange(field, formattedValue);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
        <Car size={24} className="text-primary" />
        Dados do Veículo
      </h2>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Tipo de Veículo *</label>
        <Select 
          value={formData.tipoVeiculo} 
          onValueChange={(value) => onChange('tipoVeiculo', value)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Selecione o tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="moto">Moto</SelectItem>
            <SelectItem value="carro">Carro</SelectItem>
            <SelectItem value="bicicleta">Bicicleta</SelectItem>
            <SelectItem value="van">Van</SelectItem>
            <SelectItem value="caminhao">Caminhão</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Se for bicicleta, não precisa de placa */}
      {formData.tipoVeiculo !== 'bicicleta' && (
        <>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Marca *</label>
              <Input
                placeholder="Ex: Honda, Toyota"
                value={formData.marca}
                onChange={(e) => handleInputChange('marca', e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Modelo *</label>
              <Input
                placeholder="Ex: CG 160, Corolla"
                value={formData.modelo}
                onChange={(e) => handleInputChange('modelo', e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Ano</label>
              <Input
                placeholder="2024"
                value={formData.ano}
                onChange={(e) => handleInputChange('ano', e.target.value)}
                maxLength={4}
                inputMode="numeric"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Placa *</label>
              <Input
                placeholder="ABC-1234"
                value={formData.placa}
                onChange={(e) => handleInputChange('placa', e.target.value)}
                maxLength={9}
                className="uppercase"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Cor</label>
              <Input
                placeholder="Preta"
                value={formData.cor}
                onChange={(e) => handleInputChange('cor', e.target.value)}
              />
            </div>
          </div>
        </>
      )}

      {/* Se for bicicleta, mostra aviso */}
      {formData.tipoVeiculo === 'bicicleta' && (
        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
          <p className="text-sm text-green-700">
            <strong>✅ Bicicleta:</strong> Não é necessário documento do veículo. Apenas CNH e comprovante de endereço.
          </p>
        </div>
      )}

      <div className="bg-muted/50 rounded-xl p-4 mt-4">
        <p className="text-sm text-muted-foreground">
          🏍️ Certifique-se de que seu veículo está regularizado e com toda documentação em dia.
        </p>
      </div>
    </div>
  );
};

export default VehicleInfoStep;