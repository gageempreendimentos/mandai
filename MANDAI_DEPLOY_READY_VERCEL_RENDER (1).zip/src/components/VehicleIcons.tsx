import React from 'react';
import { Truck, Car, Bike } from 'lucide-react';

const VehicleIcons: React.FC = () => {
  return (
    <div className="flex items-center gap-4 text-muted-foreground">
      <div className="animate-vehicle-pulse" style={{ animationDelay: '0s' }}>
        <Bike size={28} className="text-primary" />
      </div>
      <div className="animate-vehicle-pulse" style={{ animationDelay: '0.3s' }}>
        <Car size={28} className="text-accent" />
      </div>
      <div className="animate-vehicle-pulse" style={{ animationDelay: '0.6s' }}>
        <Truck size={28} className="text-primary" />
      </div>
    </div>
  );
};

export default VehicleIcons;
