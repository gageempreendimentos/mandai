import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Truck } from 'lucide-react';
import ReactDOMServer from 'react-dom/server';

// Fix para ícones do Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface DriverLocationMapProps {
  currentLocation: Coordinates;
  zoom?: number;
}

const DriverLocationMap: React.FC<DriverLocationMapProps> = ({ 
  currentLocation, 
  zoom = 15 
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    // Se o mapa já existe, apenas atualiza a visualização
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([currentLocation.latitude, currentLocation.longitude], zoom);
      return;
    }

    // Cria uma nova instância do mapa
    const map = L.map(mapRef.current).setView([currentLocation.latitude, currentLocation.longitude], zoom);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Ícone personalizado para o motorista
    const driverIcon = L.divIcon({
      html: ReactDOMServer.renderToString(
        <div className="relative">
          <div className="absolute inset-0 w-10 h-10 -m-1 rounded-full bg-primary/30 animate-ping" />
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-glow">
            <Truck size={16} className="text-primary-foreground" />
          </div>
        </div>
      ),
      className: 'leaflet-div-icon',
      iconSize: [32, 32],
      iconAnchor: [16, 32],
      popupAnchor: [0, -32],
    });

    // Adiciona o marcador
    L.marker([currentLocation.latitude, currentLocation.longitude], { icon: driverIcon })
      .addTo(map)
      .bindPopup('Você está aqui!', { closeButton: false });

    // Adiciona um círculo para mostrar a precisão da localização
    L.circle([currentLocation.latitude, currentLocation.longitude], {
      color: '#10b981',
      fillColor: '#10b981',
      fillOpacity: 0.1,
      radius: 50
    }).addTo(map);

    // Salva a instância do mapa
    mapInstanceRef.current = map;

    // Função de limpeza
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [currentLocation, zoom]);

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full z-0" />
      
      {/* Informações do motorista */}
      <div className="absolute top-4 left-4 right-4 z-10">
        <div className="bg-card/95 backdrop-blur-sm rounded-xl p-3 shadow-card border border-border/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
              <Truck size={16} className="text-primary-foreground" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Localização Atual</p>
              <p className="text-xs text-muted-foreground">
                Precisão: 50m
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Status de conexão */}
      <div className="absolute bottom-4 left-4 z-10">
        <div className="bg-green-500/10 border border-green-500/30 rounded-full px-3 py-1.5 flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs font-medium text-green-700">Conectado</span>
        </div>
      </div>
    </div>
  );
};

export default DriverLocationMap;