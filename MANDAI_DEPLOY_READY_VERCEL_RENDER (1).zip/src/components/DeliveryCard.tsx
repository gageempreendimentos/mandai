import React, { useState } from 'react';
import { MapPin, Clock, DollarSign, Navigation, Phone } from 'lucide-react';
import { Button } from './ui/button';
import LoadingButton from '@/components/LoadingButton';

export interface Delivery {
  id: string;
  pickup: {
    name: string;
    address: string;
  };
  dropoff: {
    name: string;
    address: string;
    phone: string;
  };
  distance: string;
  estimatedTime: string;
  value: number;
}

interface DeliveryCardProps {
  delivery: Delivery;
  onAccept: (delivery: Delivery) => void | Promise<void>;
  onReject: (id: string) => void | Promise<void>;
}

const DeliveryCard: React.FC<DeliveryCardProps> = ({ delivery, onAccept, onReject }) => {
  const [isAccepting, setIsAccepting] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);

  const handleAccept = async () => {
    try {
      setIsAccepting(true);
      await onAccept(delivery);
    } finally {
      setIsAccepting(false);
    }
  };

  const handleReject = async () => {
    try {
      setIsRejecting(true);
      await onReject(delivery.id);
    } finally {
      setIsRejecting(false);
    }
  };
  return (
    <div className="bg-card rounded-2xl p-5 shadow-card animate-slide-up border border-border/50">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-accent rounded-xl flex items-center justify-center">
            <DollarSign size={20} className="text-accent-foreground" />
          </div>
          <div>
            <span className="text-2xl font-bold text-foreground">
              R$ {delivery.value.toFixed(2)}
            </span>
            <p className="text-xs text-muted-foreground">Valor da entrega</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-muted-foreground text-sm">
          <Clock size={14} />
          <span>{delivery.estimatedTime}</span>
        </div>
      </div>

      {/* Route */}
      <div className="space-y-3 mb-4">
        {/* Pickup */}
        <div className="flex gap-3">
          <div className="flex flex-col items-center">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <div className="w-0.5 h-8 bg-border" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Retirada</p>
            <p className="font-semibold text-foreground">{delivery.pickup.name}</p>
            <p className="text-sm text-muted-foreground">{delivery.pickup.address}</p>
          </div>
        </div>

        {/* Dropoff */}
        <div className="flex gap-3">
          <div className="flex flex-col items-center">
            <div className="w-3 h-3 rounded-full bg-accent" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Entrega</p>
            <p className="font-semibold text-foreground">{delivery.dropoff.name}</p>
            <p className="text-sm text-muted-foreground">{delivery.dropoff.address}</p>
          </div>
        </div>
      </div>

      {/* Distance */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-5">
        <Navigation size={14} />
        <span>{delivery.distance} de distância</span>
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <Button 
          variant="outline" 
          className="flex-1"
          onClick={handleReject}
        >
          Recusar
        </Button>
        <LoadingButton 
          variant="hero" 
          className="flex-1"
          onClick={handleAccept}
          loading={isAccepting}
        >
          Aceitar
        </LoadingButton>
      </div>
    </div>
  );
};

export default DeliveryCard;