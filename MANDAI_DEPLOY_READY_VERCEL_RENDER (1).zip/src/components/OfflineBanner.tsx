import React from "react";
import { WifiOff } from "lucide-react";
import { notify } from "@/lib/notify";

export default function OfflineBanner() {
  const [online, setOnline] = React.useState<boolean>(() => (typeof navigator === "undefined" ? true : navigator.onLine));
  const prev = React.useRef<boolean>(online);

  React.useEffect(() => {
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);

    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);

    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, []);

  React.useEffect(() => {
    if (prev.current === online) return;
    prev.current = online;

    if (!online) notify.warning("Sem conexão", "Algumas funções podem não funcionar até a internet voltar.");
    else notify.success("Conexão restabelecida", "Você está online novamente.");
  }, [online]);

  if (online) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50">
      <div className="mx-auto flex max-w-3xl items-center justify-center gap-2 rounded-b-2xl border border-border bg-background/90 px-4 py-2 shadow-sm backdrop-blur">
        <WifiOff className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm font-medium text-foreground">Você está offline</span>
        <span className="text-xs text-muted-foreground">Verifique sua conexão para continuar.</span>
      </div>
    </div>
  );
}
