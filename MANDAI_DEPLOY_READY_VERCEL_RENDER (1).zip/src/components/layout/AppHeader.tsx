import { ReactNode } from "react";

type Props = { title: string; right?: ReactNode; subtitle?: string };

export default function AppHeader({ title, subtitle, right }: Props) {
  return (
    <div className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-black/5">
      <div className="mx-auto max-w-screen-md px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-2xl bg-white border border-black/10 shadow-sm flex items-center justify-center font-black tracking-widest text-black">
            MANDAI
          </div>
          <div className="leading-tight">
            <div className="text-[15px] font-extrabold tracking-wide">{title}</div>
            {subtitle ? <div className="text-[12px] text-black/55">{subtitle}</div> : null}
          </div>
        </div>
        <div className="flex items-center gap-2">{right}</div>
      </div>
    </div>
  );
}
