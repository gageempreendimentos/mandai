import React, { ReactNode } from "react";
import AppHeader from "@/components/layout/AppHeader";
import MapFull from "@/components/layout/MapFull";
import DraggableBottomSheet from "@/components/layout/DraggableBottomSheet";
import type { RideStage } from "@/state/rideState";

type Props = {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  /** Drive map markers/route visuals based on ride stage */
  stage?: RideStage;
  children: ReactNode;
};

export default function MapWithSheet({ title, subtitle, right, stage, children }: Props) {
  return (
    <div className="min-h-screen bg-white">
      <MapFull stage={stage} />
      <div className="fixed inset-x-0 top-0 z-40">
        <AppHeader title={title} subtitle={subtitle} right={right} />
      </div>
      <DraggableBottomSheet snaps={[170, 380, 660]} initialSnap={1}>
        <div className="max-h-[65vh] overflow-auto pr-1">{children}</div>
      </DraggableBottomSheet>
    </div>
  );
}
