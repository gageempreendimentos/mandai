import { ReactNode } from "react";
type Props = { children: ReactNode; className?: string };
export default function BottomSheet({ children, className = "" }: Props) {
  return (
    <div className={"fixed inset-x-0 bottom-0 z-30 mx-auto max-w-screen-md px-4 pb-4 " + className}>
      <div className="rounded-[24px] bg-white shadow-[var(--mandai-shadow)] border border-black/10 overflow-hidden">
        <div className="h-5 flex items-center justify-center">
          <div className="h-1.5 w-10 rounded-full bg-black/15" />
        </div>
        <div className="px-4 pb-4">{children}</div>
      </div>
    </div>
  );
}
