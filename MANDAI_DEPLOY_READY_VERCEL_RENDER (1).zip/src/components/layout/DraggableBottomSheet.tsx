import React, { ReactNode, useEffect, useMemo, useState } from "react";
import { motion, useDragControls } from "framer-motion";

type Props = {
  children: ReactNode;
  /** Snap heights in px (visible height). Example: [160, 360, 640] */
  snaps?: number[];
  /** default snap index */
  initialSnap?: number;
  /** If provided, sheet will animate to this snap index whenever it changes */
  targetSnap?: number;
  /** Optional attention pulse on the sheet container */
  attentionPulse?: boolean;
  className?: string;
};

export default function DraggableBottomSheet({
  children,
  snaps = [160, 360, 640],
  initialSnap = 1,
  targetSnap,
  attentionPulse = false,
  className = "",
}: Props) {
  const dragControls = useDragControls();
  const sorted = useMemo(() => [...snaps].sort((a, b) => a - b), [snaps]);
  const minH = sorted[0];
  const maxH = sorted[sorted.length - 1];
  const initial = sorted[Math.min(initialSnap, sorted.length - 1)];
  const [height, setHeight] = useState(initial);

  useEffect(() => {
    if (typeof targetSnap !== "number") return;
    const idx = Math.max(0, Math.min(sorted.length - 1, targetSnap));
    setHeight(sorted[idx]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetSnap]);

  const nearestSnap = (h: number) => {
    let best = sorted[0];
    let bestDist = Math.abs(h - best);
    for (const s of sorted) {
      const d = Math.abs(h - s);
      if (d < bestDist) {
        bestDist = d;
        best = s;
      }
    }
    return best;
  };

  // rubber-band: allow small overshoot but dampen
  const rubber = (value: number) => {
    if (value < minH) return minH - (minH - value) * 0.35;
    if (value > maxH) return maxH + (value - maxH) * 0.35;
    return value;
  };

  return (
    <div className={"fixed inset-x-0 bottom-0 z-30 mx-auto max-w-screen-md px-4 pb-4 " + className}>
      <motion.div
        className={
          "rounded-[24px] bg-white shadow-[var(--mandai-shadow)] border border-black/10 overflow-hidden " +
          (attentionPulse ? "ring-2 ring-black/10 animate-pulse" : "")
        }
        animate={{ height: Math.round(height) }}
        transition={{ type: "spring", damping: 28, stiffness: 280 }}
      >
        <motion.div
          className="h-10 flex items-center justify-center cursor-grab active:cursor-grabbing select-none"
          onPointerDown={(e) => dragControls.start(e)}
          drag="y"
          dragControls={dragControls}
          dragListener={false}
          dragElastic={0.08}
          dragMomentum={false}
          dragConstraints={{ top: 0, bottom: 0 }}
          onDrag={(e, info) => {
            const nextRaw = height - info.delta.y;
            setHeight(rubber(nextRaw));
          }}
          onDragEnd={() => {
            // clamp to min/max then snap
            const clamped = Math.max(minH, Math.min(maxH, height));
            setHeight(nearestSnap(clamped));
          }}
        >
          <div className="h-1.5 w-10 rounded-full bg-black/15" />
        </motion.div>

        <div className="px-4 pb-4 max-h-[calc(100%-40px)] overflow-auto pr-1">{children}</div>
      </motion.div>
    </div>
  );
}
