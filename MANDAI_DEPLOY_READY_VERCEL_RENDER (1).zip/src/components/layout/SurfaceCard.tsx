import { ReactNode } from "react";
export default function SurfaceCard({ children }: { children: ReactNode }) {
  return <div className="rounded-2xl bg-white border border-black/10 shadow-sm p-4">{children}</div>;
}
