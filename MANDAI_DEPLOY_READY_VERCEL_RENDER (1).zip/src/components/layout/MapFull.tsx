import React, { Suspense } from "react";
import type { RideStage } from "@/state/rideState";

const LiveMap = React.lazy(() => import("@/components/maps/LiveMap"));

export default function MapFull({ stage = "offered" }: { stage?: RideStage }) {
  return (
    <div className="fixed inset-0 z-0">
      <Suspense
        fallback={
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.06),transparent_55%),radial-gradient(circle_at_70%_60%,rgba(0,0,0,0.05),transparent_55%)]" />
            <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(0,0,0,0.05)_1px,transparent_1px),linear-gradient(0deg,rgba(0,0,0,0.05)_1px,transparent_1px)] bg-[size:72px_72px] opacity-[0.45]" />
          </div>
        }
      >
        <LiveMap stage={stage} />
      </Suspense>

      {/* vignette for Uber feel */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_45%,rgba(0,0,0,0.05))]" />
    </div>
  );
}
