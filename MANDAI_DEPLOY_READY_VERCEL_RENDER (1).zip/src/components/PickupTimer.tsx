import React, { useState, useEffect } from 'react';
import { Clock, AlertTriangle } from 'lucide-react';

interface PickupTimerProps {
  distanceKm: number;
  isActive: boolean;
  onTimeUp?: () => void;
}

const PickupTimer: React.FC<PickupTimerProps> = ({ distanceKm, isActive, onTimeUp }) => {
  // Calculate time based on real distance: ~2 min per km, minimum 3 min, max 15 min
  const calculateTimeInSeconds = (km: number): number => {
    const minutes = Math.max(3, Math.min(15, Math.ceil(km * 2)));
    return minutes * 60;
  };

  const totalSeconds = calculateTimeInSeconds(distanceKm);
  const [timeLeft, setTimeLeft] = useState(totalSeconds);

  useEffect(() => {
    if (!isActive) {
      setTimeLeft(totalSeconds);
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onTimeUp?.();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, totalSeconds, onTimeUp]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progress = (timeLeft / totalSeconds) * 100;
  const isLowTime = timeLeft < 60;
  const isCritical = timeLeft < 30;

  if (!isActive) return null;

  return (
    <div className={`bg-card rounded-2xl p-4 shadow-soft mb-4 border-2 transition-colors ${
      isCritical ? 'border-red-500 animate-pulse' : isLowTime ? 'border-orange-500' : 'border-transparent'
    }`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {isCritical ? (
            <AlertTriangle size={20} className="text-red-500" />
          ) : (
            <Clock size={20} className={isLowTime ? 'text-orange-500' : 'text-primary'} />
          )}
          <span className="font-medium text-foreground">Tempo para coleta</span>
        </div>
        <span className={`text-2xl font-bold tabular-nums ${
          isCritical ? 'text-red-500' : isLowTime ? 'text-orange-500' : 'text-primary'
        }`}>
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </span>
      </div>
      
      {/* Progress bar */}
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full transition-all duration-1000 ${
            isCritical ? 'bg-red-500' : isLowTime ? 'bg-orange-500' : 'bg-primary'
          }`}
          style={{ width: `${progress}%` }}
        />
      </div>
      
      <p className="text-xs text-muted-foreground mt-2 text-center">
        Baseado na distância real de {distanceKm.toFixed(1)} km
      </p>
    </div>
  );
};

export default PickupTimer;