import React, { useState } from 'react';
import { MapPin, AlertCircle, Loader2, CheckCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import LocationStatus from '@/components/LocationStatus';
import LocationPermissionModal from '@/components/LocationPermissionModal';

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface LocationSectionProps {
  location: Coordinates | null;
  accuracy: number | null;
  isLoading: boolean;
  error: any;
  isSupported: boolean;
  onRefreshLocation: () => void;
}

const LocationSection: React.FC<LocationSectionProps> = ({
  location,
  accuracy,
  isLoading,
  error,
  isSupported,
  onRefreshLocation,
}) => {
  const [showPermissionModal, setShowPermissionModal] = useState(false);

  const handleRequestPermission = () => {
    setShowPermissionModal(false);
    onRefreshLocation();
  };

  return (
    <div className="space-y-3">
      {/* Status da Localização */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin size={18} className="text-primary" />
            Localização em Tempo Real
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Status Bar */}
          <div className="flex items-center justify-between">
            <LocationStatus
              location={location}
              accuracy={accuracy}
              isLoading={isLoading}
              error={error}
              isSupported={isSupported}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={onRefreshLocation}
              disabled={isLoading}
            >
              <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
            </Button>
          </div>

          {/* Coordenadas */}
          {location && (
            <div className="bg-muted rounded-lg p-3 space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Latitude:</span>
                <span className="font-mono font-medium">{location.latitude.toFixed(6)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Longitude:</span>
                <span className="font-mono font-medium">{location.longitude.toFixed(6)}</span>
              </div>
              {accuracy && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Precisão:</span>
                  <span className="font-medium">{Math.round(accuracy)}m</span>
                </div>
              )}
            </div>
          )}

          {/* Erro */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
              <div className="flex items-center gap-2 text-red-600 mb-1">
                <AlertCircle size={16} />
                <span className="font-medium">Erro de Localização</span>
              </div>
              <p className="text-sm text-red-600">{error.message}</p>
              {error.code === 1 && (
                <p className="text-xs text-red-600 mt-1">
                  Configure no navegador: Configurações → Privacidade → Localização
                </p>
              )}
            </div>
          )}

          {/* Instruções */}
          {!location && !error && !isLoading && isSupported && (
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3">
              <p className="text-sm text-blue-700">
                Clique em "Obter Localização" para ativar o rastreamento em tempo real.
              </p>
            </div>
          )}

          {/* Botão de Ação */}
          <Button
            variant="hero"
            className="w-full"
            onClick={() => setShowPermissionModal(true)}
            disabled={isLoading || !isSupported}
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <Loader2 size={16} className="animate-spin" />
                Obtendo localização...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <MapPin size={16} />
                {location ? 'Atualizar Localização' : 'Obter Localização'}
              </span>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Modal de Permissão */}
      <LocationPermissionModal
        isOpen={showPermissionModal}
        onClose={() => setShowPermissionModal(false)}
        onGrantPermission={handleRequestPermission}
        isSupported={isSupported}
      />
    </div>
  );
};

export default LocationSection;