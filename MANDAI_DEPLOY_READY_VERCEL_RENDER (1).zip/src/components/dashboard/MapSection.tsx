import React from 'react';
import MapPlaceholder from '@/components/MapPlaceholder';
import RouteMap from '@/components/RouteMap';
import DriverLocationMap from '@/components/DriverLocationMap';
import { Delivery } from '@/components/DeliveryCard';

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface MapSectionProps {
  stage: string;
  currentDelivery: Delivery | null;
  currentLocation: Coordinates | null;
  isOnline: boolean;
}

const MapSection: React.FC<MapSectionProps> = ({ 
  stage, 
  currentDelivery, 
  currentLocation, 
  isOnline 
}) => {
  const isOnRoute = stage === 'going_pickup' || stage === 'going_delivery' || stage === 'returning';
  const isAtLocation = stage === 'at_pickup' || stage === 'at_delivery' || stage === 'at_return';
  
  // Prioridade 1: Rota de entrega ativa
  if ((isOnRoute || isAtLocation) && currentDelivery && currentLocation) {
    const routeStage = stage === 'going_pickup' || stage === 'at_pickup' 
      ? 'pickup' 
      : (stage === 'returning' || stage === 'at_return' 
        ? 'returning' 
        : 'delivering');
        
    return (
      <RouteMap 
        delivery={currentDelivery} 
        stage={routeStage} 
        currentLocation={currentLocation} 
      />
    );
  }
  
  // Prioridade 2: Mapa de localização do motorista (online, sem entrega ativa)
  if (isOnline && currentLocation && !currentDelivery) {
    return <DriverLocationMap currentLocation={currentLocation} />;
  }
  
  // Prioridade 3: Placeholder (offline ou buscando localização)
  return <MapPlaceholder isOnline={isOnline} currentLocation={currentLocation} />;
};

export default MapSection;