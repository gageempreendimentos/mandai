import React from 'react';
import { AlertCircle, Wifi, WifiOff, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

export interface ConnectionStatusProps {
  isConnected: boolean;
  connectionStatus?: 'checking' | 'connected' | 'error';
  onRetry: () => void;
  message?: string;
}

const ConnectionStatus: React.FC<ConnectionStatusProps> = ({ 
  isConnected, 
  connectionStatus = 'checking',
  onRetry,
  message = "Verifique sua conexão com a internet e tente novamente"
}) => {
  // Se conectado, não mostra nada
  if (isConnected) return null;

  // Verificando conexão
  if (connectionStatus === 'checking') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="bg-card rounded-3xl p-8 shadow-2xl max-w-md w-full text-center border border-border">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2 text-foreground">Conectando...</h2>
          <p className="text-muted-foreground">
            Aguarde enquanto estabelecemos a conexão
          </p>
        </div>
      </div>
    );
  }

  // Erro de conexão
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="bg-card rounded-3xl p-8 shadow-2xl max-w-md w-full text-center border border-destructive/30">
        <AlertCircle size={48} className="text-destructive mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2 text-foreground">Sem conexão</h2>
        <p className="text-muted-foreground mb-6">
          {message}
        </p>
        <div className="flex flex-col gap-3">
          <Button 
            variant="hero" 
            size="lg" 
            className="w-full"
            onClick={onRetry}
          >
            <RefreshCw size={16} className="mr-2" />
            Tentar Novamente
          </Button>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <WifiOff size={16} className="text-destructive" />
            <span className="text-sm">Conexão necessária para funcionamento</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectionStatus;