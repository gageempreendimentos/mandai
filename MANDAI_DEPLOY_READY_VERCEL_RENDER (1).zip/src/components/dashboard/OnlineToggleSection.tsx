import React from 'react';
import { Power } from 'lucide-react';

interface OnlineToggleSectionProps {
  isOnline: boolean;
  onToggle: () => void;
}

const OnlineToggleSection: React.FC<OnlineToggleSectionProps> = ({ isOnline, onToggle }) => {
  return (
    <div className="absolute top-20 right-4 z-10">
      <button
        onClick={onToggle}
        className={`px-4 py-2 rounded-full border-2 transition-all hover:scale-105 active:scale-95 flex items-center gap-2 ${
          isOnline 
            ? 'bg-red-500 border-red-500 text-white shadow-glow-red hover:bg-red-600' 
            : 'bg-green-500 border-green-500 text-white shadow-glow-green hover:bg-green-600'
        }`}
      >
        <Power size={16} className={isOnline ? 'text-white' : 'text-white'} />
        <span className="text-sm font-bold">
          {isOnline ? 'Offline' : 'Online'}
        </span>
      </button>
    </div>
  );
};

export default OnlineToggleSection;