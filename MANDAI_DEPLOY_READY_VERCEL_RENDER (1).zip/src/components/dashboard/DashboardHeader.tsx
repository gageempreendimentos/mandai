import React from 'react';
import { LogOut, Eye, EyeOff, Menu } from 'lucide-react';
import Logo from '@/components/Logo';

interface DashboardHeaderProps {
  dailyEarnings: number;
  showEarnings: boolean;
  onToggleEarnings: () => void;
  onLogout: () => void;
  onOpenMenu: () => void;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  dailyEarnings,
  showEarnings,
  onToggleEarnings,
  onLogout,
  onOpenMenu,
}) => {
  return (
    <header className="absolute top-0 left-0 right-0 z-20 p-3 bg-gradient-to-b from-background/95 via-background/80 to-transparent backdrop-blur-sm">
      <div className="flex items-center justify-between">
        {/* Botão Menu */}
        <button 
          onClick={onOpenMenu} 
          className="w-10 h-10 rounded-full bg-card/90 backdrop-blur-sm flex items-center justify-center shadow-soft hover:bg-card transition-colors"
        >
          <Menu size={20} className="text-foreground" />
        </button>

        {/* Logo Centralizado (menor) */}
        <div className="absolute left-1/2 -translate-x-1/2">
          <Logo size="sm" />
        </div>

        {/* Saldo e Logout */}
        <div className="flex items-center gap-2">
          {/* Saldo compacto */}
          <div className="flex items-center gap-2 bg-card/90 backdrop-blur-sm rounded-full px-3 py-1.5 shadow-soft">
            <span className="text-sm font-bold text-primary">
              {showEarnings ? `R$ ${dailyEarnings.toFixed(2)}` : '••••'}
            </span>
            <button 
              onClick={onToggleEarnings}
              className="p-1 rounded-full hover:bg-muted transition-colors"
            >
              {showEarnings ? (
                <EyeOff size={14} className="text-muted-foreground" />
              ) : (
                <Eye size={14} className="text-muted-foreground" />
              )}
            </button>
          </div>

          {/* Logout */}
          <button 
            onClick={onLogout}
            className="w-10 h-10 rounded-full bg-card/90 backdrop-blur-sm flex items-center justify-center shadow-soft hover:bg-card transition-colors"
          >
            <LogOut size={18} className="text-muted-foreground" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default DashboardHeader;