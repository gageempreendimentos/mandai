import React from 'react';
import DeliveryCard, { Delivery } from '@/components/DeliveryCard';
import PickupTimer from '@/components/PickupTimer';
import DeliveryTimer from '@/components/DeliveryTimer';
import ActiveDelivery from '@/components/ActiveDelivery';
import PendingQueue from '@/components/PendingQueue';
import BatchDeliveryCard from '@/components/BatchDeliveryCard';
import RouteOptimizerSection from '@/components/dashboard/RouteOptimizerSection';
import { BatchDelivery } from '@/hooks/useBatchDeliveries';
import { AlertCircle, Route } from 'lucide-react';

export interface Coordinate {
  lat: number;
  lng: number;
}

interface BottomPanelProps {
  stage: string;
  isOnline: boolean;
  currentDelivery: Delivery | null;
  availableBatches: BatchDelivery[] | undefined;
  availableDeliveries: Delivery[] | undefined;
  isLoadingAvailableDeliveries: boolean;
  deliveriesError: any;
  dailyEarnings: number;
  currentLocation: Coordinate | null;
  showRouteOptimizer: boolean;
  isOptimizing: boolean;
  onAcceptDelivery: (delivery: Delivery) => void;
  onRejectDelivery: (id: string) => void;
  onAcceptBatch: (batch: BatchDelivery) => void;
  onRejectBatch: (batchId: string) => void;
  onArrivedPickup: () => void;
  onConfirmPickup: () => void;
  onArrivedDelivery: () => void;
  onConfirmDelivery: (photo?: File) => void;
  onNotDelivered: () => void;
  onArrivedReturn: () => void;
  onConfirmReturn: () => void;
  onAcceptOptimizedRoute: (route: any) => void;
  setShowRouteOptimizer: (show: boolean) => void;
}

const BottomPanel: React.FC<BottomPanelProps> = ({
  stage,
  isOnline,
  currentDelivery,
  availableBatches,
  availableDeliveries,
  isLoadingAvailableDeliveries,
  deliveriesError,
  dailyEarnings,
  currentLocation,
  showRouteOptimizer,
  isOptimizing,
  onAcceptDelivery,
  onRejectDelivery,
  onAcceptBatch,
  onRejectBatch,
  onArrivedPickup,
  onConfirmPickup,
  onArrivedDelivery,
  onConfirmDelivery,
  onNotDelivered,
  onArrivedReturn,
  onConfirmReturn,
  onAcceptOptimizedRoute,
  setShowRouteOptimizer,
}) => {
  const showBatch = availableBatches && availableBatches.length > 0;
  const showIndividual = !showBatch && availableDeliveries && availableDeliveries.length > 0;

  // Preparar dados para otimização de rota (usando fallback pois coordinates pode não existir)
  const deliveriesForOptimization = availableDeliveries?.map(d => ({
    id: d.id,
    address: d.pickup.address,
    coordinates: { lat: -23.5505, lng: -46.6333 }, // Fallback para São Paulo
    type: 'pickup' as const,
    value: d.value,
    customerName: d.dropoff.name,
  })) || [];

  return (
    <div className="relative z-10 -mt-6">
      <div className="bg-background rounded-t-3xl pt-6 px-4 pb-8 min-h-[200px]">
        {/* Handle */}
        <div className="w-12 h-1 bg-border rounded-full mx-auto mb-6" />

        {stage === 'idle' && !isOnline && (
          <div className="text-center py-8">
            <p className="text-2xl font-extrabold text-primary mb-3 tracking-tight">
              Pronto para entregar?
            </p>
            <p className="text-lg font-semibold text-foreground opacity-90">
              Fique online para receber pedidos
            </p>
          </div>
        )}

        {stage === 'idle' && isOnline && !currentDelivery && (
          <>
            {/* Otimização de Rota - Nova funcionalidade */}
            {showIndividual && currentLocation && (
              <RouteOptimizerSection
                deliveries={deliveriesForOptimization}
                currentLocation={currentLocation}
                onAcceptRoute={onAcceptOptimizedRoute}
              />
            )}

            {showBatch && (
              <div className="space-y-4">
                <h2 className="text-xl font-bold text-foreground text-center flex items-center justify-center gap-2">
                  <Route size={20} className="text-primary" />
                  Rotas Otimizadas
                </h2>
                {availableBatches.map((batch, index) => (
                  <BatchDeliveryCard 
                    key={index} 
                    batch={batch} 
                    onAccept={onAcceptBatch} 
                    onReject={onRejectBatch} 
                  />
                ))}
              </div>
            )}

            {showIndividual && (
              <PendingQueue 
                deliveries={availableDeliveries || []} 
                onAccept={onAcceptDelivery} 
                onReject={onRejectDelivery} 
                isLoading={isLoadingAvailableDeliveries} 
              />
            )}

            {!showBatch && !showIndividual && !isLoadingAvailableDeliveries && (
              <div className="text-center py-8">
                <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-lg font-semibold text-foreground mb-2">
                  Buscando entregas reais...
                </p>
                <p className="text-muted-foreground">
                  Aguardando novas oportunidades
                </p>
              </div>
            )}

            {deliveriesError && (
              <div className="text-center py-8">
                <AlertCircle size={48} className="text-destructive mx-auto mb-4" />
                <p className="text-lg font-semibold text-foreground mb-2">
                  Erro ao carregar entregas
                </p>
                <p className="text-muted-foreground">
                  Verifique sua conexão e tente novamente
                </p>
              </div>
            )}
          </>
        )}

        {/* Pending */}
        {stage === 'pending' && currentDelivery && (
          <DeliveryCard 
            delivery={currentDelivery} 
            onAccept={onAcceptDelivery} 
            onReject={onRejectDelivery} 
          />
        )}

        {/* Going Pickup - Timer */}
        {stage === 'going_pickup' && currentDelivery && (
          <PickupTimer 
            distanceKm={parseFloat(currentDelivery.distance.replace(' km', '').replace(',', '.'))} 
            isActive={stage === 'going_pickup'} 
            onTimeUp={() => {}} 
          />
        )}

        {/* Going Delivery - Timer */}
        {stage === 'going_delivery' && currentDelivery && (
          <DeliveryTimer 
            distanceKm={parseFloat(currentDelivery.distance.replace(' km', '').replace(',', '.'))} 
            isActive={stage === 'going_delivery'} 
            onTimeUp={() => {}} 
          />
        )}

        {/* Active Delivery */}
        {(stage === 'going_pickup' || stage === 'at_pickup' || stage === 'going_delivery' || stage === 'at_delivery' || stage === 'returning' || stage === 'at_return') && currentDelivery && (
          <ActiveDelivery 
            delivery={currentDelivery} 
            stage={stage as any} 
            onArrivedPickup={onArrivedPickup} 
            onConfirmPickup={onConfirmPickup} 
            onArrivedDelivery={onArrivedDelivery} 
            onConfirmDelivery={onConfirmDelivery} 
            onNotDelivered={onNotDelivered} 
            onArrivedReturn={onArrivedReturn} 
            onConfirmReturn={onConfirmReturn} 
            dailyEarnings={dailyEarnings} 
          />
        )}

        {/* Completed */}
        {stage === 'completed' && (
          <div className="text-center py-8 animate-fade-in">
            <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
              <span className="text-3xl">✓</span>
            </div>
            <p className="text-xl font-bold text-foreground mb-2">
              Entrega concluída!
            </p>
            <p className="text-primary font-semibold text-lg">
              + R$ {currentDelivery?.value.toFixed(2)}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BottomPanel;