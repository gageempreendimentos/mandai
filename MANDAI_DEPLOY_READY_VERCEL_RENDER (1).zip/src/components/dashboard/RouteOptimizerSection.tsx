import React, { useState } from 'react';
import { Route, MapPin, Package, Clock, DollarSign, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import RouteOptimizer from '@/components/RouteOptimizer';

interface Coordinate {
  lat: number;
  lng: number;
}

interface DeliveryPoint {
  id: string;
  address: string;
  coordinates?: Coordinate;
  type: 'pickup' | 'dropoff';
  value: number;
  customerName: string;
}

interface RouteOptimizerSectionProps {
  deliveries: DeliveryPoint[];
  currentLocation: Coordinate;
  onAcceptRoute: (route: any) => void;
}

const RouteOptimizerSection: React.FC<RouteOptimizerSectionProps> = ({
  deliveries,
  currentLocation,
  onAcceptRoute,
}) => {
  const [showOptimizer, setShowOptimizer] = useState(false);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}min`;
  };

  const formatDistance = (km: number) => {
    if (km < 1) return `${Math.round(km * 1000)} m`;
    return `${km.toFixed(1)} km`;
  };

  // Calcular estimativa de rota combinada
  const calculateBatchEstimate = () => {
    if (deliveries.length < 2) return null;

    // Simulação simples de rota combinada
    const totalDistance = deliveries.length * 2.5; // 2.5km média por entrega
    const totalTime = totalDistance * 2; // 2 min por km
    const totalValue = deliveries.reduce((sum, d) => sum + d.value, 0);

    // Economia estimada (30% de redução)
    const savingsDistance = totalDistance * 0.3;
    const savingsTime = totalTime * 0.3;

    return {
      totalDistance,
      totalTime,
      totalValue,
      savingsDistance,
      savingsTime,
    };
  };

  const estimate = calculateBatchEstimate();

  if (deliveries.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold flex items-center gap-2">
          <Route size={18} className="text-primary" />
          Otimização de Rota
        </h3>
        <Badge variant="secondary">
          {deliveries.length} entregas
        </Badge>
      </div>

      {/* Estimativa */}
      {estimate && !showOptimizer && (
        <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <CardContent className="pt-4">
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">
                  {formatCurrency(estimate.totalValue)}
                </p>
                <p className="text-xs text-muted-foreground">Valor Total</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-accent">
                  {formatTime(estimate.totalTime)}
                </p>
                <p className="text-xs text-muted-foreground">Tempo Estimado</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">
                  {formatTime(estimate.savingsTime)}
                </p>
                <p className="text-xs text-muted-foreground">Economia</p>
              </div>
            </div>

            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 mb-3">
              <p className="text-sm font-medium text-green-600 flex items-center gap-2">
                <MapPin size={14} />
                Rota combinada pode economizar até 30% do tempo
              </p>
            </div>

            <Button
              variant="hero"
              className="w-full"
              onClick={() => setShowOptimizer(true)}
            >
              <Route size={16} className="mr-2" />
              Calcular Rota Otimizada
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Otimizador */}
      {showOptimizer && (
        <RouteOptimizer
          deliveries={deliveries}
          currentLocation={currentLocation}
          onAcceptRoute={(route) => {
            onAcceptRoute(route);
            setShowOptimizer(false);
          }}
          onRejectRoute={() => setShowOptimizer(false)}
        />
      )}
    </div>
  );
};

export default RouteOptimizerSection;