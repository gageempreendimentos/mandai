import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import PasswordInput from '@/components/PasswordInput';
import { ArrowRight, User, HelpCircle } from 'lucide-react';

interface LoginFormProps {
  cpf: string;
  senha: string;
  showPassword: boolean;
  isLoading: boolean;
  isSendingReset: boolean;
  hasSavedProgress: boolean;
  onCPFChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCPFSubmit: (e: React.FormEvent) => void;
  onPasswordSubmit: (e: React.FormEvent) => void;
  onForgotPassword: () => void;
  onSupport: () => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({
  cpf,
  senha,
  showPassword,
  isLoading,
  isSendingReset,
  hasSavedProgress,
  onCPFChange,
  onCPFSubmit,
  onPasswordSubmit,
  onForgotPassword,
  onSupport,
}) => {
  if (!showPassword) {
    return (
      <form onSubmit={onCPFSubmit} className="space-y-4">
        <div>
          <label htmlFor="cpf" className="block text-sm font-bold text-foreground mb-2">
            CPF
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <Input
              id="cpf"
              type="text"
              placeholder="000.000.000-00"
              value={cpf}
              onChange={onCPFChange}
              maxLength={14}
              inputMode="numeric"
              required
              className="pl-10"
            />
          </div>
        </div>

        <Button 
          type="submit" 
          variant="hero" 
          size="lg" 
          className="w-full mt-6"
          disabled={isLoading}
        >
          {isLoading ? (
            <span className="flex items-center gap-2">
              <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              Verificando...
            </span>
          ) : (
            <>
              Continuar
              <ArrowRight size={20} />
            </>
          )}
        </Button>
      </form>
    );
  }

  return (
    <form onSubmit={onPasswordSubmit} className="space-y-4">
      <PasswordInput
        label="Senha"
        placeholder="Digite sua senha"
        value={senha}
        onChange={(e) => (e.target.value)}
        required
      />

      <Button 
        type="submit" 
        variant="hero" 
        size="lg" 
        className="w-full mt-6"
        disabled={isLoading}
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
            Entrando...
          </span>
        ) : (
          <>
            Entrar
            <ArrowRight size={20} />
          </>
        )}
      </Button>

      <div className="flex gap-2">
        <Button
          type="button"
          variant="outline"
          className="w-full text-sm h-9"
          onClick={onForgotPassword}
          disabled={isSendingReset}
        >
          {isSendingReset ? 'Enviando...' : 'Esqueci minha senha'}
        </Button>
        <Button
          type="button"
          variant="outline"
          className="w-full text-sm h-9"
          onClick={onSupport}
        >
          <HelpCircle size={14} />
          Suporte
        </Button>
      </div>
    </form>
  );
};