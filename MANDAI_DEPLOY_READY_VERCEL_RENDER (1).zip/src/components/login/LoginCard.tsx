import React from 'react';
import { LoginForm } from './LoginForm';
import type { FormData } from '@/hooks/useRegisterForm';

interface LoginCardProps {
  cpf: string;
  senha: string;
  showPassword: boolean;
  isLoading: boolean;
  isSendingReset: boolean;
  hasSavedProgress: boolean;
  onCPFChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onCPFSubmit: (e: React.FormEvent) => void;
  onPasswordSubmit: (e: React.FormEvent) => void;
  onForgotPassword: () => void;
  onSupport: () => void;
}

export const LoginCard: React.FC<LoginCardProps> = ({
  cpf,
  senha,
  showPassword,
  isLoading,
  isSendingReset,
  hasSavedProgress,
  onCPFChange,
  onCPFSubmit,
  onPasswordSubmit,
  onForgotPassword,
  onSupport,
}) => {
  return (
    <div className="bg-card rounded-3xl shadow-card p-6 animate-slide-up mt-6" style={{ animationDelay: '0.1s' }}>
      <h2 className="text-xl font-bold text-foreground text-center mb-6">
        {showPassword ? 'Bem-vindo de volta!' : 'Comece agora'}
      </h2>

      <LoginForm
        cpf={cpf}
        senha={senha}
        showPassword={showPassword}
        isLoading={isLoading}
        isSendingReset={isSendingReset}
        hasSavedProgress={hasSavedProgress}
        onCPFChange={onCPFChange}
        onCPFSubmit={onCPFSubmit}
        onPasswordSubmit={onPasswordSubmit}
        onForgotPassword={onForgotPassword}
        onSupport={onSupport}
      />
    </div>
  );
};