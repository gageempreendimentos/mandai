import React from 'react';
import { Button } from '@/components/ui/button';
import { Truck } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import type { FormData } from '@/hooks/useRegisterForm';

interface LoginDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  hasSavedProgress: boolean;
  savedStep: number;
  savedData: FormData;
  onRegister: () => void;
  onContinueProgress: () => void;
  onSupport: () => void;
}

export const LoginDialog: React.FC<LoginDialogProps> = ({
  isOpen,
  onOpenChange,
  hasSavedProgress,
  savedStep,
  savedData,
  onRegister,
  onContinueProgress,
  onSupport,
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-center text-xl">
            {hasSavedProgress ? 'Continuar cadastro?' : 'CPF não encontrado'}
          </DialogTitle>
          {hasSavedProgress && (
            <DialogDescription className="text-center">
              Você estava no passo {savedStep}. Deseja continuar de onde parou?
            </DialogDescription>
          )}
        </DialogHeader>
        <div className="py-4 space-y-2">
          {hasSavedProgress && (
            <p className="text-center text-foreground">
              Selecione continuar para voltar ao passo salvo.
            </p>
          )}
        </div>
        <DialogFooter className="flex flex-col gap-2 sm:flex-col">
          {hasSavedProgress && (
            <Button 
              variant="hero" 
              size="lg" 
              onClick={onContinueProgress}
              className="w-full"
            >
              Continuar do Passo {savedStep}
            </Button>
          )}
          <Button 
            variant={hasSavedProgress ? "outline" : "hero"} 
            size="lg" 
            onClick={onRegister}
            className="w-full"
          >
            <Truck size={18} />
            {hasSavedProgress ? 'Novo Cadastro' : 'Sim, quero me cadastrar'}
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            onClick={() => onOpenChange(false)}
            className="w-full"
          >
            Voltar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};