import React from "react";

export default function OpenInMapsButton({ lat, lng, label="Abrir no Maps" }:{ lat:number; lng:number; label?:string }) {
  const url = `https://www.mandaigle.com/maps/dir/?api=1&destination=${lat},${lng}`;
  return (
    <a className="rounded-xl border px-3 py-2 text-sm inline-flex items-center gap-2" href={url} target="_blank" rel="noreferrer">
      {label}
    </a>
  );
}
