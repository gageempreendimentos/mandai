import React from 'react';
import { 
  Package, 
  DollarSign, 
  Clock, 
  Star, 
  TrendingUp, 
  Award,
  MapPin,
  Calendar,
  CheckCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface ClientStatsTabProps {
  deliveries: any[];
}

const ClientStatsTab: React.FC<ClientStatsTabProps> = ({ deliveries }) => {
  const completedDeliveries = deliveries.filter(d => d.status === 'delivered');
  const totalSpent = completedDeliveries.reduce((sum, d) => sum + (d.value || 0), 0);
  const averageValue = completedDeliveries.length > 0 
    ? totalSpent / completedDeliveries.length 
    : 0;
  
  const pendingDeliveries = deliveries.filter(d => d.status === 'pending').length;
  const inTransitDeliveries = deliveries.filter(d => d.status === 'in_transit').length;
  
  // Calculate average delivery time (mock data - would need actual timestamps)
  const avgDeliveryTime = completedDeliveries.length > 0 ? '45 min' : 'N/A';
  
  // Most frequent delivery address (mock)
  const mostFrequentAddress = completedDeliveries.length > 0 
    ? completedDeliveries[0].delivery_address.split(',')[0] 
    : 'N/A';

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-primary">Total Gasto</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-primary">
              R$ {totalSpent.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {completedDeliveries.length} entregas concluídas
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-accent">Média por Entrega</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-accent">
              R$ {averageValue.toFixed(2)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Valor médio por entrega
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-600">Ativas</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">
              {pendingDeliveries + inTransitDeliveries}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {pendingDeliveries} pendentes • {inTransitDeliveries} em trânsito
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500/10 to-orange-500/5 border-orange-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-orange-600">Tempo Médio</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-orange-600">
              {avgDeliveryTime}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Por entrega concluída
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Activity Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp size={18} className="text-primary" />
            Atividade Recente
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Package size={18} className="text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium">Entregas Totais</p>
                <p className="text-xs text-muted-foreground">Desde o início</p>
              </div>
            </div>
            <Badge variant="secondary">{deliveries.length}</Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle size={18} className="text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium">Concluídas</p>
                <p className="text-xs text-muted-foreground">Entregues com sucesso</p>
              </div>
            </div>
            <Badge variant="secondary" className="bg-green-500/10 text-green-600 border-green-500/20">
              {completedDeliveries.length}
            </Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <MapPin size={18} className="text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium">Destino Mais Frequentado</p>
                <p className="text-xs text-muted-foreground truncate max-w-[150px]">
                  {mostFrequentAddress}
                </p>
              </div>
            </div>
            <Badge variant="secondary">{completedDeliveries.length}x</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award size={18} className="text-primary" />
            Estatísticas Rápidas
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-3">
          <div className="text-center p-3 bg-muted rounded-lg">
            <p className="text-2xl font-bold text-primary">
              {deliveries.filter(d => d.status === 'pending').length}
            </p>
            <p className="text-xs text-muted-foreground">Aguardando</p>
          </div>
          <div className="text-center p-3 bg-muted rounded-lg">
            <p className="text-2xl font-bold text-blue-600">
              {deliveries.filter(d => d.status === 'accepted').length}
            </p>
            <p className="text-xs text-muted-foreground">Aceitas</p>
          </div>
          <div className="text-center p-3 bg-muted rounded-lg">
            <p className="text-2xl font-bold text-purple-600">
              {deliveries.filter(d => d.status === 'in_transit').length}
            </p>
            <p className="text-xs text-muted-foreground">Em Trânsito</p>
          </div>
          <div className="text-center p-3 bg-muted rounded-lg">
            <p className="text-2xl font-bold text-green-600">
              {deliveries.filter(d => d.status === 'delivered').length}
            </p>
            <p className="text-xs text-muted-foreground">Entregues</p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar size={18} className="text-primary" />
            Linha do Tempo
          </CardTitle>
        </CardHeader>
        <CardContent>
          {deliveries.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-4">
              Nenhuma atividade recente
            </p>
          ) : (
            <div className="space-y-3">
              {deliveries.slice(0, 5).map((delivery) => (
                <div key={delivery.id} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    delivery.status === 'delivered' ? 'bg-green-500/10' :
                    delivery.status === 'cancelled' ? 'bg-red-500/10' :
                    delivery.status === 'in_transit' ? 'bg-purple-500/10' :
                    delivery.status === 'accepted' ? 'bg-blue-500/10' :
                    'bg-orange-500/10'
                  }`}>
                    <Package size={14} className={
                      delivery.status === 'delivered' ? 'text-green-600' :
                      delivery.status === 'cancelled' ? 'text-red-600' :
                      delivery.status === 'in_transit' ? 'text-purple-600' :
                      delivery.status === 'accepted' ? 'text-blue-600' :
                      'text-orange-600'
                    } />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {delivery.delivery_address.split(',')[0]}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(delivery.created_at).toLocaleDateString('pt-BR', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      })} • R$ {delivery.value.toFixed(2)}
                    </p>
                  </div>
                  <Badge variant="secondary" className={
                    delivery.status === 'delivered' ? 'bg-green-500/10 text-green-600 border-green-500/20' :
                    delivery.status === 'cancelled' ? 'bg-red-500/10 text-red-600 border-red-500/20' :
                    delivery.status === 'in_transit' ? 'bg-purple-500/10 text-purple-600 border-purple-500/20' :
                    delivery.status === 'accepted' ? 'bg-blue-500/10 text-blue-600 border-blue-500/20' :
                    'bg-orange-500/10 text-orange-600 border-orange-500/20'
                  }>
                    {delivery.status === 'delivered' ? 'Entregue' :
                     delivery.status === 'cancelled' ? 'Cancelado' :
                     delivery.status === 'in_transit' ? 'Em trânsito' :
                     delivery.status === 'accepted' ? 'Aceito' : 'Pendente'}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientStatsTab;