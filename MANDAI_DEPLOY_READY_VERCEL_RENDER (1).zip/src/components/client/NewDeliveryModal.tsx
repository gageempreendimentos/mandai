import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { 
  MapPin, 
  Package, 
  Shield, 
  Key, 
  Search, 
  ChevronRight, 
  ChevronLeft,
  AlertCircle
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DeliveryFormData {
  pickup_address: string;
  delivery_address: string;
  description: string;
  value: number;
  delivery_code: string;
  cep_retirada: string;
  cep_entrega: string;
  numero_retirada: string;
  numero_entrega: string;
  complemento_retirada: string;
  complemento_entrega: string;
  has_security_code: boolean;
}

interface NewDeliveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (data: DeliveryFormData) => Promise<void>;
  isLoading: boolean;
}

const NewDeliveryModal: React.FC<NewDeliveryModalProps> = ({
  isOpen,
  onClose,
  onCreate,
  isLoading,
}) => {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<DeliveryFormData>({
    pickup_address: '',
    delivery_address: '',
    description: '',
    value: 0,
    delivery_code: '',
    cep_retirada: '',
    cep_entrega: '',
    numero_retirada: '',
    numero_entrega: '',
    complemento_retirada: '',
    complemento_entrega: '',
    has_security_code: false,
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const calculateDeliveryValue = (distance: number): number => {
    return 5 + (distance * 2);
  };

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return formData.cep_retirada.length >= 7 && formData.numero_retirada.trim() !== '';
      case 2:
        return formData.cep_entrega.length >= 7 && formData.numero_entrega.trim() !== '';
      case 3:
        return formData.description.trim() !== '' && formData.value > 0;
      case 4:
        if (formData.has_security_code) {
          return formData.delivery_code.length >= 4;
        }
        return true;
      default:
        return false;
    }
  };

  const nextStep = () => {
    if (validateStep(step)) {
      setStep(prev => prev + 1);
    } else {
      toast({ title: "Campo obrigatório", description: "Preencha todos os campos obrigatórios", variant: "destructive" });
    }
  };

  const prevStep = () => {
    setStep(prev => prev - 1);
  };

  const resetForm = () => {
    setStep(1);
    setFormData({
      pickup_address: '',
      delivery_address: '',
      description: '',
      value: 0,
      delivery_code: '',
      cep_retirada: '',
      cep_entrega: '',
      numero_retirada: '',
      numero_entrega: '',
      complemento_retirada: '',
      complemento_entrega: '',
      has_security_code: false,
    });
  };

  const handleAddressSearch = async (cep: string, type: 'pickup' | 'delivery') => {
    if (cep.length !== 8) return;

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await response.json();
      
      if (data.erro) {
        toast({ title: "CEP não encontrado", description: "Verifique o CEP e tente novamente", variant: "destructive" });
        return;
      }

      const address = `${data.logradouro}, ${data.bairro}, ${data.localidade}/${data.uf}`;
      
      if (type === 'pickup') {
        setFormData(prev => ({ ...prev, pickup_address: address }));
      } else {
        setFormData(prev => ({ ...prev, delivery_address: address }));
      }

      toast({ title: "Endereço encontrado!", description: `${data.logradouro}, ${data.bairro}` });
    } catch (error) {
      toast({ title: "Erro ao buscar CEP", description: "Tente novamente", variant: "destructive" });
    }
  };

  const handleCreate = async () => {
    await onCreate(formData);
    resetForm();
  };

  const handleCancel = () => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) handleCancel();
    }}>
      <DialogContent className="max-w-md bg-white text-gray-900 border-gray-200 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900">Nova Entrega</DialogTitle>
          <p className="text-sm text-gray-600">Passo {step} de 4</p>
        </DialogHeader>

        {/* Progress Bar */}
        <div className="flex gap-1 mb-4">
          {[1, 2, 3, 4].map((s) => (
            <div 
              key={s}
              className={`h-1 flex-1 rounded-full ${s <= step ? 'bg-primary' : 'bg-gray-200'}`}
            />
          ))}
        </div>

        {/* Step 1: Endereço de Retirada */}
        {step === 1 && (
          <div className="space-y-4 py-2">
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <MapPin size={16} className="text-primary" />
                Endereço de Retirada
              </h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">CEP *</label>
                  <div className="relative">
                    <Input
                      placeholder="00000-000"
                      value={formData.cep_retirada}
                      onChange={(e) => {
                        const formatted = e.target.value.replace(/\D/g, '').slice(0, 8);
                        setFormData(prev => ({ ...prev, cep_retirada: formatted }));
                        if (formatted.length === 8) {
                          handleAddressSearch(formatted, 'pickup');
                        }
                      }}
                      maxLength={8}
                      inputMode="numeric"
                      className="pr-12"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddressSearch(formData.cep_retirada, 'pickup')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      disabled={formData.cep_retirada.length !== 8}
                    >
                      <Search size={16} />
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Número *</label>
                  <Input
                    placeholder="Nº"
                    value={formData.numero_retirada}
                    onChange={(e) => setFormData(prev => ({ ...prev, numero_retirada: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Complemento</label>
                  <Input
                    placeholder="Apto, bloco, etc."
                    value={formData.complemento_retirada}
                    onChange={(e) => setFormData(prev => ({ ...prev, complemento_retirada: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Endereço Completo *</label>
                  <Textarea
                    placeholder="Rua, número, bairro, cidade/UF"
                    value={formData.pickup_address}
                    onChange={(e) => setFormData(prev => ({ ...prev, pickup_address: e.target.value }))}
                    rows={2}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Endereço de Entrega */}
        {step === 2 && (
          <div className="space-y-4 py-2">
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <MapPin size={16} className="text-accent" />
                Endereço de Entrega
              </h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">CEP *</label>
                  <div className="relative">
                    <Input
                      placeholder="00000-000"
                      value={formData.cep_entrega}
                      onChange={(e) => {
                        const formatted = e.target.value.replace(/\D/g, '').slice(0, 8);
                        setFormData(prev => ({ ...prev, cep_entrega: formatted }));
                        if (formatted.length === 8) {
                          handleAddressSearch(formatted, 'delivery');
                        }
                      }}
                      maxLength={8}
                      inputMode="numeric"
                      className="pr-12"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddressSearch(formData.cep_entrega, 'delivery')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-primary/10 text-primary hover:bg-primary/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      disabled={formData.cep_entrega.length !== 8}
                    >
                      <Search size={16} />
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Número *</label>
                  <Input
                    placeholder="Nº"
                    value={formData.numero_entrega}
                    onChange={(e) => setFormData(prev => ({ ...prev, numero_entrega: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Complemento</label>
                  <Input
                    placeholder="Apto, bloco, etc."
                    value={formData.complemento_entrega}
                    onChange={(e) => setFormData(prev => ({ ...prev, complemento_entrega: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Endereço Completo *</label>
                  <Textarea
                    placeholder="Rua, número, bairro, cidade/UF"
                    value={formData.delivery_address}
                    onChange={(e) => setFormData(prev => ({ ...prev, delivery_address: e.target.value }))}
                    rows={2}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Descrição e Valor */}
        {step === 3 && (
          <div className="space-y-4 py-2">
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Package size={16} className="text-primary" />
                Detalhes da Entrega
              </h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Descrição do Item *</label>
                  <Textarea
                    placeholder="Ex: Caixa com documentos, pacote pequeno, etc."
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-900 mb-1">Valor (R$) *</label>
                  <Input
                    type="number"
                    placeholder="0,00"
                    value={formData.value || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, value: parseFloat(e.target.value) || 0 }))}
                    step="0.5"
                    min="0"
                  />
                  <p className="text-xs text-gray-600 mt-1">
                    Valor estimado: {formatCurrency(calculateDeliveryValue(3))} (3km)
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Código de Segurança (Opcional) */}
        {step === 4 && (
          <div className="space-y-4 py-2">
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Shield size={16} className="text-primary" />
                Código de Segurança (Opcional)
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200">
                  <div className="flex items-center gap-3">
                    <Key size={18} className="text-primary" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Usar código de segurança</p>
                      <p className="text-xs text-gray-600">O entregador precisará informar este código</p>
                    </div>
                  </div>
                  <Switch
                    checked={formData.has_security_code}
                    onCheckedChange={(checked) => {
                      setFormData(prev => ({ ...prev, has_security_code: checked }));
                      if (!checked) {
                        setFormData(prev => ({ ...prev, delivery_code: '' }));
                      }
                    }}
                  />
                </div>

                {formData.has_security_code && (
                  <div className="animate-fade-in">
                    <label className="block text-sm font-medium text-gray-900 mb-1">Código (4+ dígitos) *</label>
                    <Input
                      placeholder="Ex: 1234"
                      value={formData.delivery_code}
                      onChange={(e) => {
                        const formatted = e.target.value.replace(/\D/g, '');
                        setFormData(prev => ({ ...prev, delivery_code: formatted }));
                      }}
                      maxLength={8}
                      inputMode="numeric"
                    />
                    <p className="text-xs text-gray-600 mt-1">
                      Este código será usado pelo entregador para confirmar a entrega
                    </p>
                  </div>
                )}

                {!formData.has_security_code && (
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                    <p className="text-sm text-orange-800">
                      <strong>Atenção:</strong> Sem código de segurança, qualquer pessoa pode confirmar a entrega.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Resumo Final */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-4">
              <h4 className="font-bold text-green-800 mb-2">Resumo da Entrega</h4>
              <div className="space-y-1 text-sm">
                <p className="text-green-700"><strong>De:</strong> {formData.pickup_address.split(',')[0]}</p>
                <p className="text-green-700"><strong>Para:</strong> {formData.delivery_address.split(',')[0]}</p>
                <p className="text-green-700"><strong>Valor:</strong> {formatCurrency(formData.value)}</p>
                {formData.has_security_code && (
                  <p className="text-green-700"><strong>Código:</strong> {formData.delivery_code}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex gap-2 pt-2">
          {step > 1 && (
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={prevStep}
            >
              <ChevronLeft size={16} />
              Voltar
            </Button>
          )}
          
          {step < 4 ? (
            <Button 
              variant="hero" 
              className="flex-1"
              onClick={nextStep}
            >
              Próximo
              <ChevronRight size={16} />
            </Button>
          ) : (
            <Button 
              variant="hero" 
              className="flex-1"
              onClick={handleCreate}
              disabled={isLoading}
            >
              {isLoading ? 'Criando...' : 'Criar Entrega'}
            </Button>
          )}
        </div>

        {/* Cancel Button */}
        <Button 
          variant="ghost" 
          className="w-full mt-2 text-gray-600"
          onClick={handleCancel}
        >
          Cancelar
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default NewDeliveryModal;