import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertCircle } from 'lucide-react';

interface PhotoModalProps {
  isOpen: boolean;
  onClose: () => void;
  photoUrl?: string;
}

const PhotoModal: React.FC<PhotoModalProps> = ({ isOpen, onClose, photoUrl }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-white text-gray-900 border-gray-200">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900">Foto da Entrega</DialogTitle>
        </DialogHeader>
        
        {photoUrl ? (
          <div className="rounded-xl overflow-hidden bg-gray-100">
            <img 
              src={photoUrl} 
              alt="Comprovante" 
              className="w-full h-auto max-h-[60vh] object-contain"
            />
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertCircle size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-gray-600">Ainda não há foto disponível</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PhotoModal;