import React from 'react';
import { User, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ClientHeaderProps {
  user: any;
  deliveryCount: number;
  onLogout: () => void;
}

const ClientHeader: React.FC<ClientHeaderProps> = ({ user, deliveryCount, onLogout }) => {
  return (
    <header className="sticky top-0 z-20 flex items-center gap-4 p-4 bg-background border-b border-border backdrop-blur-sm bg-opacity-95">
      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
        <User size={20} className="text-primary" />
      </div>
      <div className="flex-1">
        <h1 className="text-lg font-bold text-foreground">Minhas Entregas</h1>
        <p className="text-xs text-muted-foreground">{deliveryCount} pedidos</p>
      </div>
      <Button 
        variant="ghost" 
        size="icon"
        onClick={onLogout}
        className="hover:bg-destructive/10 hover:text-destructive"
      >
        <LogOut size={18} />
      </Button>
    </header>
  );
};

export default ClientHeader;