import React from 'react';
import { Filter, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface ClientFiltersProps {
  filterDate: string;
  filterStatus: 'all' | 'pending' | 'accepted' | 'in_transit' | 'delivered' | 'cancelled';
  onDateChange: (date: string) => void;
  onStatusChange: (status: 'all' | 'pending' | 'accepted' | 'in_transit' | 'delivered' | 'cancelled') => void;
  onApplyFilters: () => void;
}

const ClientFilters: React.FC<ClientFiltersProps> = ({
  filterDate,
  filterStatus,
  onDateChange,
  onStatusChange,
  onApplyFilters,
}) => {
  return (
    <div className="bg-card rounded-xl p-4 border border-border">
      <div className="flex items-center gap-2 mb-3">
        <Filter size={16} className="text-primary" />
        <span className="font-medium">Filtros</span>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs text-muted-foreground mb-1">Data</label>
          <Input
            type="date"
            value={filterDate}
            onChange={(e) => onDateChange(e.target.value)}
            className="h-9"
          />
        </div>
        <div>
          <label className="block text-xs text-muted-foreground mb-1">Status</label>
          <select
            value={filterStatus}
            onChange={(e) => onStatusChange(e.target.value as any)}
            className="w-full h-9 px-3 rounded-md border border-input bg-background text-sm"
          >
            <option value="all">Todos</option>
            <option value="pending">Aguardando</option>
            <option value="accepted">Aceito</option>
            <option value="in_transit">Em trânsito</option>
            <option value="delivered">Entregue</option>
            <option value="cancelled">Cancelado</option>
          </select>
        </div>
      </div>
      <Button 
        variant="outline" 
        className="w-full mt-3"
        onClick={onApplyFilters}
      >
        <RefreshCw size={14} className="mr-2" />
        Aplicar Filtros
      </Button>
    </div>
  );
};

export default ClientFilters;