import React from 'react';
import { MapPin, Phone, MessageCircle, Camera, CheckCircle, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

interface Delivery {
  id: string;
  pickup_address: string;
  delivery_address: string;
  description: string;
  value: number;
  status: 'pending' | 'accepted' | 'in_transit' | 'delivered' | 'cancelled';
  driver_id?: string;
  driver_name?: string;
  driver_phone?: string;
  photo_url?: string;
  created_at: string;
}

interface ClientDeliveryCardProps {
  delivery: Delivery;
  onChat: (delivery: Delivery) => void;
  onPhoto: (delivery: Delivery) => void;
  onConfirm: (deliveryId: string) => void;
  onRate: (delivery: Delivery) => void;
  onCall: (phone: string) => void;
}

const getStatusBadge = (status: string) => {
  const config = {
    pending: { text: 'Aguardando', color: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20' },
    accepted: { text: 'Aceito', color: 'bg-blue-500/10 text-blue-500 border-blue-500/20' },
    in_transit: { text: 'Em trânsito', color: 'bg-purple-500/10 text-purple-500 border-purple-500/20' },
    delivered: { text: 'Entregue', color: 'bg-green-500/10 text-green-500 border-green-500/20' },
    cancelled: { text: 'Cancelado', color: 'bg-red-500/10 text-red-500 border-red-500/20' },
  };
  return config[status as keyof typeof config] || config.pending;
};

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR', { 
    day: '2-digit', 
    month: '2-digit', 
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const ClientDeliveryCard: React.FC<ClientDeliveryCardProps> = ({
  delivery,
  onChat,
  onPhoto,
  onConfirm,
  onRate,
  onCall,
}) => {
  const status = getStatusBadge(delivery.status);

  return (
    <Card className="border border-border/50">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <Badge className={status.color}>{status.text}</Badge>
            {delivery.driver_name && (
              <span className="text-xs text-muted-foreground">
                {delivery.driver_name}
              </span>
            )}
          </div>
          <span className="text-lg font-bold text-primary">
            {formatCurrency(delivery.value)}
          </span>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-start gap-2 text-sm">
          <MapPin size={14} className="text-primary mt-0.5 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-foreground truncate">
              {delivery.pickup_address.split(',')[0]}
            </p>
            <p className="text-xs text-muted-foreground">Retirada</p>
          </div>
        </div>
        <div className="flex items-start gap-2 text-sm">
          <MapPin size={14} className="text-accent mt-0.5 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="font-medium text-foreground truncate">
              {delivery.delivery_address.split(',')[0]}
            </p>
            <p className="text-xs text-muted-foreground">Entrega</p>
          </div>
        </div>
        {delivery.description && (
          <p className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-2">
            {delivery.description}
          </p>
        )}
        
        {/* Ações baseadas no status */}
        <div className="flex gap-2 pt-2">
          {delivery.status === 'accepted' && delivery.driver_phone && (
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => onCall(delivery.driver_phone!)}
            >
              <Phone size={14} />
              Ligar
            </Button>
          )}
          
          {delivery.status === 'accepted' && (
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => onChat(delivery)}
            >
              <MessageCircle size={14} />
              Chat
            </Button>
          )}
          
          {delivery.status === 'in_transit' && (
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => onPhoto(delivery)}
            >
              <Camera size={14} />
              Ver Foto
            </Button>
          )}
          
          {delivery.status === 'in_transit' && (
            <Button 
              variant="hero" 
              size="sm" 
              className="flex-1"
              onClick={() => onConfirm(delivery.id)}
            >
              <CheckCircle size={14} />
              Confirmar
            </Button>
          )}
          
          {delivery.status === 'delivered' && (
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => onRate(delivery)}
            >
              <Star size={14} />
              Avaliar
            </Button>
          )}
        </div>

        <div className="text-xs text-muted-foreground pt-1">
          {formatDate(delivery.created_at)}
        </div>
      </CardContent>
    </Card>
  );
};

export default ClientDeliveryCard;