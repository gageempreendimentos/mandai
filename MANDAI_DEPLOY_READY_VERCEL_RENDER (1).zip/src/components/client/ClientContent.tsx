import React from 'react';
import { Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import EmptyState from '@/components/EmptyState';
import { Plus } from 'lucide-react';
import ClientDeliveryCard from './ClientDeliveryCard';
import ClientFilters from './ClientFilters';
import ClientProfileTab from './ClientProfileTab';
import ClientSupportTab from './ClientSupportTab';
import ClientStatsTab from './ClientStatsTab';

interface Delivery {
  id: string;
  pickup_address: string;
  delivery_address: string;
  description: string;
  value: number;
  status: 'pending' | 'accepted' | 'in_transit' | 'delivered' | 'cancelled';
  driver_id?: string;
  driver_name?: string;
  driver_phone?: string;
  photo_url?: string;
  created_at: string;
}

interface ClientContentProps {
  activeTab: 'inicio' | 'historico' | 'perfil' | 'suporte' | 'estatisticas';
  deliveries: Delivery[];
  filteredDeliveries: Delivery[];
  filterDate: string;
  filterStatus: 'all' | 'pending' | 'accepted' | 'in_transit' | 'delivered' | 'cancelled';
  onDateChange: (date: string) => void;
  onStatusChange: (status: 'all' | 'pending' | 'accepted' | 'in_transit' | 'delivered' | 'cancelled') => void;
  onApplyFilters: () => void;
  onNewDelivery: () => void;
  onChat: (delivery: Delivery) => void;
  onPhoto: (delivery: Delivery) => void;
  onConfirm: (deliveryId: string) => void;
  onRate: (delivery: Delivery) => void;
  onCall: (phone: string) => void;
  user: any;
}

const ClientContent: React.FC<ClientContentProps> = ({
  activeTab,
  deliveries,
  filteredDeliveries,
  filterDate,
  filterStatus,
  onDateChange,
  onStatusChange,
  onApplyFilters,
  onNewDelivery,
  onChat,
  onPhoto,
  onConfirm,
  onRate,
  onCall,
  user,
}) => {
  return (
    <div className="flex-1 overflow-auto p-4 space-y-4 pb-24">
      {/* Início Tab */}
      {activeTab === 'inicio' && (
        <>
          {/* Botão Nova Entrega */}
          <Button 
            variant="hero" 
            size="lg" 
            className="w-full shadow-lg"
            onClick={onNewDelivery}
          >
            <Plus size={18} />
            Nova Entrega
          </Button>

          {/* Entregas Ativas */}
          {filteredDeliveries.filter(d => d.status !== 'delivered' && d.status !== 'cancelled').length > 0 ? (
            <div className="space-y-3">
              <h2 className="text-lg font-bold text-foreground">Entregas Ativas</h2>
              {filteredDeliveries
                .filter(d => d.status !== 'delivered' && d.status !== 'cancelled')
                .map((delivery) => (
                  <ClientDeliveryCard
                    key={delivery.id}
                    delivery={delivery}
                    onChat={onChat}
                    onPhoto={onPhoto}
                    onConfirm={onConfirm}
                    onRate={onRate}
                    onCall={onCall}
                  />
                ))}
            </div>
          ) : (
            <EmptyState
              icon={Package}
              title="Nenhuma entrega ativa"
              description='Clique em "Nova Entrega" para começar'
              actionLabel="Nova Entrega"
              onAction={onNewDelivery}
            />
          )}
        </>
      )}

      {/* Histórico Tab */}
      {activeTab === 'historico' && (
        <div className="space-y-4">
          <ClientFilters
            filterDate={filterDate}
            filterStatus={filterStatus}
            onDateChange={onDateChange}
            onStatusChange={onStatusChange}
            onApplyFilters={onApplyFilters}
          />

          {filteredDeliveries.length === 0 ? (
            <div className="text-center py-8">
              <Package size={48} className="text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium text-foreground mb-2">Nenhuma entrega</p>
              <p className="text-sm text-muted-foreground">
                {filterStatus !== 'all' || filterDate ? 'Ajuste os filtros' : 'Sem entregas no histórico'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredDeliveries.map((delivery) => (
                <ClientDeliveryCard
                  key={delivery.id}
                  delivery={delivery}
                  onChat={onChat}
                  onPhoto={onPhoto}
                  onConfirm={onConfirm}
                  onRate={onRate}
                  onCall={onCall}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Estatísticas Tab */}
      {activeTab === 'estatisticas' && <ClientStatsTab deliveries={deliveries} />}

      {/* Perfil Tab */}
      {activeTab === 'perfil' && <ClientProfileTab user={user} />}

      {/* Suporte Tab */}
      {activeTab === 'suporte' && <ClientSupportTab />}
    </div>
  );
};

export default ClientContent;