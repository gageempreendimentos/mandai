import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface RatingModalProps {
  isOpen: boolean;
  onClose: () => void;
  deliveryId: string;
  driverId?: string;
  driverName?: string;
  userId: string;
}

const RatingModal: React.FC<RatingModalProps> = ({
  isOpen,
  onClose,
  deliveryId,
  driverId,
  driverName,
  userId,
}) => {
  const { toast } = useToast();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) {
      toast({ title: "Avaliação necessária", description: "Selecione uma nota de 1 a 5", variant: "destructive" });
      return;
    }

    setIsLoading(true);

    try {
      const { error } = await supabase
        .from('delivery_feedback')
        .insert({
          delivery_id: deliveryId,
          driver_id: driverId,
          rating: rating,
          comment: comment || null,
          customer_name: 'Cliente',
        });

      if (error) throw error;

      toast({
        title: "Avaliação enviada! ⭐",
        description: "Obrigado pelo feedback",
      });

      setRating(0);
      setComment('');
      onClose();
    } catch (error) {
      console.error('Erro ao avaliar:', error);
      toast({
        title: "Erro ao enviar avaliação",
        description: "Tente novamente",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setRating(0);
    setComment('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleCancel}>
      <DialogContent className="max-w-md bg-white text-gray-900 border-gray-200">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900">Avaliar Entrega</DialogTitle>
          <p className="text-sm text-gray-600">
            Como foi sua experiência com {driverName || 'este entregador'}?
          </p>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          {/* Rating Stars */}
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => setRating(star)}
                className="p-1"
              >
                <Star
                  size={32}
                  className={star <= rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}
                />
              </button>
            ))}
          </div>

          {/* Comment */}
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">Comentário (opcional)</label>
            <Textarea
              placeholder="Conte como foi sua experiência..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleCancel}
            disabled={isLoading}
          >
            Cancelar
          </Button>
          <Button 
            variant="hero" 
            className="flex-1"
            onClick={handleSubmit}
            disabled={rating === 0 || isLoading}
          >
            {isLoading ? 'Enviando...' : 'Enviar Avaliação'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default RatingModal;