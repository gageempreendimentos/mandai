import React from 'react';
import { MessageCircle, Phone, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const ClientSupportTab: React.FC = () => {
  const handleWhatsApp = () => {
    const message = 'Olá, preciso de ajuda com minha conta MANDAI';
    const whatsappUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handlePhone = () => {
    window.open('tel:08001234567', '_blank');
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle size={18} className="text-primary" />
            Suporte Rápido
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button 
            variant="hero" 
            className="w-full"
            onClick={handleWhatsApp}
          >
            <MessageCircle size={18} />
            WhatsApp
          </Button>
          <Button 
            variant="outline" 
            className="w-full"
            onClick={handlePhone}
          >
            <Phone size={18} />
            Telefone: 0800 123-4567
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle size={18} className="text-primary" />
            Informações Úteis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-muted-foreground">
          <div className="flex items-start gap-2">
            <AlertCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <p><strong>Problemas com a entrega?</strong> Entre em contato imediatamente pelo WhatsApp</p>
          </div>
          <div className="flex items-start gap-2">
            <AlertCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <p><strong>Código de entrega:</strong> Guarde-o para confirmar a entrega</p>
          </div>
          <div className="flex items-start gap-2">
            <AlertCircle size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <p><strong>Horário de atendimento:</strong> Segunda a Domingo, 8h às 22h</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ClientSupportTab;