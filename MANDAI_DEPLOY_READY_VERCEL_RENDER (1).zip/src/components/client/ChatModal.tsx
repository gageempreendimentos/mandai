import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, MessageSquare } from 'lucide-react';

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  deliveryId: string;
  driverName?: string;
  userId: string;
}

/**
 * ChatModal - Componente simplificado
 * 
 * NOTA: A tabela 'chat_messages' ainda não existe no banco de dados.
 * Este componente está preparado para quando a funcionalidade for implementada.
 */
const ChatModal: React.FC<ChatModalProps> = ({
  isOpen,
  onClose,
  deliveryId,
  driverName,
  userId,
}) => {
  const [message, setMessage] = useState('');

  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    // TODO: Implementar quando a tabela chat_messages for criada
    console.log('Mensagem:', message, 'DeliveryId:', deliveryId, 'UserId:', userId);
    setMessage('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-card text-foreground border-border">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <MessageSquare size={20} className="text-primary" />
            Chat
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            {driverName ? `Com ${driverName}` : 'Aguardando entregador'}
          </p>
        </DialogHeader>
        
        <div className="h-64 overflow-auto space-y-2 py-2 bg-muted rounded-lg p-3">
          <div className="flex flex-col items-center justify-center h-full text-center">
            <MessageSquare size={40} className="text-muted-foreground mb-3 opacity-50" />
            <p className="text-sm text-muted-foreground">
              Funcionalidade em desenvolvimento
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Em breve você poderá conversar com o entregador
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <Input
            placeholder="Digite sua mensagem..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            className="flex-1"
            disabled
          />
          <Button variant="hero" size="icon" onClick={handleSendMessage} disabled>
            <Send size={18} />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ChatModal;