import React, { useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { usePushNotificationsFCM } from '@/hooks/usePushNotificationsFCM';

interface ClientStatusNotificationProps {
  delivery: any;
  previousStatus?: string;
}

const ClientStatusNotification: React.FC<ClientStatusNotificationProps> = ({
  delivery,
  previousStatus,
}) => {
  const { toast } = useToast();
  const { requestPermission } = usePushNotificationsFCM();

  useEffect(() => {
    const notifyStatusChange = async () => {
      if (!delivery || !previousStatus || delivery.status === previousStatus) return;

      // Request permission if not already granted
      await requestPermission();

      // Status change messages
      const statusMessages: Record<string, { title: string; description: string }> = {
        accepted: {
          title: "Entrega aceita! 🚀",
          description: `${delivery.driver_name || 'Um entregador'} aceitou sua entrega`,
        },
        in_transit: {
          title: "Em trânsito! 📦",
          description: "Seu pedido está a caminho",
        },
        delivered: {
          title: "Entrega concluída! ✅",
          description: "Obrigado por usar nossos serviços",
        },
        cancelled: {
          title: "Entrega cancelada",
          description: "Sua entrega foi cancelada",
        },
      };

      const message = statusMessages[delivery.status];
      if (message) {
        toast({
          title: message.title,
          description: message.description,
          duration: 8000,
        });

        // Try to play sound for important updates
        if (delivery.status === 'accepted' || delivery.status === 'delivered') {
          try {
            const audio = new Audio('/sounds/status-update.mp3');
            audio.play().catch(() => {});
          } catch (e) {
            console.log('Não foi possível tocar áudio');
          }
        }
      }
    };

    notifyStatusChange();
  }, [delivery, previousStatus, toast, requestPermission]);

  return null;
};

export default ClientStatusNotification;