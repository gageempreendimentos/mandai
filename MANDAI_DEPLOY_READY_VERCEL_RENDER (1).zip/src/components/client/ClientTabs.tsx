import React from 'react';
import { Package, History, User, MessageCircle, BarChart } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface ClientTabsProps {
  activeTab: 'inicio' | 'historico' | 'perfil' | 'suporte' | 'estatisticas';
  onTabChange: (tab: 'inicio' | 'historico' | 'perfil' | 'suporte' | 'estatisticas') => void;
}

const ClientTabs: React.FC<ClientTabsProps> = ({ activeTab, onTabChange }) => {
  return (
    <div className="p-4 border-b border-border">
      <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as any)} className="w-full">
        <TabsList className="grid grid-cols-5 w-full">
          <TabsTrigger value="inicio" className="flex items-center gap-2">
            <Package size={16} /> Início
          </TabsTrigger>
          <TabsTrigger value="historico" className="flex items-center gap-2">
            <History size={16} /> Histórico
          </TabsTrigger>
          <TabsTrigger value="estatisticas" className="flex items-center gap-2">
            <BarChart size={16} /> Estatísticas
          </TabsTrigger>
          <TabsTrigger value="perfil" className="flex items-center gap-2">
            <User size={16} /> Perfil
          </TabsTrigger>
          <TabsTrigger value="suporte" className="flex items-center gap-2">
            <MessageCircle size={16} /> Suporte
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
};

export default ClientTabs;