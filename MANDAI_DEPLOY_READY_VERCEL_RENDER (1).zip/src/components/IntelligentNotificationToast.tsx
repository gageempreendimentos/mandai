import React, { useState, useEffect } from 'react';
import { X, MapPin, TrafficCone, Coffee, Gift } from 'lucide-react';

interface IntelligentNotificationToastProps {
  title: string;
  message: string;
  type: 'geolocation' | 'traffic' | 'rest' | 'promotion';
  onClose: () => void;
}

const IntelligentNotificationToast: React.FC<IntelligentNotificationToastProps> = ({
  title,
  message,
  type,
  onClose,
}) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      onClose();
    }, 8000);

    return () => clearTimeout(timer);
  }, [onClose]);

  const getIcon = () => {
    switch (type) {
      case 'geolocation':
        return <MapPin size={20} className="text-primary" />;
      case 'traffic':
        return <TrafficCone size={20} className="text-orange-500" />;
      case 'rest':
        return <Coffee size={20} className="text-blue-500" />;
      case 'promotion':
        return <Gift size={20} className="text-green-500" />;
    }
  };

  const getBgColor = () => {
    switch (type) {
      case 'geolocation':
        return 'bg-primary/10 border-primary/30';
      case 'traffic':
        return 'bg-orange-500/10 border-orange-500/30';
      case 'rest':
        return 'bg-blue-500/10 border-blue-500/30';
      case 'promotion':
        return 'bg-green-500/10 border-green-500/30';
    }
  };

  if (!isVisible) return null;

  return (
    <div className={`fixed top-20 right-4 z-50 max-w-sm animate-slide-in-right`}>
      <div className={`rounded-xl p-4 border shadow-lg backdrop-blur-sm ${getBgColor()}`}>
        <div className="flex items-start gap-3">
          <div className="mt-0.5">{getIcon()}</div>
          <div className="flex-1">
            <p className="font-bold text-foreground text-sm">{title}</p>
            <p className="text-xs text-foreground/80 mt-1 leading-relaxed">{message}</p>
          </div>
          <button
            onClick={() => {
              setIsVisible(false);
              onClose();
            }}
            className="text-foreground/60 hover:text-foreground transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default IntelligentNotificationToast;