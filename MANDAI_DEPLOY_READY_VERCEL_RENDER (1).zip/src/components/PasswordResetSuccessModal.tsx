import React from 'react';
import { CheckCircle, Mail } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';

interface PasswordResetSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  email: string;
}

const PasswordResetSuccessModal: React.FC<PasswordResetSuccessModalProps> = ({ 
  isOpen, 
  onClose, 
  email 
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-white text-foreground border-gray-200">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-full animate-pulse-ring" />
              <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow relative z-10">
                <Mail size={36} className="text-white" />
              </div>
            </div>
          </div>
          <DialogTitle className="text-center text-2xl text-foreground">
            E-mail enviado! 🎉
          </DialogTitle>
          <DialogDescription className="text-center text-gray-600">
            Enviamos um link de redefinição de senha para:
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-primary font-semibold">
            <Mail size={16} />
            {email}
          </div>
          <p className="text-sm text-gray-600 mt-3">
            Verifique sua caixa de entrada e siga as instruções para criar uma nova senha.
          </p>
        </div>

        <Button 
          variant="hero" 
          size="lg" 
          className="w-full"
          onClick={onClose}
        >
          Entendi
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default PasswordResetSuccessModal;