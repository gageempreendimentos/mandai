import React, { useState, useEffect } from 'react';
import { Star, ThumbsUp, MessageCircle, Send, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Feedback {
  id: string;
  deliveryId: string;
  rating: number;
  comment: string;
  timestamp: string;
  customerName: string;
}

interface RealTimeFeedbackProps {
  deliveryId: string;
  onFeedbackSubmit?: (feedback: Feedback) => void;
}

const RealTimeFeedback: React.FC<RealTimeFeedbackProps> = ({ 
  deliveryId, 
  onFeedbackSubmit 
}) => {
  const { toast } = useToast();
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Ouvir feedback em tempo real
  useEffect(() => {
    const channel = supabase
      .channel('feedback-channel')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'delivery_feedback',
          filter: `delivery_id=eq.${deliveryId}`
        },
        (payload) => {
          const newFeedback: Feedback = {
            id: payload.new.id,
            deliveryId: payload.new.delivery_id,
            rating: payload.new.rating,
            comment: payload.new.comment || '',
            timestamp: payload.new.created_at,
            customerName: payload.new.customer_name || 'Cliente'
          };
          
          setFeedback(newFeedback);
          setShowFeedbackForm(false);
          
          if (onFeedbackSubmit) {
            onFeedbackSubmit(newFeedback);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [deliveryId, onFeedbackSubmit]);

  // Carregar feedback existente
  useEffect(() => {
    const loadExistingFeedback = async () => {
      const { data } = await supabase
        .from('delivery_feedback')
        .select('*')
        .eq('delivery_id', deliveryId)
        .maybeSingle();
      
      if (data) {
        setFeedback({
          id: data.id,
          deliveryId: data.delivery_id,
          rating: data.rating,
          comment: data.comment || '',
          timestamp: data.created_at,
          customerName: data.customer_name || 'Cliente'
        });
      }
    };
    
    loadExistingFeedback();
  }, [deliveryId]);

  const handleSubmitFeedback = async () => {
    if (rating === 0) return;
    
    setIsSubmitting(true);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');
      
      // Obter nome do motorista
      const { data: profile } = await supabase
        .from('profiles')
        .select('nome_completo')
        .eq('id', user.id)
        .single();
      
      const { data, error } = await supabase
        .from('delivery_feedback')
        .insert({
          delivery_id: deliveryId,
          driver_id: user.id,
          rating: rating,
          comment: comment || null,
          driver_name: profile?.nome_completo || 'Motorista',
          customer_name: 'Cliente'
        })
        .select()
        .single();
      
      if (error) throw error;
      
      const newFeedback: Feedback = {
        id: data.id,
        deliveryId: data.delivery_id,
        rating: data.rating,
        comment: data.comment || '',
        timestamp: data.created_at,
        customerName: data.customer_name || 'Cliente'
      };
      
      setFeedback(newFeedback);
      
      if (onFeedbackSubmit) {
        onFeedbackSubmit(newFeedback);
      }
      
      // Reset form
      setRating(0);
      setComment('');
      setShowFeedbackForm(false);
      
      toast({
        title: "Feedback enviado!",
        description: "Obrigado por avaliar esta entrega.",
      });
    } catch (error: any) {
      console.error('Erro ao enviar feedback:', error);
      toast({
        title: "Erro ao enviar feedback",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (feedback) {
    return (
      <div className="bg-card rounded-xl p-4 border border-border animate-fade-in">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Star className="text-primary" size={16} />
            </div>
            <div>
              <p className="font-medium text-foreground">{feedback.customerName}</p>
              <p className="text-xs text-muted-foreground">Avaliou sua entrega</p>
            </div>
          </div>
          <button 
            onClick={() => setFeedback(null)}
            className="text-muted-foreground hover:text-foreground"
          >
            <X size={16} />
          </button>
        </div>
        
        <div className="flex items-center gap-1 mb-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              size={16}
              className={star <= feedback.rating ? 'text-yellow-500 fill-current' : 'text-muted-foreground'}
            />
          ))}
          <span className="text-sm font-medium ml-2">{feedback.rating}/5</span>
        </div>
        
        {feedback.comment && (
          <p className="text-sm text-foreground mb-3">{feedback.comment}</p>
        )}
        
        <div className="flex gap-2">
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => setShowFeedbackForm(true)}
          >
            <ThumbsUp size={14} className="mr-1" />
            Agradecer
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => setShowFeedbackForm(true)}
          >
            <MessageCircle size={14} className="mr-1" />
            Responder
          </Button>
        </div>
      </div>
    );
  }

  if (showFeedbackForm) {
    return (
      <div className="bg-card rounded-xl p-4 border border-border animate-fade-in">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-foreground">Enviar Feedback</h3>
          <button 
            onClick={() => setShowFeedbackForm(false)}
            className="text-muted-foreground hover:text-foreground"
          >
            <X size={16} />
          </button>
        </div>
        
        <div className="mb-4">
          <p className="text-sm text-muted-foreground mb-2">Avaliação</p>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => setRating(star)}
                className="p-1"
              >
                <Star
                  size={24}
                  className={star <= rating ? 'text-yellow-500 fill-current' : 'text-muted-foreground'}
                />
              </button>
            ))}
          </div>
        </div>
        
        <div className="mb-4">
          <label className="text-sm text-muted-foreground mb-2 block">Comentário (opcional)</label>
          <Textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="O que você achou da entrega?"
            className="min-h-[80px]"
          />
        </div>
        
        <Button
          className="w-full"
          onClick={handleSubmitFeedback}
          disabled={rating === 0 || isSubmitting}
        >
          {isSubmitting ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              Enviando...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Send size={16} />
              Enviar Feedback
            </span>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl p-4 border border-border text-center">
      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
        <MessageCircle className="text-primary" size={24} />
      </div>
      <h3 className="font-medium text-foreground mb-1">Aguardando Feedback</h3>
      <p className="text-sm text-muted-foreground mb-3">
        O cliente ainda não avaliou sua entrega
      </p>
      <Button 
        size="sm" 
        variant="outline"
        onClick={() => setShowFeedbackForm(true)}
      >
        Enviar Feedback Proativo
      </Button>
    </div>
  );
};

export default RealTimeFeedback;