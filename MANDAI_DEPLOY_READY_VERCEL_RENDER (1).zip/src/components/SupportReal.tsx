import React from 'react';
import { MessageCircle, Clock, MapPin, Car } from 'lucide-react';
import { Button } from './ui/button';

interface SupportRealProps {
  deliveryId?: string;
}

const SupportReal: React.FC<SupportRealProps> = ({ deliveryId }) => {
  const handleWhatsApp = () => {
    const message = deliveryId 
      ? `Olá, preciso de ajuda com a entrega #${deliveryId}`
      : 'Olá, preciso de ajuda com minha conta MANDAI';
    
    const whatsappUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-background p-4 space-y-4">
      <div className="bg-card rounded-2xl p-4 shadow-soft border border-border">
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <MessageCircle size={20} className="text-primary" />
          Suporte Rápido
        </h2>

        <Button
          variant="hero"
          className="w-full"
          onClick={handleWhatsApp}
        >
          <MessageCircle size={18} />
          WhatsApp
        </Button>
      </div>

      {/* Quick Help */}
      <div className="bg-card rounded-2xl p-4 shadow-soft border border-border">
        <h3 className="font-bold mb-3">Dúvidas Rápidas</h3>
        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-start gap-2">
            <MapPin size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <p><strong>Problemas com endereço?</strong> Use o botão "Não entregue" no app</p>
          </div>
          <div className="flex items-start gap-2">
            <Car size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <p><strong>Problemas com veículo?</strong> Entre em contato imediatamente</p>
          </div>
        </div>
      </div>

      {/* Delivery Info */}
      {deliveryId && (
        <div className="bg-card rounded-2xl p-4 shadow-soft border border-border">
          <h3 className="font-bold mb-2">Entrega Atual</h3>
          <p className="text-sm text-muted-foreground">
            ID: <span className="font-mono font-bold text-foreground">{deliveryId}</span>
          </p>
        </div>
      )}
    </div>
  );
};

export default SupportReal;