import React, { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import LoadingButton from '@/components/LoadingButton';
import { logError, logInfo } from '@/lib/logger';

interface Props {
  deliveryId: string;
  triggerClassName?: string;
}

const DeliveryDisputeDialog: React.FC<Props> = ({ deliveryId, triggerClassName }) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!subject.trim() || !message.trim()) return;

    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();

      // Create dispute
      const { data: dispute, error: dErr } = await supabase
        .from('delivery_disputes' as any)
        .insert({
          delivery_id: deliveryId,
          created_by: user?.id ?? null,
          created_role: 'driver',
          subject: subject.trim(),
          status: 'open',
        })
        .select('id')
        .single();

      if (dErr) throw dErr;

      // First message
      const { error: mErr } = await supabase
        .from('delivery_dispute_messages' as any)
        .insert({
          dispute_id: dispute.id,
          sender_id: user?.id ?? null,
          message: message.trim(),
        });

      if (mErr) throw mErr;

      logInfo('DeliveryDisputeDialog.created', { deliveryId, disputeId: dispute.id });

      toast({
        title: 'Problema enviado',
        description: 'O suporte/admin será notificado e verá a disputa no painel.',
      });

      setSubject('');
      setMessage('');
      setOpen(false);
    } catch (e: any) {
      logError('DeliveryDisputeDialog.submit', e);
      toast({
        title: 'Erro',
        description: e.message || 'Não foi possível enviar agora',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className={triggerClassName}>
          <AlertTriangle className="w-4 h-4 mr-2" />
          Reportar problema
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reportar problema</DialogTitle>
          <DialogDescription>
            Descreva o problema desta entrega. Isso cria uma disputa/ticket para o admin acompanhar.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <Input
            placeholder="Assunto (ex.: Cliente não atende / Endereço errado)"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
          <Textarea
            placeholder="Detalhes..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
          />
          <LoadingButton onClick={submit} loading={loading} disabled={!subject.trim() || !message.trim()}>
            Enviar
          </LoadingButton>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DeliveryDisputeDialog;
