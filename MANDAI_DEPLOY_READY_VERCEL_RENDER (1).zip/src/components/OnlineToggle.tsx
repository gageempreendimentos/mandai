import React, { memo } from 'react';
import { Power } from 'lucide-react';

interface OnlineToggleProps {
  isOnline: boolean;
  onToggle: () => void;
}

const OnlineToggle: React.FC<OnlineToggleProps> = ({ isOnline, onToggle }) => {
  return (
    <button
      onClick={onToggle}
      className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 ${
        isOnline 
          ? 'bg-green-500 shadow-glow-green' : 'bg-muted shadow-glow-muted'
      }`}
    >
      {isOnline && (
        <div className="absolute inset-0 rounded-full bg-green-500 animate-pulse-ring" />
      )}
      <Power 
        size={32} 
        className={`relative z-10 transition-colors duration-300 ${
          isOnline ? 'text-white' : 'text-white'
        }`} 
      />
    </button>
  );
};

export default memo(OnlineToggle);