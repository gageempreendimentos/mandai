import React from 'react';
import { Loader2 } from 'lucide-react';

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface MapPlaceholderProps {
  isOnline: boolean;
  currentLocation: Coordinates | null;
}

const MapPlaceholder: React.FC<MapPlaceholderProps> = ({ isOnline, currentLocation }) => {
  // Se está online e tem localização, NÃO mostre placeholder - o mapa deve aparecer
  if (isOnline && currentLocation) {
    return null;
  }

  // Se está online mas aguardando localização (GPS)
  if (isOnline && !currentLocation) {
    return (
      <div className="relative w-full h-full bg-gray-900 flex items-center justify-center text-white">
        <div className="text-center p-6">
          <Loader2 size={48} className="animate-spin mx-auto mb-4 text-primary" />
          <p className="text-white/80 text-base font-medium">
            Ativando GPS...
          </p>
          <p className="text-white/60 text-sm mt-2">
            Aguarde enquanto buscamos sua localização
          </p>
        </div>
      </div>
    );
  }

  // Se está offline
  return (
    <div className="relative w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&q=80')] bg-cover bg-center opacity-20" />
      
      <div className="relative z-10 text-center px-6 max-w-md">
        <div className="mb-6">
          <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full border-4 ${
            isOnline 
              ? 'border-green-400 bg-green-500/20 text-green-400' 
              : 'border-gray-300 bg-gray-500/20 text-gray-300'
          } mx-auto`}>
            <div className={`w-6 h-6 rounded-full ${
              isOnline 
                ? 'bg-green-400 animate-pulse' 
                : 'bg-gray-300'
            }`} />
          </div>
        </div>
        
        <h2 className={`text-2xl font-bold mb-3 ${
          isOnline 
            ? 'text-green-400' 
            : 'text-gray-200'
        }`}>
          {isOnline 
            ? 'AGUARDANDO LOCALIZAÇÃO' 
            : 'VOCÊ ESTÁ OFFLINE'}
        </h2>
        
        <p className="text-white/90 text-base font-medium mb-6">
          {isOnline 
            ? 'Ativando GPS para mostrar sua posição no mapa' 
            : 'Toque no botão abaixo para começar'}
        </p>
        
        {isOnline && (
          <div className="bg-card/10 backdrop-blur-sm rounded-xl p-4 border border-border/30">
            <p className="text-sm text-white/80">
              Certifique-se de que o GPS está ativado em seu dispositivo
            </p>
          </div>
        )}
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black/60 to-transparent" />
    </div>
  );
};

export default MapPlaceholder;