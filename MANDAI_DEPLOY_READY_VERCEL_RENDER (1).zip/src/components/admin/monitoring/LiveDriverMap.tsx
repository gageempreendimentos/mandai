import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Truck, MapPin, Wifi, WifiOff } from 'lucide-react';
import ReactDOMServer from 'react-dom/server';
import type { OnlineDriver } from '@/hooks/admin/useOnlineDrivers';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

// Fix for Leaflet icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

interface LiveDriverMapProps {
  onlineDrivers: OnlineDriver[];
  isLoading: boolean;
}

const LiveDriverMap: React.FC<LiveDriverMapProps> = ({ onlineDrivers, isLoading }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<Record<string, L.Marker>>({});
  const [mapCenter, setMapCenter] = useState<L.LatLngExpression>([-23.5505, -46.6333]); // Default to São Paulo
  const [mapZoom, setMapZoom] = useState(12);

  useEffect(() => {
    if (!mapRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapRef.current).setView(mapCenter, mapZoom);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Update or add markers for online drivers
    const currentDriverIds = new Set<string>();
    onlineDrivers.forEach(driver => {
      if (driver.current_lat && driver.current_lng) {
        currentDriverIds.add(driver.id);
        const latLng: L.LatLngExpression = [driver.current_lat, driver.current_lng];

        const driverIcon = L.divIcon({
          html: ReactDOMServer.renderToString(
            <div className="relative">
              <div className="absolute inset-0 w-10 h-10 -m-1 rounded-full bg-primary/30 animate-ping" />
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-glow">
                <Truck size={16} className="text-primary-foreground" />
              </div>
            </div>
          ),
          className: 'leaflet-div-icon',
          iconSize: [32, 32],
          iconAnchor: [16, 32],
          popupAnchor: [0, -32],
        });

        if (markersRef.current[driver.id]) {
          // Update existing marker position
          markersRef.current[driver.id].setLatLng(latLng);
          markersRef.current[driver.id].setPopupContent(`
            <div class="font-sans text-sm">
              <p class="font-bold">${driver.nome_completo}</p>
              <p class="text-muted-foreground">Online</p>
              <p class="text-xs text-muted-foreground">Última atualização: ${new Date(driver.last_location_update || '').toLocaleTimeString()}</p>
            </div>
          `);
        } else {
          // Add new marker
          const marker = L.marker(latLng, { icon: driverIcon })
            .addTo(map)
            .bindPopup(`
              <div class="font-sans text-sm">
                <p class="font-bold">${driver.nome_completo}</p>
                <p class="text-muted-foreground">Online</p>
                <p class="text-xs text-muted-foreground">Última atualização: ${new Date(driver.last_location_update || '').toLocaleTimeString()}</p>
              </div>
            `);
          markersRef.current[driver.id] = marker;
        }
      }
    });

    // Remove markers for drivers who are no longer online
    Object.keys(markersRef.current).forEach(driverId => {
      if (!currentDriverIds.has(driverId)) {
        map.removeLayer(markersRef.current[driverId]);
        delete markersRef.current[driverId];
      }
    });

    // Adjust map view to fit all online drivers if there are any
    if (onlineDrivers.length > 0) {
      const bounds = L.latLngBounds(
        onlineDrivers
          .filter(d => d.current_lat && d.current_lng)
          .map(d => [d.current_lat!, d.current_lng!] as L.LatLngExpression)
      );
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
      }
    }

    return () => {
      // Clean up markers when component unmounts or dependencies change
      Object.values(markersRef.current).forEach(marker => {
        map.removeLayer(marker);
      });
      markersRef.current = {};
    };
  }, [onlineDrivers, mapCenter, mapZoom]);

  return (
    <Card className="h-[500px] flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <MapPin size={18} className="text-primary" />
          Entregadores Online
          <Badge variant="secondary" className="ml-2">
            {onlineDrivers.length}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        {isLoading ? (
          <div className="flex items-center justify-center h-full bg-muted rounded-b-xl">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div ref={mapRef} className="w-full h-full rounded-b-xl z-0" />
        )}
      </CardContent>
    </Card>
  );
};

export default LiveDriverMap;