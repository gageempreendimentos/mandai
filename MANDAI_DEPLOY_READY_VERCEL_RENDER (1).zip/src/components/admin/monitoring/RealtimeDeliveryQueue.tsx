import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Package, Clock, Truck, User, MapPin, DollarSign, RefreshCw, AlertCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { AdminDelivery } from '@/hooks/admin/useAdminDeliveries';
import { Skeleton } from '@/components/ui/skeleton';

interface RealtimeDeliveryQueueProps {
  deliveries: AdminDelivery[];
  isLoading: boolean;
  onRefresh: () => void;
}

const RealtimeDeliveryQueue: React.FC<RealtimeDeliveryQueueProps> = ({ deliveries, isLoading, onRefresh }) => {
  const getStatusBadge = (status: string) => {
    const config: Record<string, { text: string; color: string; icon: React.ElementType }> = {
      pending: { text: 'Pendente', color: 'bg-orange-500/10 text-orange-500 border-orange-500/30', icon: Clock },
      picked_up: { text: 'Coletado', color: 'bg-blue-500/10 text-blue-500 border-blue-500/30', icon: Package },
      in_transit: { text: 'Em Trânsito', color: 'bg-purple-500/10 text-purple-500 border-purple-500/30', icon: Truck },
      not_delivered: { text: 'Não Entregue', color: 'bg-red-500/10 text-red-500 border-red-500/30', icon: AlertCircle },
    };
    return config[status as keyof typeof config] || config.pending;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Card className="h-[500px] flex flex-col">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Package size={18} className="text-primary" />
          Fila de Entregas
          <Badge variant="secondary" className="ml-2">
            {deliveries.length}
          </Badge>
        </CardTitle>
        <Button variant="ghost" size="icon" onClick={onRefresh} disabled={isLoading}>
          <RefreshCw size={18} className={isLoading ? 'animate-spin' : ''} />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-0">
        {isLoading ? (
          <div className="p-4 space-y-3">
            <Skeleton className="h-24 rounded-xl" />
            <Skeleton className="h-24 rounded-xl" />
            <Skeleton className="h-24 rounded-xl" />
          </div>
        ) : deliveries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
            <Package size={48} className="mb-4 opacity-50" />
            <p className="text-lg font-medium">Nenhuma entrega ativa</p>
            <p className="text-sm">Aguardando novos pedidos ou atualizações</p>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {deliveries.map(delivery => {
              const statusConfig = getStatusBadge(delivery.status || 'pending');
              const StatusIcon = statusConfig.icon;
              return (
                <div key={delivery.id} className="bg-muted/50 rounded-xl p-4 border border-border">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <StatusIcon size={16} className={statusConfig.color.split(' ')[1]} />
                      <span className="font-bold text-foreground">#{delivery.tracking_number}</span>
                    </div>
                    <Badge variant="secondary" className={statusConfig.color}>
                      {statusConfig.text}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p className="flex items-center gap-2">
                      <MapPin size={14} />
                      <span>De: {delivery.pickup_address.split(',')[0]}</span>
                    </p>
                    <p className="flex items-center gap-2">
                      <User size={14} />
                      <span>Para: {delivery.customer_name}</span>
                    </p>
                    {delivery.driver_name && (
                      <p className="flex items-center gap-2">
                        <Truck size={14} />
                        <span>Entregador: {delivery.driver_name}</span>
                      </p>
                    )}
                    <p className="flex items-center gap-2">
                      <DollarSign size={14} />
                      <span>Valor: R$ {delivery.value?.toFixed(2) || '0.00'}</span>
                    </p>
                    <p className="text-xs text-right text-muted-foreground">
                      Criado: {formatDate(delivery.created_at)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RealtimeDeliveryQueue;