import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Bell, CheckCircle, Clock, Package, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { AdminAlert } from '@/hooks/admin/useAdminAlerts';
import { Skeleton } from '@/components/ui/skeleton';

interface AdminAlertsProps {
  alerts: AdminAlert[];
  onMarkAsRead: (id: string) => void;
  isLoading: boolean;
}

const AdminAlerts: React.FC<AdminAlertsProps> = ({ alerts, onMarkAsRead, isLoading }) => {
  const getAlertTypeConfig = (type: AdminAlert['type']) => {
    switch (type) {
      case 'late_pickup':
        return { icon: Clock, color: 'bg-red-500/10 text-red-500 border-red-500/30', label: 'Atraso Coleta' };
      case 'late_delivery':
        return { icon: AlertTriangle, color: 'bg-red-500/10 text-red-500 border-red-500/30', label: 'Atraso Entrega' };
      case 'not_delivered_return':
        return { icon: Package, color: 'bg-orange-500/10 text-orange-500 border-orange-500/30', label: 'Devolução Pendente' };
      case 'new_pending':
        return { icon: Bell, color: 'bg-blue-500/10 text-blue-500 border-blue-500/30', label: 'Novo Pedido' };
      default:
        return { icon: Bell, color: 'bg-muted text-muted-foreground border-border', label: 'Alerta' };
    }
  };

  const unreadAlerts = alerts.filter(alert => !alert.isRead);

  return (
    <Card className="h-[500px] flex flex-col">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Bell size={18} className="text-primary" />
          Alertas
          {unreadAlerts.length > 0 && (
            <Badge variant="destructive" className="ml-2 animate-pulse">
              {unreadAlerts.length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-0">
        {isLoading ? (
          <div className="p-4 space-y-3">
            <Skeleton className="h-24 rounded-xl" />
            <Skeleton className="h-24 rounded-xl" />
            <Skeleton className="h-24 rounded-xl" />
          </div>
        ) : alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
            <CheckCircle size={48} className="mb-4 opacity-50" />
            <p className="text-lg font-medium">Nenhum alerta ativo</p>
            <p className="text-sm">Tudo sob controle!</p>
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {alerts.map(alert => {
              const config = getAlertTypeConfig(alert.type);
              const AlertIcon = config.icon;
              return (
                <div 
                  key={alert.id} 
                  className={`rounded-xl p-4 border ${config.color} ${alert.isRead ? 'opacity-70' : ''}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <AlertIcon size={20} className={config.color.split(' ')[1]} />
                      <div className="flex-1">
                        <p className="font-bold text-foreground">{config.label}</p>
                        <p className="text-sm text-foreground/90 mt-1">{alert.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(alert.timestamp).toLocaleString('pt-BR')}
                        </p>
                      </div>
                    </div>
                    {!alert.isRead && (
                      <Button variant="ghost" size="icon" onClick={() => onMarkAsRead(alert.id)}>
                        <X size={16} className="text-muted-foreground" />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AdminAlerts;