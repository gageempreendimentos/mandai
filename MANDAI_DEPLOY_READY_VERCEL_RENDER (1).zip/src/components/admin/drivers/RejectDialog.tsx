import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import LoadingButton from '@/components/LoadingButton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { AlertCircle, XCircle } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import type { DriverProfile } from '@/hooks/admin/useDriverData';

const formatCPF = (cpf: string) => cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');

interface RejectDialogProps {
  driver: DriverProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}

const RejectDialog: React.FC<RejectDialogProps> = ({ driver, isOpen, onClose, onConfirm }) => {
  const [loading, setLoading] = useState(false);

  const [rejectReason, setRejectReason] = useState('');

  if (!driver) return null;

  const handleConfirm = () => {
    if (rejectReason.trim()) {
      onConfirm(rejectReason);
      setRejectReason('');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-white text-gray-900 border-gray-200">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute inset-0 bg-red-500/20 rounded-full animate-pulse-ring" />
              <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center shadow-glow relative z-10">
                <AlertCircle size={40} className="text-white" />
              </div>
            </div>
          </div>
          <DialogTitle className="text-center text-xl text-gray-900">
            Rejeitar Entregador
          </DialogTitle>
          <DialogDescription className="text-center text-gray-600">
            Informe o motivo da rejeição
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-4">
          <div className="text-center space-y-2 bg-gray-100 rounded-xl p-4 border border-gray-200">
            <p className="font-bold text-gray-900">{driver.nome_completo}</p>
            <p className="text-sm text-gray-700">{formatCPF(driver.cpf)}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">Motivo da Rejeição *</label>
            <Textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Ex: Documentos inválidos, informações incompletas, etc."
              className="min-h-[100px]"
              required
            />
            <p className="text-xs text-gray-600 mt-1">
              Este motivo será enviado ao entregador
            </p>
          </div>
        </div>

        <DialogFooter className="sm:flex-col">
          <LoadingButton
            variant="destructive"
            size="lg"
            className="w-full"
            onClick={handleConfirm}
            loading={loading}
            disabled={!rejectReason.trim()}
          >
            <XCircle size={18} className="mr-2" />
            Confirmar Rejeição
          </LoadingButton>
          <Button
            variant="outline"
            size="lg"
            className="w-full"
            onClick={onClose}
          >
            Cancelar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RejectDialog;