import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, User, FileText, Car, MapPin, Phone, Mail, Clock } from 'lucide-react';
import type { DriverProfile } from '@/hooks/admin/useDriverData';

const formatCPF = (cpf: string) => cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
const formatPhone = (phone: string) => {
  const numbers = phone.replace(/\D/g, '');
  if (numbers.length === 11) return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  if (numbers.length === 10) return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  return phone;
};
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

interface DriverCardProps {
  driver: DriverProfile;
  onViewDetails: (driver: DriverProfile) => void;
  onApprove: (driver: DriverProfile) => void;
  onReject: (driver: DriverProfile) => void;
}

const DriverCard: React.FC<DriverCardProps> = ({ driver, onViewDetails, onApprove, onReject }) => {
  return (
    <Card className="border border-border/50 hover:border-border transition-colors">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <User size={24} className="text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">{driver.nome_completo}</CardTitle>
              <CardDescription className="text-sm">
                {formatCPF(driver.cpf)} • {formatPhone(driver.telefone)}
              </CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className="text-orange-500 bg-orange-500/10 border-orange-500/30">
            Pendente
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-2">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Car size={14} className="text-muted-foreground" />
            <span>{driver.tipo_veiculo} • {driver.marca_veiculo} {driver.modelo_veiculo}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin size={14} className="text-muted-foreground" />
            <span>{driver.cidade}, {driver.estado}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-muted-foreground" />
            <span>Cadastrado há {formatDate(driver.created_at)}</span>
          </div>
          <div className="flex items-center gap-2">
            <Mail size={14} className="text-muted-foreground" />
            <span>{driver.email}</span>
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <Button
            variant="hero"
            size="sm"
            className="flex-1"
            onClick={() => onViewDetails(driver)}
          >
            <FileText size={16} className="mr-1" />
            Ver Documentos
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1 text-green-600 border-green-500/30 hover:bg-green-500/10"
            onClick={() => onApprove(driver)}
          >
            <CheckCircle size={16} className="mr-1" />
            Aprovar
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1 text-red-600 border-red-500/30 hover:bg-red-500/10"
            onClick={() => onReject(driver)}
          >
            <XCircle size={16} className="mr-1" />
            Rejeitar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DriverCard;