import React from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { CheckCircle, XCircle, User, FileText, Car, MapPin, Phone, Mail } from 'lucide-react';
import type { DriverProfile } from '@/hooks/admin/useDriverData';

const formatCPF = (cpf: string) => cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
const formatPhone = (phone: string) => {
  const numbers = phone.replace(/\D/g, '');
  if (numbers.length === 11) return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  if (numbers.length === 10) return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  return phone;
};
const formatCEP = (cep: string) => cep.replace(/(\d{5})(\d{3})/, '$1-$2');
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

interface DriverDetailDialogProps {
  driver: DriverProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onApprove: (driver: DriverProfile) => void;
  onReject: (driver: DriverProfile) => void;
}

const DriverDetailDialog: React.FC<DriverDetailDialogProps> = ({ driver, isOpen, onClose, onApprove, onReject }) => {
  if (!driver) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-white text-gray-900 border-gray-200">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900 flex items-center gap-2">
            <User size={20} /> Detalhes do Entregador
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            Documentos e informações completas
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Personal Info */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <User size={16} /> Informações Pessoais
            </h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <p><strong>Nome:</strong> {driver.nome_completo}</p>
                <p><strong>CPF:</strong> {formatCPF(driver.cpf)}</p>
                <p><strong>RG:</strong> {driver.rg || 'Não informado'}</p>
              </div>
              <div className="space-y-2">
                <p><strong>Telefone:</strong> {formatPhone(driver.telefone)}</p>
                <p><strong>E-mail:</strong> {driver.email}</p>
                <p><strong>Data Cadastro:</strong> {formatDate(driver.created_at)}</p>
              </div>
            </div>
          </div>

          {/* Address Info */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <MapPin size={16} /> Endereço
            </h3>
            <div className="text-sm space-y-1">
              <p><strong>CEP:</strong> {formatCEP(driver.cep)}</p>
              <p><strong>Rua:</strong> {driver.rua}, {driver.numero}</p>
              <p><strong>Complemento:</strong> {driver.complemento || 'Não informado'}</p>
              <p><strong>Bairro:</strong> {driver.bairro}</p>
              <p><strong>Cidade/Estado:</strong> {driver.cidade}, {driver.estado}</p>
            </div>
          </div>

          {/* Vehicle Info */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <Car size={16} /> Veículo
            </h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <p><strong>Tipo:</strong> {driver.tipo_veiculo}</p>
                <p><strong>Marca:</strong> {driver.marca_veiculo}</p>
                <p><strong>Modelo:</strong> {driver.modelo_veiculo}</p>
              </div>
              <div className="space-y-2">
                <p><strong>Ano:</strong> {driver.ano_veiculo || 'Não informado'}</p>
                <p><strong>Placa:</strong> {driver.placa_veiculo}</p>
                <p><strong>Cor:</strong> {driver.cor_veiculo || 'Não informado'}</p>
              </div>
            </div>
          </div>

          {/* Documents */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <FileText size={16} /> Documentos
            </h3>
            <div className="space-y-3">
              {[
                { label: 'CNH', url: driver.cnh_url },
                { label: 'Comprovante de Endereço', url: driver.comprovante_endereco_url },
                { label: 'Documento do Veículo', url: driver.documento_veiculo_url },
              ].map((doc, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                      <FileText size={16} className="text-blue-500" />
                    </div>
                    <span className="text-sm font-medium">{doc.label}</span>
                  </div>
                  {doc.url ? (
                    <a
                      href={doc.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 hover:underline"
                    >
                      Ver documento
                    </a>
                  ) : (
                    <span className="text-sm text-red-500">Não enviado</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter className="flex flex-col gap-2 sm:flex-col">
          <Button
            variant="hero"
            size="lg"
            className="w-full"
            onClick={() => {
              onClose();
              onApprove(driver);
            }}
          >
            <CheckCircle size={18} className="mr-2" />
            Aprovar Entregador
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="w-full text-red-600 border-red-500/30 hover:bg-red-500/10"
            onClick={() => {
              onClose();
              onReject(driver);
            }}
          >
            <XCircle size={18} className="mr-2" />
            Rejeitar Entregador
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DriverDetailDialog;