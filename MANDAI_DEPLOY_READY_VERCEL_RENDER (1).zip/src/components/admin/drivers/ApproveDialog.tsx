import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import LoadingButton from '@/components/LoadingButton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { CheckCircle } from 'lucide-react';
import type { DriverProfile } from '@/hooks/admin/useDriverData';

const formatCPF = (cpf: string) => cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');

interface ApproveDialogProps {
  driver: DriverProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void | Promise<void>;
}

const ApproveDialog: React.FC<ApproveDialogProps> = ({ driver, isOpen, onClose, onConfirm }) => {
  const [loading, setLoading] = useState(false);

  const handleConfirm = async () => {
    try {
      setLoading(true);
      await onConfirm();
    } finally {
      setLoading(false);
    }
  };
  if (!driver) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-white text-gray-900 border-gray-200">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="relative">
              <div className="absolute inset-0 bg-green-500/20 rounded-full animate-pulse-ring" />
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center shadow-glow relative z-10">
                <CheckCircle size={40} className="text-white" />
              </div>
            </div>
          </div>
          <DialogTitle className="text-center text-xl text-gray-900">
            Confirmar Aprovação
          </DialogTitle>
          <DialogDescription className="text-center text-gray-600">
            {driver.nome_completo} poderá fazer entregas
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 text-center space-y-2 bg-gray-100 rounded-xl p-4 border border-gray-200">
          <p className="font-bold text-gray-900">{driver.nome_completo}</p>
          <p className="text-sm text-gray-700">{formatCPF(driver.cpf)}</p>
          <p className="text-sm text-gray-600">{driver.email}</p>
        </div>

        <DialogFooter className="sm:flex-col">
          <LoadingButton
            variant="hero"
            size="lg"
            className="w-full"
            onClick={handleConfirm}
            loading={loading}
          >
            <CheckCircle size={18} className="mr-2" />
            Confirmar Aprovação
          </LoadingButton>
          <Button
            variant="outline"
            size="lg"
            className="w-full"
            onClick={onClose}
          >
            Cancelar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ApproveDialog;