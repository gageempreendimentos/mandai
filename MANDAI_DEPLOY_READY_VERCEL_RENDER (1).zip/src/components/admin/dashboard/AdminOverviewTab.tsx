import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Package, Users, Truck, DollarSign, CheckCircle, Clock, AlertCircle, UserPlus, FileText, Settings, BarChart3 } from 'lucide-react';
import type { AdminStats } from '@/hooks/admin/useAdminStats';

type LateStage = 'accept' | 'pickup' | 'delivery';

interface LateDelivery {
  id: string;
  tracking_number: string;
  status: string;
  late_stage: LateStage | null;
  driver_id: string | null;
  created_at?: string;
}

interface DriverOption {
  id: string;
  nome_completo: string | null;
  is_online?: boolean | null;
}

interface AdminOverviewTabProps {
  stats: AdminStats | null;
}

const AdminOverviewTab: React.FC<AdminOverviewTabProps> = ({ stats }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [lateDeliveries, setLateDeliveries] = useState<LateDelivery[]>([]);
  const [isLateLoading, setIsLateLoading] = useState(true);

  const [drivers, setDrivers] = useState<DriverOption[]>([]);
  const [isReassignOpen, setIsReassignOpen] = useState(false);
  const [reassignTarget, setReassignTarget] = useState<LateDelivery | null>(null);
  const [selectedDriverId, setSelectedDriverId] = useState<string>('');
  const [isReassigning, setIsReassigning] = useState(false);

  const stageLabel = (stage: LateStage | null) => {
    if (stage === 'accept') return 'Aceite atrasado';
    if (stage === 'pickup') return 'Coleta atrasada';
    if (stage === 'delivery') return 'Entrega atrasada';
    return 'Atraso';
  };

  const loadLateDeliveries = async () => {
    try {
      setIsLateLoading(true);
      const { data, error } = await supabase
        .from('deliveries')
        .select('id, tracking_number, status, late_stage, driver_id, created_at')
        .not('late_stage', 'is', null)
        .neq('status', 'delivered')
        .neq('status', 'canceled')
        .order('created_at', { ascending: false })
        .limit(8);

      if (error) throw error;
      setLateDeliveries((data as any) || []);
    } catch (e) {
      // Não travar o dashboard por causa disso
      console.error('Erro ao carregar entregas atrasadas:', e);
      setLateDeliveries([]);
    } finally {
      setIsLateLoading(false);
    }
  };

  const loadDrivers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, nome_completo, is_online')
        .eq('status', 'approved')
        .order('nome_completo', { ascending: true });
      if (error) throw error;
      setDrivers((data as any) || []);
    } catch (e) {
      console.error('Erro ao carregar entregadores:', e);
      setDrivers([]);
    }
  };

  useEffect(() => {
    loadLateDeliveries();
    loadDrivers();
  }, []);

  const lateCount = lateDeliveries.length;

  const openReassign = (delivery: LateDelivery) => {
    setReassignTarget(delivery);
    setSelectedDriverId('');
    setIsReassignOpen(true);
  };

  const confirmReassign = async () => {
    if (!reassignTarget || !selectedDriverId) return;
    try {
      setIsReassigning(true);
      const { error } = await supabase.functions.invoke('admin-reassign', {
        body: {
          delivery_id: reassignTarget.id,
          new_driver_id: selectedDriverId,
          timeout_seconds: 45,
        },
      });
      if (error) throw error;
      toast({
        title: 'Reatribuição enviada',
        description: 'Nova oferta enviada ao entregador selecionado.',
      });
      setIsReassignOpen(false);
      setReassignTarget(null);
      await loadLateDeliveries();
    } catch (e: any) {
      console.error(e);
      toast({
        title: 'Erro ao reatribuir',
        description: e?.message || 'Não foi possível reatribuir agora.',
        variant: 'destructive',
      });
    } finally {
      setIsReassigning(false);
    }
  };

  return (
    <>
      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Entregas Totais</CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalDeliveries || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats?.completedDeliveries || 0} concluídas
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Entregadores</CardTitle>
            <Truck className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalDrivers || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats?.activeDrivers || 0} ativos
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Usuários</CardTitle>
            <Users className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{(stats?.totalClients || 0) + (stats?.totalRestaurants || 0)}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Clientes e Restaurantes
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500/10 to-orange-500/5 border-orange-500/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pendências</CardTitle>
            <AlertCircle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.pendingDeliveries || 0}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats?.pendingDrivers || 0} entregadores
            </p>
          </CardContent>
        </Card>
      </div>


      {/* Late Deliveries */}
      <Card className="mb-6 border-amber-200/60">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div className="flex items-center gap-2">
            <CardTitle className="text-sm font-medium">Entregas atrasadas</CardTitle>
            <Badge variant={lateCount > 0 ? 'destructive' : 'secondary'}>
              {lateCount}
            </Badge>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate('/admin/deliveries/management')}>
            Ver todas
          </Button>
        </CardHeader>
        <CardContent>
          {isLateLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : lateDeliveries.length === 0 ? (
            <div className="text-sm text-muted-foreground flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Nenhuma entrega marcada como atrasada agora.
            </div>
          ) : (
            <div className="space-y-2">
              {lateDeliveries.map((d) => (
                <div key={d.id} className="flex items-center justify-between rounded-lg border p-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium truncate">#{d.tracking_number}</span>
                      <Badge variant="outline" className="truncate">{stageLabel(d.late_stage)}</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      Status: {d.status}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="secondary" size="sm" onClick={() => openReassign(d)}>
                      Reatribuir
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isReassignOpen} onOpenChange={setIsReassignOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reatribuir entregador</DialogTitle>
            <DialogDescription>
              Selecione um entregador para receber uma nova oferta com timeout.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <div className="text-sm font-medium">Entregador</div>
            <Select value={selectedDriverId} onValueChange={setSelectedDriverId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um entregador" />
              </SelectTrigger>
              <SelectContent>
                {drivers.map((dr) => (
                  <SelectItem key={dr.id} value={dr.id}>
                    {dr.nome_completo || dr.id}{dr.is_online ? ' (online)' : ''}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsReassignOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={confirmReassign} disabled={!selectedDriverId || isReassigning}>
              {isReassigning ? 'Reatribuindo…' : 'Confirmar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Button
          variant="hero"
          className="h-24 text-lg font-semibold"
          onClick={() => navigate('/admin/drivers/pending')}
        >
          <UserPlus size={20} className="mr-2" />
          Aprovar Entregadores
          <Badge className="ml-2 bg-white text-primary">{stats?.pendingDrivers || 0}</Badge>
        </Button>
        <Button
          variant="outline"
          className="h-24 text-lg font-semibold border-dashed"
          onClick={() => navigate('/admin/withdrawals')}
        >
          <DollarSign size={20} className="mr-2" />
          Processar Saques
          <Badge className="ml-2 bg-primary text-white">{stats?.pendingWithdrawals || 0}</Badge>
        </Button>
      </div>

      {/* Navigation Buttons */}
      <Button
        variant="outline"
        className="w-full h-16 text-lg font-semibold mt-4"
        onClick={() => navigate('/admin/statistics')}
      >
        <BarChart3 size={20} className="mr-2" />
        Estatísticas Avançadas
      </Button>

      <Button
        variant="outline"
        className="w-full h-16 text-lg font-semibold mt-4"
        onClick={() => navigate('/admin/settings')}
      >
        <Settings size={20} className="mr-2" />
        Configurações do Sistema
      </Button>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock size={18} /> Atividades Recentes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <CheckCircle size={20} className="text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Nova entrega concluída</p>
                <p className="text-xs text-muted-foreground">R$ 15,50 • Há 2 minutos</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
              <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                <UserPlus size={20} className="text-accent" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Novo entregador cadastrado</p>
                <p className="text-xs text-muted-foreground">Aguardando aprovação • Há 10 minutos</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
};

export default AdminOverviewTab;