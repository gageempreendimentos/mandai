import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Truck, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import type { AdminStats } from '@/hooks/admin/useAdminStats';

interface AdminDriversTabProps {
  stats: AdminStats | null;
}

const AdminDriversTab: React.FC<AdminDriversTabProps> = ({ stats }) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck size={18} /> Gerenciar Entregadores
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold text-primary">{stats?.totalDrivers || 0}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
            <div className="p-3 bg-green-500/10 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{stats?.activeDrivers || 0}</p>
              <p className="text-xs text-green-600">Ativos</p>
            </div>
            <div className="p-3 bg-orange-500/10 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">{stats?.pendingDrivers || 0}</p>
              <p className="text-xs text-orange-600">Pendentes</p>
            </div>
          </div>

          <div className="space-y-2">
            <Button
              variant="hero"
              className="w-full"
              onClick={() => navigate('/admin/drivers/pending')}
            >
              <AlertCircle size={18} className="mr-2" />
              Revisar Pendentes ({stats?.pendingDrivers || 0})
            </Button>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => navigate('/admin/drivers/active')}
            >
              <CheckCircle size={18} className="mr-2" />
              Ver Ativos ({stats?.activeDrivers || 0})
            </Button>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => navigate('/admin/drivers/rejected')}
            >
              <XCircle size={18} className="mr-2" />
              Ver Rejeitados
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDriversTab;