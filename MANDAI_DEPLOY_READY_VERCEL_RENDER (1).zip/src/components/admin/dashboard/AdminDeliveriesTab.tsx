import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Package, Clock, CheckCircle, XCircle, Filter, Search } from 'lucide-react';
import type { AdminStats } from '@/hooks/admin/useAdminStats';

interface AdminDeliveriesTabProps {
  stats: AdminStats | null;
}

const AdminDeliveriesTab: React.FC<AdminDeliveriesTabProps> = ({ stats }) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package size={18} /> Gerenciar Entregas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold text-primary">{stats?.totalDeliveries || 0}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
            <div className="p-3 bg-orange-500/10 rounded-lg">
              <p className="text-2xl font-bold text-orange-600">{stats?.pendingDeliveries || 0}</p>
              <p className="text-xs text-orange-600">Pendentes</p>
            </div>
            <div className="p-3 bg-green-500/10 rounded-lg">
              <p className="text-2xl font-bold text-green-600">{stats?.completedDeliveries || 0}</p>
              <p className="text-xs text-green-600">Concluídas</p>
            </div>
          </div>

          <div className="space-y-2">
            <Button
              variant="hero"
              className="w-full"
              onClick={() => navigate('/admin/deliveries/pending')}
            >
              <Clock size={18} className="mr-2" />
              Entregas Pendentes ({stats?.pendingDeliveries || 0})
            </Button>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => navigate('/admin/deliveries/completed')}
            >
              <CheckCircle size={18} className="mr-2" />
              Entregas Concluídas
            </Button>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => navigate('/admin/deliveries/cancelled')}
            >
              <XCircle size={18} className="mr-2" />
              Entregas Canceladas
            </Button>
          </div>

          {/* New: Gerenciamento Avançado */}
          <div className="pt-4 border-t border-border">
            <h3 className="font-bold mb-3 flex items-center gap-2">
              <Filter size={16} /> Gerenciamento Avançado
            </h3>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => navigate('/admin/deliveries/management')}
            >
              <Search size={16} className="mr-2" />
              Filtros Avançados & Ações em Massa
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDeliveriesTab;