import React from 'react';
import { LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ThemeToggle from '@/components/ThemeToggle';

interface AdminDashboardHeaderProps {
  onLogout: () => void;
}

const AdminDashboardHeader: React.FC<AdminDashboardHeaderProps> = ({ onLogout }) => {
  return (
    <header className="sticky top-0 z-20 flex items-center justify-between p-4 bg-background border-b border-border backdrop-blur-sm bg-opacity-95">
      <h1 className="text-xl font-bold text-foreground">Painel Administrativo</h1>
      <div className="flex items-center gap-2">
        <ThemeToggle />
        <Button variant="ghost" size="icon" onClick={onLogout}>
        <LogOut size={20} className="text-muted-foreground" />
      </Button>
      </div>
    </header>
  );
};

export default AdminDashboardHeader;