import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DollarSign, FileText, Clock } from 'lucide-react';
import type { AdminStats } from '@/hooks/admin/useAdminStats';

interface AdminFinancialTabProps {
  stats: AdminStats | null;
}

const AdminFinancialTab: React.FC<AdminFinancialTabProps> = ({ stats }) => {
  const navigate = useNavigate();

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-green-500/5 to-green-500/10 border-green-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-600">
            <DollarSign size={18} /> Receita Total
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-green-600">
            R$ {stats?.totalEarnings?.toFixed(2) || '0,00'}
          </div>
          <p className="text-sm text-green-600/80 mt-2">
            Valor bruto de todas as entregas concluídas
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText size={18} /> Saques Pendentes
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-orange-500/10 rounded-lg border border-orange-500/20">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center">
                <Clock size={24} className="text-orange-500" />
              </div>
              <div>
                <p className="text-lg font-bold text-orange-600">
                  {stats?.pendingWithdrawals || 0} saques
                </p>
                <p className="text-sm text-orange-600/80">
                  Aguardando processamento
                </p>
              </div>
            </div>
            <Button
              variant="hero"
              onClick={() => navigate('/admin/withdrawals')}
            >
              Processar Saques
            </Button>
          </div>

          <div className="space-y-2">
            <Button
              variant="outline"
              className="w-full"
              onClick={() => navigate('/admin/financial/transactions')}
            >
              <DollarSign size={18} className="mr-2" />
              Ver Transações
            </Button>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => navigate('/admin/financial/reports')}
            >
              <FileText size={18} className="mr-2" />
              Relatórios Financeiros
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminFinancialTab;