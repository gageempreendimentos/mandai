import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { User, Mail, Phone, FileText, Truck, Utensils, Shield } from 'lucide-react';
import type { UserProfile } from '@/hooks/admin/useUserManagementData';
import type { Enums } from '@/integrations/supabase/types';

const formatPhone = (phone: string | null) => {
  if (!phone) return 'N/A';
  const numbers = phone.replace(/\D/g, '');
  if (numbers.length === 11) return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  if (numbers.length === 10) return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  return phone;
};

const getRoleBadge = (role: Enums<'app_role'> | null) => {
  switch (role) {
    case 'admin': return { text: 'Admin', color: 'bg-red-500/10 text-red-500 border-red-500/30', icon: Shield };
    case 'driver': return { text: 'Entregador', color: 'bg-primary/10 text-primary border-primary/30', icon: Truck };
    case 'client': return { text: 'Cliente', color: 'bg-blue-500/10 text-blue-500 border-blue-500/30', icon: User };
    case 'restaurant': return { text: 'Restaurante', color: 'bg-orange-500/10 text-orange-500 border-orange-500/30', icon: Utensils };
    default: return { text: 'Desconhecido', color: 'bg-muted text-muted-foreground border-border', icon: User };
  }
};

const getStatusBadge = (status: string | null) => {
  switch (status) {
    case 'approved': return { text: 'Ativo', color: 'bg-green-500/10 text-green-500 border-green-500/30' };
    case 'pending': return { text: 'Pendente', color: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/30' };
    case 'rejected': return { text: 'Rejeitado', color: 'bg-red-500/10 text-red-500 border-red-500/30' };
    case 'deactivated': return { text: 'Desativado', color: 'bg-gray-500/10 text-gray-500 border-gray-500/30' };
    default: return { text: 'Desconhecido', color: 'bg-muted text-muted-foreground border-border' };
  }
};

interface UserCardProps {
  user: UserProfile;
  onViewDetails: (user: UserProfile) => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onViewDetails }) => {
  const roleBadge = getRoleBadge(user.role);
  const statusBadge = getStatusBadge(user.status);
  const RoleIcon = roleBadge.icon;

  return (
    <Card className="border border-border/50 hover:border-border transition-colors">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${roleBadge.color.split(' ')[0]}`}>
              <RoleIcon size={24} className={roleBadge.color.split(' ')[1]} />
            </div>
            <div>
              <CardTitle className="text-lg">{user.nome_completo || user.email}</CardTitle>
              <CardDescription className="text-sm">
                {user.email}
              </CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className={statusBadge.color}>
            {statusBadge.text}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-2">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Mail size={14} className="text-muted-foreground" />
            <span>{user.email}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone size={14} className="text-muted-foreground" />
            <span>{formatPhone(user.telefone)}</span>
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <Button
            variant="hero"
            size="sm"
            className="flex-1"
            onClick={() => onViewDetails(user)}
          >
            <FileText size={16} className="mr-1" />
            Ver Detalhes
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default UserCard;