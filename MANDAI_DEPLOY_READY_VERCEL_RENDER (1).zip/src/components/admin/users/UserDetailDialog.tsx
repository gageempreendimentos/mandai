import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { CheckCircle, XCircle, User, Mail, Phone, MapPin, Car, Shield, Utensils, Edit } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { UserProfile } from '@/hooks/admin/useUserManagementData';
import type { Enums } from '@/integrations/supabase/types';

const formatCPF = (cpf: string | null) => cpf ? cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4') : 'N/A';
const formatPhone = (phone: string | null) => {
  if (!phone) return 'N/A';
  const numbers = phone.replace(/\D/g, '');
  if (numbers.length === 11) return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  if (numbers.length === 10) return numbers.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  return phone;
};
const formatCEP = (cep: string | null) => cep ? cep.replace(/(\d{5})(\d{3})/, '$1-$2') : 'N/A';
const formatDate = (dateString: string | null) => {
  if (!dateString) return 'N/A';
  const date = new Date(dateString);
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
};

const getRoleLabel = (role: Enums<'app_role'> | null) => {
  switch (role) {
    case 'admin': return 'Administrador';
    case 'driver': return 'Entregador';
    case 'client': return 'Cliente';
    case 'restaurant': return 'Restaurante';
    default: return 'Desconhecido';
  }
};

const getStatusLabel = (status: string | null) => {
  switch (status) {
    case 'approved': return 'Ativo';
    case 'pending': return 'Pendente';
    case 'rejected': return 'Rejeitado';
    case 'deactivated': return 'Desativado';
    default: return 'Desconhecido';
  }
};

interface UserDetailDialogProps {
  user: UserProfile | null;
  isOpen: boolean;
  onClose: () => void;
  onActivate: (user: UserProfile) => void;
  onDeactivate: (user: UserProfile) => void;
  onUpdateRole: (userId: string, newRole: Enums<'app_role'>) => void;
}

const UserDetailDialog: React.FC<UserDetailDialogProps> = ({ user, isOpen, onClose, onActivate, onDeactivate, onUpdateRole }) => {
  const [editingRole, setEditingRole] = useState(false);
  const [newRole, setNewRole] = useState<Enums<'app_role'> | null>(null);

  useEffect(() => {
    if (user) {
      setNewRole(user.role);
    }
  }, [user]);

  if (!user) return null;

  const handleSaveRole = () => {
    if (newRole && newRole !== user.role) {
      onUpdateRole(user.id, newRole);
    }
    setEditingRole(false);
  };

  const isDriver = user.role === 'driver';
  const isRestaurant = user.role === 'restaurant';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-white text-gray-900 border-gray-200 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900 flex items-center gap-2">
            <User size={20} /> Detalhes do Usuário
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            Informações completas e gestão de conta
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Basic Info */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <User size={16} /> Informações Básicas
            </h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <p><strong>Nome:</strong> {user.nome_completo || 'N/A'}</p>
                <p><strong>E-mail:</strong> {user.email}</p>
                <p><strong>Telefone:</strong> {formatPhone(user.telefone)}</p>
              </div>
              <div className="space-y-2">
                <p><strong>CPF:</strong> {formatCPF(user.cpf)}</p>
                <p><strong>RG:</strong> {user.rg || 'N/A'}</p>
                <p><strong>Data Cadastro:</strong> {formatDate(user.created_at)}</p>
              </div>
            </div>
          </div>

          {/* Role and Status */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <Shield size={16} /> Função e Status
            </h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <p><strong>Função:</strong> {getRoleLabel(user.role)}</p>
                {editingRole ? (
                  <div className="flex items-center gap-2">
                    <Select value={newRole || ''} onValueChange={(value) => setNewRole(value as Enums<'app_role'>)}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Alterar função" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="client">Cliente</SelectItem>
                        <SelectItem value="driver">Entregador</SelectItem>
                        <SelectItem value="restaurant">Restaurante</SelectItem>
                        <SelectItem value="admin">Administrador</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button size="sm" onClick={handleSaveRole}>Salvar</Button>
                    <Button size="sm" variant="outline" onClick={() => setEditingRole(false)}>Cancelar</Button>
                  </div>
                ) : (
                  <Button variant="outline" size="sm" onClick={() => setEditingRole(true)}>
                    <Edit size={14} className="mr-1" /> Alterar Função
                  </Button>
                )}
              </div>
              <div className="space-y-2">
                <p><strong>Status:</strong> {getStatusLabel(user.status)}</p>
                {user.status === 'approved' ? (
                  <Button variant="destructive" size="sm" onClick={() => onDeactivate(user)}>
                    <XCircle size={14} className="mr-1" /> Desativar Conta
                  </Button>
                ) : (
                  <Button variant="hero" size="sm" onClick={() => onActivate(user)}>
                    <CheckCircle size={14} className="mr-1" /> Ativar Conta
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Address Info (if available) */}
          {(user.cep || user.rua) && (
            <div className="bg-gray-50 rounded-xl p-4">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <MapPin size={16} /> Endereço
              </h3>
              <div className="text-sm space-y-1">
                <p><strong>CEP:</strong> {formatCEP(user.cep)}</p>
                <p><strong>Rua:</strong> {user.rua || 'N/A'}, {user.numero || 'N/A'}</p>
                <p><strong>Complemento:</strong> {user.complemento || 'N/A'}</p>
                <p><strong>Bairro:</strong> {user.bairro || 'N/A'}</p>
                <p><strong>Cidade/Estado:</strong> {user.cidade || 'N/A'}, {user.estado || 'N/A'}</p>
              </div>
            </div>
          )}

          {/* Vehicle Info (if driver) */}
          {isDriver && (user.tipo_veiculo || user.placa_veiculo) && (
            <div className="bg-gray-50 rounded-xl p-4">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <Car size={16} /> Veículo
              </h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <p><strong>Tipo:</strong> {user.tipo_veiculo || 'N/A'}</p>
                  <p><strong>Marca:</strong> {user.marca_veiculo || 'N/A'}</p>
                  <p><strong>Modelo:</strong> {user.modelo_veiculo || 'N/A'}</p>
                </div>
                <div className="space-y-2">
                  <p><strong>Ano:</strong> {user.ano_veiculo || 'N/A'}</p>
                  <p><strong>Placa:</strong> {user.placa_veiculo || 'N/A'}</p>
                  <p><strong>Cor:</strong> {user.cor_veiculo || 'N/A'}</p>
                </div>
              </div>
            </div>
          )}

          {/* Documents (if driver) */}
          {isDriver && (user.cnh_url || user.comprovante_endereco_url || user.documento_veiculo_url) && (
            <div className="bg-gray-50 rounded-xl p-4">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <FileText size={16} /> Documentos
              </h3>
              <div className="space-y-3">
                {[
                  { label: 'CNH', url: user.cnh_url },
                  { label: 'Comprovante de Endereço', url: user.comprovante_endereco_url },
                  { label: 'Documento do Veículo', url: user.documento_veiculo_url },
                ].map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                        <FileText size={16} className="text-blue-500" />
                      </div>
                      <span className="text-sm font-medium">{doc.label}</span>
                    </div>
                    {doc.url ? (
                      <a
                        href={doc.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:underline"
                      >
                        Ver documento
                      </a>
                    ) : (
                      <span className="text-sm text-red-500">Não enviado</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex flex-col gap-2 sm:flex-col">
          <Button
            variant="outline"
            size="lg"
            className="w-full"
            onClick={onClose}
          >
            Fechar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default UserDetailDialog;