import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Search, Filter, RefreshCw, Users, UserPlus, Utensils } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useUserManagementData, UserProfile } from '@/hooks/admin/useUserManagementData';
import UserCard from './UserCard';
import UserDetailDialog from './UserDetailDialog';

const UserManagementTab: React.FC = () => {
  const { users, isLoading, fetchUsers, activateUser, deactivateUser, updateUserRole } = useUserManagementData();
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const searchMatch = 
        user.nome_completo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.cpf?.includes(searchTerm) ||
        user.telefone?.includes(searchTerm);
      
      const roleMatch = roleFilter === 'all' || user.role === roleFilter;
      const statusMatch = statusFilter === 'all' || user.status === statusFilter;

      return searchMatch && roleMatch && statusMatch;
    });
  }, [users, searchTerm, roleFilter, statusFilter]);

  const handleViewDetails = (user: UserProfile) => {
    setSelectedUser(user);
    setShowDetailDialog(true);
  };

  const handleActivateUser = async (user: UserProfile) => {
    await activateUser(user.id, user.nome_completo || user.email);
    setShowDetailDialog(false);
  };

  const handleDeactivateUser = async (user: UserProfile) => {
    await deactivateUser(user.id, user.nome_completo || user.email);
    setShowDetailDialog(false);
  };

  const handleUpdateUserRole = async (userId: string, newRole: 'admin' | 'driver' | 'client' | 'restaurant') => {
    await updateUserRole(userId, newRole);
    setShowDetailDialog(false);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setRoleFilter('all');
    setStatusFilter('all');
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users size={18} className="text-primary" />
            Gerenciar Usuários
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome, email, CPF ou telefone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo de Usuário" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="driver">Entregadores</SelectItem>
                <SelectItem value="client">Clientes</SelectItem>
                <SelectItem value="restaurant">Restaurantes</SelectItem>
                <SelectItem value="admin">Administradores</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Status da Conta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="approved">Aprovados</SelectItem>
                <SelectItem value="pending">Pendentes</SelectItem>
                <SelectItem value="rejected">Rejeitados</SelectItem>
                <SelectItem value="deactivated">Desativados</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={clearFilters}
              disabled={!searchTerm && roleFilter === 'all' && statusFilter === 'all'}
            >
              <Filter size={16} className="mr-2" />
              Limpar Filtros
            </Button>
            <Button
              variant="hero"
              className="flex-1"
              onClick={fetchUsers}
              disabled={isLoading}
            >
              <RefreshCw size={16} className="mr-2" />
              Atualizar
            </Button>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="space-y-3">
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
        </div>
      ) : filteredUsers.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 px-4 text-center text-muted-foreground">
          <Users size={48} className="mb-4 opacity-50" />
          <p className="text-lg font-medium">Nenhum usuário encontrado</p>
          <p className="text-sm">Ajuste os filtros ou tente novamente</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredUsers.map(user => (
            <UserCard 
              key={user.id} 
              user={user} 
              onViewDetails={handleViewDetails} 
            />
          ))}
        </div>
      )}

      <UserDetailDialog
        user={selectedUser}
        isOpen={showDetailDialog}
        onClose={() => setShowDetailDialog(false)}
        onActivate={handleActivateUser}
        onDeactivate={handleDeactivateUser}
        onUpdateRole={handleUpdateUserRole}
      />
    </div>
  );
};

export default UserManagementTab;