import React, { useState } from 'react';
import { MapPin, Route, Clock, DollarSign, CheckCircle, AlertCircle, Package, Truck, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useRouteOptimization } from '@/hooks/useRouteOptimization';
import { useToast } from '@/hooks/use-toast';

interface Coordinate {
  lat: number;
  lng: number;
}

interface DeliveryPoint {
  id: string;
  address: string;
  coordinates?: Coordinate;
  type: 'pickup' | 'dropoff';
  value: number;
  customerName: string;
}

interface RouteOptimizerProps {
  deliveries: DeliveryPoint[];
  currentLocation: Coordinate;
  onAcceptRoute: (route: any) => void;
  onRejectRoute: () => void;
}

const RouteOptimizer: React.FC<RouteOptimizerProps> = ({
  deliveries,
  currentLocation,
  onAcceptRoute,
  onRejectRoute,
}) => {
  const { toast } = useToast();
  const { calculateOptimizedRoute, calculateBatchRoute, isOptimizing } = useRouteOptimization();
  const [selectedDeliveries, setSelectedDeliveries] = useState<string[]>([]);
  const [routeType, setRouteType] = useState<'single' | 'batch' | null>(null);
  const [routeResult, setRouteResult] = useState<any>(null);

  const formatDistance = (km: number) => {
    if (km < 1) return `${Math.round(km * 1000)} m`;
    return `${km.toFixed(1)} km`;
  };

  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}min`;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const toggleDelivery = (id: string) => {
    setSelectedDeliveries(prev => 
      prev.includes(id) 
        ? prev.filter(d => d !== id)
        : [...prev, id]
    );
  };

  const handleCalculateRoute = async (type: 'single' | 'batch') => {
    if (selectedDeliveries.length === 0) {
      toast({ title: "Selecione entregas", description: "Marque pelo menos uma entrega", variant: "destructive" });
      return;
    }

    if (type === 'batch' && selectedDeliveries.length < 2) {
      toast({ title: "Rota combinada", description: "Selecione pelo menos 2 entregas", variant: "destructive" });
      return;
    }

    setRouteType(type);

    const selectedPoints = deliveries.filter(d => selectedDeliveries.includes(d.id));

    try {
      if (type === 'single') {
        const result = await new Promise<any>((resolve, reject) => {
          calculateOptimizedRoute(
            {
              points: selectedPoints,
              startCoord: currentLocation,
              useAPI: true,
            },
            {
              onSuccess: (data) => resolve(data),
              onError: (error) => reject(error),
            }
          );
        });

        setRouteResult(result);
        onAcceptRoute(result);
      } else {
        const result = await new Promise<any>((resolve, reject) => {
          calculateBatchRoute(
            {
              points: selectedPoints,
              startCoord: currentLocation,
              useAPI: true,
            },
            {
              onSuccess: (data) => resolve(data),
              onError: (error) => reject(error),
            }
          );
        });

        setRouteResult(result);
        onAcceptRoute(result);
      }
    } catch (error) {
      console.error('Erro ao calcular rota:', error);
    }
  };

  const totalValue = deliveries
    .filter(d => selectedDeliveries.includes(d.id))
    .reduce((sum, d) => sum + d.value, 0);

  // Se já calculou a rota, mostra o resultado
  if (routeResult) {
    return (
      <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Route size={18} className="text-primary" />
            Rota Otimizada {routeType === 'batch' ? '(Combinada)' : ''}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Resumo da Rota */}
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 bg-card rounded-lg border border-border">
              <p className="text-2xl font-bold text-primary">
                {formatDistance(routeResult.totalDistance)}
              </p>
              <p className="text-xs text-muted-foreground">Distância</p>
            </div>
            <div className="text-center p-3 bg-card rounded-lg border border-border">
              <p className="text-2xl font-bold text-accent">
                {formatTime(routeResult.totalTime)}
              </p>
              <p className="text-xs text-muted-foreground">Tempo</p>
            </div>
            <div className="text-center p-3 bg-card rounded-lg border border-border">
              <p className="text-2xl font-bold text-green-600">
                {formatCurrency(routeResult.savings.time * 0.5)}
              </p>
              <p className="text-xs text-muted-foreground">Economia</p>
            </div>
          </div>

          {/* Waypoints */}
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Pontos da Rota:</h4>
            {routeResult.waypoints.map((wp: any, index: number) => (
              <div key={wp.id} className="flex items-start gap-3 p-3 bg-card rounded-lg border border-border">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  wp.type === 'pickup' ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{wp.address.split(',')[0]}</p>
                  <p className="text-xs text-muted-foreground">{wp.instructions}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Chegada estimada: {wp.estimatedArrival}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Economia */}
          <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
            <p className="text-sm font-medium text-green-600 flex items-center gap-2">
              <CheckCircle size={14} />
              Economia estimada: {formatTime(routeResult.savings.time)} ({formatDistance(routeResult.savings.distance)})
            </p>
          </div>

          {/* Ações */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => {
                setRouteResult(null);
                setRouteType(null);
                setSelectedDeliveries([]);
                onRejectRoute();
              }}
            >
              Cancelar
            </Button>
            <Button
              variant="hero"
              className="flex-1"
              onClick={() => onAcceptRoute(routeResult)}
            >
              <CheckCircle size={16} className="mr-2" />
              Aceitar Rota
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Seleção de Entregas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package size={18} className="text-primary" />
            Selecione as Entregas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {deliveries.map(delivery => (
            <div
              key={delivery.id}
              className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-all ${
                selectedDeliveries.includes(delivery.id)
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:border-primary/50'
              }`}
              onClick={() => toggleDelivery(delivery.id)}
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  delivery.type === 'pickup' ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'
                }`}>
                  {delivery.type === 'pickup' ? <Package size={16} /> : <Truck size={16} />}
                </div>
                <div>
                  <p className="text-sm font-medium">{delivery.address.split(',')[0]}</p>
                  <p className="text-xs text-muted-foreground">{delivery.customerName}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold">{formatCurrency(delivery.value)}</p>
                <p className="text-xs text-muted-foreground">
                  {delivery.type === 'pickup' ? 'Coleta' : 'Entrega'}
                </p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Resumo da Seleção */}
      {selectedDeliveries.length > 0 && (
        <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium">Total Selecionado:</span>
              <span className="text-lg font-bold text-primary">
                {formatCurrency(totalValue)}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="hero"
                size="sm"
                onClick={() => handleCalculateRoute('single')}
                disabled={isOptimizing}
              >
                {isOptimizing ? (
                  <span className="flex items-center gap-2">
                    <RefreshCw size={14} className="animate-spin" />
                    Calculando...
                  </span>
                ) : (
                  <>
                    <MapPin size={14} className="mr-1" />
                    Rota Única
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleCalculateRoute('batch')}
                disabled={selectedDeliveries.length < 2 || isOptimizing}
              >
                {isOptimizing ? (
                  <span className="flex items-center gap-2">
                    <RefreshCw size={14} className="animate-spin" />
                    Calculando...
                  </span>
                ) : (
                  <>
                    <Route size={14} className="mr-1" />
                    Rota Combinada
                  </>
                )}
              </Button>
            </div>
            {selectedDeliveries.length >= 2 && (
              <p className="text-xs text-muted-foreground mt-2 text-center">
                Rota combinada pode economizar até 30% do tempo
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Ações */}
      <div className="flex gap-2">
        <Button
          variant="outline"
          className="flex-1"
          onClick={() => {
            setSelectedDeliveries([]);
            onRejectRoute();
          }}
        >
          Cancelar
        </Button>
      </div>
    </div>
  );
};

export default RouteOptimizer;