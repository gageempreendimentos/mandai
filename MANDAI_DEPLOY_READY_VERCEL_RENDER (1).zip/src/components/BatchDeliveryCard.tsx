import React, { useState } from 'react';
import { Package, Clock, DollarSign, MapPin, CheckCircle, Route } from 'lucide-react';
import { Button } from './ui/button';
import LoadingButton from '@/components/LoadingButton';
import { BatchDelivery } from '@/hooks/useBatchDeliveries';

interface BatchDeliveryCardProps {
  batch: BatchDelivery;
  onAccept: (batch: BatchDelivery) => void | Promise<void>;
  onReject: (batchId: string) => void | Promise<void>;
}

const BatchDeliveryCard: React.FC<BatchDeliveryCardProps> = ({ batch, onAccept, onReject }) => {
  const [isAccepting, setIsAccepting] = useState(false);
  const [isRejecting, setIsRejecting] = useState(false);

  const handleAccept = async () => {
    try {
      setIsAccepting(true);
      await onAccept(batch);
    } finally {
      setIsAccepting(false);
    }
  };

  const handleReject = async () => {
    try {
      setIsRejecting(true);
      await onReject(batch.deliveries[0].id);
    } finally {
      setIsRejecting(false);
    }
  };

  const firstDelivery = batch.deliveries[0];
  
  // Calcular economia estimada com o agrupamento
  const individualValue = batch.deliveries.reduce((sum, d) => sum + d.value, 0);
  const batchBonus = batch.deliveries.length * 2; // Bônus de R$2 por entrega agrupada
  const totalWithBonus = individualValue + batchBonus;

  return (
    <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-5 shadow-card border border-primary/20 animate-slide-up">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center">
            <Route size={24} className="text-white" />
          </div>
          <div>
            <h3 className="font-bold text-foreground">Rota Otimizada</h3>
            <p className="text-xs text-muted-foreground">
              {batch.deliveries.length} entregas • {batch.totalTime} min
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-primary">
            R$ {totalWithBonus.toFixed(2)}
          </p>
          <p className="text-xs text-muted-foreground">Total + bônus</p>
        </div>
      </div>
      
      {/* Bônus destacado */}
      <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 mb-4">
        <div className="flex items-center gap-2">
          <CheckCircle size={16} className="text-green-500" />
          <span className="text-sm font-bold text-green-700">
            Bônus por agrupamento: R$ {batchBonus.toFixed(2)}
          </span>
        </div>
        <p className="text-xs text-green-600 mt-1">
          Ganhe mais fazendo entregas próximas juntas
        </p>
      </div>
      
      {/* Resumo da Rota */}
      <div className="space-y-2 mb-4 text-sm">
        <div className="flex items-center gap-2 text-muted-foreground">
          <MapPin size={14} className="text-primary" />
          <span className="truncate">Ponto de coleta: {firstDelivery.pickup.name}</span>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <MapPin size={14} className="text-accent" />
          <span className="truncate">Primeira entrega: {firstDelivery.dropoff.name}</span>
          {batch.deliveries.length > 1 && (
            <span className="ml-2 px-2 py-0.5 bg-primary/10 text-primary rounded-full text-xs">
              +{batch.deliveries.length - 1} outras
            </span>
          )}
        </div>
      </div>
      
      {/* Métricas */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-card/50 rounded-lg p-2 text-center">
          <DollarSign size={14} className="mx-auto text-primary mb-1" />
          <p className="text-xs font-bold text-foreground">
            R$ {(totalWithBonus / batch.deliveries.length).toFixed(2)}
          </p>
          <p className="text-[10px] text-muted-foreground">Média</p>
        </div>
        <div className="bg-card/50 rounded-lg p-2 text-center">
          <MapPin size={14} className="mx-auto text-accent mb-1" />
          <p className="text-xs font-bold text-foreground">
            {batch.totalDistance.toFixed(1)}km
          </p>
          <p className="text-[10px] text-muted-foreground">Total</p>
        </div>
        <div className="bg-card/50 rounded-lg p-2 text-center">
          <Clock size={14} className="mx-auto text-orange-500 mb-1" />
          <p className="text-xs font-bold text-foreground">
            {batch.totalTime}min
          </p>
          <p className="text-[10px] text-muted-foreground">Tempo</p>
        </div>
      </div>
      
      {/* Detalhes das Entregas */}
      <div className="space-y-2 mb-4">
        {batch.deliveries.map((delivery, index) => (
          <div key={delivery.id} className="flex items-center gap-2 text-xs text-muted-foreground">
            <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
              {index + 1}
            </div>
            <span className="truncate flex-1">{delivery.dropoff.name}</span>
            <span className="font-bold text-primary">R$ {delivery.value.toFixed(2)}</span>
          </div>
        ))}
      </div>
      
      {/* Ações */}
      <div className="flex gap-2">
        <LoadingButton 
          variant="outline" 
          className="flex-1" 
          onClick={handleReject}
          loading={isRejecting}
        >
          Recusar
        </LoadingButton>
        <LoadingButton 
          variant="hero" 
          className="flex-1" 
          onClick={handleAccept}
          loading={isAccepting}
        >
          <CheckCircle size={16} />
          Aceitar Rota
        </LoadingButton>
      </div>
    </div>
  );
};

export default BatchDeliveryCard;