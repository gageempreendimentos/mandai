import React from 'react';
import { Package, AlertCircle } from 'lucide-react';
import DeliveryCard, { Delivery } from './DeliveryCard';
import { Button } from './ui/button';

interface PendingQueueProps {
  deliveries: Delivery[];
  onAccept: (delivery: Delivery) => void;
  onReject: (id: string) => void;
  isLoading?: boolean;
}

const PendingQueue: React.FC<PendingQueueProps> = ({
  deliveries,
  onAccept,
  onReject,
  isLoading = false,
}) => {
  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-lg font-semibold text-foreground mb-2">
          Buscando entregas...
        </p>
        <p className="text-muted-foreground">
          Você será notificado instantaneamente
        </p>
      </div>
    );
  }

  if (deliveries.length === 0) {
    return (
      <div className="text-center py-8">
        <Package size={48} className="text-muted-foreground mx-auto mb-4 opacity-50" />
        <p className="text-lg font-semibold text-foreground mb-2">
          Nenhuma entrega disponível
        </p>
        <p className="text-muted-foreground">
          Aguardando novas oportunidades...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-foreground text-center">Entregas Disponíveis</h2>
      {deliveries.map((delivery) => (
        <DeliveryCard
          key={delivery.id}
          delivery={delivery}
          onAccept={onAccept}
          onReject={onReject}
        />
      ))}
    </div>
  );
};

export default PendingQueue;