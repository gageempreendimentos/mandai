import React from "react";
import { Button } from "@/components/ui/button";
import { Wrench } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function UnderConstruction({ title = "Em desenvolvimento" }: { title?: string }) {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-lg text-center space-y-4">
        <div className="mx-auto w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
          <Wrench className="text-primary" />
        </div>
        <div className="space-y-1">
          <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
          <p className="text-sm text-muted-foreground">
            Estamos preparando algo incrível para você. 🚀
          </p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Button variant="outline" onClick={() => navigate(-1)}>Voltar</Button>
          <Button onClick={() => navigate("/driver")}>Ir ao painel</Button>
        </div>
      </div>
    </div>
  );
}
