import React from 'react';

const Slogan: React.FC = () => {
  return null;
};

export default Slogan;