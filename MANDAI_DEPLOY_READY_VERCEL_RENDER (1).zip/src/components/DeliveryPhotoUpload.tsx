import React, { useState, useRef } from 'react';
import { Camera, X, Check, Upload } from 'lucide-react';
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';

interface DeliveryPhotoUploadProps {
  onPhotoCaptured: (file: File) => void;
  onPhotoRemoved: () => void;
  photo: File | null;
}

const DeliveryPhotoUpload: React.FC<DeliveryPhotoUploadProps> = ({ 
  onPhotoCaptured, 
  onPhotoRemoved,
  photo 
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setShowCamera(true);
      }
    } catch (error) {
      toast({
        title: "Erro de câmera",
        description: "Não foi possível acessar a câmera. Use o upload.",
        variant: "destructive",
      });
      setShowCamera(false);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;

    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0);
      
      canvas.toBlob((blob) => {
        if (blob) {
          const file = new File([blob], `entrega_${Date.now()}.jpg`, { type: 'image/jpeg' });
          handleFileSelected(file);
          stopCamera();
        }
      }, 'image/jpeg', 0.8);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setShowCamera(false);
  };

  const handleFileSelected = (file: File) => {
    // Validar tamanho (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Foto muito grande",
        description: "Máximo: 5MB",
        variant: "destructive",
      });
      return;
    }

    // Validar tipo
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Formato inválido",
        description: "Use apenas imagens",
        variant: "destructive",
      });
      return;
    }

    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    onPhotoCaptured(file);
  };

  const handleRemove = () => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setPreviewUrl(null);
    onPhotoRemoved();
  };

  if (photo && previewUrl) {
    return (
      <div className="space-y-2">
        <label className="block text-sm font-medium text-foreground">
          Foto da Entrega
        </label>
        <div className="relative rounded-xl overflow-hidden border-2 border-primary bg-primary/5">
          <img src={previewUrl} alt="Entrega" className="w-full h-48 object-cover" />
          <button
            onClick={handleRemove}
            className="absolute top-2 right-2 w-8 h-8 bg-destructive text-white rounded-full flex items-center justify-center hover:bg-destructive/90"
          >
            <X size={16} />
          </button>
          <div className="absolute bottom-2 left-2 bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
            <Check size={12} />
            Foto capturada
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-foreground">
        Foto da Entrega *
      </label>
      
      {showCamera ? (
        <div className="space-y-3">
          <div className="relative rounded-xl overflow-hidden bg-black">
            <video
              ref={videoRef}
              className="w-full h-48 object-cover"
              autoPlay
              playsInline
            />
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-3">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  stopCamera();
                  fileInputRef.current?.click();
                }}
              >
                <Upload size={16} />
                Upload
              </Button>
              <Button
                variant="hero"
                size="sm"
                onClick={capturePhoto}
              >
                <Camera size={16} />
                Tirar Foto
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={stopCamera}
              >
                <X size={16} />
                Cancelar
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <Button
            variant="secondary"
            className="flex-1"
            onClick={startCamera}
          >
            <Camera size={18} />
            Usar Câmera
          </Button>
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload size={18} />
            Upload
          </Button>
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFileSelected(file);
          e.target.value = '';
        }}
      />

      <p className="text-xs text-muted-foreground">
        Foto será usada como comprovante da entrega
      </p>
    </div>
  );
};

export default DeliveryPhotoUpload;