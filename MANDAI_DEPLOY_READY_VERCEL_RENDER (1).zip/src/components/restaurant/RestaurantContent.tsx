import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Package, DollarSign, AlertCircle } from 'lucide-react';
import type { RestaurantOrder } from '@/pages/RestaurantDashboard';

interface RestaurantContentProps {
  activeTab: 'pendentes' | 'preparando' | 'prontos' | 'historico';
  orders: RestaurantOrder[];
  isLoading: boolean;
  totalEarnings: number;
  onNewOrder: () => void;
  onViewDetails: (order: RestaurantOrder) => void;
  onUpdateStatus: (orderId: string, status: string) => void;
  getStatusBadge: (status: string) => { color: string; icon: any };
  getStatusText: (status: string) => string;
  formatDate: (date: string) => string;
}

const RestaurantContent: React.FC<RestaurantContentProps> = ({
  activeTab,
  orders,
  isLoading,
  totalEarnings,
  onNewOrder,
  onViewDetails,
  onUpdateStatus,
  getStatusBadge,
  getStatusText,
  formatDate,
}) => {
  return (
    <div className="flex-1 overflow-auto p-4 space-y-4 pb-20">
      {/* Stats Cards */}
      {activeTab === 'pendentes' && (
        <div className="grid grid-cols-2 gap-4 mb-4">
          <Card className="bg-gradient-to-br from-orange-500/10 to-orange-500/5 border-orange-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-orange-600">Pedidos Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {orders.filter(o => o.status === 'pending').length}
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-green-600">Receita Hoje</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                R$ {totalEarnings.toFixed(2)}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* New Order Button */}
      {activeTab === 'pendentes' && (
        <Button 
          variant="hero" 
          size="lg" 
          className="w-full bg-orange-500 hover:bg-orange-600 text-white"
          onClick={onNewOrder}
        >
          <Plus size={18} className="mr-2" />
          Novo Pedido
        </Button>
      )}

      {/* Orders List */}
      {orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
          <Package size={48} className="text-muted-foreground mb-4 opacity-50" />
          <h2 className="text-xl font-bold mb-2">
            {activeTab === 'pendentes' ? 'Nenhum pedido pendente' : 
             activeTab === 'preparando' ? 'Nenhum pedido em preparo' :
             activeTab === 'prontos' ? 'Nenhum pedido pronto' : 'Sem histórico'}
          </h2>
          <p className="text-sm text-muted-foreground">
            {activeTab === 'pendentes' ? 'Clique em "Novo Pedido" para começar' : 'Aguardando pedidos...'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => {
            const badge = getStatusBadge(order.status);
            const Icon = badge.icon;
            
            return (
              <Card key={order.id} className="border border-border/50 hover:border-border transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-orange-500/10 flex items-center justify-center">
                        <Package size={24} className="text-orange-500" />
                      </div>
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                          #{order.order_number}
                          <Icon size={16} className={badge.color.split(' ')[1]} />
                        </CardTitle>
                        <p className="text-sm text-muted-foreground">
                          {order.customer_name} • R$ {order.total_value.toFixed(2)}
                        </p>
                      </div>
                    </div>
                    <Badge variant="secondary" className={badge.color}>
                      {getStatusText(order.status)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-2">
                  <div className="text-sm text-muted-foreground mb-3">
                    <p className="truncate">Endereço: {order.delivery_address}</p>
                    <p className="mt-1">Criado em: {formatDate(order.created_at)}</p>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => onViewDetails(order)}
                    >
                      Ver Detalhes
                    </Button>
                    
                    {order.status === 'pending' && (
                      <Button
                        variant="hero"
                        size="sm"
                        className="flex-1 bg-blue-500 hover:bg-blue-600"
                        onClick={() => onUpdateStatus(order.id, 'preparing')}
                      >
                        Iniciar Preparo
                      </Button>
                    )}
                    
                    {order.status === 'preparing' && (
                      <Button
                        variant="hero"
                        size="sm"
                        className="flex-1 bg-green-500 hover:bg-green-600"
                        onClick={() => onUpdateStatus(order.id, 'ready')}
                      >
                        Marcar Pronto
                      </Button>
                    )}
                    
                    {order.status === 'ready' && (
                      <Button
                        variant="hero"
                        size="sm"
                        className="flex-1 bg-purple-500 hover:bg-purple-600"
                        onClick={() => onUpdateStatus(order.id, 'in_transit')}
                      >
                        Enviar Entrega
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default RestaurantContent;