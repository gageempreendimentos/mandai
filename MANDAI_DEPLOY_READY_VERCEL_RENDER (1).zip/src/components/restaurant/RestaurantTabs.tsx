import React from 'react';
import { Clock, Utensils, CheckCircle, History } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface RestaurantTabsProps {
  activeTab: 'pendentes' | 'preparando' | 'prontos' | 'historico';
  onTabChange: (tab: 'pendentes' | 'preparando' | 'prontos' | 'historico') => void;
}

const RestaurantTabs: React.FC<RestaurantTabsProps> = ({ activeTab, onTabChange }) => {
  return (
    <div className="p-4 border-b border-border">
      <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as any)} className="w-full">
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="pendentes" className="flex items-center gap-2">
            <Clock size={16} /> Pendentes
          </TabsTrigger>
          <TabsTrigger value="preparando" className="flex items-center gap-2">
            <Utensils size={16} /> Preparando
          </TabsTrigger>
          <TabsTrigger value="prontos" className="flex items-center gap-2">
            <CheckCircle size={16} /> Prontos
          </TabsTrigger>
          <TabsTrigger value="historico" className="flex items-center gap-2">
            <History size={16} /> Histórico
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
};

export default RestaurantTabs;