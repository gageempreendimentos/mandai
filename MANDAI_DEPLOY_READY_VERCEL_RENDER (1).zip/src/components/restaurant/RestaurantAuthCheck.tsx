import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import AccessDenied from '@/components/AccessDenied';
import { logError } from '@/lib/logger';

interface RestaurantAuthCheckProps {
  children: React.ReactNode;
}

const RestaurantAuthCheck: React.FC<RestaurantAuthCheckProps> = ({ children }) => {
  const [status, setStatus] = useState<'loading' | 'ok' | 'unauthenticated' | 'wrong_role' | 'error'>('loading');
  const navigate = useNavigate();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      setStatus('unauthenticated');
      navigate('/restaurant');
      return;
    }

    // Verificar se é restaurante
    const { data: role } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'restaurant')
      .single();

    if (!role) {
      setStatus('wrong_role');
      return;
    }

    setStatus('ok');
    } catch (error) {
      logError(error, { guard: 'restaurant' });
      setStatus('error');
    }

  };

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-foreground font-medium">Verificando acesso...</p>
        </div>
      </div>
    );
  }

  if (status === 'wrong_role') {
    return (
      <AccessDenied
        title="Acesso restrito"
        description="Você está logado, mas sua conta não tem perfil de restaurante."
        goToLabel="Ir para o app"
        goToPath="/"
      />
    );
  }

  if (status === 'error') {
    return (
      <AccessDenied
        title="Não foi possível verificar seu acesso"
        description="Tente novamente. Se continuar, verifique sua conexão."
        goToLabel="Tentar novamente"
        goToPath="/"
      />
    );
  }

  return <>{children}</>;
};

export default RestaurantAuthCheck;