import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Plus, Trash2 } from 'lucide-react';

interface NewOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (orderData: any) => Promise<void>;
  isLoading: boolean;
}

interface OrderItem {
  name: string;
  quantity: number;
  price: number;
}

const NewOrderModal: React.FC<NewOrderModalProps> = ({ isOpen, onClose, onCreate, isLoading }) => {
  const { toast } = useToast();
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [items, setItems] = useState<OrderItem[]>([{ name: '', quantity: 1, price: 0 }]);
  const [notes, setNotes] = useState('');

  const addItem = () => {
    setItems([...items, { name: '', quantity: 1, price: 0 }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const updateItem = (index: number, field: keyof OrderItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };

  const calculateTotal = () => {
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const validateForm = () => {
    if (!customerName || !customerPhone || !deliveryAddress) {
      toast({ title: "Dados incompletos", description: "Preencha todos os campos obrigatórios", variant: "destructive" });
      return false;
    }
    
    const validItems = items.filter(item => item.name.trim() && item.price > 0);
    if (validItems.length === 0) {
      toast({ title: "Itens inválidos", description: "Adicione pelo menos um item com nome e preço", variant: "destructive" });
      return false;
    }

    return true;
  };

  const handleCreate = async () => {
    if (!validateForm()) return;

    const orderData = {
      customer_name: customerName,
      customer_phone: customerPhone,
      delivery_address: deliveryAddress,
      items: items.filter(item => item.name.trim()).map(item => 
        `${item.name} (x${item.quantity}) - R$ ${(item.price * item.quantity).toFixed(2)}`
      ).join('\n'),
      total_value: calculateTotal(),
      notes,
    };

    await onCreate(orderData);
    
    // Reset form
    setCustomerName('');
    setCustomerPhone('');
    setDeliveryAddress('');
    setItems([{ name: '', quantity: 1, price: 0 }]);
    setNotes('');
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{2})(\d)/, '($1) $2')
        .replace(/(\d{5})(\d)/, '$1-$2');
    }
    return value.slice(0, 15);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg bg-white text-gray-900 border-gray-200 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900">Novo Pedido</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Customer Info */}
          <div className="space-y-3">
            <h3 className="font-bold text-gray-900">Informações do Cliente</h3>
            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Nome *</label>
              <Input
                placeholder="Nome do cliente"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Telefone *</label>
              <Input
                placeholder="(00) 00000-0000"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(formatPhone(e.target.value))}
                maxLength={15}
                inputMode="numeric"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Endereço de Entrega *</label>
              <Textarea
                placeholder="Rua, número, bairro, cidade/UF"
                value={deliveryAddress}
                onChange={(e) => setDeliveryAddress(e.target.value)}
                rows={2}
              />
            </div>
          </div>

          {/* Items */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-gray-900">Itens do Pedido</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={addItem}
                className="text-orange-500 border-orange-500/30 hover:bg-orange-500/10"
              >
                <Plus size={14} className="mr-1" />
                Adicionar Item
              </Button>
            </div>
            
            <div className="space-y-2">
              {items.map((item, index) => (
                <div key={index} className="flex gap-2 items-start p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex-1 space-y-2">
                    <Input
                      placeholder="Nome do item"
                      value={item.name}
                      onChange={(e) => updateItem(index, 'name', e.target.value)}
                    />
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Qtd"
                        value={item.quantity}
                        onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 1)}
                        className="w-20"
                        min={1}
                      />
                      <Input
                        type="number"
                        placeholder="Preço (R$)"
                        value={item.price || ''}
                        onChange={(e) => updateItem(index, 'price', parseFloat(e.target.value) || 0)}
                        className="flex-1"
                        min={0}
                        step="0.01"
                      />
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-red-500 hover:bg-red-500/10"
                    onClick={() => removeItem(index)}
                    disabled={items.length === 1}
                  >
                    <Trash2 size={16} />
                  </Button>
                </div>
              ))}
            </div>

            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="font-medium text-green-700">Total do Pedido</span>
                <span className="text-xl font-bold text-green-700">
                  R$ {calculateTotal().toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-3">
            <h3 className="font-bold text-gray-900">Observações</h3>
            <Textarea
              placeholder="Alguma observação especial? (opcional)"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={onClose}
            disabled={isLoading}
          >
            Cancelar
          </Button>
          <Button
            variant="hero"
            className="flex-1 bg-orange-500 hover:bg-orange-600 text-white"
            onClick={handleCreate}
            disabled={isLoading}
          >
            {isLoading ? 'Criando...' : 'Criar Pedido'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NewOrderModal;