import React from 'react';
import { LogOut, Utensils } from 'lucide-react';
import Logo from '@/components/Logo';

interface RestaurantHeaderProps {
  user: any;
  onLogout: () => void;
}

const RestaurantHeader: React.FC<RestaurantHeaderProps> = ({ user, onLogout }) => {
  return (
    <header className="sticky top-0 z-20 flex items-center gap-4 p-4 bg-background border-b border-border backdrop-blur-sm bg-opacity-95">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-orange-500/10 flex items-center justify-center">
          <Utensils size={20} className="text-orange-500" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-foreground">Restaurante</h1>
          <p className="text-xs text-muted-foreground">
            {user?.user_metadata?.nome || 'Restaurante Parceiro'}
          </p>
        </div>
      </div>
      
      <button 
        onClick={onLogout}
        className="ml-auto w-10 h-10 rounded-full bg-card flex items-center justify-center shadow-soft hover:bg-muted transition-colors"
      >
        <LogOut size={18} className="text-muted-foreground" />
      </button>
    </header>
  );
};

export default RestaurantHeader;