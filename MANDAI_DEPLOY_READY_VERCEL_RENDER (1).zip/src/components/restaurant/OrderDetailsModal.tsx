import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Package, User, Phone, MapPin, DollarSign, Clock, Utensils, CheckCircle, Truck } from 'lucide-react';

interface OrderDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: any;
  getStatusBadge: (status: string) => { color: string; icon: any };
  getStatusText: (status: string) => string;
  formatDate: (date: string) => string;
  onUpdateStatus: (orderId: string, status: string) => void;
}

const OrderDetailsModal: React.FC<OrderDetailsModalProps> = ({
  isOpen,
  onClose,
  order,
  getStatusBadge,
  getStatusText,
  formatDate,
  onUpdateStatus,
}) => {
  if (!order) return null;

  const badge = getStatusBadge(order.status);
  const Icon = badge.icon;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-white text-gray-900 border-gray-200 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900 flex items-center gap-2">
            <Package size={20} /> Pedido #{order.order_number}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Status */}
          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-full ${order.status === 'delivered' ? 'bg-green-500/10' : order.status === 'cancelled' ? 'bg-red-500/10' : 'bg-orange-500/10'} flex items-center justify-center`}>
                  <Icon size={24} className={badge.color.split(' ')[1]} />
                </div>
                <div>
                  <p className="text-lg font-bold">{getStatusText(order.status)}</p>
                  <p className="text-sm text-gray-600">Atualizado em {formatDate(order.updated_at || order.created_at)}</p>
                </div>
              </div>
              <Badge variant="secondary" className={badge.color}>
                {getStatusText(order.status)}
              </Badge>
            </div>
          </div>

          {/* Customer Info */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <User size={16} /> Cliente
            </h3>
            <div className="space-y-2 text-sm">
              <p className="flex items-center gap-2">
                <User size={14} className="text-gray-500" />
                {order.customer_name}
              </p>
              <p className="flex items-center gap-2">
                <Phone size={14} className="text-gray-500" />
                {order.customer_phone}
              </p>
            </div>
          </div>

          {/* Delivery Address */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <MapPin size={16} /> Endereço de Entrega
            </h3>
            <p className="text-sm text-gray-700">{order.delivery_address}</p>
          </div>

          {/* Items */}
          <div className="bg-gray-50 rounded-xl p-4">
            <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
              <Package size={16} /> Itens do Pedido
            </h3>
            <div className="space-y-2 text-sm whitespace-pre-line bg-white rounded-lg p-3 border border-gray-200">
              {order.items}
            </div>
            <div className="mt-3 pt-3 border-t border-gray-200 flex items-center justify-between">
              <span className="font-medium text-gray-700">Total</span>
              <span className="text-xl font-bold text-green-600">R$ {order.total_value.toFixed(2)}</span>
            </div>
          </div>

          {/* Notes */}
          {order.notes && (
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
              <h3 className="font-bold text-yellow-700 mb-2 flex items-center gap-2">
                <Utensils size={16} /> Observações
              </h3>
              <p className="text-sm text-yellow-800">{order.notes}</p>
            </div>
          )}

          {/* Status Actions */}
          {order.status === 'pending' && (
            <Button
              variant="hero"
              className="w-full bg-blue-500 hover:bg-blue-600"
              onClick={() => onUpdateStatus(order.id, 'preparing')}
            >
              <Utensils size={18} className="mr-2" />
              Iniciar Preparo
            </Button>
          )}

          {order.status === 'preparing' && (
            <Button
              variant="hero"
              className="w-full bg-green-500 hover:bg-green-600"
              onClick={() => onUpdateStatus(order.id, 'ready')}
            >
              <CheckCircle size={18} className="mr-2" />
              Marcar Pronto
            </Button>
          )}

          {order.status === 'ready' && (
            <Button
              variant="hero"
              className="w-full bg-purple-500 hover:bg-purple-600"
              onClick={() => onUpdateStatus(order.id, 'in_transit')}
            >
              <Truck size={18} className="mr-2" />
              Enviar Entrega
            </Button>
          )}
        </div>

        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            className="w-full"
            onClick={onClose}
          >
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OrderDetailsModal;