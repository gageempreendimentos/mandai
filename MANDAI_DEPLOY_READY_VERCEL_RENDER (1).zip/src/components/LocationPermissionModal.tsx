import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { MapPin, AlertCircle, CheckCircle } from 'lucide-react';

interface LocationPermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGrantPermission: () => void;
  isSupported: boolean;
}

const LocationPermissionModal: React.FC<LocationPermissionModalProps> = ({
  isOpen,
  onClose,
  onGrantPermission,
  isSupported,
}) => {
  if (!isSupported) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-sm bg-white text-gray-900 border-gray-200">
          <DialogHeader>
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center">
                <AlertCircle size={40} className="text-red-500" />
              </div>
            </div>
            <DialogTitle className="text-center text-xl text-gray-900">
              Geolocalização Não Suportada
            </DialogTitle>
            <DialogDescription className="text-center text-gray-600">
              Seu navegador não suporta geolocalização. Use um navegador moderno como Chrome, Firefox ou Safari.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 pt-4">
            <Button variant="outline" className="w-full" onClick={onClose}>
              Fechar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-white text-gray-900 border-gray-200">
        <DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-blue-500/10 rounded-full flex items-center justify-center">
              <MapPin size={40} className="text-blue-500" />
            </div>
          </div>
          <DialogTitle className="text-center text-xl text-gray-900">
            Permissão de Localização
          </DialogTitle>
          <DialogDescription className="text-center text-gray-600">
            Para usar o rastreamento em tempo real, precisamos da sua permissão para acessar sua localização.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-bold text-blue-800 mb-2 flex items-center gap-2">
              <CheckCircle size={16} />
              Benefícios:
            </h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Roteirização otimizada em tempo real</li>
              <li>• Alertas de trânsito próximos</li>
              <li>• Entregas próximas automaticamente</li>
              <li>• Precisão na estimativa de tempo</li>
            </ul>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <h4 className="font-bold text-orange-800 mb-2 flex items-center gap-2">
              <AlertCircle size={16} />
              Importante:
            </h4>
            <p className="text-sm text-orange-700">
              Você pode revogar a permissão a qualquer momento nas configurações do navegador.
            </p>
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={onClose}>
            Cancelar
          </Button>
          <Button variant="hero" className="flex-1" onClick={onGrantPermission}>
            Permitir Localização
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LocationPermissionModal;