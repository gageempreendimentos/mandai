import React from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

export default function CrisisBanner() {
  const q = useQuery({ queryKey: ["system_status_banner"], queryFn: () => fetchJSON("/admin/system/status"), refetchInterval: 15000 });
  if (!q.data?.crisis_mode) return null;

  return (
    <div className="w-full px-4 py-2 text-sm border-b bg-yellow-100">
      ⚠️ Sistema em <b>modo de contingência</b>. Algumas ações podem estar temporariamente bloqueadas.
    </div>
  );
}
