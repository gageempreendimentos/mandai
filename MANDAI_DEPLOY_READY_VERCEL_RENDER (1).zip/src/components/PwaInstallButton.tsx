import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePwaInstall } from '@/hooks/usePwaInstall';
import { notify } from '@/lib/notify';

export default function PwaInstallButton() {
  const { canInstall, install } = usePwaInstall();

  if (!canInstall) return null;

  const onClick = async () => {
    const { outcome } = await install();
    if (outcome === 'accepted') notify.success('MANDAI instalado com sucesso!');
    else notify.info('Instalação cancelada.');
  };

  return (
    <Button variant="secondary" className="w-full justify-start gap-2" onClick={onClick}>
      <Download className="h-4 w-4" />
      Instalar MANDAI
    </Button>
  );
}
