import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Loader2, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { searchCep, validateCep, formatCEP } from '@/lib/correiosApi';

interface AddressData {
  cep: string;
  rua: string;
  bairro: string;
  cidade: string;
  estado: string;
  complemento?: string;
  numero?: string;
}

interface AddressFormProps {
  data: AddressData;
  onChange: (field: keyof AddressData, value: string) => void;
  onAddressFound: (addressData: Partial<AddressData>) => void;
}

export const AddressForm: React.FC<AddressFormProps> = ({ data, onChange, onAddressFound }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [cepError, setCepError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleCEPChange = (value: string) => {
    // Formata o CEP enquanto o usuário digita
    const formatted = formatCEP(value);
    onChange('cep', formatted);
    setCepError(null); // Limpa o erro ao digitar
  };

  const handleCEPBlur = () => {
    // Valida o CEP quando o usuário sai do campo
    const cleanCep = data.cep.replace(/\D/g, '');
    if (cleanCep.length === 8) {
      console.log(`[AddressForm] CEP completo (8 dígitos), iniciando busca automática...`);
      fetchAddress();
    }
  };

  const fetchAddress = async () => {
    const validation = validateCep(data.cep);
    
    if (!validation.valid) {
      setCepError(validation.message);
      toast({
        title: "CEP inválido",
        description: validation.message,
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setCepError(null);
    
    console.log(`[AddressForm] Buscando CEP: ${data.cep}`);
    
    try {
      const address = await searchCep(data.cep);
      console.log(`[AddressForm] Resultado de searchCep:`, address);
      
      if (!address) {
        console.log(`[AddressForm] CEP não encontrado`);
        setCepError('CEP não encontrado');
        toast({
          title: "CEP não encontrado",
          description: "Verifique o CEP e tente novamente",
          variant: "destructive",
        });
        return;
      }

      console.log(`[AddressForm] Endereço encontrado:`, address);

      // Preencher os campos automaticamente
      onAddressFound({
        rua: address.logradouro || '',
        bairro: address.bairro || '',
        cidade: address.localidade || '',
        estado: address.uf || '',
        complemento: address.complemento || '',
      });

      toast({
        title: "Endereço encontrado! ✅",
        description: `${address.logradouro}, ${address.bairro}`,
      });
    } catch (error) {
      console.error('[AddressForm] Erro ao buscar CEP:', error);
      setCepError('Erro ao buscar CEP. Tente novamente.');
      toast({
        title: "Erro ao buscar CEP",
        description: "Não foi possível buscar o endereço. Preencha manualmente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* CEP com busca automática */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">CEP *</label>
        <div className="relative">
          <Input
            placeholder="00000-000"
            value={data.cep}
            onChange={(e) => handleCEPChange(e.target.value)}
            onBlur={handleCEPBlur}
            inputMode="numeric"
            className={`pr-12 ${cepError ? 'border-destructive' : ''}`}
          />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={fetchAddress}
            disabled={isLoading || data.cep.replace(/\D/g, '').length !== 8}
            className="absolute right-1 top-1/2 -translate-y-1/2 px-2"
          >
            {isLoading ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Search size={16} />
            )}
          </Button>
        </div>
        {cepError && (
          <div className="flex items-center gap-2 mt-1 text-destructive text-sm">
            <AlertCircle size={14} />
            {cepError}
          </div>
        )}
        <p className="text-xs text-muted-foreground mt-1">
          Digite o CEP (8 dígitos) e preencha automaticamente, ou preencha manualmente.
        </p>
      </div>

      {/* Rua e Número */}
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2">
          <label className="block text-sm font-medium text-foreground mb-2">Rua *</label>
          <Input
            placeholder="Nome da rua"
            value={data.rua}
            onChange={(e) => onChange('rua', e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Número *</label>
          <Input
            placeholder="Nº"
            value={data.numero || ''}
            onChange={(e) => onChange('numero', e.target.value)}
          />
        </div>
      </div>

      {/* Complemento */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Complemento</label>
        <Input
          placeholder="Apto, bloco, etc."
          value={data.complemento || ''}
          onChange={(e) => onChange('complemento', e.target.value)}
        />
      </div>

      {/* Bairro */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Bairro *</label>
        <Input
          placeholder="Seu bairro"
          value={data.bairro}
          onChange={(e) => onChange('bairro', e.target.value)}
        />
      </div>

      {/* Cidade e Estado */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Cidade *</label>
          <Input
            placeholder="Sua cidade"
            value={data.cidade}
            onChange={(e) => onChange('cidade', e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Estado *</label>
          <Input
            placeholder="UF"
            value={data.estado}
            onChange={(e) => onChange('estado', e.target.value)}
            maxLength={2}
          />
        </div>
      </div>
    </div>
  );
};