import React, { useState } from 'react';
import { Phone, CheckCircle, MapPin, Wallet, XCircle, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Delivery } from './DeliveryCard';
import NavigationButtons from './NavigationButtons';
import DeliveryPhotoUpload from './DeliveryPhotoUpload';
import DeliveryDisputeDialog from './DeliveryDisputeDialog';
import { useNavigate } from 'react-router-dom';

type DeliveryStage = 'going_pickup' | 'at_pickup' | 'going_delivery' | 'at_delivery' | 'returning' | 'at_return';

interface ActiveDeliveryProps {
  delivery: Delivery;
  stage: DeliveryStage;
  onArrivedPickup: () => void;
  onConfirmPickup: () => void;
  onArrivedDelivery: () => void;
  onConfirmDelivery: (photo?: File) => void;
  onNotDelivered: () => void;
  onArrivedReturn: () => void;
  onConfirmReturn: () => void;
  dailyEarnings: number;
}

const ActiveDelivery: React.FC<ActiveDeliveryProps> = ({ 
  delivery, 
  stage, 
  onArrivedPickup,
  onConfirmPickup, 
  onArrivedDelivery,
  onConfirmDelivery,
  onNotDelivered,
  onArrivedReturn,
  onConfirmReturn,
  dailyEarnings
}) => {
  const navigate = useNavigate();
  const [photo, setPhoto] = useState<File | null>(null);
  
  const isPickupPhase = stage === 'going_pickup' || stage === 'at_pickup';
  const isReturning = stage === 'returning' || stage === 'at_return';
  const isAtLocation = stage === 'at_pickup' || stage === 'at_delivery' || stage === 'at_return';
  
  const getCurrentAddress = () => {
    if (isReturning) return delivery.pickup;
    if (isPickupPhase) return delivery.pickup;
    return delivery.dropoff;
  };
  
  const currentAddress = getCurrentAddress();

  const getButtonAction = () => {
    switch (stage) {
      case 'going_pickup':
        return { label: 'Cheguei no Local', action: onArrivedPickup, icon: MapPin };
      case 'at_pickup':
        return { label: 'Coletei o Pedido', action: onConfirmPickup, icon: CheckCircle };
      case 'going_delivery':
        return { label: 'Cheguei no Destino', action: onArrivedDelivery, icon: MapPin };
      case 'at_delivery':
        return { label: 'Entreguei o Pedido', action: () => onConfirmDelivery(photo), icon: CheckCircle };
      case 'returning':
        return { label: 'Cheguei na Loja', action: onArrivedReturn, icon: MapPin };
      case 'at_return':
        return { label: 'Devolvi a Mercadoria', action: onConfirmReturn, icon: CheckCircle };
    }
  };
  
  const getLocationLabel = () => {
    if (isReturning) return 'Retornar para';
    if (isPickupPhase) return 'Retirar em';
    return 'Entregar para';
  };

  const buttonConfig = getButtonAction();
  const ButtonIcon = buttonConfig.icon;

  const handleChat = () => {
    navigate(`/chat/${delivery.id}`);
  };

  return (
    <div className="animate-slide-up space-y-3">
      {/* Current destination card */}
      <div className="bg-card/95 backdrop-blur-sm rounded-xl p-4 border border-border/50">
        <div className="flex items-start gap-3 mb-3">
          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
            isReturning ? 'bg-destructive/10 text-destructive' : isPickupPhase ? 'bg-accent/10 text-accent' : 'bg-primary/10 text-primary'
          }`}>
            <MapPin size={18} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">
              {getLocationLabel()}
            </p>
            <p className="font-semibold text-foreground">{currentAddress.name}</p>
            <p className="text-sm text-muted-foreground">{currentAddress.address}</p>
          </div>
          {!isPickupPhase && !isReturning && delivery.dropoff.phone && (
            <a 
              href={`tel:${delivery.dropoff.phone}`}
              className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary"
            >
              <Phone size={16} />
            </a>
          )}
        </div>
        
        {/* Navigation buttons */}
        <NavigationButtons address={currentAddress.address} />
      </div>

      {/* Valor da entrega */}
      <div className="bg-card/95 backdrop-blur-sm rounded-xl p-3 border border-border/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Wallet size={16} className="text-primary" />
          <span className="text-sm text-muted-foreground">Valor da entrega</span>
        </div>
        <span className="text-lg font-bold text-primary">
          R$ {delivery.value.toFixed(2)}
        </span>
      </div>

      {/* Photo Upload - only at delivery location */}
      {stage === 'at_delivery' && (
        <DeliveryPhotoUpload
          photo={photo}
          onPhotoCaptured={setPhoto}
          onPhotoRemoved={() => setPhoto(null)}
        />
      )}

      {/* Action button */}
      <Button 
        variant={isAtLocation ? 'hero' : 'accent'} 
        className="w-full"
        onClick={buttonConfig.action}
        disabled={stage === 'at_delivery' && !photo}
      >
        <ButtonIcon size={18} />
        {buttonConfig.label}
      </Button>
        
      {/* Not delivered button - only show at delivery location */}
      {stage === 'at_delivery' && (
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex-1 text-destructive border-destructive/30 hover:bg-destructive/10"
            onClick={onNotDelivered}
          >
            <XCircle size={18} />
            Não entregue
          </Button>
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleChat}
          >
            <MessageCircle size={18} />
            Chat
          </Button>
          <DeliveryDisputeDialog deliveryId={delivery.id} triggerClassName="flex-1" />
        </div>
      )}
    </div>
  );
};

export default ActiveDelivery;