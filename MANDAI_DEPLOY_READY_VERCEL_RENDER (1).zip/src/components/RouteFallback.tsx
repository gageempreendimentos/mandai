export default function RouteFallback() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-white">
      <div className="text-center flex flex-col items-center">
        <img src="/splash-mandai.jpg" alt="MANDAI" className="w-40 mb-4" />
        <div className="text-[13px] text-black/55">Carregando…</div>
        <div className="mt-3 h-7 w-7 rounded-full border-2 border-black/20 border-t-black animate-spin" />
      </div>
    </div>
  );
}
