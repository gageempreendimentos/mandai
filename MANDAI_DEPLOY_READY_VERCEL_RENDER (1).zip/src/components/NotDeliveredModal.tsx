import React, { useState } from 'react';
import { X, AlertTriangle, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

interface NotDeliveredModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}

const reasons = [
  { id: 'client_not_found', label: 'Cliente não encontrado' },
  { id: 'wrong_address', label: 'Endereço errado' },
  { id: 'address_not_found', label: 'Endereço não encontrado' },
  { id: 'client_cancelled', label: 'Cliente desistiu' },
  { id: 'damaged', label: 'Avariado' },
];

const NotDeliveredModal: React.FC<NotDeliveredModalProps> = ({ isOpen, onClose, onConfirm }) => {
  const [selectedReason, setSelectedReason] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleConfirm = () => {
    if (selectedReason) {
      onConfirm(selectedReason);
      setSelectedReason(null);
    }
  };

  const handleSupport = () => {
    navigate('/driver/support');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm bg-white text-foreground border-gray-200">
        <DialogHeader>
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle size={20} className="text-destructive" />
            <DialogTitle className="text-lg text-foreground">Não entregue</DialogTitle>
          </div>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <p className="text-sm text-gray-600">
            Selecione o motivo da não entrega:
          </p>

          <div className="space-y-2">
            {reasons.map((reason) => (
              <button
                key={reason.id}
                onClick={() => setSelectedReason(reason.id)}
                className={`w-full p-3 rounded-xl text-left transition-colors ${
                  selectedReason === reason.id
                    ? 'bg-primary text-white'
                    : 'bg-gray-100 text-foreground hover:bg-gray-200'
                }`}
              >
                {reason.label}
              </button>
            ))}
          </div>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              variant="secondary" 
              className="flex-1"
              onClick={handleSupport}
            >
              <MessageCircle size={16} />
              Suporte
            </Button>
            <Button 
              variant="destructive" 
              className="flex-1" 
              onClick={handleConfirm}
              disabled={!selectedReason}
            >
              Confirmar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NotDeliveredModal;