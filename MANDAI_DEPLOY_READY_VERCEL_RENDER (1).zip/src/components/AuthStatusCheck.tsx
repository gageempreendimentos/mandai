import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, Clock, XCircle, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import Logo from './Logo';
import AccessDenied from '@/components/AccessDenied';
import { logError } from '@/lib/logger';

interface AuthStatusCheckProps {
  children: React.ReactNode;
}

const AuthStatusCheck: React.FC<AuthStatusCheckProps> = ({ children }) => {
  const [status, setStatus] = useState<'loading' | 'approved' | 'pending' | 'rejected' | 'unauthenticated' | 'no_profile' | 'error'>('loading');
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
    // Verificar se usuário está autenticado
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      setStatus('unauthenticated');
      navigate('/');
      return;
    }

    // Buscar perfil do usuário
    const { data: profile } = await supabase
      .from('profiles')
      .select('status')
      .eq('id', user.id)
      .single();

    if (!profile) {
      setStatus('no_profile');
      return;
    }

    const profileStatus = (profile.status as 'approved' | 'pending' | 'rejected') || 'pending';
    setStatus(profileStatus);

    // Se não estiver aprovado, mostrar notificação
    if (profile.status !== 'approved') {
      // REMOVIDO: toast de "Acesso restrito"
    }
    } catch (error) {
      logError(error, { guard: 'driver' });
      setStatus('error');
    }

  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-foreground font-medium">Verificando acesso...</p>
        </div>
      </div>
    );
  }

  if (status === 'pending') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="bg-card rounded-3xl p-6 shadow-2xl max-w-md w-full border border-border">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-yellow-500/10 rounded-full flex items-center justify-center">
              <Clock size={40} className="text-yellow-500" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-center mb-2">Conta em análise</h2>
          <p className="text-center text-muted-foreground mb-6">
            Seus dados foram enviados e estão sendo analisados. Você receberá um e-mail quando sua conta for aprovada.
          </p>
          <div className="space-y-2">
            <Button variant="outline" className="w-full" onClick={handleLogout}>
              Sair
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (status === 'rejected') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="bg-card rounded-3xl p-6 shadow-2xl max-w-md w-full border border-border">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center">
              <XCircle size={40} className="text-red-500" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-center mb-2">Conta rejeitada</h2>
          <p className="text-center text-muted-foreground mb-6">
            Infelizmente, sua solicitação foi rejeitada. Entre em contato com o suporte para mais informações.
          </p>
          <div className="space-y-2">
            <Button variant="outline" className="w-full" onClick={() => navigate('/driver/support')}>
              Falar com Suporte
            </Button>
            <Button variant="destructive" className="w-full" onClick={handleLogout}>
              Sair
            </Button>
          </div>
        </div>
      </div>
    );
  }

  
  if (status === 'no_profile') {
    return (
      <AccessDenied
        title="Perfil não encontrado"
        description="Seu cadastro não está completo. Faça login novamente ou finalize seu perfil."
        goToLabel="Ir para o início"
        goToPath="/"
      />
    );
  }

  if (status === 'error') {
    return (
      <AccessDenied
        title="Não foi possível verificar seu acesso"
        description="Tente novamente. Se continuar, verifique sua conexão."
        goToLabel="Ir para o início"
        goToPath="/"
      />
    );
  }

if (status === 'unauthenticated') {
    return null;
  }

  return <>{children}</>;
};

export default AuthStatusCheck;