import { useLocation } from "react-router-dom";

function getArea(pathname: string) {
  if (pathname.startsWith("/client")) return "CLIENTE";
  if (pathname.startsWith("/driver")) return "ENTREGADOR";
  if (pathname.startsWith("/admin")) return "ADMIN";
  if (pathname.startsWith("/restaurant")) return "RESTAURANTE";
  return "GERAL";
}

export default function AreaBadge() {
  const { pathname } = useLocation();

  if (import.meta.env.PROD) return null;

  return (
    <div
      style={{
        position: "fixed",
        top: 10,
        left: 10,
        zIndex: 9999,
        padding: "6px 12px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 700,
        background: "rgba(0,0,0,0.75)",
        color: "#fff",
        border: "1px solid rgba(255,255,255,0.15)",
        backdropFilter: "blur(6px)",
      }}
    >
      {getArea(pathname)}
    </div>
  );
}
