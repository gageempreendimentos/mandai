import React from 'react';
import { AlertCircle, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ConnectionStatusProps {
  isConnected: boolean;
  onRetry: () => void;
  message?: string;
}

const ConnectionStatus: React.FC<ConnectionStatusProps> = ({ 
  isConnected, 
  onRetry,
  message = "Verifique sua conexão com a internet e tente novamente"
}) => {
  if (isConnected) return null;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="bg-card rounded-3xl p-8 shadow-2xl max-w-md w-full text-center border border-destructive/30">
        <AlertCircle size={48} className="text-destructive mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2">Sem conexão</h2>
        <p className="text-muted-foreground mb-6">
          {message}
        </p>
        <div className="flex flex-col gap-3">
          <Button 
            variant="hero" 
            size="lg" 
            className="w-full"
            onClick={onRetry}
          >
            <WifiOff size={16} className="mr-2" />
            Tentar Novamente
          </Button>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <Wifi size={16} className="text-destructive" />
            <span className="text-sm">Conexão necessária para funcionamento</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectionStatus;