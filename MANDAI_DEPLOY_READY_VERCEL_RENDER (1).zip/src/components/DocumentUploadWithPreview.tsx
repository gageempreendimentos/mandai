import React, { useState, useRef } from 'react';
import { Upload, CheckCircle, X, Eye, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

interface DocumentUploadWithPreviewProps {
  label: string;
  file: File | null;
  onChange: (file: File | null) => void;
  icon: React.ReactNode;
  accept?: string;
  maxSizeMB?: number;
  persistedFileName?: string; // Nuevo prop para el nombre de archivo guardado
}

const DocumentUploadWithPreview: React.FC<DocumentUploadWithPreviewProps> = ({
  label,
  file,
  onChange,
  icon,
  accept = "image/*,.pdf",
  maxSizeMB = 10,
  persistedFileName = '',
}) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const validateFile = (selectedFile: File): boolean => {
    setError(null);
    
    const sizeMB = selectedFile.size / 1024 / 1024;
    if (sizeMB > maxSizeMB) {
      setError(`Arquivo muito grande. Máximo: ${maxSizeMB}MB`);
      return false;
    }

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf'];
    if (!validTypes.includes(selectedFile.type)) {
      setError('Formato inválido. Use JPG, PNG ou PDF');
      return false;
    }

    return true;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!validateFile(selectedFile)) {
      return;
    }

    if (selectedFile.type.startsWith('image/')) {
      const url = URL.createObjectURL(selectedFile);
      setPreviewUrl(url);
    } else {
      setPreviewUrl(null);
    }

    onChange(selectedFile);
  };

  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setPreviewUrl(null);
    setError(null);
    onChange(null);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const handlePreview = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (file && file.type.startsWith('image/')) {
      setShowPreview(true);
    }
  };

  const isImage = file?.type.startsWith('image/');

  // Determinar qué mostrar: archivo actual, archivo persistido o instrucciones
  const showPersistedInfo = !file && persistedFileName;
  const showUploadArea = !file && !persistedFileName;
  const showFileInfo = !!file;

  return (
    <>
      <div className="space-y-2">
        <label className="block text-sm font-medium text-foreground">{label}</label>
        
        {/* Área de Upload */}
        {showUploadArea && (
          <div
            onClick={() => inputRef.current?.click()}
            className="relative flex items-center gap-3 p-4 border-2 border-dashed rounded-xl transition-all cursor-pointer hover:border-primary/50 hover:bg-primary/5"
          >
            <input
              ref={inputRef}
              type="file"
              accept={accept}
              className="hidden"
              onChange={handleFileSelect}
            />
            
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
              {icon}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">Clique para fazer upload</p>
              <p className="text-xs text-muted-foreground">JPG, PNG ou PDF até {maxSizeMB}MB</p>
            </div>
            <Upload size={20} className="text-muted-foreground flex-shrink-0" />
          </div>
        )}

        {/* Información de Archivo Persistido */}
        {showPersistedInfo && (
          <div className="relative flex items-center gap-3 p-4 border-2 border-dashed border-orange-300 bg-orange-50 rounded-xl transition-all">
            <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 flex-shrink-0">
              {icon}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-orange-800">Arquivo da sessão anterior:</p>
              <p className="text-xs text-orange-700 font-mono mt-1">{persistedFileName}</p>
              <p className="text-xs text-orange-600 mt-1">⚠️ Selecione o arquivo novamente para finalizar.</p>
            </div>
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="p-2 rounded-full bg-orange-500 text-white hover:bg-orange-600 transition-colors"
            >
              <Upload size={16} />
            </button>
            <input
              ref={inputRef}
              type="file"
              accept={accept}
              className="hidden"
              onChange={handleFileSelect}
            />
          </div>
        )}

        {/* Información del Archivo Actual */}
        {showFileInfo && (
          <div className="relative flex items-center gap-3 p-4 border-2 border-primary bg-primary/5 rounded-xl transition-all">
            <input
              ref={inputRef}
              type="file"
              accept={accept}
              className="hidden"
              onChange={handleFileSelect}
            />
            
            {isImage && previewUrl ? (
              <div className="w-14 h-14 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                <img 
                  src={previewUrl} 
                  alt="Preview" 
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              <CheckCircle className="text-primary flex-shrink-0" size={24} />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{file.name}</p>
              <p className="text-xs text-muted-foreground">
                {(file.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
            <div className="flex gap-1">
              {isImage && (
                <button
                  type="button"
                  onClick={handlePreview}
                  className="p-2 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                >
                  <Eye size={16} />
                </button>
              )}
              <button
                type="button"
                onClick={handleRemove}
                className="p-2 rounded-full bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        )}
        
        {error && (
          <div className="flex items-center gap-2 text-destructive text-sm">
            <AlertCircle size={14} />
            {error}
          </div>
        )}
      </div>

      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Pré-visualização do Documento</DialogTitle>
          </DialogHeader>
          {previewUrl && (
            <div className="relative rounded-lg overflow-hidden bg-muted">
              <img 
                src={previewUrl} 
                alt="Document preview" 
                className="w-full h-auto max-h-[70vh] object-contain"
              />
            </div>
          )}
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setShowPreview(false)}>
              Fechar
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => {
                handleRemove({} as React.MouseEvent);
                setShowPreview(false);
              }}
            >
              Remover
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default DocumentUploadWithPreview;