import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MapPin, Navigation, Circle, Truck, Package, Store, Flag } from 'lucide-react';
import ReactDOMServer from 'react-dom/server';
import { Delivery } from './DeliveryCard';
import { useDeliveryCoordinates } from '@/hooks/useDeliveryCoordinates';

// Fix para ícones do Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

interface Coordinates {
  latitude: number;
  longitude: number;
}

interface RouteMapProps {
  delivery: Delivery;
  stage: 'pickup' | 'delivering' | 'returning';
  currentLocation: Coordinates;
}

const RouteMap: React.FC<RouteMapProps> = ({ delivery, stage, currentLocation }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const [routeCoords, setRouteCoords] = useState<L.LatLngExpression[]>([]);
  const isPickupStage = stage === 'pickup';
  const isReturningStage = stage === 'returning';
  const destination = isReturningStage ? delivery.pickup : (isPickupStage ? delivery.pickup : delivery.dropoff);

  // Use o hook para obter as coordenadas de destino
  const { data: destinationCoords, isLoading: isLoadingDestination } = useDeliveryCoordinates(
    delivery.id,
    isPickupStage ? 'pickup' : 'delivery'
  );

  useEffect(() => {
    if (!currentLocation || !destinationCoords) return;

    const startPoint: L.LatLngExpression = [currentLocation.latitude, currentLocation.longitude];
    
    // destinationCoords pode ter latitude/longitude ou lat/lng
    const destLat = 'latitude' in destinationCoords ? destinationCoords.latitude : (destinationCoords as any).lat;
    const destLng = 'longitude' in destinationCoords ? destinationCoords.longitude : (destinationCoords as any).lng;
    const endPoint: L.LatLngExpression = [destLat, destLng];

    const newRouteCoords = [startPoint, endPoint];
    setRouteCoords(newRouteCoords);

    // Se o mapa já existe, atualiza a visualização e a rota
    if (mapInstanceRef.current) {
      const map = mapInstanceRef.current;
      map.setView(startPoint, 15);
      
      // Limpa camadas antigas (marcadores e polilinhas)
      map.eachLayer((layer) => {
        if (layer instanceof L.Marker || layer instanceof L.Polyline) {
          map.removeLayer(layer);
        }
      });
      
      // Adiciona os marcadores e a rota atualizados
      addMarkersAndRoute(map, startPoint, endPoint, newRouteCoords);
      return;
    }

    // Cria uma nova instância do mapa
    const map = L.map(mapRef.current!).setView(startPoint, 15);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Adiciona marcadores e rota
    addMarkersAndRoute(map, startPoint, endPoint, newRouteCoords);

    // Salva a instância do mapa
    mapInstanceRef.current = map;

    // Função de limpeza
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [currentLocation, destinationCoords]);

  const addMarkersAndRoute = (
    map: L.Map, 
    startPoint: L.LatLngExpression, 
    endPoint: L.LatLngExpression, 
    routeCoords: L.LatLngExpression[]
  ) => {
    // Ícones personalizados
    const driverIcon = L.divIcon({
      html: ReactDOMServer.renderToString(
        <div className="relative">
          <div className="absolute inset-0 w-8 h-8 -m-2 rounded-full bg-primary/30 animate-ping" />
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shadow-glow">
            <Truck size={20} className="text-primary-foreground" />
          </div>
        </div>
      ),
      className: 'leaflet-div-icon',
      iconSize: [32, 32],
      iconAnchor: [16, 32],
      popupAnchor: [0, -32],
    });

    const pickupIcon = L.divIcon({
      html: ReactDOMServer.renderToString(
        <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center shadow-lg border-2 border-white">
          <Store size={20} className="text-accent-foreground" />
        </div>
      ),
      className: 'leaflet-div-icon',
      iconSize: [40, 40],
      iconAnchor: [20, 40],
      popupAnchor: [0, -40],
    });

    const dropoffIcon = L.divIcon({
      html: ReactDOMServer.renderToString(
        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shadow-lg border-2 border-white">
          <Package size={20} className="text-primary-foreground" />
        </div>
      ),
      className: 'leaflet-div-icon',
      iconSize: [40, 40],
      iconAnchor: [20, 40],
      popupAnchor: [0, -40],
    });

    const returnIcon = L.divIcon({
      html: ReactDOMServer.renderToString(
        <div className="w-10 h-10 rounded-full bg-destructive flex items-center justify-center shadow-lg border-2 border-white">
          <Flag size={20} className="text-destructive-foreground" />
        </div>
      ),
      className: 'leaflet-div-icon',
      iconSize: [40, 40],
      iconAnchor: [20, 40],
      popupAnchor: [0, -40],
    });

    // Adiciona marcadores
    L.marker(startPoint, { icon: driverIcon })
      .addTo(map)
      .bindPopup('Sua Posição');

    const destinationIcon = isReturningStage 
      ? returnIcon 
      : isPickupStage 
        ? pickupIcon 
        : dropoffIcon;

    L.marker(endPoint, { icon: destinationIcon })
      .addTo(map)
      .bindPopup(
        isReturningStage 
          ? `Retornar para: ${delivery.pickup.name}` 
          : isPickupStage 
            ? `Coleta: ${delivery.pickup.name}` 
            : `Entrega: ${delivery.dropoff.name}`
      );

    // Adiciona polilinha (rota) com estilo melhorado
    if (routeCoords.length > 1) {
      L.polyline(routeCoords, {
        color: '#10b981',
        weight: 6,
        opacity: 0.7,
        dashArray: '10, 10',
        lineCap: 'round',
        lineJoin: 'round'
      }).addTo(map);
      
      // Adiciona uma segunda linha para criar efeito de borda
      L.polyline(routeCoords, {
        color: '#047857',
        weight: 2,
        opacity: 0.9,
        lineCap: 'round',
        lineJoin: 'round'
      }).addTo(map);
    }
  };

  if (!currentLocation || isLoadingDestination) {
    return (
      <div className="relative w-full h-full bg-gray-800 flex items-center justify-center text-white">
        <div className="text-center p-6">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-xl font-bold text-primary">Aguardando localização...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full">
      <div ref={mapRef} className="w-full h-full z-0" />
      
      {/* Minimized info card */}
      <div className="absolute top-4 left-4 right-4 z-10">
        <div className="bg-card/95 backdrop-blur-sm rounded-xl p-4 shadow-card border border-border/50">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
              isReturningStage 
                ? 'bg-destructive/10 text-destructive' 
                : isPickupStage 
                  ? 'bg-accent/10 text-accent' 
                  : 'bg-primary/10 text-primary'
            }`}>
              {isReturningStage ? (
                <Flag size={24} />
              ) : isPickupStage ? (
                <Store size={24} />
              ) : (
                <Package size={24} />
              )}
            </div>
            
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                {isReturningStage 
                  ? 'Retornar para' 
                  : (isPickupStage 
                    ? 'Retirar em' 
                    : 'Entregar para')}
              </p>
              <p className="font-semibold text-foreground truncate">{destination.name}</p>
              <p className="text-xs text-muted-foreground truncate">{destination.address}</p>
            </div>
            
            <div className="text-right flex-shrink-0">
              <p className="text-lg font-bold text-primary">{delivery.estimatedTime}</p>
              <p className="text-xs text-muted-foreground">{delivery.distance}</p>
            </div>
          </div>
          
          {/* Progress bar */}
          <div className="mt-3 pt-3 border-t border-border/50">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Progresso</span>
              <span className="font-medium">65%</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-1000 ease-out" 
                style={{ width: '65%' }}
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom status */}
      <div className="absolute bottom-4 left-4 right-4 z-10">
        <div className="bg-primary text-primary-foreground px-4 py-3 rounded-full shadow-glow inline-flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-primary-foreground animate-pulse" />
          <span className="text-sm font-medium">
            {isReturningStage 
              ? 'Retornando à loja' 
              : (isPickupStage 
                ? 'Indo buscar pedido' 
                : 'Indo entregar')}
          </span>
        </div>
      </div>
      
      {/* Navigation button */}
      <div className="absolute bottom-20 right-4 z-10">
        <button className="w-14 h-14 bg-primary rounded-full flex items-center justify-center shadow-lg hover:bg-primary/90 transition-all transform hover:scale-105 active:scale-95">
          <Navigation size={24} className="text-primary-foreground" />
        </button>
      </div>
    </div>
  );
};

export default RouteMap;