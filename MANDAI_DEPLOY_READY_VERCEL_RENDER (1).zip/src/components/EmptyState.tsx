import React from 'react';
import { Button } from '@/components/ui/button';
import type { LucideIcon } from 'lucide-react';

type Props = {
  icon: LucideIcon;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
};

export default function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
  className = '',
}: Props) {
  return (
    <div className={`text-center py-10 ${className}`}>
      <Icon className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-60" />
      <p className="text-lg font-semibold text-foreground mb-2">{title}</p>
      {description ? <p className="text-sm text-muted-foreground mb-4">{description}</p> : null}
      {actionLabel && onAction ? (
        <div className="flex justify-center">
          <Button variant="hero" onClick={onAction}>
            {actionLabel}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
