import React, { useEffect, useRef } from "react";
import maplibregl, { Map as MLMap, Marker } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import type { RideStage } from "@/state/rideState";

type Props = {
  stage?: RideStage;
};

const ROUTE_SOURCE = "mandai-route";
const ROUTE_LAYER_OUTLINE = "mandai-route-outline";
const ROUTE_LAYER_MAIN = "mandai-route-main";

export default function LiveMap({ stage = "offered" }: Props) {
  const ref = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<MLMap | null>(null);
  const markersRef = useRef<{ pickup?: Marker; drop?: Marker; driver?: Marker }>({});

  useEffect(() => {
    if (!ref.current || mapRef.current) return;

    const map = new maplibregl.Map({
      container: ref.current,
      style: "https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json",
      center: [-46.6333, -23.5505], // São Paulo (placeholder)
      zoom: 12,
      attributionControl: false,
    });

    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");

    map.on("load", () => {
      // Route preview (simple polyline) to mimic Uber/99
      if (!map.getSource(ROUTE_SOURCE)) {
        map.addSource(ROUTE_SOURCE, {
          type: "geojson",
          data: {
            type: "Feature",
            properties: {},
            geometry: { type: "LineString", coordinates: [] },
          },
        });
      }

      if (!map.getLayer(ROUTE_LAYER_OUTLINE)) {
        map.addLayer({
          id: ROUTE_LAYER_OUTLINE,
          type: "line",
          source: ROUTE_SOURCE,
          layout: { "line-cap": "round", "line-join": "round", visibility: "none" },
          paint: {
            "line-color": "rgba(0,0,0,0.30)",
            "line-width": 7,
          },
        });
      }

      if (!map.getLayer(ROUTE_LAYER_MAIN)) {
        map.addLayer({
          id: ROUTE_LAYER_MAIN,
          type: "line",
          source: ROUTE_SOURCE,
          layout: { "line-cap": "round", "line-join": "round", visibility: "none" },
          paint: {
            "line-color": "#111827",
            "line-width": 4,
            "line-opacity": 0.75,
          },
        });
      }
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Example coordinates (close to center)
    const pickup = [-46.646, -23.557] as [number, number];
    const drop = [-46.615, -23.543] as [number, number];
    const driver = [-46.632, -23.552] as [number, number];

    const makeEl = (label: string, dark: boolean) => {
      const el = document.createElement("div");
      el.style.padding = "6px 10px";
      el.style.borderRadius = "999px";
      el.style.fontSize = "12px";
      el.style.fontWeight = "600";
      el.style.boxShadow = "0 10px 25px rgba(0,0,0,.18)";
      el.style.whiteSpace = "nowrap";
      if (dark) {
        el.style.background = "#0b0b12";
        el.style.color = "#fff";
      } else {
        el.style.background = "#fff";
        el.style.color = "#0b0b12";
        el.style.border = "1px solid rgba(0,0,0,.18)";
      }
      el.textContent = label;
      return el;
    };

    const showPickup = stage === "offered" || stage === "accepted" || stage === "enroute";
    const showDrop = stage === "accepted" || stage === "enroute" || stage === "completed";
    const showDriver = stage !== "idle";

    const showRoute = showPickup && showDrop;

    const updateRoute = () => {
      const src = map.getSource(ROUTE_SOURCE) as maplibregl.GeoJSONSource | undefined;
      if (!src) return;
      src.setData({
        type: "Feature",
        properties: {},
        geometry: { type: "LineString", coordinates: showRoute ? [pickup, drop] : [] },
      } as any);

      const visibility = showRoute ? "visible" : "none";
      if (map.getLayer(ROUTE_LAYER_OUTLINE)) map.setLayoutProperty(ROUTE_LAYER_OUTLINE, "visibility", visibility);
      if (map.getLayer(ROUTE_LAYER_MAIN)) map.setLayoutProperty(ROUTE_LAYER_MAIN, "visibility", visibility);
    };

    if (map.isStyleLoaded()) updateRoute();
    else map.once("load", updateRoute);

    // pickup marker
    if (showPickup) {
      if (!markersRef.current.pickup) {
        markersRef.current.pickup = new maplibregl.Marker({ element: makeEl("Retirada", true) })
          .setLngLat(pickup)
          .addTo(map);
      }
    } else {
      markersRef.current.pickup?.remove();
      markersRef.current.pickup = undefined;
    }

    // drop marker
    if (showDrop) {
      if (!markersRef.current.drop) {
        markersRef.current.drop = new maplibregl.Marker({ element: makeEl("Destino", false) })
          .setLngLat(drop)
          .addTo(map);
      }
    } else {
      markersRef.current.drop?.remove();
      markersRef.current.drop = undefined;
    }

    // driver marker
    if (showDriver) {
      const label = stage === "enroute" ? "Em rota" : "Você";
      if (!markersRef.current.driver) {
        markersRef.current.driver = new maplibregl.Marker({ element: makeEl(label, false) })
          .setLngLat(driver)
          .addTo(map);
      } else {
        markersRef.current.driver.getElement().textContent = label;
      }
    } else {
      markersRef.current.driver?.remove();
      markersRef.current.driver = undefined;
    }

    // Fit bounds for nice view when accepted/enroute/completed
    if (stage === "accepted" || stage === "enroute" || stage === "completed") {
      const bounds = new maplibregl.LngLatBounds();
      if (showPickup) bounds.extend(pickup);
      if (showDrop) bounds.extend(drop);
      if (showDriver) bounds.extend(driver);
      map.fitBounds(bounds, { padding: 80, duration: 500 });
    }
  }, [stage]);

  return <div ref={ref} className="absolute inset-0" />;
}
