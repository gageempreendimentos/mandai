import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import type { AppRole } from "@/lib/authLite";
import { getRole, isAuthed } from "@/lib/authLite";

/**
 * Simple route guard.
 * - If the user isn't logged in (or role doesn't match), redirect to /login?role=...
 * - Preserves the target path so we can return after login (optional)
 */
export default function ProtectedRoute({
  role,
  children,
}: {
  role: AppRole;
  children: React.ReactNode;
}) {
  const location = useLocation();
  const ok = isAuthed(role) && getRole() === role;

  if (!ok) {
    const next = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/login?role=${role}&next=${next}`} replace />;
  }

  return <>{children}</>;
}
