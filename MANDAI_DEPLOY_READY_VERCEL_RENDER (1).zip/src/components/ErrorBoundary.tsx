import React from 'react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';
import { AlertTriangle, RotateCcw, Home } from 'lucide-react';
import { logError } from '@/lib/logger';

type Props = {
  children: React.ReactNode;
};

type State = {
  hasError: boolean;
  errorMessage?: string;
};

export default class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: unknown): State {
    return { hasError: true, errorMessage: error instanceof Error ? error.message : 'Erro inesperado' };
  }

  componentDidCatch(error: unknown, info: unknown) {
    logError(error, { react: 'ErrorBoundary', info });
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-6">
          <div className="w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-card">
            <div className="flex justify-center mb-4">
              <Logo />
            </div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <p className="text-lg font-semibold text-foreground">Algo deu errado</p>
                <p className="text-sm text-muted-foreground">O app encontrou um erro inesperado.</p>
              </div>
            </div>

            {this.state.errorMessage ? (
              <p className="text-sm text-muted-foreground bg-muted/50 border border-border rounded-xl p-3 mb-4">
                {this.state.errorMessage}
              </p>
            ) : null}

            <div className="flex gap-3">
              <Button className="flex-1" variant="secondary" onClick={this.handleGoHome}>
                <Home className="w-4 h-4" />
                Início
              </Button>
              <Button className="flex-1" variant="hero" onClick={this.handleReload}>
                <RotateCcw className="w-4 h-4" />
                Recarregar
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
