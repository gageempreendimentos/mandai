import React from 'react';
import { useFeatureFlag } from '@/lib/featureFlags';

type Props = {
  flag: string;
  fallback?: React.ReactNode;
  children: React.ReactNode;
};

const FeatureGate: React.FC<Props> = ({ flag, fallback = null, children }) => {
  const { enabled, isLoading } = useFeatureFlag(flag, false);

  if (isLoading) return fallback;
  if (!enabled) return fallback;

  return <>{children}</>;
};

export default FeatureGate;
