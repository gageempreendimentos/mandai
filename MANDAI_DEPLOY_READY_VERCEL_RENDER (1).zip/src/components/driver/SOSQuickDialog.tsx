import React, { useMemo, useState } from 'react';
import { AlertTriangle, Phone, MapPin, XCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import LoadingButton from '@/components/LoadingButton';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { logError, logInfo } from '@/lib/logger';

type Preset = {
  key: string;
  title: string;
  message: string;
  icon: React.ComponentType<any>;
};

interface Props {
  deliveryId: string;
  className?: string;
}

/**
 * One-tap SOS: creates a dispute/ticket with a preset reason.
 */
const SOSQuickDialog: React.FC<Props> = ({ deliveryId, className }) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Preset | null>(null);
  const [note, setNote] = useState('');

  const presets = useMemo<Preset[]>(
    () => [
      {
        key: 'no_answer',
        title: 'Cliente não atende',
        message: 'Estou no local e o cliente não atende. Preciso de orientação.',
        icon: Phone,
      },
      {
        key: 'wrong_address',
        title: 'Endereço errado',
        message: 'O endereço informado parece incorreto. Solicito confirmação/atualização.',
        icon: MapPin,
      },
      {
        key: 'restaurant_closed',
        title: 'Restaurante fechado',
        message: 'Cheguei para coletar e o restaurante está fechado/indisponível.',
        icon: XCircle,
      },
      {
        key: 'incident',
        title: 'Acidente / imprevisto',
        message: 'Tive um imprevisto durante a rota. Preciso de suporte imediato.',
        icon: AlertTriangle,
      },
    ],
    []
  );

  const submit = async () => {
    if (!selected) return;
    try {
      setLoading(true);
      const {
        data: { user },
      } = await supabase.auth.getUser();

      const subject = selected.title;
      const message = [selected.message, note.trim() ? `Obs: ${note.trim()}` : '']
        .filter(Boolean)
        .join('\n');

      const { data: dispute, error: dErr } = await supabase
        .from('delivery_disputes' as any)
        .insert({
          delivery_id: deliveryId,
          created_by: user?.id ?? null,
          created_role: 'driver',
          subject,
          status: 'open',
        })
        .select('id')
        .single();

      if (dErr) throw dErr;

      const { error: mErr } = await supabase
        .from('delivery_dispute_messages' as any)
        .insert({
          dispute_id: dispute.id,
          sender_id: user?.id ?? null,
          message,
        });

      if (mErr) throw mErr;

      logInfo('SOSQuickDialog.created', {
        deliveryId,
        disputeId: dispute.id,
        preset: selected.key,
      });

      toast({
        title: 'SOS enviado',
        description: 'O admin/suporte foi notificado e verá o ticket no painel.',
      });
      setNote('');
      setSelected(null);
      setOpen(false);
    } catch (e: any) {
      logError('SOSQuickDialog.submit', e);
      toast({
        title: 'Erro',
        description: e.message || 'Não foi possível enviar agora',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="destructive" className={className}>
          <AlertTriangle className="w-4 h-4 mr-2" />
          SOS
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Problema rápido (SOS)</DialogTitle>
          <DialogDescription>
            Toque em uma opção para criar um ticket. O admin pode reatribuir/ajudar imediatamente.
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {presets.map((p) => {
            const Icon = p.icon;
            const active = selected?.key === p.key;
            return (
              <button
                key={p.key}
                type="button"
                onClick={() => setSelected(p)}
                className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-colors ${
                  active ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted'
                }`}
              >
                <div className="w-9 h-9 rounded-full bg-destructive/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-destructive" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold">{p.title}</div>
                  <div className="text-xs text-muted-foreground">{p.message}</div>
                </div>
              </button>
            );
          })}
        </div>

        <Textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Observações (opcional)"
          rows={3}
        />

        <LoadingButton onClick={submit} loading={loading} disabled={!selected}>
          Enviar SOS
        </LoadingButton>
      </DialogContent>
    </Dialog>
  );
};

export default SOSQuickDialog;
