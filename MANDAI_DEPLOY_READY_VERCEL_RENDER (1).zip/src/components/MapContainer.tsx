import React from 'react';
import { MapPin, Navigation, ZoomIn, ZoomOut, Locate } from 'lucide-react';

interface MapContainerProps {
  children: React.ReactNode;
  className?: string;
  onZoomIn?: () => void;
  onZoomOut?: () => void;
  onLocate?: () => void;
  showControls?: boolean;
}

const MapContainer: React.FC<MapContainerProps> = ({ 
  children, 
  className = '',
  onZoomIn,
  onZoomOut,
  onLocate,
  showControls = true
}) => {
  return (
    <div className={`relative w-full h-full ${className}`}>
      {children}
      
      {/* Location info */}
      <div className="absolute top-4 left-4 z-10 bg-card/95 backdrop-blur-sm rounded-xl p-3 shadow-card border border-border/50">
        <div className="flex items-center gap-2 text-sm">
          <MapPin size={16} className="text-primary" />
          <span className="font-medium">Localização em tempo real</span>
        </div>
      </div>
      
      {/* Map controls */}
      {showControls && (
        <div className="absolute bottom-24 right-4 z-10 flex flex-col gap-2">
          <button 
            className="w-12 h-12 bg-card rounded-full flex items-center justify-center shadow-lg hover:bg-muted transition-colors border border-border"
            onClick={onLocate}
          >
            <Locate size={20} className="text-foreground" />
          </button>
          <button 
            className="w-12 h-12 bg-card rounded-full flex items-center justify-center shadow-lg hover:bg-muted transition-colors border border-border"
            onClick={onZoomIn}
          >
            <ZoomIn size={20} className="text-foreground" />
          </button>
          <button 
            className="w-12 h-12 bg-card rounded-full flex items-center justify-center shadow-lg hover:bg-muted transition-colors border border-border"
            onClick={onZoomOut}
          >
            <ZoomOut size={20} className="text-foreground" />
          </button>
        </div>
      )}
      
      {/* Navigation button */}
      <div className="absolute bottom-4 right-4 z-10">
        <button className="w-14 h-14 bg-primary rounded-full flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors">
          <Navigation size={24} className="text-primary-foreground" />
        </button>
      </div>
    </div>
  );
};

export default MapContainer;