import React, { useState, useEffect } from 'react';
import { Navigation, MessageCircle, Star, Check } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface NavigationButtonsProps {
  address: string;
}

type NavApp = 'mandaigle' | 'waze';

const NavigationButtons: React.FC<NavigationButtonsProps> = ({ address }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [favorite, setFavorite] = useState<NavApp | null>(null);
  const encodedAddress = encodeURIComponent(address);

  useEffect(() => {
    const saved = localStorage.getItem('favoriteNavApp');
    if (saved === 'mandaigle' || saved === 'waze') {
      setFavorite(saved);
    }
  }, []);

  const openMandaigleMaps = () => {
    window.open(`https://www.mandaigle.com/maps/dir/?api=1&destination=${encodedAddress}`, '_blank');
    setIsOpen(false);
  };

  const openWaze = () => {
    window.open(`https://waze.com/ul?q=${encodedAddress}&navigate=yes`, '_blank');
    setIsOpen(false);
  };

  const openSupport = () => {
    window.open('/driver/support', '_blank');
  };

  const handleNavClick = () => {
    if (favorite === 'mandaigle') {
      openMandaigleMaps();
    } else if (favorite === 'waze') {
      openWaze();
    } else {
      setIsOpen(true);
    }
  };

  const setFavoriteApp = (app: NavApp) => {
    setFavorite(app);
    localStorage.setItem('favoriteNavApp', app);
  };

  const removeFavorite = () => {
    setFavorite(null);
    localStorage.removeItem('favoriteNavApp');
  };

  return (
    <>
      <div className="flex justify-between items-center gap-2">
        {/* Suporte - Lado Esquerdo */}
        <button
          onClick={openSupport}
          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-green-600 text-white hover:bg-green-700 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
        >
          <MessageCircle size={16} />
          <span className="font-semibold text-sm">Suporte</span>
        </button>

        {/* Navegar - Lado Direito */}
        <button
          onClick={handleNavClick}
          className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
        >
          <Navigation size={16} />
          <span className="font-semibold text-sm">Navegar</span>
          {favorite && <Star size={12} className="fill-current" />}
        </button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-center">Escolha o navegador</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-3 py-4">
            <button
              onClick={openMandaigleMaps}
              className="w-full flex items-center gap-3 p-4 rounded-xl border border-border hover:border-blue-500 hover:bg-blue-500/5 transition-all"
            >
              <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Navigation size={24} className="text-blue-500" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-semibold text-foreground">Mandaigle Maps</p>
                <p className="text-sm text-muted-foreground">Navegação Mandaigle</p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (favorite === 'mandaigle') {
                    removeFavorite();
                  } else {
                    setFavoriteApp('mandaigle');
                  }
                }}
                className={`p-2 rounded-full transition-colors ${
                  favorite === 'mandaigle' 
                    ? 'bg-yellow-500/20 text-yellow-500' 
                    : 'hover:bg-muted text-muted-foreground'
                }`}
              >
                <Star size={20} className={favorite === 'mandaigle' ? 'fill-current' : ''} />
              </button>
            </button>

            <button
              onClick={openWaze}
              className="w-full flex items-center gap-3 p-4 rounded-xl border border-border hover:border-cyan-500 hover:bg-cyan-500/5 transition-all"
            >
              <div className="w-12 h-12 rounded-full bg-cyan-500/10 flex items-center justify-center">
                <Navigation size={24} className="text-cyan-500" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-semibold text-foreground">Waze</p>
                <p className="text-sm text-muted-foreground">Navegação Waze</p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (favorite === 'waze') {
                    removeFavorite();
                  } else {
                    setFavoriteApp('waze');
                  }
                }}
                className={`p-2 rounded-full transition-colors ${
                  favorite === 'waze' 
                    ? 'bg-yellow-500/20 text-yellow-500' 
                    : 'hover:bg-muted text-muted-foreground'
                }`}
              >
                <Star size={20} className={favorite === 'waze' ? 'fill-current' : ''} />
              </button>
            </button>
          </div>

          {favorite && (
            <p className="text-center text-xs text-muted-foreground pb-2">
              <Check size={12} className="inline mr-1" />
              {favorite === 'mandaigle' ? 'Mandaigle Maps' : 'Waze'} é seu favorito
            </p>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default NavigationButtons;