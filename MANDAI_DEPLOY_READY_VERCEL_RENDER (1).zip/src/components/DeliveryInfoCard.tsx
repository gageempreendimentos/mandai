import React, { memo } from 'react';
import { MapPin, Clock, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface DeliveryInfoCardProps {
  pickup: {
    name: string;
    address: string;
  };
  dropoff: {
    name: string;
    address: string;
  };
  distance: string;
  estimatedTime: string;
  value: number;
  onAccept?: () => void;
  onReject?: () => void;
  showActions?: boolean;
}

const DeliveryInfoCard: React.FC<DeliveryInfoCardProps> = memo(({
  pickup,
  dropoff,
  distance,
  estimatedTime,
  value,
  onAccept,
  onReject,
  showActions = false
}) => {
  return (
    <div className="bg-card rounded-2xl p-5 shadow-card border border-border/50">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-accent rounded-xl flex items-center justify-center">
            <DollarSign size={20} className="text-accent-foreground" />
          </div>
          <div>
            <span className="text-2xl font-bold text-foreground">
              R$ {value.toFixed(2)}
            </span>
            <p className="text-xs text-muted-foreground">Valor da entrega</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-muted-foreground text-sm">
          <Clock size={14} />
          <span>{estimatedTime}</span>
        </div>
      </div>

      <div className="space-y-3 mb-4">
        <div className="flex gap-3">
          <div className="flex flex-col items-center">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <div className="w-0.5 h-8 bg-border" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Retirada</p>
            <p className="font-semibold text-foreground">{pickup.name}</p>
            <p className="text-sm text-muted-foreground">{pickup.address}</p>
          </div>
        </div>

        <div className="flex gap-3">
          <div className="flex flex-col items-center">
            <div className="w-3 h-3 rounded-full bg-accent" />
          </div>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground uppercase tracking-wide">Entrega</p>
            <p className="font-semibold text-foreground">{dropoff.name}</p>
            <p className="text-sm text-muted-foreground">{dropoff.address}</p>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-5">
        <MapPin size={14} />
        <span>{distance} de distância</span>
      </div>

      {showActions && (
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="flex-1" 
            onClick={onReject}
          >
            Recusar
          </Button>
          <Button 
            variant="hero" 
            className="flex-1" 
            onClick={onAccept}
          >
            Aceitar
          </Button>
        </div>
      )}
    </div>
  );
});

DeliveryInfoCard.displayName = 'DeliveryInfoCard';

export default DeliveryInfoCard;