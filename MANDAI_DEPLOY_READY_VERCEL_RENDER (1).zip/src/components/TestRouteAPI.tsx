import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { calculateRouteFromAddresses, geocodeAddress } from '@/lib/routeCalculator';
import { useToast } from '@/hooks/use-toast';
import { MapPin, Route, Clock, AlertCircle, CheckCircle } from 'lucide-react';

const TestRouteAPI: React.FC = () => {
  const { toast } = useToast();
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<any>(null);

  const testAPI = async () => {
    setTesting(true);
    setResult(null);

    try {
      // Teste 1: Geocoding
      toast({ title: "Testando geocoding...", description: "Convertendo endereço em coordenadas" });
      
      const pickupCoords = await geocodeAddress('Rua das Flores, 123, São Paulo, SP');
      const dropoffCoords = await geocodeAddress('Av. Paulista, 1000, São Paulo, SP');

      if (!pickupCoords || !dropoffCoords) {
        throw new Error('Falha no geocoding');
      }

      // Teste 2: Cálculo de rota
      toast({ title: "Testando roteirização...", description: "Calculando rota com OpenRouteService" });
      
      const route = await calculateRouteFromAddresses(
        'Rua das Flores, 123, São Paulo, SP',
        'Av. Paulista, 1000, São Paulo, SP'
      );

      if (!route) {
        throw new Error('Falha no cálculo de rota');
      }

      setResult({
        pickupCoords,
        dropoffCoords,
        route,
        success: true,
      });

      toast({
        title: "✅ API funcionando!",
        description: `Rota calculada: ${route.distance}km em ${route.duration}min`,
      });
    } catch (error: any) {
      console.error('Erro no teste:', error);
      
      setResult({
        success: false,
        error: error.message,
      });

      toast({
        title: "❌ Erro na API",
        description: error.message || 'Verifique a API Key',
        variant: "destructive",
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Route size={18} className="text-primary" />
          Testar API OpenRouteService
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-muted-foreground">
          <p>API Key configurada: {import.meta.env.VITE_OPENROUTESERVICE_API_KEY ? '✅ Sim' : '❌ Não'}</p>
          <p className="mt-1">Teste com endereços de São Paulo</p>
        </div>

        <Button
          onClick={testAPI}
          disabled={testing}
          className="w-full"
        >
          {testing ? 'Testando...' : 'Testar API'}
        </Button>

        {result && (
          <div className="space-y-3">
            {result.success ? (
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle size={20} className="text-green-600" />
                  <span className="font-medium text-green-700">API funcionando corretamente!</span>
                </div>
                
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="bg-white/50 rounded-lg p-3">
                    <p className="text-xs text-muted-foreground">Distância</p>
                    <p className="text-lg font-bold text-primary">{result.route.distance} km</p>
                  </div>
                  <div className="bg-white/50 rounded-lg p-3">
                    <p className="text-xs text-muted-foreground">Tempo</p>
                    <p className="text-lg font-bold text-accent">{result.route.duration} min</p>
                  </div>
                </div>

                <div className="mt-3 text-xs text-muted-foreground">
                  <p><strong>De:</strong> {result.pickupCoords.lat.toFixed(6)}, {result.pickupCoords.lng.toFixed(6)}</p>
                  <p><strong>Para:</strong> {result.dropoffCoords.lat.toFixed(6)}, {result.dropoffCoords.lng.toFixed(6)}</p>
                </div>
              </div>
            ) : (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
                <div className="flex items-center gap-2">
                  <AlertCircle size={20} className="text-red-600" />
                  <span className="font-medium text-red-700">Erro na API</span>
                </div>
                <p className="text-sm text-red-600 mt-2">{result.error}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TestRouteAPI;