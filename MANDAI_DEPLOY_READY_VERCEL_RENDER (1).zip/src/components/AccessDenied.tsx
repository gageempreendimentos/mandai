import React from 'react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';
import { ShieldAlert, LogOut, ArrowRight } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';

type Props = {
  title: string;
  description?: string;
  goToLabel?: string;
  goToPath?: string;
  showLogout?: boolean;
};

export default function AccessDenied({
  title,
  description,
  goToLabel = 'Ir para o início',
  goToPath = '/',
  showLogout = true,
}: Props) {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
    } finally {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-card">
        <div className="flex justify-center mb-4">
          <Logo />
        </div>

        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
            <ShieldAlert className="w-5 h-5 text-destructive" />
          </div>
          <div>
            <p className="text-lg font-semibold text-foreground">{title}</p>
            {description ? <p className="text-sm text-muted-foreground mt-1">{description}</p> : null}
          </div>
        </div>

        <div className="flex gap-3">
          <Button className="flex-1" variant="hero" onClick={() => navigate(goToPath)}>
            <ArrowRight className="w-4 h-4" />
            {goToLabel}
          </Button>
          {showLogout ? (
            <Button className="flex-1" variant="secondary" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          ) : null}
        </div>
      </div>
    </div>
  );
}
