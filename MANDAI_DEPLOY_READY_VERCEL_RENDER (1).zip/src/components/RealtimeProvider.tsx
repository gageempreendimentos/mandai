import React, { useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface RealtimeProviderProps {
  children: React.ReactNode;
}

export const RealtimeProvider: React.FC<RealtimeProviderProps> = ({ children }) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    // Canal para entregas (entregadores)
    const deliveriesChannel = supabase
      .channel('deliveries-channel')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'deliveries',
          filter: 'status=eq.pending',
        },
        async (payload) => {
          console.log('📡 Nova entrega via realtime:', payload.new);
          
          queryClient.invalidateQueries({ queryKey: ['deliveries', 'available'] });
          
          toast({
            title: "Nova entrega disponível! 🚀",
            description: `R$ ${((payload.new as any).value || 0).toFixed(2)}`,
            duration: 5000,
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'deliveries',
        },
        (payload) => {
          console.log('📡 Entrega atualizada via realtime:', payload.new);
          
          queryClient.invalidateQueries({ queryKey: ['deliveries'] });
          
          supabase.auth.getUser().then(({ data: { user } }) => {
            const newData = payload.new as any;
            if (user && newData.driver_id === user.id) {
              if (['delivered', 'not_delivered', 'cancelled'].includes(newData.status)) {
                toast({
                  title: "Status atualizado",
                  description: `Entrega: ${newData.status}`,
                  duration: 3000,
                });
              }
            }
          });
        }
      )
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          console.log('✅ Conectado ao canal de entregas');
        }
      });

    return () => {
      supabase.removeChannel(deliveriesChannel);
    };
  }, [queryClient, toast]);

  return <>{children}</>;
};
