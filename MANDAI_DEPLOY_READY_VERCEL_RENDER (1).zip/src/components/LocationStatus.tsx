import React from 'react';
import { MapPin, AlertCircle, Loader2, CheckCircle } from 'lucide-react';

interface LocationStatusProps {
  location: { latitude: number; longitude: number } | null;
  accuracy: number | null;
  isLoading: boolean;
  error: any;
  isSupported: boolean;
}

const LocationStatus: React.FC<LocationStatusProps> = ({
  location,
  accuracy,
  isLoading,
  error,
  isSupported,
}) => {
  if (!isSupported) {
    return (
      <div className="flex items-center gap-2 text-red-600 bg-red-500/10 rounded-full px-3 py-1.5">
        <AlertCircle size={14} />
        <span className="text-sm font-medium">Geolocalização não suportada</span>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 text-yellow-600 bg-yellow-500/10 rounded-full px-3 py-1.5">
        <Loader2 size={14} className="animate-spin" />
        <span className="text-sm font-medium">Obtendo localização...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center gap-2 text-red-600 bg-red-500/10 rounded-full px-3 py-1.5">
        <AlertCircle size={14} />
        <span className="text-sm font-medium">
          {error.code === 1 ? 'Permissão negada' : 'Erro ao obter localização'}
        </span>
      </div>
    );
  }

  if (location) {
    return (
      <div className="flex items-center gap-2 text-green-600 bg-green-500/10 rounded-full px-3 py-1.5">
        <CheckCircle size={14} />
        <span className="text-sm font-medium">
          {accuracy ? `Precisão: ${Math.round(accuracy)}m` : 'Localizado'}
        </span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 text-gray-500 bg-gray-500/10 rounded-full px-3 py-1.5">
      <MapPin size={14} />
      <span className="text-sm font-medium">Aguardando localização</span>
    </div>
  );
};

export default LocationStatus;