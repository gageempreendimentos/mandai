import React, { memo } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Headphones, User, History, LogOut, Wallet, BarChart3, Settings } from 'lucide-react';
import Logo from './Logo';
import ThemeToggle from './ThemeToggle';
import PwaInstallButton from '@/components/PwaInstallButton';
import { supabase } from '@/integrations/supabase/client';
import { logout as liteLogout } from '@/lib/authLite';

interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const SideMenu: React.FC<SideMenuProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try { await supabase.auth.signOut(); } catch {}
    try { liteLogout(); } catch {}
    navigate('/');
    onClose();
  };

  const menuItems = [
    { icon: History, label: 'Histórico', onClick: () => navigate('/driver/history') },
    { icon: BarChart3, label: 'Desempenho', onClick: () => navigate('/driver/performance') },
    { icon: Wallet, label: 'Financeiro', onClick: () => navigate('/driver/financial') },
    { icon: Headphones, label: 'Suporte', onClick: () => navigate('/driver/support') },
    { icon: User, label: 'Perfil', onClick: () => navigate('/driver/profile') },
    { icon: Settings, label: 'Configurações', onClick: () => navigate('/driver/settings') },
  ];

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 z-40 animate-fade-in"
        onClick={onClose}
      />
      
      {/* Menu */}
      <div className="fixed top-0 left-0 h-full w-3/4 max-w-xs bg-card z-50 shadow-2xl animate-slide-in-left flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <Logo size="md" variant="dashboard" />
          <div className="flex items-center gap-2">
            <ThemeToggle />
            
            <div className="mb-3">
  <PwaInstallButton />
</div>

<button 
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
          >
            <X size={20} className="text-foreground" />
          </button>
          </div>
        </div>

        {/* Menu Items */}
        <nav className="flex-1 p-4 overflow-auto">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.label}>
                <button
                  onClick={() => {
                    item.onClick();
                    onClose();
                  }}
                  className="w-full flex items-center gap-4 p-4 rounded-xl hover:bg-muted transition-colors text-left"
                >
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <item.icon size={20} className="text-primary" />
                  </div>
                  <span className="text-foreground font-medium">{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"
          >
            <LogOut size={18} />
            <span className="font-medium">Sair</span>
          </button>
          <p className="text-xs text-muted-foreground text-center mt-4">
            MANDAI © 2025
          </p>
        </div>
      </div>
    </>
  );
};

export default memo(SideMenu);