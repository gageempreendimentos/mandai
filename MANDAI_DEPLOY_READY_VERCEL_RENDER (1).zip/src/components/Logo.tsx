import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { useTheme } from 'next-themes';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  variant?: 'login' | 'dashboard' | 'splash';
  /** Subtle premium animation (recommended for splash/login) */
  animated?: boolean;
}

const Logo: React.FC<LogoProps> = ({
  size = 'md',
  showText = true,
  variant = 'dashboard',
  animated = variant === 'splash' || variant === 'login',
}) => {
  const reduceMotion = useReducedMotion();
  const { theme } = useTheme();

  const containerSizes = {
    sm: 'gap-2',
    md: 'gap-3',
    lg: 'gap-4',
    xl: 'gap-4',
  };

  const iconSizes = {
    sm: 'w-12 h-12',
    md: 'w-16 h-16',
    lg: 'w-24 h-24',
    xl: 'w-44 h-14',
  };

  // Single source of truth: same mark used on splash + all pages
  const imageSrc = '/mandai-black.svg';

  // If the app is in dark mode, invert the mark so it stays visible while keeping the same file.
  const isDark = theme === 'dark';
  const imgClass = `${iconSizes[size]} object-contain ${isDark ? 'invert' : ''}`;

  const Img = animated && !reduceMotion ? motion.img : 'img';
  const Wrap = animated && !reduceMotion ? motion.div : 'div';

  const wrapProps =
    animated && !reduceMotion
      ? {
          initial: { opacity: 0, y: 6, scale: 0.98 },
          animate: { opacity: 1, y: 0, scale: 1 },
          transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] },
        }
      : {};

  const imgProps =
    animated && !reduceMotion
      ? {
          initial: { opacity: 0, scale: 0.95 },
          animate: { opacity: 1, scale: 1 },
          transition: { delay: 0.06, duration: 0.45, ease: [0.22, 1, 0.36, 1] },
        }
      : {};

  return (
    <Wrap className={`flex items-center ${containerSizes[size]}`} {...wrapProps}>
      <Img src={imageSrc} alt="MANDAI" className={imgClass} {...imgProps} />
      {showText && variant !== 'splash' ? (
        <span className="text-xl font-extrabold tracking-tight">MANDAI</span>
      ) : null}
    </Wrap>
  );
};

export default Logo;
