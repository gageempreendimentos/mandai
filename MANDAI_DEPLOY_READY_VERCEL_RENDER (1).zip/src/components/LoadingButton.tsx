import React from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

type ButtonProps = React.ComponentProps<typeof Button>;

type Props = ButtonProps & {
  loading?: boolean;
};

export default function LoadingButton({ loading, children, disabled, ...props }: Props) {
  return (
    <Button disabled={disabled || loading} {...props}>
      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
      {children}
    </Button>
  );
}
