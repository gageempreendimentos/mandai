import React from "react";

export default function BrandLogo({ size = 56 }: { size?: number }) {
  return (
    <img
      src="/logo-mandai.svg"
      alt="MANDAI"
      width={size}
      height={size}
      style={{ width: size, height: size, objectFit: "contain" }}
    />
  );
}
