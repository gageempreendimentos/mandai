import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

interface DeliveryTimerProps {
  distanceKm: number;
  isActive: boolean;
  onTimeUp: () => void;
}

const DeliveryTimer: React.FC<DeliveryTimerProps> = ({ distanceKm, isActive, onTimeUp }) => {
  // Calculate time: 2 minutes per km, minimum 5 minutes, maximum 20 minutes
  const calculateMinutes = () => {
    const calculated = Math.round(distanceKm * 2);
    return Math.min(Math.max(calculated, 5), 20);
  };

  const [timeLeft, setTimeLeft] = useState(calculateMinutes() * 60);
  const totalTime = calculateMinutes() * 60;

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          onTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, onTimeUp]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progress = (timeLeft / totalTime) * 100;

  const getStatusColor = () => {
    if (progress > 50) return 'text-primary';
    if (progress > 25) return 'text-yellow-500';
    return 'text-destructive';
  };

  const getProgressColor = () => {
    if (progress > 50) return 'bg-primary';
    if (progress > 25) return 'bg-yellow-500';
    return 'bg-destructive';
  };

  return (
    <div className="bg-card/95 backdrop-blur-sm rounded-xl p-3 border border-border/50 mb-3">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Clock size={16} className={getStatusColor()} />
          <span className="text-sm text-muted-foreground">Tempo para entrega</span>
        </div>
        <span className={`text-lg font-bold ${getStatusColor()}`}>
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <div 
          className={`h-full ${getProgressColor()} transition-all duration-1000 ease-linear`}
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};

export default DeliveryTimer;