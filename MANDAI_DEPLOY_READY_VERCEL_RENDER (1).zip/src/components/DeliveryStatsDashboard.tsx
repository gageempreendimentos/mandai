import React from 'react';
import { Trophy, TrendingUp, Target, Award, Star, Zap, Clock, MapPin, Gift } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

interface DeliveryStats {
  totalDeliveries: number;
  completedDeliveries: number;
  onTimeDeliveries: number;
  averageRating: number;
  totalEarnings: number;
  hoursOnline: number;
  efficiencyScore: number;
  level: number;
  nextLevelProgress: number;
  achievements: string[];
}

interface DeliveryStatsDashboardProps {
  stats: DeliveryStats;
}

const DeliveryStatsDashboard: React.FC<DeliveryStatsDashboardProps> = ({ stats }) => {
  const getLevelTitle = (level: number) => {
    const titles = ['Iniciante', 'Entregador', 'Profissional', 'Mestre', 'Lenda'];
    return titles[Math.min(level - 1, titles.length - 1)] || 'Iniciante';
  };

  const getLevelColor = (level: number) => {
    const colors = ['text-gray-500', 'text-blue-500', 'text-green-500', 'text-purple-500', 'text-yellow-500'];
    return colors[Math.min(level - 1, colors.length - 1)] || 'text-gray-500';
  };

  return (
    <div className="space-y-6">
      {/* Nível e Progresso */}
      <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Trophy className="text-primary" />
            Seu Nível
          </CardTitle>
          <Badge variant="secondary" className="text-lg">
            <span className={getLevelColor(stats.level)}>Nível {stats.level} - {getLevelTitle(stats.level)}</span>
          </Badge>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Progresso para o próximo nível</span>
                <span>{stats.nextLevelProgress}%</span>
              </div>
              <Progress value={stats.nextLevelProgress} className="h-2" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-card p-3 rounded-lg border">
                <p className="text-xs text-muted-foreground">Entregas para próximo nível</p>
                <p className="font-bold text-lg">12</p>
              </div>
              <div className="bg-card p-3 rounded-lg border">
                <p className="text-xs text-muted-foreground">Bônus disponível</p>
                <p className="font-bold text-lg text-green-500">R$ 25</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estatísticas Principais */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-card hover:bg-muted/50 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <TrendingUp className="text-green-500" size={20} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Entregas</p>
                <p className="font-bold text-lg">{stats.completedDeliveries}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card hover:bg-muted/50 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Star className="text-blue-500" size={20} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Avaliação</p>
                <p className="font-bold text-lg">{stats.averageRating}/5</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card hover:bg-muted/50 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Zap className="text-purple-500" size={20} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Eficiência</p>
                <p className="font-bold text-lg">{stats.efficiencyScore}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card hover:bg-muted/50 transition-colors">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-orange-500/10 flex items-center justify-center">
                <Target className="text-orange-500" size={20} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">No Prazo</p>
                <p className="font-bold text-lg">
                  {stats.onTimeDeliveries}/{stats.completedDeliveries}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Conquistas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="text-primary" />
            Suas Conquistas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            {stats.achievements.map((achievement, index) => (
              <div 
                key={index} 
                className="bg-card border rounded-lg p-3 text-center hover:bg-muted/50 transition-colors cursor-pointer"
              >
                <div className="w-8 h-8 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-2">
                  <Star className="text-yellow-500" size={16} />
                </div>
                <p className="text-xs font-medium">{achievement}</p>
              </div>
            ))}
            <div className="bg-muted/50 border-2 border-dashed rounded-lg p-3 text-center">
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center mx-auto mb-2">
                <Star className="text-muted-foreground" size={16} />
              </div>
              <p className="text-xs text-muted-foreground">Mais em breve</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recompensas */}
      <Card className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gift className="text-green-500" />
            Recompensas Disponíveis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-card rounded-lg border">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                  <Trophy className="text-green-500" size={20} />
                </div>
                <div>
                  <p className="font-medium">Entregador do Mês</p>
                  <p className="text-xs text-muted-foreground">Complete 50 entregas este mês</p>
                </div>
              </div>
              <Badge variant="secondary">R$ 100</Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-card rounded-lg border">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Clock className="text-blue-500" size={20} />
                </div>
                <div>
                  <p className="font-medium">Pontualidade 100%</p>
                  <p className="text-xs text-muted-foreground">10 entregas no prazo</p>
                </div>
              </div>
              <Badge variant="secondary">R$ 30</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DeliveryStatsDashboard;