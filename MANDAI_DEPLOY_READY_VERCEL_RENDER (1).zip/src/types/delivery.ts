import type { Tables } from '@/integrations/supabase/types';

// Define a base type for coordinates
export interface Coordinates {
  lat: number;
  lng: number;
}

// Define the structure for pickup and dropoff locations
export interface LocationDetails {
  name: string;
  address: string;
  phone?: string; // Optional phone for dropoff
  coordinates?: Coordinates;
}

// Extend the auto-generated 'deliveries' table type with application-specific fields
export interface Delivery extends Tables<'deliveries'> {
  pickup: LocationDetails;
  dropoff: LocationDetails;
  distance: string; // Formatted distance string (e.g., "3.2 km")
  estimatedTime: string; // Formatted time string (e.g., "15 min")
  value: number; // Ensure value is always a number
}