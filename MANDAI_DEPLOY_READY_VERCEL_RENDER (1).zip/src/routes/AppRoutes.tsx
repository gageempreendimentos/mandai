import React, { Suspense, lazy } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import RouteFallback from "@/components/RouteFallback";
import ProtectedRoute from "@/components/ProtectedRoute";

// Lazy pages
const Entry = lazy(() => import("@/pages/Entry"));
const Login = lazy(() => import("@/pages/Login"));

// Driver
const DriverArea = lazy(() => import("@/pages/DashboardReal"));
const HistoryPage = lazy(() => import("@/pages/History"));
const PerformancePage = lazy(() => import("@/pages/Performance"));
const FinancialPage = lazy(() => import("@/pages/Financial"));
const SupportPage = lazy(() => import("@/pages/Support"));
const ProfilePage = lazy(() => import("@/pages/Profile"));
const SettingsPage = lazy(() => import("@/pages/Settings"));

// Other areas
const ClientArea = lazy(() => import("@/pages/ClientDashboard"));
const AdminArea = lazy(() => import("@/pages/admin/AdminDashboard"));
const RestaurantArea = lazy(() => import("@/pages/RestaurantDashboard"));

const NotFound = lazy(() => import("@/pages/NotFound"));

export default function AppRoutes() {
  return (
    <Suspense fallback={<RouteFallback />}>
      <Routes>
        {/* Entry */}
        <Route path="/" element={<Navigate to="/entry" replace />} />
        <Route path="/entry" element={<Entry />} />

        {/* Login */}
        <Route path="/login" element={<Login />} />

        {/* Driver */}
        <Route
          path="/driver"
          element={
            <ProtectedRoute role="driver">
              <DriverArea />
            </ProtectedRoute>
          }
        />
        <Route path="/dashboard" element={<Navigate to="/driver" replace />} />

        <Route
          path="/driver/history"
          element={
            <ProtectedRoute role="driver">
              <HistoryPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/driver/performance"
          element={
            <ProtectedRoute role="driver">
              <PerformancePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/driver/financial"
          element={
            <ProtectedRoute role="driver">
              <FinancialPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/driver/support"
          element={
            <ProtectedRoute role="driver">
              <SupportPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/driver/profile"
          element={
            <ProtectedRoute role="driver">
              <ProfilePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/driver/settings"
          element={
            <ProtectedRoute role="driver">
              <SettingsPage />
            </ProtectedRoute>
          }
        />

        {/* Admin */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute role="admin">
              <AdminArea />
            </ProtectedRoute>
          }
        />

        {/* Restaurant */}
        <Route
          path="/restaurant"
          element={
            <ProtectedRoute role="restaurant">
              <RestaurantArea />
            </ProtectedRoute>
          }
        />

        {/* Client */}
        <Route
          path="/client"
          element={
            <ProtectedRoute role="client">
              <ClientArea />
            </ProtectedRoute>
          }
        />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
