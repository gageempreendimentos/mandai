import React, { Suspense } from "react";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";

import CrisisBanner from "@/components/CrisisBanner";
import OfflineBanner from "@/components/OfflineBanner";
import RouteFallback from "@/components/RouteFallback";
import AreaBadge from "@/components/AreaBadge";
import AppRoutes from "@/routes/AppRoutes";
import { ThemeProvider } from "@/providers/ThemeProvider";
import { RealtimeProvider } from "@/components/RealtimeProvider";

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <OfflineBanner />
        <TooltipProvider>
          <RealtimeProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <CrisisBanner />
              <AreaBadge />
              <Suspense fallback={<RouteFallback />}>
                <AppRoutes />
              </Suspense>
            </BrowserRouter>
          </RealtimeProvider>
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
