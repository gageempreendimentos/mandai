import { apiFetch } from "@/services/apiFetch";

export async function fetchOnlineDrivers() {
  return apiFetch<{ drivers: any[] }>("/admin/drivers/online");
}

export async function fetchZones() {
  return apiFetch<{ zones: any[] }>("/zones");
}

export async function fetchDriverHeatmapPoints() {
  return apiFetch<{ points: { lat: number; lng: number }[] }>("/admin/heatmap/drivers");
}
