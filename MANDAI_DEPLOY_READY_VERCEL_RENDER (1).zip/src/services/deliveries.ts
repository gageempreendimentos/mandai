export type DeliveryRequest = {
  id: string;
  pickup: { label: string; lat: number; lng: number };
  dropoff: { label: string; lat: number; lng: number };
  priceBRL: number;
  distanceKm: number;
};

export type DeliveryRequestEvent =
  | { type: "REQUEST"; payload: DeliveryRequest }
  | { type: "CANCEL"; id: string };

export type Unsubscribe = () => void;

/**
 * Produção: assinaturas de pedidos devem vir do backend (WebSocket/SSE/Supabase Realtime).
 * Este módulo não gera dados "fake". Enquanto a fonte realtime não estiver ligada,
 * a assinatura fica desativada (no-op).
 */
export function subscribeToDeliveryRequests(_opts: {
  onEvent: (e: DeliveryRequestEvent) => void;
  enabled: boolean;
}): Unsubscribe {
  // No-op: manter estável sem simulação.
  return () => {};
}
