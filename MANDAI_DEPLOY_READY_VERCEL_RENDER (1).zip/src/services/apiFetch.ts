import { getToken } from "@/lib/authLite";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "http://localhost:8080";

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const token = getToken();
  const headers = new Headers(init?.headers || {});
  headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const res = await fetch(`${API_BASE}${path}`, { ...init, headers });
  const text = await res.text();
  const data = text ? JSON.parse(text) : {};

  if (!res.ok) {
    const err: any = new Error(data?.error || res.statusText);
    err.status = res.status;
    err.data = data;
    throw err;
  }

  return data as T;
}
