import { supabase } from '@/integrations/supabase/client';

type AuditPayload = {
  action: string;
  entity?: string;
  entity_id?: string;
  metadata?: Record<string, unknown>;
};

/**
 * Log de auditoria "best effort".
 *
 * Esse app pode rodar em ambientes onde a tabela `audit_logs` ainda não existe
 * ou onde o usuário não tem permissão (RLS). Por isso:
 * - tenta inserir, mas
 * - nunca derruba a UI em caso de erro
 */
export async function auditLog(payload: AuditPayload): Promise<void> {
  try {
    const { data: auth } = await supabase.auth.getUser();
    const actor_id = auth.user?.id ?? null;

    // Tenta gravar em audit_logs (se existir)
    await supabase.from('audit_logs' as any).insert({
      actor_id,
      action: payload.action,
      entity: payload.entity ?? null,
      entity_id: payload.entity_id ?? null,
      metadata: payload.metadata ?? null,
      created_at: new Date().toISOString(),
    } as any);
  } catch (err) {
    // Não quebra o app
    console.debug('auditLog (ignorado):', err);
  }
}
