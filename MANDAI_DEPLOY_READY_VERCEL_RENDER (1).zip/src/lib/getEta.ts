type LatLng = { lat: number; lng: number };

function apiBase() {
  // Prefer a single env var across the app.
  // Set VITE_API_BASE on Vercel to your backend URL (Render/Fly/VPS).
  return (
    (import.meta.env.VITE_API_BASE as string) ||
    (import.meta.env.VITE_API_URL as string) ||
    "http://localhost:8080"
  );
}

async function backendEta(from: LatLng, to: LatLng): Promise<number | null> {
  const qs = new URLSearchParams({
    from_lat: String(from.lat),
    from_lng: String(from.lng),
    to_lat: String(to.lat),
    to_lng: String(to.lng),
  });

  const url = `${apiBase()}/maps/route?${qs.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return null;
  const j = await res.json();
  const duration = Number(j?.duration_s);
  if (!Number.isFinite(duration) || duration <= 0) return null;
  return duration;
}

async function publicOsrmEta(from: LatLng, to: LatLng): Promise<number | null> {
  const url = `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=false&alternatives=false&steps=false`;
  const res = await fetch(url);
  if (!res.ok) return null;
  const j = await res.json();
  const duration = Number(j?.routes?.[0]?.duration);
  if (!Number.isFinite(duration) || duration <= 0) return null;
  return duration;
}

/**
 * Retorna ETA em segundos. Prioriza backend (permite trocar provider), com fallback para OSRM público.
 */
export async function getEtaSeconds(from: LatLng, to: LatLng): Promise<number | null> {
  try {
    const v = await backendEta(from, to);
    if (v) return v;
  } catch {
    // ignore
  }

  try {
    return await publicOsrmEta(from, to);
  } catch {
    return null;
  }
}

export function etaMinFromSeconds(seconds: number | null, fallbackMin: number) {
  if (!seconds) return fallbackMin;
  const m = Math.round(seconds / 60);
  return Math.max(1, m);
}
