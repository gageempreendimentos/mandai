import { calculateRouteFromAddresses, geocodeAddress } from './routeCalculator';

interface Coordinate {
  lat: number;
  lng: number;
}

// Interface interna do routeOptimizer
interface RoutePointInternal {
  id: string;
  address: string;
  coordinates: Coordinate;
  type: 'pickup' | 'dropoff';
  value: number;
  customerName: string;
}

// Interface para entrada (coordinates pode ser opcional)
export interface RoutePointInput {
  id: string;
  address: string;
  coordinates?: Coordinate;
  type: 'pickup' | 'dropoff';
  value: number;
  customerName: string;
}

interface RouteResult {
  order: string[];
  totalDistance: number;
  totalTime: number;
  savings: {
    distance: number;
    time: number;
  };
  waypoints: Array<{
    id: string;
    type: 'pickup' | 'dropoff';
    address: string;
    estimatedArrival: string;
    instructions: string;
  }>;
}

interface BatchRouteResult {
  deliveries: RoutePointInput[];
  totalDistance: number;
  totalTime: number;
  optimizedOrder: string[];
  waypoints: Array<{
    id: string;
    type: 'pickup' | 'dropoff';
    address: string;
    estimatedArrival: string;
    instructions: string;
  }>;
  savings: {
    distance: number;
    time: number;
  };
}

// Converter endereço em coordenadas (com cache)
const addressCache = new Map<string, Coordinate>();

const getCoordinatesForAddress = async (address: string): Promise<Coordinate> => {
  // Verifica cache
  if (addressCache.has(address)) {
    return addressCache.get(address)!;
  }

  // Tenta geocoding real
  const coords = await geocodeAddress(address);
  
  if (coords) {
    addressCache.set(address, coords);
    return coords;
  }

  // Fallback: coordenadas simuladas baseadas no hash do endereço
  const hash = address.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const baseLat = -23.5505; // São Paulo centro
  const baseLng = -46.6333;
  
  const latVariation = ((hash % 100) - 50) / 1000;
  const lngVariation = ((hash % 100) - 50) / 1000;
  
  const simulatedCoords = {
    lat: baseLat + latVariation,
    lng: baseLng + lngVariation,
  };

  addressCache.set(address, simulatedCoords);
  return simulatedCoords;
};

// Função auxiliar para calcular distância entre coordenadas
const calculateDistance = (coord1: Coordinate, coord2: Coordinate): number => {
  const R = 6371; // Raio da Terra em km
  const dLat = toRad(coord2.lat - coord1.lat);
  const dLng = toRad(coord2.lng - coord1.lng);
  
  const lat1 = toRad(coord1.lat);
  const lat2 = toRad(coord2.lat);
  
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.sin(dLng/2) * Math.sin(dLng/2) * Math.cos(lat1) * Math.cos(lat2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

const toRad = (degrees: number): number => degrees * (Math.PI / 180);

// Algoritmo de vizinho mais próximo (Nearest Neighbor)
const nearestNeighbor = (points: RoutePointInternal[], startCoord: Coordinate): { order: string[]; totalDistance: number; totalTime: number; savings: { distance: number; time: number; } } => {
  const unvisited = [...points];
  const order: string[] = [];
  let currentCoord = startCoord;
  let totalDistance = 0;

  while (unvisited.length > 0) {
    let nearest = unvisited[0];
    let minDistance = calculateDistance(currentCoord, nearest.coordinates);

    for (let i = 1; i < unvisited.length; i++) {
      const distance = calculateDistance(currentCoord, unvisited[i].coordinates);
      if (distance < minDistance) {
        minDistance = distance;
        nearest = unvisited[i];
      }
    }

    order.push(nearest.id);
    totalDistance += minDistance;
    currentCoord = nearest.coordinates;
    unvisited.splice(unvisited.indexOf(nearest), 1);
  }

  const totalTime = Math.round(totalDistance * 2 + order.length * 5);
  const randomDistance = points.length * 3;
  const distanceSavings = randomDistance - totalDistance;
  const timeSavings = (randomDistance * 2) - totalTime;

  return {
    order,
    totalDistance: parseFloat(totalDistance.toFixed(2)),
    totalTime,
    savings: {
      distance: parseFloat(distanceSavings.toFixed(2)),
      time: timeSavings,
    },
  };
};

// Calcular rota otimizada usando API ou TSP
export const calculateOptimizedRoute = async (
  points: RoutePointInput[],
  startCoord: Coordinate,
  useAPI: boolean = true
): Promise<RouteResult> => {
  if (points.length === 0) {
    return {
      order: [],
      totalDistance: 0,
      totalTime: 0,
      savings: { distance: 0, time: 0 },
      waypoints: [],
    };
  }

  // Se houver apenas um ponto, retorna rota simples
  if (points.length === 1) {
    const point = points[0];
    const estimatedArrival = new Date(Date.now() + 10 * 60000).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return {
      order: [point.id],
      totalDistance: 0,
      totalTime: 10,
      savings: { distance: 0, time: 0 },
      waypoints: [
        {
          id: point.id,
          type: point.type,
          address: point.address,
          estimatedArrival,
          instructions: point.type === 'pickup' 
            ? 'Siga para o local de coleta' 
            : 'Siga para o local de entrega',
        },
      ],
    };
  }

  // Garantir que todos os pontos têm coordenadas
  const pointsWithCoords: RoutePointInternal[] = await Promise.all(
    points.map(async (point) => ({
      ...point,
      coordinates: point.coordinates || await getCoordinatesForAddress(point.address),
    }))
  );

  // Usar TSP para otimizar a ordem
  const tspResult = nearestNeighbor(pointsWithCoords, startCoord);
  
  // Gerar waypoints com estimativas
  const waypoints = tspResult.order.map((id, index) => {
    const point = pointsWithCoords.find(p => p.id === id)!;
    const estimatedTime = index === 0 
      ? calculateDistance(startCoord, point.coordinates) * 2
      : calculateDistance(
          pointsWithCoords.find(p => p.id === tspResult.order[index - 1])!.coordinates,
          point.coordinates
        ) * 2;
    
    const estimatedArrival = new Date(Date.now() + estimatedTime * 60000).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return {
      id: point.id,
      type: point.type,
      address: point.address,
      estimatedArrival,
      instructions: index === 0 
        ? 'Siga para o primeiro ponto' 
        : `Continue para ${point.type === 'pickup' ? 'coletar' : 'entregar'} em ${point.address.split(',')[0]}`,
    };
  });

  return {
    ...tspResult,
    waypoints,
  };
};

// Calcular rota combinada para múltiplas entregas
export const calculateBatchRoute = async (
  points: RoutePointInput[],
  startCoord: Coordinate,
  useAPI: boolean = true
): Promise<BatchRouteResult> => {
  if (points.length < 2) {
    throw new Error('Selecione pelo menos 2 entregas para rota combinada');
  }

  const route = await calculateOptimizedRoute(points, startCoord, useAPI);
  
  return {
    deliveries: points,
    totalDistance: route.totalDistance,
    totalTime: route.totalTime,
    optimizedOrder: route.order,
    waypoints: route.waypoints,
    savings: route.savings,
  };
};