type Level = "debug" | "info" | "warn" | "error";
type LogItem = { t: number; level: Level; msg: string; meta?: any };

const KEY = "mandai.logs.v1";
const MAX = 500;

function load(): LogItem[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}
function save(items: LogItem[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(items.slice(-MAX)));
  } catch {}
}

function shouldDebug() {
  return import.meta.env.DEV;
}

function push(level: Level, msg: string, meta?: any) {
  const items = load();
  items.push({ t: Date.now(), level, msg, meta });
  save(items);

  if (level === "debug" && !shouldDebug()) return;

  const fn =
    level === "error"
      ? console.error
      : level === "warn"
      ? console.warn
      : console.log;

  fn(`[${level}] ${msg}`, meta ?? "");
}

export const logger = {
  debug: (m: string, meta?: any) => push("debug", m, meta),
  info: (m: string, meta?: any) => push("info", m, meta),
  warn: (m: string, meta?: any) => push("warn", m, meta),
  error: (m: string, meta?: any) => push("error", m, meta),
  read: () => load(),
  clear: () => localStorage.removeItem(KEY),
};
