import { getRide, setRide, type Ride } from "@/state/rideState";
import { getRole, getToken, getUserId } from "@/lib/authLite";

type WsMsg =
  | { type: "RIDE_STATE"; payload: Ride }
  | { type: "RIDE_UPDATE"; payload: Ride }
  | { type: "ERROR"; payload?: any };

let ws: WebSocket | null = null;
let isConnected = false;
let reconnectTimer: number | null = null;

// WebSocket usually runs on the same host as the API (upgrade on the same port).
// If VITE_WS_URL is not set, derive it from VITE_API_BASE.
function defaultWsBase() {
  const api = (import.meta.env.VITE_WS_URL as string) || (import.meta.env.VITE_API_BASE as string) || "http://localhost:8080";
  return api
    .replace(/^https:/i, "wss:")
    .replace(/^http:/i, "ws:");
}

const WS_BASE = defaultWsBase();

export function wsStatus() {
  return { isConnected, url: WS_BASE };
}

function buildWsUrl() {
  const token = getToken() || "";
  const role = getRole() || "";
  const userId = getUserId();
  const u = new URL(WS_BASE);
  u.searchParams.set("token", token);
  // role/userId are not required by the server (it validates via JWT), but keep for debugging.
  if (role) u.searchParams.set("role", role);
  if (userId) u.searchParams.set("userId", userId);
  return u.toString();
}

function initialRooms() {
  const rooms: string[] = [];
  const role = getRole();
  const userId = getUserId();
  rooms.push(`user:${userId}`);
  if (role) rooms.push(`role:${role}`);

  const ride = getRide();
  if (ride?.id) rooms.push(`ride:${ride.id}`);
  return rooms;
}

export function wsConnect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;

  const url = buildWsUrl();

  try {
    ws = new WebSocket(url);
  } catch {
    return;
  }

  ws.addEventListener("open", () => {
    isConnected = true;
    // join rooms (server expects one room per message)
    for (const room of initialRooms()) {
      wsSend("SUBSCRIBE", { room });
    }
  });

  ws.addEventListener("message", (ev) => {
    try {
      const msg = JSON.parse(String(ev.data)) as WsMsg;

      if (msg.type === "RIDE_STATE") setRide(msg.payload);
      if (msg.type === "RIDE_UPDATE") setRide(msg.payload);
      if (msg.type === "ERROR") {
        // keep silent; server will deny actions if not authed
        // console.warn("WS ERROR", msg.payload);
      }
    } catch {}
  });

  ws.addEventListener("close", () => {
    isConnected = false;
    scheduleReconnect();
  });

  ws.addEventListener("error", () => {
    isConnected = false;
    scheduleReconnect();
  });
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = window.setTimeout(() => {
    reconnectTimer = null;
    wsConnect();
  }, 1200);
}

export function wsSend(type: string, payload?: any) {
  try {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    // Server protocol expects top-level fields (not nested in "payload").
    if (payload && typeof payload === "object" && !Array.isArray(payload)) {
      ws.send(JSON.stringify({ type, ...payload }));
    } else if (payload !== undefined) {
      ws.send(JSON.stringify({ type, payload }));
    } else {
      ws.send(JSON.stringify({ type }));
    }
  } catch {}
}

// helper actions
export function wsUpdateRide(patch: Partial<Ride>) {
  const next = { ...getRide(), ...patch };
  setRide(next); // optimistic
  wsSend("RIDE_UPDATE", patch);
}

export function wsResetRide() {
  const cur = getRide();
  setRide({ ...cur, stage: "offered", etaMin: 7 });
  wsSend("RIDE_RESET");
}

export function wsSetRideRoom(rideId: string) {
  wsSend("SUBSCRIBE", { room: `ride:${rideId}` });
}
