import { supabase } from '@/integrations/supabase/client';

// Configuração - OpenRouteService
const API_KEY = import.meta.env.VITE_OPENROUTESERVICE_API_KEY;
const API_URL = 'https://api.openrouteservice.org/v2/directions/driving-car/geojson';

interface Coordinates {
  lat: number;
  lng: number;
}

interface RouteResult {
  distance: number; // em km
  duration: number; // em minutos
  polyline?: string; // rota codificada
}

// Calcular rota usando OpenRouteService
export const calculateRoute = async (
  pickupCoords: Coordinates,
  dropoffCoords: Coordinates
): Promise<RouteResult | null> => {
  try {
    // Verifica se a API Key está configurada
    if (!API_KEY) {
      console.warn('API Key do OpenRouteService não configurada. Usando cálculo simples.');
      return calculateSimpleRoute(pickupCoords, dropoffCoords);
    }

    const body = {
      coordinates: [
        [pickupCoords.lng, pickupCoords.lat],
        [dropoffCoords.lng, dropoffCoords.lat],
      ],
      instructions: false,
      geometry: true,
    };

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data.features || data.features.length === 0) {
      return null;
    }

    const route = data.features[0];
    const properties = route.properties.summary;

    return {
      distance: properties.distance / 1000, // converter para km
      duration: Math.round(properties.duration / 60), // converter para minutos
      polyline: route.geometry,
    };
  } catch (error) {
    console.error('Erro ao calcular rota com OpenRouteService:', error);
    // Fallback para cálculo simples
    return calculateSimpleRoute(pickupCoords, dropoffCoords);
  }
};

// Cálculo simples (Haversine) - SEM API
const calculateSimpleRoute = (
  pickupCoords: Coordinates,
  dropoffCoords: Coordinates
): RouteResult => {
  const R = 6371; // Raio da Terra em km
  
  const dLat = toRad(dropoffCoords.lat - pickupCoords.lat);
  const dLon = toRad(dropoffCoords.lng - pickupCoords.lng);
  
  const lat1 = toRad(pickupCoords.lat);
  const lat2 = toRad(dropoffCoords.lat);
  
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  
  // Estimativa de tempo: 2 min por km + 5 min fixos
  const duration = Math.round(distance * 2 + 5);
  
  return {
    distance: parseFloat(distance.toFixed(2)),
    duration,
  };
};

// Geocoding: Converter endereço em coordenadas
// Usa Nominatim (API gratuita da OpenStreetMap)
export const geocodeAddress = async (address: string): Promise<Coordinates | null> => {
  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&limit=1&countrycodes=br`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': '365Entregas/1.0 (seu-email@dominio.com)', // Obrigatório para Nominatim
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (data.length === 0) {
      console.log('Endereço não encontrado, usando coordenadas simuladas');
      return simulateGeocode(address);
    }

    return {
      lat: parseFloat(data[0].lat),
      lng: parseFloat(data[0].lon),
    };
  } catch (error) {
    console.error('Erro no geocoding:', error);
    // Fallback para coordenadas simuladas
    return simulateGeocode(address);
  }
};

// Função de simulação (fallback)
const simulateGeocode = (address: string): Coordinates => {
  // Gera coordenadas baseadas no hash do endereço
  const hash = address.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  
  // São Paulo centro
  const baseLat = -23.5505;
  const baseLng = -46.6333;
  
  // Variação baseada no hash
  const latVariation = ((hash % 100) - 50) / 1000; // -0.05 a 0.05
  const lngVariation = ((hash % 100) - 50) / 1000; // -0.05 a 0.05
  
  return {
    lat: baseLat + latVariation,
    lng: baseLng + lngVariation,
  };
};

// Calcular rota completa: endereço -> coordenadas -> distância
export const calculateRouteFromAddresses = async (
  pickupAddress: string,
  dropoffAddress: string
): Promise<RouteResult | null> => {
  try {
    const pickupCoords = await geocodeAddress(pickupAddress);
    const dropoffCoords = await geocodeAddress(dropoffAddress);
    
    if (!pickupCoords || !dropoffCoords) {
      return null;
    }
    
    return await calculateRoute(pickupCoords, dropoffCoords);
  } catch (error) {
    console.error('Erro ao calcular rota:', error);
    return null;
  }
};

// Salvar coordenadas na entrega (para evitar recálculo)
export const saveDeliveryCoordinates = async (
  deliveryId: string,
  pickupCoords: Coordinates,
  dropoffCoords: Coordinates
) => {
  const { error } = await supabase
    .from('deliveries')
    .update({
      pickup_lat: pickupCoords.lat,
      pickup_lng: pickupCoords.lng,
      delivery_lat: dropoffCoords.lat,
      delivery_lng: dropoffCoords.lng,
    })
    .eq('id', deliveryId);
  
  if (error) throw error;
};

// Obter coordenadas da entrega (se já calculadas)
export const getDeliveryCoordinates = async (
  deliveryId: string
): Promise<{ pickup: Coordinates; dropoff: Coordinates } | null> => {
  const { data, error } = await supabase
    .from('deliveries')
    .select('pickup_lat, pickup_lng, delivery_lat, delivery_lng')
    .eq('id', deliveryId)
    .single();
  
  if (error || !data) return null;
  
  if (!data.pickup_lat || !data.pickup_lng || !data.delivery_lat || !data.delivery_lng) {
    return null;
  }
  
  return {
    pickup: { lat: data.pickup_lat, lng: data.pickup_lng },
    dropoff: { lat: data.delivery_lat, lng: data.delivery_lng },
  };
};

// Função auxiliar para converter graus para radianos
function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

// Formatar distância para exibição
export const formatDistance = (km: number): string => {
  if (km < 1) {
    return `${Math.round(km * 1000)} m`;
  }
  return `${km.toFixed(1)} km`;
};

// Formatar duração para exibição
export const formatDuration = (minutes: number): string => {
  if (minutes < 60) {
    return `${minutes} min`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}h ${mins}min`;
};