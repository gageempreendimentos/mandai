export async function isFirebaseSwHealthy(): Promise<boolean> {
  try {
    const res = await fetch("/firebase-messaging-sw.js", { cache: "no-store" });
    const text = await res.text();

    // Basic heuristics for placeholder/incomplete SW
    if (text.includes("YOUR_PROJECT") || text.includes("YOUR_SENDER_ID")) return false;
    if (text.length < 200) return false;

    return true;
  } catch {
    return false;
  }
}
