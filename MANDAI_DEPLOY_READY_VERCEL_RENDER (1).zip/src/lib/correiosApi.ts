import { useToast } from '@/hooks/use-toast';

interface CorreiosAddress {
  cep: string;
  logradouro: string;
  complemento: string;
  bairro: string;
  localidade: string;
  uf: string;
  ibge: string;
  gia: string;
  ddd: string;
  siafi: string;
}

export const searchCep = async (cep: string): Promise<CorreiosAddress | null> => {
  try {
    const cleanCep = cep.replace(/\D/g, '');
    
    if (cleanCep.length !== 8) {
      throw new Error('CEP deve ter exatamente 8 dígitos.');
    }

    const url = `https://viacep.com.br/ws/${cleanCep}/json/`;
    console.log(`[correiosApi] Buscando CEP da URL: ${url}`);
    const response = await fetch(url);
    console.log(`[correiosApi] Status da resposta HTTP: ${response.status}`);

    if (!response.ok) {
      console.error(`[correiosApi] Erro HTTP! Status: ${response.status}`);
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log(`[correiosApi] Dados JSON recebidos:`, data);

    if (data.erro) {
      console.log(`[correiosApi] ViaCEP retornou erro para o CEP ${cleanCep}:`, data);
      return null;
    }

    return {
      cep: data.cep,
      logradouro: data.logradouro || '',
      complemento: data.complemento || '',
      bairro: data.bairro || '',
      localidade: data.localidade || '',
      uf: data.uf || '',
      ibge: data.ibge || '',
      gia: data.gia || '',
      ddd: data.ddd || '',
      siafi: data.siafi || '',
    };
  } catch (error) {
    console.error('[correiosApi] Erro ao consultar CEP:', error);
    return null;
  }
};

export const validateCep = (cep: string): { valid: boolean; message: string } => {
  const cleanCep = cep.replace(/\D/g, '');
  
  console.log(`[validateCep] CEP original: ${cep}`);
  console.log(`[validateCep] CEP limpo: ${cleanCep}`);
  console.log(`[validateCep] Tamanho do CEP limpo: ${cleanCep.length}`);
  
  if (cleanCep.length === 0) {
    return { valid: false, message: 'CEP é obrigatório.' };
  }
  
  if (cleanCep.length !== 8) {
    return { valid: false, message: 'CEP deve ter exatamente 8 dígitos.' };
  }
  
  // Verificar se é um CEP válido (não todos os dígitos iguais)
  if (/^(\d)\1+$/.test(cleanCep)) {
    return { valid: false, message: 'CEP inválido.' };
  }
  
  return { valid: true, message: '' };
};

export const formatCEP = (value: string): string => {
  const numbers = value.replace(/\D/g, '');
  
  // Se tiver mais de 8 dígitos, mantém apenas os primeiros 8
  const limitedNumbers = numbers.slice(0, 8);
  
  // Formata: 12345678 -> 12345-678
  if (limitedNumbers.length >= 6) {
    return limitedNumbers.replace(/(\d{5})(\d)/, '$1-$2');
  }
  
  // Se tiver menos de 6 dígitos, retorna sem hífen
  return limitedNumbers;
};