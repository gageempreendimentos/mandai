export type AppRole = "driver" | "admin" | "restaurant" | "client";

const KEY_ROLE = "mandai_role";
const KEY_TOKEN = "mandai_access_token";
const KEY_SUB = "mandai_sub";

export function isAuthed(expectedRole?: AppRole): boolean {
  const token = localStorage.getItem(KEY_TOKEN);
  const role = localStorage.getItem(KEY_ROLE) as AppRole | null;
  if (!token || !role) return false;
  return expectedRole ? role === expectedRole : true;
}

export function getToken(): string | null {
  return localStorage.getItem(KEY_TOKEN);
}

export function getRole(): AppRole | null {
  return (localStorage.getItem(KEY_ROLE) as AppRole | null) || null;
}

export function getSub(): string | null {
  return localStorage.getItem(KEY_SUB);
}

export function setSession(role: AppRole, access_token: string, sub?: string) {
  localStorage.setItem(KEY_ROLE, role);
  localStorage.setItem(KEY_TOKEN, access_token);
  if (sub) localStorage.setItem(KEY_SUB, sub);
}

export function logout() {
  localStorage.removeItem(KEY_TOKEN);
  localStorage.removeItem(KEY_ROLE);
  localStorage.removeItem(KEY_SUB);
}
