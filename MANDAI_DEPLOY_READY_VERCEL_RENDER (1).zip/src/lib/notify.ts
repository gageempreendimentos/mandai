import { toast } from "sonner";
import { loadSettings } from "@/lib/mandaiSettings";
import { haptic } from "@/lib/haptics";

const h = () => loadSettings().hapticsEnabled;

export const notify = {
  success: (message: string, description?: string) => {
    haptic("success", h());
    return toast.success(message, { description });
  },
  error: (message: string, description?: string) => {
    haptic("error", h());
    return toast.error(message, { description });
  },
  info: (message: string, description?: string) => {
    haptic("light", h());
    return toast(message, { description });
  },
  warning: (message: string, description?: string) => {
    haptic("warning", h());
    return toast.warning(message, { description });
  },
};
