export type HapticType = "light" | "success" | "warning" | "error";

export function haptic(type: HapticType, enabled: boolean = true) {
  if (!enabled) return;
  if (typeof navigator === "undefined") return;
  const vib = (navigator as any).vibrate as undefined | ((p: number | number[]) => boolean);
  if (!vib) return;

  const patterns: Record<HapticType, number | number[]> = {
    light: 12,
    success: [10, 30, 14],
    warning: [18, 35, 18],
    error: [24, 40, 24],
  };

  try {
    vib(patterns[type]);
  } catch {
    // ignore
  }
}
