import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export type FeatureFlag = { key: string; enabled: boolean; description?: string | null };

export const useFeatureFlags = () => {
  return useQuery({
    queryKey: ['feature_flags'],
    queryFn: async (): Promise<Record<string, boolean>> => {
      const { data, error } = await supabase.from('feature_flags').select('key, enabled');
      if (error) {
        // se tabela não existir ou sem permissão, falha silenciosa
        return {};
      }
      const map: Record<string, boolean> = {};
      for (const row of data ?? []) map[row.key] = !!row.enabled;
      return map;
    },
    staleTime: 60_000,
    retry: 1,
  });
};

export const useFeatureFlag = (key: string, defaultValue = false) => {
  const q = useFeatureFlags();
  const enabled = (q.data && key in q.data) ? !!q.data[key] : defaultValue;
  return { ...q, enabled };
};
