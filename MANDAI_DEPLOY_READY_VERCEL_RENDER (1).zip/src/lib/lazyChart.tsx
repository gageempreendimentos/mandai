import React, { Suspense } from 'react';

export function lazyChart<T extends React.ComponentType<any>>(
  factory: () => Promise<{ default: T }>,
  Fallback: React.ReactNode = <div className="h-40 rounded-2xl bg-muted animate-pulse" />
) {
  const C = React.lazy(factory);
  return (props: React.ComponentProps<T>) => (
    <Suspense fallback={Fallback}>
      <C {...props} />
    </Suspense>
  );
}
