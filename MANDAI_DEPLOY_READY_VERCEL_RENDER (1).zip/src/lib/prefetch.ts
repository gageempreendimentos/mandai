/**
 * Prefetch utilities (safe)
 *
 * Goals:
 * - NEVER break the app if something goes wrong
 * - Prefer running only in DEV, or in PROD when on Wi‑Fi and user isn't on Data Saver
 * - Execute when the browser is idle (requestIdleCallback) with a safe fallback
 */

export type ImportFn = () => Promise<unknown>;

function isBrowser() {
  return typeof window !== "undefined";
}

function getConnection(): any {
  const nav: any = navigator;
  return nav?.connection || nav?.mozConnection || nav?.webkitConnection || null;
}

/**
 * Allow prefetching:
 * - Always in DEV
 * - In PROD only if:
 *   - not saveData
 *   - and connection looks like Wi‑Fi (type === "wifi" OR effectiveType is fast && downlink is decent)
 */
export function canPrefetch(): boolean {
  try {
    // Prefetch is opt-in. Default off for best startup performance.
    // Enable with VITE_PREFETCH=true
    if (import.meta.env.VITE_PREFETCH !== "true") return false;

    // Vite env flags
    if (import.meta.env.DEV) return true;
    if (!isBrowser()) return false;

    const conn = getConnection();
    if (!conn) return false;

    if (conn.saveData) return false;

    // NetworkInformation API (not supported everywhere)
    if (typeof conn.type === "string" && conn.type.toLowerCase() === "wifi") return true;

    // Fallback heuristics: allow only if very likely on mandaid connection
    const effectiveType = String(conn.effectiveType || "").toLowerCase(); // "4g", "3g", ...
    const downlink = Number(conn.downlink || 0); // Mbps
    // Be conservative: require fast + decent downlink (approx Wi‑Fi quality)
    if (effectiveType === "4g" && downlink >= 10) return true;

    return false;
  } catch {
    return false;
  }
}

function scheduleIdle(fn: () => void) {
  try {
    if (!isBrowser()) return;

    const w: any = window as any;

    if (typeof w.requestIdleCallback === "function") {
      w.requestIdleCallback(() => {
        try {
          fn();
        } catch {
          // ignore
        }
      });
      return;
    }

    setTimeout(() => {
      try {
        fn();
      } catch {
        // ignore
      }
    }, 300);
  } catch {
    // ignore
  }
}

/**
 * Prefetch a dynamic import safely.
 */
export function prefetch(importFn: ImportFn) {
  try {
    if (!isBrowser()) return;
    if (!canPrefetch()) return;

    scheduleIdle(() => {
      try {
        void importFn();
      } catch {
        // silent
      }
    });
  } catch {
    // silent
  }
}

/**
 * Backwards-compatible helper used in Entry.tsx.
 * - If called with no args, it does nothing (safe).
 * - If passed an array of import functions, it prefetches them.
 */
export function prefetchRoutes(importFns?: ImportFn[]) {
  try {
    if (!importFns || importFns.length === 0) return;
    importFns.forEach((fn) => prefetch(fn));
  } catch {
    // silent
  }
}
