// Compat layer: some parts of the app import "@/lib/mandaiSettings".
// The actual implementation lives in gooSettings.ts.

export type { MandaiSettings } from "@/lib/gooSettings";
export { defaultSettings, loadSettings, saveSettings, updateSettings } from "@/lib/gooSettings";
