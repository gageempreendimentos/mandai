export async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;

  // Single SW for push + cache
  const swUrl = "/firebase-messaging-sw.js";

  try {
    const reg = await navigator.serviceWorker.register(swUrl, { scope: "/" });
    return reg;
  } catch (err) {
    // Do not break the app if SW registration fails
    console.warn("SW registration failed:", err);
  }
}
