export type NavProvider = "waze" | "google";

function enc(v: string) {
  return encodeURIComponent(String(v || "").trim());
}

/**
 * Monta URL de navegação por endereço.
 * - waze: abre rota no Waze
 * - google: abre rota no Google Maps
 */
export function buildNavUrl(provider: NavProvider, destination: string) {
  const dest = String(destination || "").trim();
  if (!dest) return null;

  if (provider === "waze") {
    return `https://waze.com/ul?q=${enc(dest)}&navigate=yes`;
  }

  // Google Maps universal link
  return `https://www.google.com/maps/dir/?api=1&destination=${enc(dest)}&travelmode=driving`;
}

export function openNav(provider: NavProvider, destination: string) {
  const url = buildNavUrl(provider, destination);
  if (!url) return;
  window.open(url, "_blank", "noopener,noreferrer");
}
