type LatLng = [number, number];

function roundCoord(n: number) {
  return Math.round(n * 1e5) / 1e5;
}

function keyFor(from: LatLng, to: LatLng) {
  return `osrm:${roundCoord(from[0])},${roundCoord(from[1])}->${roundCoord(to[0])},${roundCoord(to[1])}`;
}

function straightLine(from: LatLng, to: LatLng): LatLng[] {
  return [from, to];
}

export async function getRouteOSRM(from: LatLng, to: LatLng): Promise<LatLng[]> {
  const k = keyFor(from, to);

  // Session cache (fast)
  const cached = sessionStorage.getItem(k);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {}
  }

  const url = `https://router.project-osrm.org/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}?overview=full&geometries=geojson`;

  // Simple backoff retry
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`OSRM ${res.status}`);
      const data = await res.json();

      const coords = data.routes?.[0]?.geometry?.coordinates;
      if (!coords?.length) throw new Error("No route");

      const route: LatLng[] = coords.map(([lng, lat]: number[]) => [lat, lng]);
      sessionStorage.setItem(k, JSON.stringify(route));
      return route;
    } catch (e) {
      if (attempt == 0) await new Promise((r) => setTimeout(r, 800));
    }
  }

  // Fallback to straight line so UI never "loses" the route
  return straightLine(from, to);
}
