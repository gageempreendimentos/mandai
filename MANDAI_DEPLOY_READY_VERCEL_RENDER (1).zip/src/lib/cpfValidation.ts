import { useToast } from '@/hooks/use-toast';

/**
 * Validação completa de CPF
 * Verifica formato, dígitos verificadores e CPFs bloqueados
 */
export const validateCPF = (cpf: string): boolean => {
  const cleanCPF = cpf.replace(/\D/g, '');
  
  // Verifica se tem 11 dígitos
  if (cleanCPF.length !== 11) {
    return false;
  }

  // Verifica CPFs bloqueados/inválidos comuns
  const blockedCPFs = [
    '00000000000',
    '11111111111',
    '22222222222',
    '33333333333',
    '44444444444',
    '55555555555',
    '66666666666',
    '77777777777',
    '88888888888',
    '99999999999',
  ];

  if (blockedCPFs.includes(cleanCPF)) {
    return false;
  }

  // Calcula primeiro dígito verificador
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cleanCPF.charAt(i)) * (10 - i);
  }
  
  let remainder = (sum * 10) % 11;
  const firstVerifier = remainder === 10 ? 0 : remainder;

  if (firstVerifier !== parseInt(cleanCPF.charAt(9))) {
    return false;
  }

  // Calcula segundo dígito verificador
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cleanCPF.charAt(i)) * (11 - i);
  }
  
  remainder = (sum * 10) % 11;
  const secondVerifier = remainder === 10 ? 0 : remainder;

  if (secondVerifier !== parseInt(cleanCPF.charAt(10))) {
    return false;
  }

  return true;
};

/**
 * Hook para validação de CPF com mensagens
 */
export const useCPFValidation = () => {
  const { toast } = useToast();

  const validateAndNotify = (cpf: string): boolean => {
    const cleanCPF = cpf.replace(/\D/g, '');
    
    if (cleanCPF.length === 0) {
      return false;
    }
    
    if (cleanCPF.length !== 11) {
      toast({
        title: "CPF incompleto",
        description: `Digite os 11 dígitos. Atual: ${cleanCPF.length}`,
        variant: "destructive",
      });
      return false;
    }

    // Validação completa
    const isValid = validateCPF(cpf);
    
    if (!isValid) {
      toast({
        title: "CPF inválido",
        description: "Digite um CPF válido com dígitos verificadores corretos",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  return { validateCPF, validateAndNotify };
};