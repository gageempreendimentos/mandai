/**
 * Algoritmo TSP (Traveling Salesman Problem) para otimização de rotas
 * Implementa algoritmo de força bruta para pequenas quantidades de pontos
 * e algoritmo de vizinho mais próximo para maior escala
 */

interface Coordinate {
  lat: number;
  lng: number;
}

interface RoutePoint {
  id: string;
  coordinates: Coordinate;
  type: 'pickup' | 'dropoff';
  value: number;
}

interface RouteResult {
  order: string[];
  totalDistance: number;
  totalTime: number;
  savings: {
    distance: number;
    time: number;
  };
}

// Calcular distância entre dois pontos usando Haversine
const calculateDistance = (coord1: Coordinate, coord2: Coordinate): number => {
  const R = 6371; // Raio da Terra em km
  const dLat = toRad(coord2.lat - coord1.lat);
  const dLng = toRad(coord2.lng - coord1.lng);
  
  const lat1 = toRad(coord1.lat);
  const lat2 = toRad(coord2.lat);
  
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.sin(dLng/2) * Math.sin(dLng/2) * Math.cos(lat1) * Math.cos(lat2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};

const toRad = (degrees: number): number => degrees * (Math.PI / 180);

// Algoritmo de vizinho mais próximo (Nearest Neighbor)
const nearestNeighbor = (points: RoutePoint[], startCoord: Coordinate): RouteResult => {
  const unvisited = [...points];
  const order: string[] = [];
  let currentCoord = startCoord;
  let totalDistance = 0;

  while (unvisited.length > 0) {
    let nearest = unvisited[0];
    let minDistance = calculateDistance(currentCoord, nearest.coordinates);

    for (let i = 1; i < unvisited.length; i++) {
      const distance = calculateDistance(currentCoord, unvisited[i].coordinates);
      if (distance < minDistance) {
        minDistance = distance;
        nearest = unvisited[i];
      }
    }

    order.push(nearest.id);
    totalDistance += minDistance;
    currentCoord = nearest.coordinates;
    unvisited.splice(unvisited.indexOf(nearest), 1);
  }

  // Calcular tempo estimado (2 min por km + 5 min fixos por parada)
  const totalTime = Math.round(totalDistance * 2 + order.length * 5);

  // Calcular economia comparado com rota aleatória
  const randomDistance = points.length * 3; // 3km média por entrega
  const distanceSavings = randomDistance - totalDistance;
  const timeSavings = (randomDistance * 2) - totalTime;

  return {
    order,
    totalDistance: parseFloat(totalDistance.toFixed(2)),
    totalTime,
    savings: {
      distance: parseFloat(distanceSavings.toFixed(2)),
      time: timeSavings,
    },
  };
};

// Algoritmo de força bruta (para até 8 pontos)
const bruteForce = (points: RoutePoint[], startCoord: Coordinate): RouteResult => {
  const n = points.length;
  if (n > 8) {
    // Para mais de 8 pontos, usa vizinho mais próximo
    return nearestNeighbor(points, startCoord);
  }

  const allPermutations = generatePermutations(points.map(p => p.id));
  let bestOrder: string[] = [];
  let bestDistance = Infinity;

  for (const perm of allPermutations) {
    let distance = 0;
    let currentCoord = startCoord;

    for (const id of perm) {
      const point = points.find(p => p.id === id)!;
      distance += calculateDistance(currentCoord, point.coordinates);
      currentCoord = point.coordinates;
    }

    if (distance < bestDistance) {
      bestDistance = distance;
      bestOrder = perm;
    }
  }

  const totalTime = Math.round(bestDistance * 2 + n * 5);
  const randomDistance = n * 3;
  const distanceSavings = randomDistance - bestDistance;
  const timeSavings = (randomDistance * 2) - totalTime;

  return {
    order: bestOrder,
    totalDistance: parseFloat(bestDistance.toFixed(2)),
    totalTime,
    savings: {
      distance: parseFloat(distanceSavings.toFixed(2)),
      time: timeSavings,
    },
  };
};

// Gerar permutações
const generatePermutations = (arr: string[]): string[][] => {
  if (arr.length <= 1) return [arr];
  
  const permutations: string[][] = [];
  for (let i = 0; i < arr.length; i++) {
    const rest = [...arr.slice(0, i), ...arr.slice(i + 1)];
    const restPermutations = generatePermutations(rest);
    for (const perm of restPermutations) {
      permutations.push([arr[i], ...perm]);
    }
  }
  return permutations;
};

// Função principal de otimização
export const optimizeRoute = (
  points: RoutePoint[],
  startCoord: Coordinate,
  algorithm: 'auto' | 'tsp' | 'nearest' = 'auto'
): RouteResult => {
  if (points.length === 0) {
    return {
      order: [],
      totalDistance: 0,
      totalTime: 0,
      savings: { distance: 0, time: 0 },
    };
  }

  // Se houver apenas um ponto, retorna ele mesmo
  if (points.length === 1) {
    return {
      order: [points[0].id],
      totalDistance: 0,
      totalTime: 5, // 5 min fixos
      savings: { distance: 0, time: 0 },
    };
  }

  // Escolhe algoritmo baseado na quantidade de pontos e preferência
  if (algorithm === 'tsp' || (algorithm === 'auto' && points.length <= 8)) {
    return bruteForce(points, startCoord);
  } else {
    return nearestNeighbor(points, startCoord);
  }
};

// Agrupar entregas próximas para rota combinada
export const groupDeliveriesForBatch = (
  points: RoutePoint[],
  maxDistance: number = 3
): RoutePoint[][] => {
  const groups: RoutePoint[][] = [];
  const used = new Set<string>();

  points.forEach(point => {
    if (used.has(point.id)) return;

    const group: RoutePoint[] = [point];
    used.add(point.id);

    // Encontrar pontos próximos
    points.forEach(other => {
      if (used.has(other.id)) return;
      
      const distance = calculateDistance(point.coordinates, other.coordinates);
      if (distance <= maxDistance) {
        group.push(other);
        used.add(other.id);
      }
    });

    if (group.length > 1) {
      groups.push(group);
    }
  });

  return groups;
};

// Calcular rota combinada para múltiplas entregas
export const optimizeBatchRoute = (
  points: RoutePoint[],
  startCoord: Coordinate
): RouteResult[] => {
  const groups = groupDeliveriesForBatch(points);
  
  if (groups.length === 0) {
    // Não há entregas próximas suficientes para rota combinada
    return [optimizeRoute(points, startCoord, 'nearest')];
  }

  // Para cada grupo, otimiza a rota
  return groups.map(group => optimizeRoute(group, startCoord, 'tsp'));
};