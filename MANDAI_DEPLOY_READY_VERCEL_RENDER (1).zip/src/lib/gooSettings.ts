export type MandaiSettings = {
  soundsEnabled: boolean;
  notificationsEnabled: boolean;
  theme: "light" | "dark" | "system";
  supportWhatsapp: string;
  hapticsEnabled: boolean;
};

const KEY = "mandai.settings.v1";

export const defaultSettings: MandaiSettings = {
  soundsEnabled: true,
  notificationsEnabled: true,
  theme: "system",
  supportWhatsapp: "5537998650485", // default from earlier conversations
  hapticsEnabled: true,
};

export function loadSettings(): MandaiSettings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSettings;
    const parsed = JSON.parse(raw) as Partial<MandaiSettings>;
    return {
      ...defaultSettings,
      ...parsed,
    };
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(next: MandaiSettings) {
  localStorage.setItem(KEY, JSON.stringify(next));
}

export function updateSettings(patch: Partial<MandaiSettings>) {
  const cur = loadSettings();
  const next = { ...cur, ...patch };
  saveSettings(next);
  return next;
}
