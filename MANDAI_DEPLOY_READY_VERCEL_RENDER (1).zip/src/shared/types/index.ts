export type Role = "admin" | "driver" | "client" | "restaurant";
