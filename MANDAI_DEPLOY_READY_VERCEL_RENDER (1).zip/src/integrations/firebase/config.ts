import { initializeApp } from 'firebase/app';
import { getMessaging, getToken, onMessage, isSupported, type Messaging } from 'firebase/messaging';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// Inicializa Firebase (isso não quebra mesmo se algumas envs estiverem vazias, mas deixamos aviso)
export const firebaseApp = initializeApp(firebaseConfig);

let messagingInstance: Messaging | null = null;

const hasFirebaseMessagingEnv = () =>
  Boolean(
    import.meta.env.VITE_FIREBASE_API_KEY &&
      import.meta.env.VITE_FIREBASE_PROJECT_ID &&
      import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID &&
      import.meta.env.VITE_FIREBASE_APP_ID
  );

// Retorna o messaging apenas quando suportado e com env mínima configurada
export const getMessagingSafe = async (): Promise<Messaging | null> => {
  const supported = await isSupported();
  if (!supported) return null;

  if (!hasFirebaseMessagingEnv()) {
    console.warn('⚠️ Firebase Messaging: variáveis de ambiente incompletas (FCM desativado).');
    return null;
  }

  if (!messagingInstance) {
    messagingInstance = getMessaging(firebaseApp);
  }
  return messagingInstance;
};

// Função para solicitar permissão e obter token
export const requestNotificationPermission = async (): Promise<string | null> => {
  try {
    const messaging = await getMessagingSafe();
    if (!messaging) {
      console.log('Firebase Messaging não suportado ou não configurado neste ambiente');
      return null;
    }

    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      console.log('Permissão de notificação negada');
      return null;
    }

    const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY;
    if (!vapidKey) {
      console.warn('⚠️ VITE_FIREBASE_VAPID_KEY não configurado (não será possível obter token FCM).');
      return null;
    }

    const token = await getToken(messaging, { vapidKey });

    if (!token) {
      console.log('Não foi possível obter o token');
      return null;
    }

    console.log('Token FCM:', token);
    return token;
  } catch (error) {
    console.error('Erro ao solicitar permissão:', error);
    return null;
  }
};

// Função para ouvir mensagens em foreground
export const onMessageListener = async () => {
  const messaging = await getMessagingSafe();
  if (!messaging) return null;

  return new Promise((resolve) => {
    onMessage(messaging, (payload) => {
      console.log('Mensagem recebida em foreground:', payload);
      resolve(payload);
    });
  });
};
