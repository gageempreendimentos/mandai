import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

// Import the supabase client like this:
// import { supabase } from "@/integrations/supabase/client";

const isSupabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_PUBLISHABLE_KEY);

console.log('=== VERIFICANDO CONEXÃO SUPABASE ===');
console.log('URL:', SUPABASE_URL ? '✅ Configurada' : '❌ NÃO configurada');
console.log('Chave:', SUPABASE_PUBLISHABLE_KEY ? '✅ Configurada' : '❌ NÃO configurada');

if (!isSupabaseConfigured) {
  console.warn('⚠️ Supabase não configurado. O app vai iniciar em modo limitado.');
  console.warn('Crie um arquivo .env na raiz com:');
  console.warn('VITE_SUPABASE_URL=...');
  console.warn('VITE_SUPABASE_PUBLISHABLE_KEY=...');
}

// Para evitar crash no Dyad/preview quando não existe .env, criamos um client "seguro".
// Se não estiver configurado, qualquer chamada de rede vai falhar rapidamente com uma mensagem clara.
const safeFetch: typeof fetch = (url, options) => {
  if (!isSupabaseConfigured) {
    return Promise.reject(
      new Error('Supabase não configurado: defina VITE_SUPABASE_URL e VITE_SUPABASE_PUBLISHABLE_KEY no .env')
    );
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);

  return fetch(url, {
    ...options,
    signal: controller.signal,
  }).finally(() => clearTimeout(timeoutId));
};

export const supabase = createClient<Database>(
  isSupabaseConfigured ? SUPABASE_URL : 'http://localhost:54321',
  isSupabaseConfigured ? SUPABASE_PUBLISHABLE_KEY : 'public-anon-key',
  {
    auth: isSupabaseConfigured
      ? {
          storage: localStorage,
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
          flowType: 'pkce',
        }
      : {
          // Sem config, não persiste nada para evitar erros em ambientes de preview
          persistSession: false,
          autoRefreshToken: false,
          detectSessionInUrl: false,
        },
    global: {
      headers: {
        'x-application-name': 'mandai',
      },
      fetch: safeFetch,
    },
  }
);
