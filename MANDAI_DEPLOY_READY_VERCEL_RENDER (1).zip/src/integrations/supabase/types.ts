export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      deliveries: {
        Row: {
          created_at: string | null
          customer_name: string
          delivery_address: string
          delivery_lat: number | null
          delivery_lng: number | null
          delivery_time: string | null
          driver_id: string | null
          id: string
          not_delivered_reason: string | null
          notes: string | null
          photo_url: string | null
          pickup_address: string
          pickup_lat: number | null
          pickup_lng: number | null
          pickup_time: string | null
          status: Database["public"]["Enums"]["delivery_status"] | null
          tracking_number: string
          updated_at: string | null
          value: number | null
        }
        Insert: {
          created_at?: string | null
          customer_name: string
          delivery_address: string
          delivery_lat?: number | null
          delivery_lng?: number | null
          delivery_time?: string | null
          driver_id?: string | null
          id?: string
          not_delivered_reason?: string | null
          notes?: string | null
          photo_url?: string | null
          pickup_address: string
          pickup_lat?: number | null
          pickup_lng?: number | null
          pickup_time?: string | null
          status?: Database["public"]["Enums"]["delivery_status"] | null
          tracking_number: string
          updated_at?: string | null
          value?: number | null
        }
        Update: {
          created_at?: string | null
          customer_name?: string
          delivery_address?: string
          delivery_lat?: number | null
          delivery_lng?: number | null
          delivery_time?: string | null
          driver_id?: string | null
          id?: string
          not_delivered_reason?: string | null
          notes?: string | null
          photo_url?: string | null
          pickup_address?: string
          pickup_lat?: number | null
          pickup_lng?: number | null
          pickup_time?: string | null
          status?: Database["public"]["Enums"]["delivery_status"] | null
          tracking_number?: string
          updated_at?: string | null
          value?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "deliveries_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_feedback: {
        Row: {
          comment: string | null
          created_at: string | null
          customer_name: string | null
          delivery_id: string
          driver_id: string
          driver_name: string | null
          id: string
          rating: number
        }
        Insert: {
          comment?: string | null
          created_at?: string | null
          customer_name?: string | null
          delivery_id: string
          driver_id: string
          driver_name?: string | null
          id?: string
          rating: number
        }
        Update: {
          comment?: string | null
          created_at?: string | null
          customer_name?: string | null
          delivery_id?: string
          driver_id?: string
          driver_name?: string | null
          id?: string
          rating?: number
        }
        Relationships: [
          {
            foreignKeyName: "delivery_feedback_delivery_id_fkey"
            columns: ["delivery_id"]
            isOneToOne: false
            referencedRelation: "deliveries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "delivery_feedback_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      freight_bids: {
        Row: {
          bid_amount: number
          bid_status: Database["public"]["Enums"]["freight_bid_status"]
          created_at: string
          driver_id: string
          id: string
          request_id: string
          updated_at: string
        }
        Insert: {
          bid_amount: number
          bid_status?: Database["public"]["Enums"]["freight_bid_status"]
          created_at?: string
          driver_id: string
          id?: string
          request_id: string
          updated_at?: string
        }
        Update: {
          bid_amount?: number
          bid_status?: Database["public"]["Enums"]["freight_bid_status"]
          created_at?: string
          driver_id?: string
          id?: string
          request_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "freight_bids_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "freight_bids_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "freight_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      freight_requests: {
        Row: {
          accepted_bid_id: string | null
          client_id: string
          created_at: string
          dropoff_address: string
          estimated_distance_km: number
          estimated_value: number
          id: string
          item_description: string
          item_dimensions: string | null
          item_weight: number | null
          pickup_address: string
          status: Database["public"]["Enums"]["freight_request_status"]
          updated_at: string
        }
        Insert: {
          accepted_bid_id?: string | null
          client_id: string
          created_at?: string
          dropoff_address: string
          estimated_distance_km: number
          estimated_value: number
          id?: string
          item_description: string
          item_dimensions?: string | null
          item_weight?: number | null
          pickup_address: string
          status?: Database["public"]["Enums"]["freight_request_status"]
          updated_at?: string
        }
        Update: {
          accepted_bid_id?: string | null
          client_id?: string
          created_at?: string
          dropoff_address?: string
          estimated_distance_km?: number
          estimated_value?: number
          id?: string
          item_description?: string
          item_dimensions?: string | null
          item_weight?: number | null
          pickup_address?: string
          status?: Database["public"]["Enums"]["freight_request_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "freight_requests_accepted_bid_id_fkey"
            columns: ["accepted_bid_id"]
            isOneToOne: false
            referencedRelation: "freight_bids"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "freight_requests_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string | null
          delivery_id: string | null
          driver_id: string | null
          id: string
          message: string
          read: boolean | null
          title: string
          type: string | null
        }
        Insert: {
          created_at?: string | null
          delivery_id?: string | null
          driver_id?: string | null
          id?: string
          message: string
          read?: boolean | null
          title: string
          type?: string | null
        }
        Update: {
          created_at?: string | null
          delivery_id?: string | null
          driver_id?: string | null
          id?: string
          message?: string
          read?: boolean | null
          title?: string
          type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notifications_delivery_id_fkey"
            columns: ["delivery_id"]
            isOneToOne: false
            referencedRelation: "deliveries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          ano_veiculo: string | null
          bairro: string | null
          cep: string | null
          cidade: string | null
          cnh_url: string | null
          complemento: string | null
          comprovante_endereco_url: string | null
          cor_veiculo: string | null
          cpf: string
          created_at: string | null
          data_nascimento: string | null
          documento_veiculo_url: string | null
          email: string
          estado: string | null
          id: string
          marca_veiculo: string | null
          modelo_veiculo: string | null
          nav_preference: string | null
          nome_completo: string
          numero: string | null
          overlay_enabled: boolean | null
          placa_veiculo: string | null
          push_token: string | null
          rg: string | null
          rua: string | null
          status: string | null
          telefone: string
          tipo_veiculo: Database["public"]["Enums"]["vehicle_type"] | null
          updated_at: string | null
        }
        Insert: {
          ano_veiculo?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          cnh_url?: string | null
          complemento?: string | null
          comprovante_endereco_url?: string | null
          cor_veiculo?: string | null
          cpf: string
          created_at?: string | null
          data_nascimento?: string | null
          documento_veiculo_url?: string | null
          email: string
          estado?: string | null
          id: string
          marca_veiculo?: string | null
          modelo_veiculo?: string | null
          nav_preference?: string | null
          nome_completo: string
          numero?: string | null
          overlay_enabled?: boolean | null
          placa_veiculo?: string | null
          push_token?: string | null
          rg?: string | null
          rua?: string | null
          status?: string | null
          telefone: string
          tipo_veiculo?: Database["public"]["Enums"]["vehicle_type"] | null
          updated_at?: string | null
        }
        Update: {
          ano_veiculo?: string | null
          bairro?: string | null
          cep?: string | null
          cidade?: string | null
          cnh_url?: string | null
          complemento?: string | null
          comprovante_endereco_url?: string | null
          cor_veiculo?: string | null
          cpf?: string
          created_at?: string | null
          data_nascimento?: string | null
          documento_veiculo_url?: string | null
          email?: string
          estado?: string | null
          id?: string
          marca_veiculo?: string | null
          modelo_veiculo?: string | null
          nav_preference?: string | null
          nome_completo?: string
          numero?: string | null
          overlay_enabled?: boolean | null
          placa_veiculo?: string | null
          push_token?: string | null
          rg?: string | null
          rua?: string | null
          status?: string | null
          telefone?: string
          tipo_veiculo?: Database["public"]["Enums"]["vehicle_type"] | null
          updated_at?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      withdrawals: {
        Row: {
          amount: number
          created_at: string | null
          driver_id: string
          id: string
          pix_key: string | null
          pix_key_type: string | null
          processed_at: string | null
          rejection_reason: string | null
          requested_at: string
          status: string
          updated_at: string | null
        }
        Insert: {
          amount: number
          created_at?: string | null
          driver_id: string
          id?: string
          pix_key?: string | null
          pix_key_type?: string | null
          processed_at?: string | null
          rejection_reason?: string | null
          requested_at?: string
          status?: string
          updated_at?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          driver_id?: string
          id?: string
          pix_key?: string | null
          pix_key_type?: string | null
          processed_at?: string | null
          rejection_reason?: string | null
          requested_at?: string
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "withdrawals_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      rates_config: {
        Row: {
          id: string
          value_per_km: number
          min_time_minutes: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          value_per_km?: number
          min_time_minutes?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          value_per_km?: number
          min_time_minutes?: number
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      peak_hours: {
        Row: {
          id: string
          day_of_week: string
          start_time: string
          end_time: string
          multiplier: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          day_of_week: string
          start_time: string
          end_time: string
          multiplier?: number
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      delivery_zones: {
        Row: {
          id: string
          name: string
          description: string | null
          coordinates: Json | null
          extra_fee: number
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          coordinates?: Json | null
          extra_fee?: number
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          coordinates?: Json | null
          extra_fee?: number
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      promotions: {
        Row: {
          id: string
          code: string
          type: string
          value: number
          min_order_value: number | null
          max_discount_amount: number | null
          usage_limit: number | null
          used_count: number | null
          expires_at: string | null
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          code: string
          type: string
          value: number
          min_order_value?: number | null
          max_discount_amount?: number | null
          usage_limit?: number | null
          used_count?: number | null
          expires_at?: string | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          code?: string
          type?: string
          value?: number
          min_order_value?: number | null
          max_discount_amount?: number | null
          usage_limit?: number | null
          used_count?: number | null
          expires_at?: string | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_tracking_number: { Args: never; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "driver"
      delivery_status:
        | "pending"
        | "picked_up"
        | "in_transit"
        | "delivered"
        | "not_delivered"
        | "cancelled"
      vehicle_type: "moto" | "carro" | "bicicleta" | "van" | "caminhao"
      freight_request_status:
        | "pending_bids"
        | "bidding_closed"
        | "accepted"
        | "in_transit"
        | "completed"
        | "cancelled"
      freight_bid_status: "pending" | "accepted" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "driver"],
      delivery_status: [
        "pending",
        "picked_up",
        "in_transit",
        "delivered",
        "not_delivered",
        "cancelled",
      ],
      vehicle_type: ["moto", "carro", "bicicleta", "van", "caminhao"],
      freight_request_status: [
        "pending_bids",
        "bidding_closed",
        "accepted",
        "in_transit",
        "completed",
        "cancelled",
      ],
      freight_bid_status: ["pending", "accepted", "rejected"],
    },
  },
} as const