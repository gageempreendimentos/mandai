import { useSyncExternalStore } from "react";
import { getRide, subscribe, type Ride } from "./rideState";

export function useRide(): Ride {
  return useSyncExternalStore(subscribe, getRide, getRide);
}
