export type RideStage = "idle" | "offered" | "accepted" | "enroute" | "completed";

export type Ride = {
  id: string;
  /** Número do pedido/ticket visível para todos (pode ser diferente do id interno). */
  ticket?: string;
  pickup: string;
  dropoff: string;
  /** Coordenadas (quando disponíveis pelo backend/realtime). */
  pickup_lat?: number;
  pickup_lng?: number;
  dropoff_lat?: number;
  dropoff_lng?: number;
  /** Lista de paradas (modo restaurante premium). Se definido, dropoff representa a parada atual. */
  stops?: string[];
  /** Índice da parada atual (0-based). */
  stopIndex?: number;
  /** Data/hora de agendamento (quando o restaurante agenda a entrega). */
  scheduledAt?: string;
  /** Avisos operacionais para o entregador (ex.: levar troco/maquininha, itens gelados). */
  alerts?: {
    coldItems?: boolean;
    carryChange?: boolean;
    carryCardMachine?: boolean;
    notes?: string;
  };
  price: number;
  stage: RideStage;
  etaMin: number;
};

const STORAGE_KEY = "mandai:ride";

const defaultRide: Ride = {
  id: "1029",
  ticket: "TKT-1029",
  pickup: "Centro",
  dropoff: "Santa Luzia",
  stops: ["Santa Luzia"],
  stopIndex: 0,
  alerts: {
    coldItems: true,
    carryChange: false,
    carryCardMachine: true,
    notes: "Levar gelo/bolsa térmica e maquininha.",
  },
  price: 18,
  stage: "offered",
  etaMin: 7,
};

type Listener = () => void;
const listeners = new Set<Listener>();

const bc = typeof BroadcastChannel !== "undefined" ? new BroadcastChannel("mandai:ride") : null;
bc?.addEventListener("message", () => {
  // another tab updated ride
  emit();
  bc?.postMessage({ t: Date.now() });
});

function emit() {
  listeners.forEach((l) => l());
}

export function subscribe(listener: Listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getRide(): Ride {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultRide;
    return { ...defaultRide, ...JSON.parse(raw) } as Ride;
  } catch {
    return defaultRide;
  }
}

export function setRide(next: Ride) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {}
  emit();
  bc?.postMessage({ t: Date.now() });
}

export function updateRide(patch: Partial<Ride>) {
  const cur = getRide();
  setRide({ ...cur, ...patch });
}

export function resetRide() {
  setRide(defaultRide);
}
