import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import ErrorBoundary from './components/ErrorBoundary';
import './index.css';
import { registerServiceWorker } from './lib/serviceWorker';
import { logError } from './lib/logger';
import { wsConnect } from "@/lib/wsClient";
import { initSentry } from "@/lib/sentry";

const removeSplash = () => {
  const splash = document.getElementById('mandai-splash');
  if (!splash) return;
  splash.classList.add('mandai-splash--hide');
  window.setTimeout(() => splash.remove(), 260);
};


window.addEventListener('error', (event) => {
  // @ts-expect-error - event.error may be unknown
  logError(event.error ?? event.message, { source: 'window.error' });
});

window.addEventListener('unhandledrejection', (event) => {
  // @ts-expect-error - event.reason may be unknown
  logError(event.reason, { source: 'unhandledrejection' });
});

// Service Worker
// - Em DEV: desregistra para evitar cache atrapalhando layout/splash.
// - Em PROD: registra normalmente (se você quiser offline/cache).
if ('serviceWorker' in navigator) {
  if (import.meta.env.PROD) {
initSentry();
    registerServiceWorker();
  } else {
    navigator.serviceWorker.getRegistrations?.().then((regs) => {
      regs.forEach((reg) => reg.unregister());
    }).catch(() => {});
  }
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);

// Remove o splash SOMENTE quando a primeira tela real estiver montada
// (evita aparecer o RouteFallback/Logo por alguns frames).
const onReady = () => {
  window.removeEventListener('mandai:app-ready', onReady);
  removeSplash();
};
window.addEventListener('mandai:app-ready', onReady, { once: true });

// Segurança: se por algum motivo não disparar, remove após alguns segundos.
window.setTimeout(() => removeSplash(), 6000);
