import React, { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from "@/components/Logo";
import { motion, useReducedMotion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { setSession } from "@/lib/authLite";

const API_BASE = (import.meta.env.VITE_API_BASE as string) || "http://localhost:8080";

type Role = "driver" | "client" | "restaurant" | "admin";

export default function Login() {
  const reduceMotion = useReducedMotion();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const role = (params.get("role") as Role) || "driver";
  const next = params.get("next");

  const [identifier, setIdentifier] = useState("");
  const [pin, setPin] = useState("");
  const [loading, setLoading] = useState(false);

  const copy = useMemo(() => {
    switch (role) {
      case "driver":
        return { title: "Entrar como Entregador", label: "CPF", placeholder: "Digite seu CPF" };
      case "client":
        return { title: "Entrar como Cliente", label: "Telefone", placeholder: "Digite seu telefone" };
      case "restaurant":
        return { title: "Entrar como Restaurante", label: "CNPJ/ID", placeholder: "Digite o identificador do restaurante" };
      case "admin":
        return { title: "Entrar como Admin", label: "PIN", placeholder: "Digite o PIN do admin" };
      default:
        return { title: "Entrar", label: "Identificador", placeholder: "Digite seu identificador" };
    }
  }, [role]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const body: any = { role };
      if (role === "admin") body.pin = pin;
      else body.identifier = identifier;

      const res = await fetch(`${API_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || "login_failed");

      setSession(role, data.access_token, data.sub);

      if (next) {
        try {
          navigate(decodeURIComponent(next), { replace: true });
          return;
        } catch {
          // fall through
        }
      }

      if (role === "driver") navigate("/driver", { replace: true });
      else if (role === "client") navigate("/client", { replace: true });
      else if (role === "restaurant") navigate("/restaurant", { replace: true });
      else navigate("/admin", { replace: true });
    } catch (err: any) {
      console.error(err);
      alert(String(err?.message || err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <motion.div
      className="min-h-screen flex items-center justify-center p-4 bg-white"
      initial={reduceMotion ? false : { opacity: 0, y: 10 }}
      animate={reduceMotion ? {} : { opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
    >
      <Card className="w-full max-w-md shadow-lg rounded-3xl">
        <CardHeader>
          <div className="flex justify-center pb-2">
            <Logo size="lg" variant="login" />
          </div>
          <CardTitle className="text-center text-3xl font-extrabold tracking-tight">
            MANDAI
          </CardTitle>
          <p className="text-center text-sm text-muted-foreground">{copy.title}</p>
        </CardHeader>

        <CardContent className="space-y-4">
          <form className="space-y-4" onSubmit={onSubmit}>
            {role !== "admin" ? (
              <div className="space-y-2">
                <Label>{copy.label}</Label>
                <Input value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder={copy.placeholder} />
              </div>
            ) : (
              <div className="space-y-2">
                <Label>{copy.label}</Label>
                <Input type="password" value={pin} onChange={(e) => setPin(e.target.value)} placeholder={copy.placeholder} />
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Entrando..." : "Entrar"}
            </Button>

            <div className="flex justify-center gap-2 pt-2">
              <Button type="button" variant="ghost" onClick={() => navigate("/", { replace: true })}>
                Voltar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
}
