import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function TermsGate() {
  const [docs, setDocs] = useState<any[]>([]);
  const [accepted, setAccepted] = useState<Record<string, boolean>>({});
  const [msg, setMsg] = useState("");

  useEffect(()=>{ fetchJSON("/terms/current").then((d)=>setDocs(d.docs||[])).catch(()=>{}); }, []);

  const required = docs.filter(d=>["terms","privacy"].includes(d.doc_type));

  return (
    <div className="p-4 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Aceite de Termos</h1>
      <div className="text-sm opacity-70">
        Para continuar usando o MANDAI, você precisa aceitar os documentos abaixo.
      </div>

      {required.map((d)=>(
        <div key={d.doc_type} className="rounded-2xl border p-4 space-y-2">
          <div className="flex items-center justify-between gap-3">
            <div className="font-medium">{d.title} ({d.version})</div>
            <label className="text-sm flex items-center gap-2">
              <input type="checkbox" checked={!!accepted[d.doc_type]} onChange={(e)=>setAccepted(a=>({ ...a, [d.doc_type]: e.target.checked }))} />
              Aceito
            </label>
          </div>
          <div className="text-sm whitespace-pre-wrap opacity-90">{d.content_md}</div>
        </div>
      ))}

      <button
        className="rounded-xl border px-4 py-2"
        onClick={async()=>{
          setMsg("");
          const ok = required.every(d=>accepted[d.doc_type]);
          if (!ok) { setMsg("Você precisa aceitar todos os documentos."); return; }
          await postJSON("/terms/accept", { accept: required.map(d=>({ doc_type:d.doc_type, version:d.version })) });
          location.href = "/onboarding";
        }}
      >
        Continuar
      </button>

      {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
    </div>
  );
}
