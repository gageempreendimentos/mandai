import Logo from "@/assets/mandai_logo.jpg";
import React from "react";

export default function LandingHome() {
  return (
    <div className="min-h-screen p-6 flex flex-col items-center justify-center gap-6">
      <div className="max-w-2xl text-center space-y-3">
        <div className="flex items-center justify-center gap-3">
          <img src={Logo} alt="MANDAI" className="h-14 w-14 rounded-2xl object-cover border" />
          <h1 className="text-4xl font-bold">MANDAI Entregas</h1>
        </div>
        <p className="text-base opacity-80">
          A plataforma completa de entregas e fretes: restaurante, cliente, entregador e admin em um só lugar.
        </p>
        <div className="flex gap-3 justify-center flex-wrap">
          <a className="rounded-xl border px-4 py-2" href="/landing/restaurante">Sou Restaurante</a>
          <a className="rounded-xl border px-4 py-2" href="/landing/entregador">Sou Entregador</a>
          <a className="rounded-xl border px-4 py-2" href="/client/login">Entrar</a>
        </div>
      </div>
      <div className="max-w-3xl grid md:grid-cols-3 gap-3 w-full">
        {["Sem taxa abusiva","Rastreamento em tempo real","Operação profissional"].map((t)=>(
          <div key={t} className="rounded-2xl border p-4">
            <div className="font-medium">{t}</div>
            <div className="text-sm opacity-70 mt-1">Pronto para sua cidade.</div>
          </div>
        ))}
      </div>
    </div>
  );
}
