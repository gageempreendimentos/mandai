import React from "react";

export default function LandingDriver() {
  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Para Entregadores</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <div className="font-medium">Ganhe mais com o MANDAI</div>
        <ul className="list-disc pl-5 text-sm opacity-80 space-y-1">
          <li>Receba corridas em tempo real</li>
          <li>Navegação integrada</li>
          <li>Saque PIX (estrutura pronta)</li>
        </ul>
      </div>
      <div className="flex gap-3 flex-wrap">
        <a className="rounded-xl border px-4 py-2" href="/driver/login">Entrar</a>
        <a className="rounded-xl border px-4 py-2" href="https://wa.me/55">Cadastrar via WhatsApp</a>
        <a className="rounded-xl border px-4 py-2" href="/landing">Voltar</a>
      </div>
    </div>
  );
}
