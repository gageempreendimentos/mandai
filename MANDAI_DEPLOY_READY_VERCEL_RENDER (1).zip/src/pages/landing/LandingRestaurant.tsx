import React from "react";

export default function LandingRestaurant() {
  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">Para Restaurantes</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <div className="font-medium">Vantagens</div>
        <ul className="list-disc pl-5 text-sm opacity-80 space-y-1">
          <li>Receba pedidos e acompanhe status</li>
          <li>Sem taxa sobre a venda (configurável)</li>
          <li>Relatórios e suporte no painel</li>
        </ul>
      </div>
      <div className="flex gap-3 flex-wrap">
        <a className="rounded-xl border px-4 py-2" href="/restaurant/login">Acessar painel</a>
        <a className="rounded-xl border px-4 py-2" href="https://wa.me/55">Falar no WhatsApp</a>
        <a className="rounded-xl border px-4 py-2" href="/landing">Voltar</a>
      </div>
    </div>
  );
}
