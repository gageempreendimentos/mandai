import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}

export default function RestaurantOrders() {
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(()=>{
    fetchJSON("/restaurants2/me/orders").then(d=>setOrders(d.orders||[]));
  }, []);

  return (
    <div className="p-4 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Pedidos</h1>
      <div className="rounded-2xl border overflow-hidden">
        {orders.length===0 ? <div className="p-4 opacity-70">Sem pedidos ainda.</div> : null}
        {orders.map((o)=>(
          <div key={o.id} className="p-4 border-b last:border-b-0">
            <div className="font-medium">{o.status}</div>
            <div className="text-xs opacity-70">{o.pickup?.address || "Coleta"} → {o.dropoff?.address || "Entrega"}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
