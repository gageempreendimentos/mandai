import { prefetchRoutes } from '@/lib/prefetch';
import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import AppHeader from "@/components/layout/AppHeader";

export default function Entry() {
  useEffect(() => { window.dispatchEvent(new Event('mandai:app-ready')); }, []);
  useEffect(() => {
    // Prefetch is opt-in (helps on Wi‑Fi in PROD, but can slow down local/dev).
    // Enable by setting VITE_PREFETCH=true
    if (import.meta.env.VITE_PREFETCH === "true") {
      prefetchRoutes([
        () => import("@/pages/DashboardReal"),
        () => import("@/pages/ClientDashboard"),
        () => import("@/pages/RestaurantDashboard"),
        () => import("@/pages/admin/AdminDashboard"),
      ]);
    }

  }, []);

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <AppHeader title="Escolha a área" subtitle="Visual estilo Uber" />
      <div className="mx-auto max-w-screen-md px-4 py-4 pb-28">
      <div className="w-full max-w-3xl space-y-4">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-extrabold tracking-tight">MANDAI</h1>
          <p className="text-muted-foreground">
            Escolha como você quer entrar
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card className="rounded-3xl shadow-lg">
            <CardHeader>
              <CardTitle>Entregador</CardTitle>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full">
                <Link to="/login?role=driver">Entrar</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="rounded-3xl shadow-lg">
            <CardHeader>
              <CardTitle>Admin</CardTitle>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full" variant="secondary">
                <Link to="/login?role=admin">Entrar</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="rounded-3xl shadow-lg">
            <CardHeader>
              <CardTitle>Restaurante</CardTitle>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full" variant="secondary">
                <Link to="/login?role=restaurant">Entrar</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="rounded-3xl shadow-lg">
            <CardHeader>
              <CardTitle>Cliente</CardTitle>
            </CardHeader>
            <CardContent>
              <Button asChild className="w-full" variant="secondary">
                <Link to="/login?role=client">Entrar</Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        <p className="text-xs text-muted-foreground text-center">
          No Dyad, use URLs com <b>#</b> (ex: <b>#/admin</b>).
        </p>
      </div>
          </div>
    </div>
  );
}