import React, { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Lock, Mail } from "lucide-react";
import Logo from "@/components/Logo";

const RestaurantLogin: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const reduceMotion = useReducedMotion();

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (!email || !senha) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha e-mail e senha",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password: senha,
      });
      if (error) throw error;

      // Check restaurant role (optional – keeps the app safer)
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error("Falha no login");

      const { data: role, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "restaurant")
        .single();

      if (roleError || !role) {
        await supabase.auth.signOut();
        throw new Error("Acesso negado. Você não é um restaurante.");
      }

      toast({
        title: "Login realizado! ✅",
        description: "Bem-vindo ao painel do restaurante",
      });

      navigate("/restaurant-dashboard");
    } catch (e: any) {
      toast({
        title: "Erro ao fazer login",
        description: e?.message || "Verifique suas credenciais",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background (food/kitchen vibe without external images) */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(255,170,0,0.28),transparent_55%),radial-gradient(circle_at_80%_45%,rgba(255,80,80,0.20),transparent_55%),radial-gradient(circle_at_35%_85%,rgba(0,0,0,0.35),transparent_55%),linear-gradient(180deg,rgba(10,20,35,0.75),rgba(10,20,35,0.65))]" />
        <div className="absolute inset-0 backdrop-blur-[2px]" />
      </div>

      <motion.div
        className="relative z-10 min-h-screen flex flex-col items-center"
        initial={reduceMotion ? false : { opacity: 0, y: 10 }}
        animate={reduceMotion ? {} : { opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="pt-10 pb-6 text-center">
          <div className="flex justify-center">
            <Logo size="lg" variant="login" />
          </div>
          <div className="mt-2 text-4xl font-extrabold tracking-tight text-white">MANDAI</div>
          <div className="mt-1 text-xl font-bold tracking-wide text-amber-400">RESTAURANTE</div>
          <div className="mt-8 text-xl text-white/85">Faça login para continuar.</div>
        </div>

        <div className="w-full px-5 pb-10">
          <div className="mx-auto max-w-md rounded-3xl bg-white/10 border border-white/15 shadow-[var(--mandai-shadow)] p-6 backdrop-blur-sm">
            <div className="space-y-3">
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/60" />
                <Input
                  type="email"
                  placeholder="restaurante@exemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-12 pl-10 rounded-2xl bg-white/10 border-white/15 text-white placeholder:text-white/45"
                />
              </div>

              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/60" />
                <Input
                  type="password"
                  placeholder="Senha"
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  className="h-12 pl-10 rounded-2xl bg-white/10 border-white/15 text-white placeholder:text-white/45"
                />
              </div>
            </div>

            <Button
              variant="hero"
              size="lg"
              className="w-full mt-5 rounded-2xl bg-amber-500 hover:bg-amber-500/90 text-white"
              onClick={handleSubmit}
              disabled={isLoading}
            >
              {isLoading ? "Entrando..." : "Entrar"}
            </Button>

            <p className="text-center text-sm text-white/70 mt-4">
              Não tem conta?{" "}
              <a href="/restaurant-register" className="text-white underline underline-offset-4 hover:opacity-90">
                Cadastrar restaurante
              </a>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default RestaurantLogin;
