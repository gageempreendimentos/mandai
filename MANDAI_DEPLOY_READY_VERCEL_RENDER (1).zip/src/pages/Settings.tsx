import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import SideMenu from "@/components/SideMenu";
import { Button } from "@/components/ui/button";
import MapWithSheet from "@/components/layout/MapWithSheet";
import SurfaceCard from "@/components/layout/SurfaceCard";

export default function SettingsPage() {
  useEffect(() => { window.dispatchEvent(new Event("mandai:app-ready")); }, []);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />
      <MapWithSheet
        title="Configurações"
        subtitle="Preferências"
        right={
          <div className="flex items-center gap-2">
            <Button asChild variant="outline" className="rounded-2xl">
              <Link to="/driver">Voltar</Link>
            </Button>
            <Button variant="outline" className="rounded-2xl" onClick={() => setMenuOpen(true)}>
              Menu
            </Button>
          </div>
        }
      >
        
<div className="space-y-3">
  <SurfaceCard>
    <div className="text-sm font-semibold">Notificações</div>
    <div className="mt-3 grid grid-cols-2 gap-2">
      <Button variant="outline" className="rounded-2xl">Som</Button>
      <Button variant="outline" className="rounded-2xl">Vibração</Button>
      <Button variant="outline" className="rounded-2xl">Silencioso</Button>
      <Button variant="outline" className="rounded-2xl">Alto</Button>
    </div>
  </SurfaceCard>

  <SurfaceCard>
    <div className="text-sm font-semibold">Privacidade</div>
    <div className="mt-2 text-sm text-black/60">Permissões e dados do app.</div>
  </SurfaceCard>
</div>

      </MapWithSheet>
    </>
  );
}
