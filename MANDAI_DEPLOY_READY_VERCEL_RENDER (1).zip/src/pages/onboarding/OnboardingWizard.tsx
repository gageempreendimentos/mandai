import React, { useEffect, useMemo, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

// We infer role from localStorage token payload in this project style (best effort)
function getRole() {
  try {
    const raw = localStorage.getItem("auth");
    if (!raw) return "client";
    const a = JSON.parse(raw);
    return a?.role || "client";
  } catch { return "client"; }
}

const stepsByRole: Record<string, string[]> = {
  driver: [
    "Permita acesso à localização (GPS).",
    "Fique ONLINE para receber entregas.",
    "Aceite uma entrega quando aparecer.",
    "Clique em Iniciar rota para navegar.",
    "Finalize a entrega e confirme."
  ],
  restaurant: [
    "Revise seus dados e horários.",
    "Quando chegar pedido, confirme o preparo.",
    "Acompanhe o status até sair para entrega."
  ],
  admin: [
    "Crie zonas e políticas.",
    "Cadastre restaurantes.",
    "Ative dispatch e monitore operações."
  ],
  client: [
    "Confira seu telefone e endereço.",
    "Crie um pedido.",
    "Acompanhe o entregador no mapa."
  ]
};

export default function OnboardingWizard() {
  const role = useMemo(()=>getRole(), []);
  const steps = stepsByRole[role] || stepsByRole.client;
  const [step, setStep] = useState(0);

  useEffect(()=>{
    fetchJSON("/onboarding/me").then((d)=>setStep(Number(d.onboarding_step||0))).catch(()=>{});
  }, []);

  const done = step >= steps.length;

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Bem-vindo!</h1>
      <div className="text-sm opacity-70">Onboarding rápido ({role})</div>

      <div className="rounded-2xl border p-4 space-y-3">
        {!done ? (
          <>
            <div className="text-sm opacity-70">Passo {step+1} de {steps.length}</div>
            <div className="text-lg font-medium">{steps[step]}</div>
            <div className="flex gap-2">
              <button className="rounded-xl border px-3 py-2" disabled={step===0} onClick={()=>setStep(s=>Math.max(0,s-1))}>Voltar</button>
              <button className="rounded-xl border px-3 py-2" onClick={()=>setStep(s=>s+1)}>Próximo</button>
            </div>
          </>
        ) : (
          <>
            <div className="text-lg font-medium">Tudo pronto ✅</div>
            <button className="rounded-xl border px-3 py-2" onClick={async()=>{
              await postJSON("/onboarding/me", { onboarding_step: steps.length, onboarding_done: true });
              // send user to their home
              if (role==="admin") location.href="/admin";
              else if (role==="restaurant") location.href="/restaurant";
              else if (role==="driver") location.href="/driver";
              else location.href="/client";
            }}>Entrar no app</button>
          </>
        )}
      </div>

      <div className="text-xs opacity-60">
        Você pode pular depois; o sistema salva seu progresso.
      </div>
    </div>
  );
}
