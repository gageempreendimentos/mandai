import React, { useState } from "react";

async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

type Stop = { address: string };

export default function ClientFreightNew() {
  const [pickup, setPickup] = useState("");
  const [pickupLat, setPickupLat] = useState("");
  const [pickupLng, setPickupLng] = useState("");
  const [dropoff, setDropoff] = useState("");
  const [dropLat, setDropLat] = useState("");
  const [dropLng, setDropLng] = useState("");
  const [stops, setStops] = useState<Stop[]>([]);
  const [km, setKm] = useState(5);
  const [vehicle, setVehicle] = useState<"carro"|"van"|"caminhao">("carro");
  const [weight, setWeight] = useState(30);
  const [helpers, setHelpers] = useState(0);
  const [stairs, setStairs] = useState(false);

  const [waitMin, setWaitMin] = useState(0);
  const [insurance, setInsurance] = useState(false);
  const [declared, setDeclared] = useState(0);
  const [priority, setPriority] = useState(false);
  const [fragile, setFragile] = useState(false);

  const [windowStart, setWindowStart] = useState("");
  const [windowEnd, setWindowEnd] = useState("");

  const [msg, setMsg] = useState("");

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Solicitar Frete</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="Coleta (endereço)" value={pickup} onChange={(e)=>setPickup(e.target.value)} />
        <div className="grid grid-cols-2 gap-2">
          <input className="border rounded-xl px-3 py-2" placeholder="Coleta lat (opcional)" value={pickupLat} onChange={(e)=>setPickupLat(e.target.value)} />
          <input className="border rounded-xl px-3 py-2" placeholder="Coleta lng (opcional)" value={pickupLng} onChange={(e)=>setPickupLng(e.target.value)} />
        </div>
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="Entrega final (endereço)" value={dropoff} onChange={(e)=>setDropoff(e.target.value)} />
        <div className="grid grid-cols-2 gap-2">
          <input className="border rounded-xl px-3 py-2" placeholder="Entrega lat (opcional)" value={dropLat} onChange={(e)=>setDropLat(e.target.value)} />
          <input className="border rounded-xl px-3 py-2" placeholder="Entrega lng (opcional)" value={dropLng} onChange={(e)=>setDropLng(e.target.value)} />
        </div>

        <div className="text-sm font-medium mt-2">Paradas (opcional)</div>
        <div className="space-y-2">
          {stops.map((s,i)=>(
            <div key={i} className="flex gap-2">
              <input className="border rounded-xl px-3 py-2 flex-1" placeholder={`Parada ${i+1}`} value={s.address} onChange={(e)=>{
                const v=e.target.value; setStops(arr=>arr.map((x,ix)=> ix===i ? { ...x, address:v } : x));
              }} />
              <button className="rounded-xl border px-3 py-2" onClick={()=>setStops(arr=>arr.filter((_,ix)=>ix!==i))}>X</button>
            </div>
          ))}
          {stops.length < 3 ? <button className="rounded-xl border px-3 py-2 text-sm" onClick={()=>setStops(arr=>[...arr,{ address:"" }])}>+ Add parada</button> : null}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <div className="text-xs opacity-70 mb-1">Distância (km)</div>
            <button type="button" className="mt-1 text-xs underline opacity-70" onClick={async()=>{
              const a=[Number(pickupLat),Number(pickupLng),Number(dropLat),Number(dropLng)];
              if (!a.every(Number.isFinite)) return;
              const r = await fetch(`/maps/route?from_lat=${a[0]}&from_lng=${a[1]}&to_lat=${a[2]}&to_lng=${a[3]}`, { credentials:"include" });
              const j = await r.json();
              if (j?.ok) setKm(Number(j.distance_km.toFixed(2)));
            }}>calcular pelo mapa</button>
            <input type="number" className="border rounded-xl px-3 py-2 w-full" value={km} onChange={(e)=>setKm(Number(e.target.value))} />
          </div>
          <div>
            <div className="text-xs opacity-70 mb-1">Veículo</div>
            <select className="border rounded-xl px-3 py-2 w-full" value={vehicle} onChange={(e)=>setVehicle(e.target.value as any)}>
              <option value="carro">Carro</option>
              <option value="van">Van</option>
              <option value="caminhao">Caminhão</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <div className="text-xs opacity-70 mb-1">Peso (kg)</div>
            <input type="number" className="border rounded-xl px-3 py-2 w-full" value={weight} onChange={(e)=>setWeight(Number(e.target.value))} />
          </div>
          <div>
            <div className="text-xs opacity-70 mb-1">Ajudantes</div>
            <input type="number" className="border rounded-xl px-3 py-2 w-full" value={helpers} onChange={(e)=>setHelpers(Number(e.target.value))} />
          </div>
        </div>

        <label className="text-sm flex items-center gap-2">
          <input type="checkbox" checked={stairs} onChange={(e)=>setStairs(e.target.checked)} />
          Precisa subir escadas
        </label>

        <div className="rounded-xl border p-3 space-y-2">
          <div className="text-sm font-medium">Extras</div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div className="text-xs opacity-70 mb-1">Espera (min)</div>
              <input type="number" className="border rounded-xl px-3 py-2 w-full" value={waitMin} onChange={(e)=>setWaitMin(Number(e.target.value))} />
            </div>
            <div>
              <div className="text-xs opacity-70 mb-1">Valor declarado (R$)</div>
              <input type="number" className="border rounded-xl px-3 py-2 w-full" value={declared} onChange={(e)=>setDeclared(Number(e.target.value))} />
            </div>
          </div>
          <label className="text-sm flex items-center gap-2">
            <input type="checkbox" checked={insurance} onChange={(e)=>setInsurance(e.target.checked)} />
            Seguro da carga
          </label>
          <label className="text-sm flex items-center gap-2">
            <input type="checkbox" checked={priority} onChange={(e)=>setPriority(e.target.checked)} />
            Prioridade
          </label>
          <label className="text-sm flex items-center gap-2">
            <input type="checkbox" checked={fragile} onChange={(e)=>setFragile(e.target.checked)} />
            Frágil
          </label>
        </div>

        <div className="rounded-xl border p-3 space-y-2">
          <div className="text-sm font-medium">Agendamento (janela)</div>
          <div className="grid grid-cols-2 gap-2">
            <input className="border rounded-xl px-3 py-2" placeholder="Início (ISO/AAAA-MM-DD HH:mm)" value={windowStart} onChange={(e)=>setWindowStart(e.target.value)} />
            <input className="border rounded-xl px-3 py-2" placeholder="Fim (ISO/AAAA-MM-DD HH:mm)" value={windowEnd} onChange={(e)=>setWindowEnd(e.target.value)} />
          </div>
          <div className="text-xs opacity-60">Se deixar vazio, vira “agora”.</div>
        </div>

        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          setMsg("");
          const r = await postJSON("/freight/create", {
            pickup: { address: pickup, lat: pickupLat ? Number(pickupLat) : undefined, lng: pickupLng ? Number(pickupLng) : undefined },
            dropoff: { address: dropoff, lat: dropLat ? Number(dropLat) : undefined, lng: dropLng ? Number(dropLng) : undefined },
            stops: stops.filter(s=>s.address?.trim()).map(s=>({ address: s.address })),
            distance_km: km,
            duration_min: Math.round(km*4),
            cargo_type: "geral",
            weight_kg: weight,
            helpers_needed: helpers,
            stairs,
            vehicle_type_hint: vehicle,
            wait_minutes: waitMin,
            insurance,
            declared_value_cents: Math.round((declared||0) * 100),
            priority,
            fragile,
            pickup_window_start: windowStart || null,
            pickup_window_end: windowEnd || null
          });
          if (r.ok) {
            const q=r.quote;
            setMsg(`Frete criado ✅ Ride: ${r.ride_id} | Base: R$ ${(q.total_cents/100).toFixed(2)} | Ofertas: min R$ ${(q.recommended.min_bid_cents/100).toFixed(2)} / max R$ ${(q.recommended.max_bid_cents/100).toFixed(2)}`);
          } else setMsg(`Erro: ${r.error || "unknown"}`);
        }}>
          Criar frete (base + ofertas)
        </button>

        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>
    </div>
  );
}
