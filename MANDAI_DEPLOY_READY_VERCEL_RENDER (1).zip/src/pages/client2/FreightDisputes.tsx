import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

export default function FreightDisputes() {
  const [sp] = useSearchParams();
  const [rideId, setRideId] = useState(sp.get("ride") || "");
  const [reason, setReason] = useState("carga_nao_corresponde");
  const [details, setDetails] = useState("");
  const [list, setList] = useState<any[]>([]);

  const load = async()=> {
    if (!rideId) return;
    const d = await fetchJSON(`/freight/${rideId}/disputes`);
    setList(d.disputes||[]);
  };

  useEffect(()=>{ load(); }, [rideId]);

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Disputas do Frete</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <div className="flex gap-2 flex-wrap">
          <input className="border rounded-xl px-3 py-2 flex-1 min-w-[240px]" placeholder="ride_id" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
          <button className="rounded-xl border px-3 py-2" onClick={load}>Atualizar</button>
        </div>

        <select className="border rounded-xl px-3 py-2 w-full" value={reason} onChange={(e)=>setReason(e.target.value)}>
          <option value="carga_nao_corresponde">Carga não corresponde</option>
          <option value="cliente_nao_apareceu">Cliente não apareceu</option>
          <option value="dano">Dano na carga</option>
          <option value="outro">Outro</option>
        </select>
        <textarea className="border rounded-xl px-3 py-2 w-full" rows={3} placeholder="Detalhes" value={details} onChange={(e)=>setDetails(e.target.value)} />
        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          if (!rideId) return;
          await postJSON(`/freight/${rideId}/disputes`, { reason, details });
          setDetails("");
          load();
        }}>Abrir disputa</button>

        <div className="space-y-2">
          {list.map((d)=>(
            <div key={d.id} className="rounded-xl border p-3">
              <div className="font-medium">{d.reason} • {d.status}</div>
              <div className="text-sm opacity-70">{d.details}</div>
              {d.resolution ? <div className="text-sm">Resolução: {d.resolution}</div> : null}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
