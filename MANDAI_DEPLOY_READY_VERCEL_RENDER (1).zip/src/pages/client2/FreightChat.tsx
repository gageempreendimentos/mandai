import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

export default function FreightChat() {
  const [sp] = useSearchParams();
  const [rideId, setRideId] = useState(sp.get("ride") || "");
  const [items, setItems] = useState<any[]>([]);
  const [text, setText] = useState("");
  const [file, setFile] = useState<File|null>(null);
  const [msg, setMsg] = useState("");

  const load = async () => {
    if (!rideId) return;
    const d = await fetchJSON(`/freight/${rideId}/chat`);
    setItems(d.messages||[]);
  };

  useEffect(()=>{ if (!rideId) return; load(); const t=setInterval(load, 2500); return ()=>clearInterval(t); }, [rideId]);

  const upload = async () => {
    if (!file) return null;
    const b64 = await new Promise<string>((resolve,reject)=>{
      const fr = new FileReader();
      fr.onload = ()=>resolve(String(fr.result));
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });
    const r = await postJSON("/uploads-api/base64", { kind:"chat", filename: file.name, base64_data: b64 });
    if (r.ok) return r.url;
    throw new Error(r.error||"upload_failed");
  };

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-3">
      <h1 className="text-2xl font-semibold">Chat do Frete</h1>

      <div className="rounded-2xl border p-3 space-y-2">
        <div className="flex gap-2 flex-wrap">
          <input className="border rounded-xl px-3 py-2 flex-1 min-w-[240px]" placeholder="ride_id" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
          <button className="rounded-xl border px-3 py-2" onClick={load}>Abrir</button>
        </div>

        <div className="h-[340px] overflow-auto rounded-xl border p-2 space-y-2 bg-white">
          {items.map((m)=>(
            <div key={m.id} className="text-sm">
              <div className="text-xs opacity-60">{m.sender_role} • {new Date(m.created_at).toLocaleString()}</div>
              {m.message ? <div>{m.message}</div> : null}
              {m.image_url ? <a className="underline text-xs" href={m.image_url} target="_blank">Ver imagem</a> : null}
            </div>
          ))}
        </div>

        <div className="grid gap-2">
          <input className="border rounded-xl px-3 py-2" placeholder="Mensagem" value={text} onChange={(e)=>setText(e.target.value)} />
          <input type="file" accept="image/*" className="border rounded-xl px-3 py-2" onChange={(e)=>setFile(e.target.files?.[0] || null)} />
          <button className="rounded-xl border px-3 py-2" onClick={async()=>{
            setMsg("");
            if (!rideId) return;
            try{
              const url = file ? await upload() : null;
              await postJSON(`/freight/${rideId}/chat`, { message: text || null, image_url: url });
              setText(""); setFile(null);
              load();
            } catch(e:any) {
              setMsg("Falha ao enviar");
            }
          }}>Enviar</button>
          {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
        </div>
      </div>
    </div>
  );
}
