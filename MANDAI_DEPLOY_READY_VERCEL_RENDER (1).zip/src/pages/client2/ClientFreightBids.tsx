import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}
async function postJSON(url: string, body?: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body||{}) });
  return r.json();
}

export default function ClientFreightBids() {
  const [sp] = useSearchParams();
  const [rideId, setRideId] = useState(sp.get("ride") || "");
  const [bids, setBids] = useState<any[]>([]);
  const [msg, setMsg] = useState("");

  const load = async () => {
    setMsg("");
    if (!rideId) return;
    const d = await fetchJSON(`/freight/${rideId}/bids`);
    setBids(d.bids||[]);
  };

  useEffect(()=>{ load(); }, [rideId]);

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Ofertas do Frete</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <div className="flex gap-2 flex-wrap">
          <input className="border rounded-xl px-3 py-2 flex-1 min-w-[260px]" placeholder="ride_id" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
          <button className="rounded-xl border px-3 py-2" onClick={load}>Atualizar</button>
        </div>

        {bids.length===0 ? <div className="text-sm opacity-70">Sem ofertas (ou expiraram).</div> : null}

        <div className="space-y-2">
          {bids.map((b)=>(
            <div key={b.id} className="rounded-xl border p-3 flex items-center justify-between gap-3">
              <div>
                <div className="font-medium">R$ {(Number(b.bid_cents||0)/100).toFixed(2)}</div>
                <div className="text-xs opacity-70">Expira: {b.expires_at ? new Date(b.expires_at).toLocaleString() : "—"}</div>
              </div>
              <button className="rounded-xl border px-3 py-2 text-sm" onClick={async()=>{
                const r = await postJSON(`/freight/${rideId}/accept-bid/${b.id}`);
                if (r.ok) setMsg(`Oferta aceita ✅ Taxa cancelamento: R$ ${(Number(r.cancel_fee_cents||0)/100).toFixed(2)}`);
                else setMsg(`Erro: ${r.error||"unknown"}`);
              }}>Aceitar</button>
            </div>
          ))}
        </div>

        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>
    </div>
  );
}
