import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}

export default function ClientMyFreights() {
  const [items, setItems] = useState<any[]>([]);
  const [err, setErr] = useState("");

  useEffect(()=>{
    fetchJSON("/freight/my").then(d=>setItems(d.rides||[])).catch(()=>setErr("Falha ao carregar"));
  }, []);

  return (
    <div className="p-4 max-w-3xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Meus Fretes</h1>
        <Link className="rounded-xl border px-3 py-2 text-sm" to="/client/freight/new">Novo frete</Link>
      </div>

      {err ? <div className="text-sm text-red-600">{err}</div> : null}

      <div className="rounded-2xl border overflow-hidden">
        {items.length===0 ? <div className="p-4 opacity-70">Nenhum frete ainda.</div> : null}
        {items.map((r)=>(
          <div key={r.id} className="p-4 border-b last:border-b-0 flex items-start justify-between gap-3">
            <div>
              <div className="font-medium">Frete #{String(r.id).slice(0,8)}</div>
              <div className="text-xs opacity-70">{r.status} • R$ {(Number(r.fare_cents||0)/100).toFixed(2)}</div>
              <div className="text-xs opacity-70 mt-1">
                {r.pickup?.address || "Coleta"} → {r.dropoff?.address || "Entrega"}
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Link className="rounded-xl border px-3 py-2 text-sm" to={`/client/freight/bids?ride=${r.id}`}>Ofertas</Link>
              <Link className="rounded-xl border px-3 py-2 text-sm" to={`/client/freight/chat?ride=${r.id}`}>Chat</Link>
              <Link className="rounded-xl border px-3 py-2 text-sm" to={`/client/freight/disputes?ride=${r.id}`}>Disputa</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
