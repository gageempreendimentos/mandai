import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import SideMenu from "@/components/SideMenu";
import { Button } from "@/components/ui/button";
import MapWithSheet from "@/components/layout/MapWithSheet";
import SurfaceCard from "@/components/layout/SurfaceCard";

export default function SupportPage() {
  useEffect(() => { window.dispatchEvent(new Event("mandai:app-ready")); }, []);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />
      <MapWithSheet
        title="Suporte"
        subtitle="Ajuda e atendimento"
        right={
          <div className="flex items-center gap-2">
            <Button asChild variant="outline" className="rounded-2xl">
              <Link to="/driver">Voltar</Link>
            </Button>
            <Button variant="outline" className="rounded-2xl" onClick={() => setMenuOpen(true)}>
              Menu
            </Button>
          </div>
        }
      >
        
<div className="space-y-3">
  <SurfaceCard>
    <div className="text-sm font-semibold">Canais</div>
    <div className="mt-3 grid grid-cols-2 gap-2">
      <Button className="rounded-2xl bg-black text-white hover:bg-black/90">Chat</Button>
      <Button variant="outline" className="rounded-2xl">WhatsApp</Button>
      <Button variant="outline" className="rounded-2xl">Ligação</Button>
      <Button variant="outline" className="rounded-2xl">FAQ</Button>
    </div>
  </SurfaceCard>

  <SurfaceCard>
    <div className="text-sm font-semibold">Emergência</div>
    <div className="mt-2 text-sm text-black/60">Use o botão SOS durante uma corrida.</div>
  </SurfaceCard>
</div>

      </MapWithSheet>
    </>
  );
}
