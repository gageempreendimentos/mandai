import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import SideMenu from "@/components/SideMenu";
import { Button } from "@/components/ui/button";
import MapWithSheet from "@/components/layout/MapWithSheet";
import SurfaceCard from "@/components/layout/SurfaceCard";

export default function PerformancePage() {
  useEffect(() => { window.dispatchEvent(new Event("mandai:app-ready")); }, []);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />
      <MapWithSheet
        title="Performance"
        subtitle="Nota e metas"
        right={
          <div className="flex items-center gap-2">
            <Button asChild variant="outline" className="rounded-2xl">
              <Link to="/driver">Voltar</Link>
            </Button>
            <Button variant="outline" className="rounded-2xl" onClick={() => setMenuOpen(true)}>
              Menu
            </Button>
          </div>
        }
      >
        
<div className="space-y-3">
  <div className="grid grid-cols-3 gap-2">
    <SurfaceCard>
      <div className="text-xs text-black/60">Nota</div>
      <div className="text-lg font-extrabold">4,9</div>
    </SurfaceCard>
    <SurfaceCard>
      <div className="text-xs text-black/60">Taxa aceite</div>
      <div className="text-lg font-extrabold">92%</div>
    </SurfaceCard>
    <SurfaceCard>
      <div className="text-xs text-black/60">Cancel.</div>
      <div className="text-lg font-extrabold">1%</div>
    </SurfaceCard>
  </div>

  <SurfaceCard>
    <div className="text-sm font-semibold">Dicas</div>
    <div className="mt-2 text-sm text-black/60 space-y-1">
      <div>• Aceite rápido aumenta prioridade</div>
      <div>• Mantenha a rota ativa para mais pedidos</div>
      <div>• Finalize com foto quando necessário</div>
    </div>
  </SurfaceCard>
</div>

      </MapWithSheet>
    </>
  );
}
