import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import SideMenu from "@/components/SideMenu";
import { Button } from "@/components/ui/button";
import MapWithSheet from "@/components/layout/MapWithSheet";
import SurfaceCard from "@/components/layout/SurfaceCard";

export default function ProfilePage() {
  useEffect(() => { window.dispatchEvent(new Event("mandai:app-ready")); }, []);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />
      <MapWithSheet
        title="Perfil"
        subtitle="Seus dados"
        right={
          <div className="flex items-center gap-2">
            <Button asChild variant="outline" className="rounded-2xl">
              <Link to="/driver">Voltar</Link>
            </Button>
            <Button variant="outline" className="rounded-2xl" onClick={() => setMenuOpen(true)}>
              Menu
            </Button>
          </div>
        }
      >
        
<div className="space-y-3">
  <SurfaceCard>
    <div className="text-sm font-semibold">Entregador</div>
    <div className="mt-2 text-sm text-black/60 space-y-1">
      <div>• Nome: Gleiton</div>
      <div>• Telefone: (37) 99865-0485</div>
      <div>• Veículo: Moto</div>
    </div>
  </SurfaceCard>

  <SurfaceCard>
    <div className="text-sm font-semibold">Documentos</div>
    <div className="mt-3 grid grid-cols-2 gap-2">
      <Button variant="outline" className="rounded-2xl">CNH</Button>
      <Button variant="outline" className="rounded-2xl">Documento</Button>
    </div>
  </SurfaceCard>
</div>

      </MapWithSheet>
    </>
  );
}
