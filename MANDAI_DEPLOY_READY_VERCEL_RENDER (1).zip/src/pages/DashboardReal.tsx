import React, { useEffect, useRef, useState } from "react";
import { useNavigate, Navigate } from "react-router-dom";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";

import OfflineBanner from "@/components/OfflineBanner";
import SideMenu from "@/components/SideMenu";
import OnlineToggle from "@/components/OnlineToggle";
import DashboardSkeleton from "@/components/skeletons/DashboardSkeleton";

import { useWarmStart } from "@/hooks/useWarmStart";
import { useDriverOnlineStatus } from "@/hooks/useDriverOnlineStatus";
import { useMandaiSettings } from "@/hooks/useMandaiSettings";

import { haptic } from "@/lib/haptics";
import { isAuthed, logout } from "@/lib/authLite";

import AppHeader from "@/components/layout/AppHeader";
import DraggableBottomSheet from "@/components/layout/DraggableBottomSheet";
import SurfaceCard from "@/components/layout/SurfaceCard";
import MapFull from "@/components/layout/MapFull";

import { useRide } from "@/state/useRide";
import { type RideStage } from "@/state/rideState";
import { wsConnect, wsUpdateRide, wsResetRide } from "@/lib/wsClient";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, RotateCcw, Package, Navigation, Phone, Snowflake, Banknote, CreditCard, AlertTriangle } from "lucide-react";
import { playIncomingChime } from "@/lib/sounds";
import { openNav } from "@/lib/navigation";
import { getCurrentLocation } from "@/lib/getCurrentLocation";
import { getEtaSeconds, etaMinFromSeconds } from "@/lib/getEta";

const ACCEPT_TIMEOUT_SECONDS = 45;

export default function DashboardReal() {
  useEffect(() => {
    window.dispatchEvent(new Event("mandai:app-ready"));
  }, []);

  useEffect(() => {
    if (isAuthed("driver")) wsConnect();
  }, []);

  const navigate = useNavigate();
  const ready = useWarmStart();
  // Login is handled by /login; keep dashboard light.
  const [menuOpen, setMenuOpen] = useState(false);
  const { isOnline, toggleOnline } = useDriverOnlineStatus();
  const { settings } = useMandaiSettings();

  const ride = useRide();
  const etaRef = useRef<number>(ride.etaMin);
  const [incoming, setIncoming] = useState(false);
  const [sheetSnap, setSheetSnap] = useState<number | undefined>(undefined);
  const [offerEndsAt, setOfferEndsAt] = useState<number | null>(null);
  const [offerLeft, setOfferLeft] = useState<number>(ACCEPT_TIMEOUT_SECONDS);

  // Keep ETA based on real route whenever coords are available
  useEffect(() => {
    let cancelled = false;
    async function run() {
      // only when we have coordinates
      const hasPickup = Number.isFinite(ride.pickup_lat) && Number.isFinite(ride.pickup_lng);
      const hasDrop = Number.isFinite(ride.dropoff_lat) && Number.isFinite(ride.dropoff_lng);
      if (!hasPickup || !hasDrop) return;

      const me = await getCurrentLocation(6000);
      if (!me || cancelled) return;

      // Offered/Accepted -> ETA até retirada; Enroute -> ETA até destino/parada atual
      const target = ride.stage === "enroute"
        ? { lat: ride.dropoff_lat as number, lng: ride.dropoff_lng as number }
        : { lat: ride.pickup_lat as number, lng: ride.pickup_lng as number };

      const seconds = await getEtaSeconds(me, target);
      if (cancelled) return;
      wsUpdateRide({ etaMin: etaMinFromSeconds(seconds, ride.etaMin) });
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [ride.stage, ride.pickup_lat, ride.pickup_lng, ride.dropoff_lat, ride.dropoff_lng]);

  useEffect(() => {
    etaRef.current = ride.etaMin;
  }, [ride.etaMin]);

  // Lightweight countdown while enroute (1 min ticks)
  useEffect(() => {
    if (ride.stage !== "enroute") return;
    const t = window.setInterval(() => {
      wsUpdateRide({ etaMin: Math.max(1, etaRef.current - 1) });
    }, 60_000);
    return () => window.clearInterval(t);
  }, [ride.stage]);

  useEffect(() => {
    // Incoming call animation when a new offer arrives
    if (ride.stage === "offered") {
      setIncoming(true);
      setSheetSnap(1);
      playIncomingChime();
      haptic("success", settings.hapticsEnabled);
      const end = Date.now() + ACCEPT_TIMEOUT_SECONDS * 1000;
      setOfferEndsAt(end);
      setOfferLeft(ACCEPT_TIMEOUT_SECONDS);
      const t = window.setTimeout(() => setIncoming(false), 4200);
      return () => window.clearTimeout(t);
    }
    setIncoming(false);
    setSheetSnap(undefined);
    setOfferEndsAt(null);
  }, [ride.stage, settings.hapticsEnabled]);

  // Offer countdown (auto-expire)
  useEffect(() => {
    if (ride.stage !== "offered" || !offerEndsAt) return;
    const tick = () => {
      const left = Math.max(0, Math.ceil((offerEndsAt - Date.now()) / 1000));
      setOfferLeft(left);
      if (left <= 0) {
        toast("Oferta expirada. Voltando para aguardar...");
        wsUpdateRide({ stage: "idle" });
        setOfferEndsAt(null);
      }
    };
    tick();
    const t = window.setInterval(tick, 1000);
    return () => window.clearInterval(t);
  }, [ride.stage, offerEndsAt]);

  if (!ready) return <DashboardSkeleton />;

  if (!isAuthed("driver")) {
    return <Navigate to="/login?role=driver" replace />;
  }

  const stageLabel =
    ride.stage === "idle"
      ? "Aguardando…"
      : ride.stage === "offered"
        ? "Nova corrida"
        : ride.stage === "accepted"
          ? "Aceita"
          : ride.stage === "enroute"
            ? "Em rota"
            : "Finalizada";

  const setStage = (stage: RideStage) => wsUpdateRide({ stage });

  const stopCount = ride.stops?.length || 0;
  const stopIndex = ride.stopIndex || 0;

  const currentDestination =
    ride.stage === "accepted"
      ? ride.pickup
      : ride.stage === "enroute"
        ? (ride.stops?.[stopIndex] || ride.dropoff)
        : ride.dropoff;

  function advanceStopOrComplete() {
    if (!ride.stops || ride.stops.length <= 1) {
      setStage("completed");
      return;
    }
    const nextIndex = (ride.stopIndex || 0) + 1;
    if (nextIndex >= ride.stops.length) {
      setStage("completed");
      return;
    }
    wsUpdateRide({ stopIndex: nextIndex, dropoff: ride.stops[nextIndex] });
    toast(`Próxima parada: ${ride.stops[nextIndex]}`);
  }

  const primaryAction =
    ride.stage === "offered"
      ? { text: "Aceitar", onClick: () => (setStage("accepted"), toast("Corrida aceita!"), haptic("success", settings.hapticsEnabled)) }
      : ride.stage === "accepted"
        ? { text: "Iniciar rota", onClick: () => (setStage("enroute"), toast("Rota iniciada"), haptic("light", settings.hapticsEnabled)) }
        : ride.stage === "enroute"
          ? { text: stopCount > 1 ? "Concluir parada" : "Finalizar", onClick: () => (advanceStopOrComplete(), haptic("success", settings.hapticsEnabled)) }
          : ride.stage === "completed"
            ? { text: "Nova corrida", onClick: () => (wsResetRide(), toast("Buscando nova corrida…")) }
            : { text: "Buscar corridas", onClick: () => setStage("offered") };

  return (
    <div className="min-h-screen bg-white">
      <MapFull stage={ride.stage} />

      <AnimatePresence>
        {incoming ? (
          <motion.div
            className="fixed inset-x-0 top-20 z-50 mx-auto max-w-screen-md px-4"
            initial={{ y: -30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -30, opacity: 0 }}
            transition={{ type: "spring", damping: 20, stiffness: 260 }}
          >
            <div className="rounded-3xl bg-white shadow-[var(--mandai-shadow)] border border-black/10 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-2">
                  <div className="h-9 w-9 rounded-full bg-green-50 text-green-700 flex items-center justify-center">
                    <Package className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-sm text-black/60">Chamada recebida</div>
                    <div className="text-base font-extrabold tracking-tight">Nova Corrida</div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  className="h-9 w-9 rounded-full"
                  onClick={() => {
                    wsResetRide();
                    toast("Oferta ignorada");
                  }}
                >
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>

              <div className="px-4 pb-4">
                <div className="flex items-start gap-3 py-2 border-t border-black/5">
                  <div className="mt-1 h-7 w-7 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center">
                    <MapPin className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-semibold">{ride.pickup}</div>
                  </div>
                </div>
                <div className="flex items-start gap-3 py-2 border-t border-black/5">
                  <div className="mt-1 h-7 w-7 rounded-full bg-yellow-50 text-yellow-700 flex items-center justify-center">
                    <MapPin className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-semibold">{ride.dropoff}</div>
                  </div>
                </div>

                <div className="mt-2 flex items-center justify-center gap-2 text-sm font-semibold text-black/80">
                  <span>{Math.max(5, ride.etaMin)} min</span>
                  <span className="text-black/30">•</span>
                  <span>R$ {ride.price}</span>
                </div>

                <div className="mt-3 flex gap-2">
                  <Button className="flex-1 rounded-2xl bg-green-600 text-white hover:bg-green-600/90" onClick={primaryAction.onClick}>
                    Aceitar Corrida
                  </Button>
                  <Button variant="outline" className="rounded-2xl" onClick={() => wsResetRide()}>
                    Recusar
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <div className="fixed inset-x-0 top-0 z-40">
        <AppHeader
          title="Entregador"
          subtitle={isOnline ? `${stageLabel} • Online` : `${stageLabel} • Offline`}
          right={
            <div className="flex items-center gap-2">
              <OnlineToggle
                isOnline={isOnline}
                onToggle={() => {
                  const next = toggleOnline();
                  haptic(next ? "success" : "warning", settings.hapticsEnabled);
                  toast(next ? "Você está online" : "Você está offline");
                }}
              />
              <Button variant="outline" className="rounded-2xl" onClick={() => setMenuOpen(true)}>
                Menu
              </Button>
              <Button
                variant="outline"
                className="rounded-2xl"
                onClick={() => {
                  logout();
                  navigate("/entry", { replace: true });
                }}
              >
                Sair
              </Button>
            </div>
          }
        />
      </div>

      <OfflineBanner />
      <SideMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <DraggableBottomSheet snaps={[200, 440, 700]} initialSnap={1} targetSnap={sheetSnap} attentionPulse={ride.stage === "offered"}>
        {ride.stage === "offered" ? (
          <div className="overflow-hidden rounded-[18px] border border-black/10">
            <div className="flex items-center justify-between px-4 py-3">
              <div className="text-lg font-extrabold tracking-tight">Nova Corrida</div>
              <Button
                variant="ghost"
                className="h-9 w-9 rounded-full"
                onClick={() => {
                  wsUpdateRide({ stage: "idle" });
                  setOfferEndsAt(null);
                  toast("Oferta ignorada");
                }}
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>

            <div className="px-4 pb-3">
              <div className="flex items-start gap-3 py-2 border-t border-black/5">
                <div className="mt-1 h-7 w-7 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center">
                  <MapPin className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold">{ride.pickup}</div>
                </div>
              </div>
              <div className="flex items-start gap-3 py-2 border-t border-black/5">
                <div className="mt-1 h-7 w-7 rounded-full bg-yellow-50 text-yellow-700 flex items-center justify-center">
                  <MapPin className="h-4 w-4" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold">{ride.dropoff}</div>
                </div>
              </div>

              <div className="mt-2 flex items-center justify-center gap-2 text-sm font-semibold text-black/80">
                <span>{Math.max(5, ride.etaMin)} min</span>
                <span className="text-black/30">•</span>
                <span>R$ {ride.price}</span>
              </div>

              <div className="mt-2 text-center text-xs text-black/50">
                Expira em <span className="font-semibold text-black/70">{offerLeft}s</span>
              </div>

              <Button className="mt-3 w-full rounded-2xl bg-green-600 text-white hover:bg-green-600/90" onClick={primaryAction.onClick}>
                Aceitar Corrida
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-sm text-black/60">Status</div>
                <div className="text-xl font-extrabold tracking-tight">{stageLabel}</div>
                {ride.stage === "enroute" ? <div className="text-sm text-black/55">Chegada em ~ {ride.etaMin} min</div> : null}
              </div>
              <Button className="rounded-2xl bg-black text-white hover:bg-black/90" onClick={primaryAction.onClick}>
                {primaryAction.text}
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <SurfaceCard>
                <div className="text-xs text-black/60">Ganhos</div>
                <div className="text-lg font-extrabold">R$ 148</div>
              </SurfaceCard>
              <SurfaceCard>
                <div className="text-xs text-black/60">Entregas</div>
                <div className="text-lg font-extrabold">6</div>
              </SurfaceCard>
              <SurfaceCard>
                <div className="text-xs text-black/60">Nota</div>
                <div className="text-lg font-extrabold">4,9</div>
              </SurfaceCard>
            </div>

            <SurfaceCard>
              <div className="text-sm font-semibold">Detalhes</div>
              <div className="mt-2 text-sm text-black/60 space-y-1">
                <div className="flex items-center gap-2"><Package className="h-4 w-4" /> Ticket: {ride.ticket || `TKT-${ride.id}`}</div>

                {(ride.alerts?.coldItems || ride.alerts?.carryChange || ride.alerts?.carryCardMachine || ride.alerts?.notes) ? (
                  <div className="mt-2 rounded-2xl border border-black/10 bg-amber-50 px-3 py-2 text-amber-900">
                    <div className="flex items-center gap-2 text-xs font-semibold">
                      <AlertTriangle className="h-4 w-4" /> Atenção (não esquecer)
                    </div>
                    <div className="mt-2 space-y-1 text-xs">
                      {ride.alerts?.coldItems ? (
                        <div className="flex items-center gap-2"><Snowflake className="h-4 w-4" /> Itens gelados (refrigerante/água) — levar bolsa térmica/gelo</div>
                      ) : null}
                      {ride.alerts?.carryChange ? (
                        <div className="flex items-center gap-2"><Banknote className="h-4 w-4" /> Levar troco</div>
                      ) : null}
                      {ride.alerts?.carryCardMachine ? (
                        <div className="flex items-center gap-2"><CreditCard className="h-4 w-4" /> Levar maquininha</div>
                      ) : null}
                      {ride.alerts?.notes ? (
                        <div className="text-amber-800/90">Obs.: {ride.alerts.notes}</div>
                      ) : null}
                    </div>
                  </div>
                ) : null}

                {stopCount > 1 ? (
                  <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Parada {stopIndex + 1}/{stopCount}: {ride.stops?.[stopIndex] || ride.dropoff}</div>
                ) : (
                  <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Destino: {ride.dropoff}</div>
                )}
                <div className="flex items-center gap-2"><Navigation className="h-4 w-4" /> Retirada: {ride.pickup}</div>
                <div className="flex items-center gap-2"><Phone className="h-4 w-4" /> Suporte rápido no menu</div>
              </div>

              {(ride.stage === "accepted" || ride.stage === "enroute") ? (
                <div className="mt-3 flex gap-2">
                  <Button
                    variant="outline"
                    className="flex-1 rounded-2xl"
                    onClick={() => openNav("waze", currentDestination)}
                  >
                    Abrir no Waze
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 rounded-2xl"
                    onClick={() => openNav("google", currentDestination)}
                  >
                    Abrir no Maps
                  </Button>
                </div>
              ) : null}
            </SurfaceCard>
          </div>
        )}
      </DraggableBottomSheet>
    </div>
  );
}
