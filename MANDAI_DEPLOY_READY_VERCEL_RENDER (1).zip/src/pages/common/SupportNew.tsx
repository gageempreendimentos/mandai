import React, { useState } from "react";

async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function SupportNew() {
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [priority, setPriority] = useState(2);
  const [rideId, setRideId] = useState("");
  const [msg, setMsg] = useState("");

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Abrir Ticket</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="Assunto" value={subject} onChange={(e)=>setSubject(e.target.value)} />
        <textarea className="border rounded-xl px-3 py-2 w-full min-h-[140px]" placeholder="Descreva o problema" value={message} onChange={(e)=>setMessage(e.target.value)} />
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="Ride ID (opcional)" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
        <select className="border rounded-xl px-3 py-2 w-full" value={priority} onChange={(e)=>setPriority(Number(e.target.value))}>
          <option value={1}>Alta</option>
          <option value={2}>Normal</option>
          <option value={3}>Baixa</option>
        </select>
        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          setMsg("");
          const r = await postJSON("/support", { subject, message, priority, ride_id: rideId || null });
          setMsg(r.ok ? `Enviado! Ticket #${r.id}` : `Erro: ${r.error || "unknown"}`);
        }}>Enviar</button>
        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>
    </div>
  );
}
