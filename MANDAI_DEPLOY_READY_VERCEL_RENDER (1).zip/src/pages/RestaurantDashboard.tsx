import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";

import DashboardSkeleton from "@/components/skeletons/DashboardSkeleton";
import { useWarmStart } from "@/hooks/useWarmStart";
import { isAuthed, logout } from "@/lib/authLite";

import MapWithSheet from "@/components/layout/MapWithSheet";
import { RotateCcw } from "lucide-react";

import { useRide } from "@/state/useRide";
import { wsResetRide, wsUpdateRide } from "@/lib/wsClient";

export default function RestaurantDashboard() {
  useEffect(() => {
    window.dispatchEvent(new Event("mandai:app-ready"));
  }, []);

  const navigate = useNavigate();
  const ready = useWarmStart();
  const [sending, setSending] = useState(false);
  const [premiumOpen, setPremiumOpen] = useState(false);
  const [ticket, setTicket] = useState("TKT-1029");
  const [stopsText, setStopsText] = useState("Rua A, 10\nRua B, 200\nRua C, 33");
  const [scheduledAt, setScheduledAt] = useState<string>("");
  const [needsChange, setNeedsChange] = useState(false);
  const [needsCardMachine, setNeedsCardMachine] = useState(false);
  const [hasWater, setHasWater] = useState(false);
  const [hasSoda, setHasSoda] = useState(false);
  const [alertNotes, setAlertNotes] = useState("");
  const ride = useRide();

  if (!ready) return <DashboardSkeleton />;

  if (!isAuthed("restaurant")) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md rounded-3xl shadow-lg border-black/10">
          <CardHeader>
            <CardTitle className="text-center text-3xl font-extrabold tracking-tight">MANDAI</CardTitle>
            <p className="text-center text-sm text-black/60">Entrar como Restaurante</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>CNPJ / Email</Label>
              <Input placeholder="restaurante@mandai.com" />
            </div>
            <div className="space-y-2">
              <Label>Senha</Label>
              <Input type="password" placeholder="••••••••" />
            </div>

            <Button
              className="w-full rounded-2xl"
              onClick={() => {
                toast("Bem-vindo!");
              }}
            >
              Entrar
            </Button>

            <Button variant="outline" className="w-full rounded-2xl" asChild>
              <Link to="/entry">Voltar</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusText =
    ride.stage === "offered"
      ? "Chamando entregador…"
      : ride.stage === "accepted"
        ? "Entregador aceitou"
        : ride.stage === "enroute"
          ? `Entregador a caminho • ~${ride.etaMin} min`
          : ride.stage === "completed"
            ? "Pedido entregue ✅"
            : "Pronto para despachar";

  return (
    <MapWithSheet
      title="Restaurante"
      subtitle={statusText}
      stage={ride.stage}
      right={
        <Button
          variant="outline"
          className="rounded-2xl"
          onClick={() => {
            logout();
            navigate("/entry", { replace: true });
          }}
        >
          Sair
        </Button>
      }
    >
      <div className="overflow-hidden rounded-[18px] border border-black/10">
        <div className="flex items-center justify-between px-4 py-3">
          <div>
            <div className="text-lg font-extrabold tracking-tight">Pedido para Entrega</div>
            <div className="text-sm text-black/60">Ticket {ride.ticket || ticket} • Lucas Martins</div>
          </div>
          <Button
            variant="ghost"
            className="h-9 w-9 rounded-full"
            onClick={() => {
              wsResetRide();
              toast("Pedido resetado");
            }}
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>

        <div className="px-4 pb-3">
          <div className="py-3 border-t border-black/5">
            <div className="text-sm font-semibold">Itens</div>
            <div className="mt-2 text-sm text-black/60 space-y-1">
              <div>2x Burger</div>
              <div>1x Batata Frita</div>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <div className="text-sm text-black/55">Sai em 5 min</div>
              <div className="text-sm font-semibold">R$ {ride.price}</div>
            </div>
          <div className="mt-3 rounded-2xl border border-black/10 bg-white px-3 py-3">
            <div className="text-sm font-semibold">Avisos para o entregador (opcional)</div>
            <div className="mt-2 grid grid-cols-1 gap-3">
              <div className="flex items-center justify-between">
                <div className="text-sm text-black/70">Precisa levar troco</div>
                <Switch checked={needsChange} onCheckedChange={setNeedsChange} />
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-black/70">Levar maquininha</div>
                <Switch checked={needsCardMachine} onCheckedChange={setNeedsCardMachine} />
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-black/70">Água</div>
                <Switch checked={hasWater} onCheckedChange={setHasWater} />
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-black/70">Refrigerante</div>
                <Switch checked={hasSoda} onCheckedChange={setHasSoda} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-black/60">Observação (opcional)</Label>
                <Input
                  value={alertNotes}
                  onChange={(e) => setAlertNotes(e.target.value)}
                  placeholder="Ex.: entregar na portaria / cuidado com vidro…"
                  className="rounded-2xl"
                />
              </div>
            </div>
          </div>

          </div>

          <Button
            className="mt-3 w-full rounded-2xl bg-orange-500 text-white hover:bg-orange-500/90"
            disabled={sending}
            onClick={() => {
              setSending(true);
              if (ride.stage === "idle" || ride.stage === "completed") wsResetRide();
              wsUpdateRide({
                stage: "offered",
                ...((hasWater || hasSoda || needsChange || needsCardMachine || alertNotes.trim())
                  ? {
                      alerts: {
                        coldItems: hasWater || hasSoda,
                        carryChange: needsChange,
                        carryCardMachine: needsCardMachine,
                        ...(alertNotes.trim() ? { notes: alertNotes.trim() } : {}),
                      },
                    }
                  : {}),
              });
              toast("Pedido despachado! Procurando entregador…");
              window.setTimeout(() => setSending(false), 650);
            }}
          >
            {sending ? "Despachando…" : "Despachar Pedido"}
          </Button>

          <Button
            variant="outline"
            className="mt-2 w-full rounded-2xl border-orange-500/30 text-orange-600 hover:bg-orange-500/10"
            onClick={() => setPremiumOpen(true)}
          >
            Modo Restaurante Premium (lote + agendamento)
          </Button>
        </div>
      </div>

      <Dialog open={premiumOpen} onOpenChange={(open) => setPremiumOpen(open)}>
        <DialogContent className="max-w-lg rounded-3xl">
          <DialogHeader>
            <DialogTitle>Restaurante Premium</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Ticket/Número do pedido</Label>
              <Input value={ticket} onChange={(e) => setTicket(e.target.value)} placeholder="TKT-0001" />
            </div>

            <div className="space-y-2">
              <Label>Agendar (opcional)</Label>
              <Input
                type="datetime-local"
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
              />
              <p className="text-xs text-black/60">Se ficar vazio, sai na hora.</p>
            </div>

            <div className="space-y-2">
              <Label>Entregas (uma por linha)</Label>
              <Textarea
                rows={5}
                value={stopsText}
                onChange={(e) => setStopsText(e.target.value)}
                placeholder="Rua 1, 10\nRua 2, 200\nRua 3, 300"
              />
              <p className="text-xs text-black/60">Você pode colocar 2, 3 ou mais entregas. O sistema manda todas pro mesmo entregador.</p>
            <div className="rounded-2xl border border-black/10 bg-white px-3 py-3">
              <div className="text-sm font-semibold">Avisos para o entregador (opcional)</div>
              <div className="mt-2 grid grid-cols-1 gap-3">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-black/70">Precisa levar troco</div>
                  <Switch checked={needsChange} onCheckedChange={setNeedsChange} />
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-black/70">Levar maquininha</div>
                  <Switch checked={needsCardMachine} onCheckedChange={setNeedsCardMachine} />
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-black/70">Água</div>
                  <Switch checked={hasWater} onCheckedChange={setHasWater} />
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-black/70">Refrigerante</div>
                  <Switch checked={hasSoda} onCheckedChange={setHasSoda} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-black/60">Observação (opcional)</Label>
                  <Input
                    value={alertNotes}
                    onChange={(e) => setAlertNotes(e.target.value)}
                    placeholder="Ex.: entregar na portaria / cuidado com vidro…"
                    className="rounded-2xl"
                  />
                </div>
              </div>
            </div>

            </div>

            <div className="flex gap-2">
              <Button variant="outline" className="flex-1 rounded-2xl" onClick={() => setPremiumOpen(false)}>
                Cancelar
              </Button>
              <Button
                className="flex-1 rounded-2xl bg-orange-500 text-white hover:bg-orange-500/90"
                onClick={() => {
                  const stops = stopsText
                    .split("\n")
                    .map((s) => s.trim())
                    .filter(Boolean);
                  if (stops.length < 2) {
                    toast("Coloque pelo menos 2 endereços para o lote");
                    return;
                  }
                  // Atualiza a corrida/ticket compartilhado e dispara oferta.
                  wsUpdateRide({
                    ticket,
                    stops,
                    stopIndex: 0,
                    dropoff: stops[0],
                    stage: "offered",
                    ...((hasWater || hasSoda || needsChange || needsCardMachine || alertNotes.trim())
                      ? {
                          alerts: {
                            coldItems: hasWater || hasSoda,
                            carryChange: needsChange,
                            carryCardMachine: needsCardMachine,
                            ...(alertNotes.trim() ? { notes: alertNotes.trim() } : {}),
                          },
                        }
                      : {}),
                    ...(scheduledAt ? { scheduledAt: new Date(scheduledAt).toISOString() } : {}),
                  });
                  toast(`Lote criado: ${stops.length} entregas. Chamando entregador…`);
                  setPremiumOpen(false);
                }}
              >
                Criar lote e despachar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </MapWithSheet>
  );
}
