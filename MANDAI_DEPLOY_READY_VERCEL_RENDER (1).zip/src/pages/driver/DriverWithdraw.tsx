import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function DriverWithdraw() {
  const [pixKey, setPixKey] = useState("");
  const [amount, setAmount] = useState(1000);
  const [list, setList] = useState<any[]>([]);
  const [msg, setMsg] = useState("");

  async function refresh() {
    const r = await fetchJSON("/pix/me/withdrawals");
    setList(r.withdrawals || []);
  }

  useEffect(() => { refresh(); }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Saque PIX (MVP)</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <div className="text-xs opacity-70">*MVP simulado (sem integração bancária ainda).</div>
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="Chave PIX (cpf/email/telefone/aleatória)" value={pixKey} onChange={(e)=>setPixKey(e.target.value)} />
        <input className="border rounded-xl px-3 py-2 w-full" type="number" placeholder="Valor (centavos)" value={amount} onChange={(e)=>setAmount(Number(e.target.value))} />
        <button
          className="rounded-xl border px-3 py-2"
          onClick={async ()=>{
            setMsg("");
            const r = await postJSON("/pix/withdraw", { pix_key: pixKey, amount_cents: amount });
            setMsg(r.ok ? `Solicitado (#${r.request_id})` : `Erro: ${r.error || "unknown"}`);
            await refresh();
          }}
        >
          Solicitar saque
        </button>
        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>

      <div className="rounded-2xl border p-4">
        <div className="font-medium mb-2">Histórico</div>
        {list.length === 0 ? <div className="opacity-70">Nenhuma solicitação ainda.</div> : (
          <div className="space-y-2">
            {list.map((w)=>(
              <div key={w.id} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                <div>
                  <div className="font-medium">R$ {(Number(w.amount_cents)/100).toFixed(2)} — {w.status}</div>
                  <div className="text-xs opacity-70">{new Date(w.created_at).toLocaleString()}</div>
                </div>
                <div className="text-xs opacity-70">{w.provider_ref || ""}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
