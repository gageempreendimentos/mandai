import React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body?: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body||{}) });
  return r.json();
}

export default function DriverCampaigns() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["campaigns"], queryFn: () => fetchJSON("/campaigns"), refetchInterval: 30000 });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Campanhas</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-3">
            {(q.data?.campaigns || []).length === 0 ? <div className="opacity-70">Sem campanhas ativas.</div> : null}
            {(q.data?.campaigns || []).map((c: any) => (
              <div key={c.id} className="border-b pb-3 last:border-b-0 last:pb-0">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{c.name}</div>
                  <div className="text-sm font-semibold">Bônus: R$ {(Number(c.bonus_cents)/100).toFixed(2)}</div>
                </div>
                <div className="text-xs opacity-70">
                  {new Date(c.start_at).toLocaleString()} → {new Date(c.end_at).toLocaleString()} | meta: {c.target_rides} entregas
                </div>
                <button
                  className="mt-2 rounded-xl border px-3 py-2 text-sm"
                  onClick={async ()=>{
                    await postJSON(`/campaigns/${c.id}/claim`);
                    qc.invalidateQueries({ queryKey: ["campaigns"] });
                  }}
                >
                  Tentar resgatar
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
