import React, { useEffect, useState } from "react";

async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function DriverDuty() {
  useEffect(()=>{
    fetch('/drivers/me', { credentials:'include' }).then(r=>r.json()).then(d=>{
      const u = d?.user;
      if (u) {
        setOnDuty(!!u.on_duty);
        setDriverBlocked(!!u.is_disabled);
        if (u.is_disabled) setBlockedMsg('Seu acesso está bloqueado temporariamente.');
      }
    }).catch(()=>{});
  }, []);

  const [onDuty, setOnDuty] = useState(true);
  const [driverBlocked, setDriverBlocked] = useState(false);
  const [blockedMsg, setBlockedMsg] = useState("");
  const [msg, setMsg] = useState("");

  return (
    <div className="p-4 space-y-3">
      <h1 className="text-xl font-semibold">Plantão</h1>
      <div className="rounded-2xl border p-4 flex items-center justify-between">
        <div>
          <div className="font-medium">{onDuty ? "Disponível" : "Fora do plantão"}</div>
          <div className="text-xs opacity-70">Se estiver fora do plantão, você não recebe novas corridas.</div>
        </div>
        <button
          className="rounded-xl border px-3 py-2"
          disabled={driverBlocked}
          onClick={async ()=>{
            const next = !onDuty;
            setOnDuty(next);
            const r = await postJSON("/drivers/duty", { on_duty: next });
            setMsg(r.ok ? "Atualizado!" : "Erro");
          }}
        >
          {onDuty ? "Desligar" : "Ligar"}
        </button>
      </div>
      {driverBlocked ? <div className="text-sm text-red-600">{blockedMsg}</div> : null}
      {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
    </div>
  );
}
