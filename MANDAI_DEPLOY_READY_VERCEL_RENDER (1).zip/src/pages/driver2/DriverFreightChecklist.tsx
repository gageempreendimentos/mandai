import React, { useState } from "react";

async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

export default function DriverFreightChecklist() {
  const [rideId, setRideId] = useState("");
  const [items, setItems] = useState(true);
  const [weight, setWeight] = useState(true);
  const [file, setFile] = useState<File|null>(null);
  const [notes, setNotes] = useState("");
  const [msg, setMsg] = useState("");

  const upload = async () => {
    if (!file) return null;
    const b64 = await new Promise<string>((resolve,reject)=>{
      const fr = new FileReader();
      fr.onload = ()=>resolve(String(fr.result));
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });
    const r = await postJSON("/uploads-api/base64", { kind:"checklist", filename: file.name, base64_data: b64 });
    if (r.ok) return r.url;
    throw new Error(r.error||"upload_failed");
  };

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Checklist de Coleta</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="ride_id" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={items} onChange={(e)=>setItems(e.target.checked)} /> Itens conferidos</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={weight} onChange={(e)=>setWeight(e.target.checked)} /> Peso conferido</label>
        <input type="file" accept="image/*" className="border rounded-xl px-3 py-2 w-full" onChange={(e)=>setFile(e.target.files?.[0]||null)} />
        <textarea className="border rounded-xl px-3 py-2 w-full" rows={3} placeholder="Observações" value={notes} onChange={(e)=>setNotes(e.target.value)} />
        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          setMsg("");
          if (!rideId) return;
          try{
            const photo_url = await upload();
            const r = await postJSON(`/freight/${rideId}/checklist`, { confirmed_items: items, confirmed_weight: weight, photo_url, notes: notes||null });
            setMsg(r.ok ? "Checklist enviado ✅" : `Erro: ${r.error||"unknown"}`);
          } catch {
            setMsg("Falha no upload");
          }
        }}>Enviar checklist</button>
        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>
    </div>
  );
}
