import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}

export default function DriverMyRides() {
  const [rides, setRides] = useState<any[]>([]);

  useEffect(()=>{
    fetchJSON("/drivers/me/rides").then(d=>setRides(d.rides||[]));
  }, []);

  return (
    <div className="p-4 max-w-3xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Minhas corridas</h1>
      <div className="rounded-2xl border overflow-hidden">
        {rides.length===0 ? <div className="p-4 opacity-70">Sem corridas ainda.</div> : null}
        {rides.map((r)=>(
          <div key={r.id} className="p-4 border-b last:border-b-0">
            <div className="font-medium">{r.kind} • {r.status}</div>
            <div className="text-xs opacity-70">{r.pickup?.address || "Coleta"} → {r.dropoff?.address || "Entrega"}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
