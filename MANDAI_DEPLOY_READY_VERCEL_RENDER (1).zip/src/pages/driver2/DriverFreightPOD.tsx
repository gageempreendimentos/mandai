import React, { useState } from "react";

async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

export default function DriverFreightPOD() {
  const [rideId, setRideId] = useState("");
  const [receiver, setReceiver] = useState("");
  const [file, setFile] = useState<File|null>(null);
  const [notes, setNotes] = useState("");
  const [msg, setMsg] = useState("");

  const upload = async () => {
    if (!file) return null;
    const b64 = await new Promise<string>((resolve,reject)=>{
      const fr = new FileReader();
      fr.onload = ()=>resolve(String(fr.result));
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });
    const r = await postJSON("/uploads-api/base64", { kind:"pod", filename: file.name, base64_data: b64 });
    if (r.ok) return r.url;
    throw new Error(r.error||"upload_failed");
  };

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Comprovante (POD)</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="ride_id" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="Nome do recebedor" value={receiver} onChange={(e)=>setReceiver(e.target.value)} />
        <input type="file" accept="image/*" className="border rounded-xl px-3 py-2 w-full" onChange={(e)=>setFile(e.target.files?.[0] || null)} />
        <textarea className="border rounded-xl px-3 py-2 w-full" rows={3} placeholder="Observações" value={notes} onChange={(e)=>setNotes(e.target.value)} />
        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          setMsg("");
          if (!rideId) return;
          try{
            const photo_url = await upload();
            const r = await postJSON(`/freight/${rideId}/pod`, { receiver_name: receiver, photo_url, notes: notes || null });
            setMsg(r.ok ? "POD enviado ✅" : `Erro: ${r.error||"unknown"}`);
            setFile(null);
          } catch {
            setMsg("Falha no upload");
          }
        }}>Enviar POD</button>
        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>
    </div>
  );
}
