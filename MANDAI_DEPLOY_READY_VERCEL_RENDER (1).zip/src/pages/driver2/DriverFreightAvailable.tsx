import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

export default function DriverFreightAvailable() {
  const [rides, setRides] = useState<any[]>([]);
  const [bid, setBid] = useState<Record<string, number>>({});

  useEffect(()=>{ fetchJSON("/freight/available").then(d=>setRides(d.rides||[])).catch(()=>{}); }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Fretes disponíveis</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        {rides.length===0 ? <div className="opacity-70">Sem fretes por enquanto.</div> : null}
        {rides.map((r)=>(
          <div key={r.id} className="border-b pb-3 last:border-b-0 last:pb-0">
            <div className="font-medium">Ride {r.id}</div>
            <div className="text-xs opacity-70">Base: R$ {(Number(r.fare_cents||0)/100).toFixed(2)} • {Number(r.distance_km||0).toFixed(1)} km</div>
            <div className="mt-2 flex gap-2 items-center flex-wrap">
              <input
                className="border rounded-xl px-3 py-2 text-sm"
                placeholder="Sua oferta (R$)"
                value={bid[r.id] ?? ""}
                onChange={(e)=>setBid(b=>({ ...b, [r.id]: Number(e.target.value) }))}
              />
              <button className="rounded-xl border px-3 py-2 text-sm" onClick={async()=>{
                const value = Number(bid[r.id]||0);
                if (!value || value<=0) return;
                await postJSON(`/freight/${r.id}/bid`, { bid_cents: Math.round(value*100) });
                alert("Oferta enviada!");
              }}>Enviar oferta</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
