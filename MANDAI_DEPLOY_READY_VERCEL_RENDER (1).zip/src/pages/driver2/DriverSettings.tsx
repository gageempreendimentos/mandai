import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

export default function DriverSettings() {
  const [vehicle, setVehicle] = useState("moto");
  const [kg, setKg] = useState(20);
  const [vol, setVol] = useState("P");
  const [msg, setMsg] = useState("");

  const [city, setCity] = useState("");
  const [radius, setRadius] = useState(8);
  const [zones, setZones] = useState<any[]>([]);
  const [selectedZones, setSelectedZones] = useState<string[]>([]);
  const [msgArea, setMsgArea] = useState("");

  useEffect(()=>{
    fetchJSON("/drivers/me").then(d=>{
      setVehicle(d?.driver?.vehicle_type || "moto");
      setKg(Number(d?.driver?.capacity_kg || 20));
      setVol(d?.driver?.capacity_volume || "P");
    }).catch(()=>{});

    fetchJSON("/drivers/me").then(d=>{
      setCity(d?.user?.preferred_city || "");
      setRadius(Number(d?.user?.service_radius_km || 8));
    }).catch(()=>{});

    fetchJSON("/drivers/zones").then(d=>{
      setZones(d?.zones || []);
      setSelectedZones((d?.selected_zone_ids || []).map(String));
    }).catch(()=>{});
  }, []);

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Meu veículo</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <div className="text-sm font-medium">Tipo de veículo</div>
        <select className="border rounded-xl px-3 py-2 w-full" value={vehicle} onChange={(e)=>setVehicle(e.target.value)}>
          <option value="moto">Moto (Delivery)</option>
          <option value="carro">Carro (Frete)</option>
          <option value="van">Van (Frete)</option>
          <option value="caminhao">Caminhão (Frete)</option>
        </select>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <div className="text-sm font-medium">Capacidade (kg)</div>
            <input type="number" className="border rounded-xl px-3 py-2 w-full" value={kg} onChange={(e)=>setKg(Number(e.target.value))} />
          </div>
          <div>
            <div className="text-sm font-medium">Volume</div>
            <select className="border rounded-xl px-3 py-2 w-full" value={vol} onChange={(e)=>setVol(e.target.value)}>
              <option value="P">P</option>
              <option value="M">M</option>
              <option value="G">G</option>
            </select>
          </div>
        </div>

        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          setMsg("");
          const r = await postJSON("/drivers/me/vehicle", { vehicle_type: vehicle, capacity_kg: kg, capacity_volume: vol });
          setMsg(r.ok ? "Salvo!" : `Erro: ${r.error||"unknown"}`);
        }}>Salvar</button>

        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
        <div className="text-xs opacity-60">
          *Frete aparece apenas para Carro/Van/Caminhão.
        </div>

      <div className="rounded-2xl border p-4 space-y-2">
        <h2 className="text-lg font-semibold">Área de atuação</h2>
        <div className="text-xs opacity-70">Escolha sua cidade e (opcional) zonas/bairros para priorizar corridas.</div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <div className="text-sm font-medium">Cidade</div>
            <input className="border rounded-xl px-3 py-2 w-full" placeholder="Ex: Belo Horizonte" value={city} onChange={(e)=>setCity(e.target.value)} />
          </div>
          <div>
            <div className="text-sm font-medium">Raio (km)</div>
            <input type="number" min={1} max={50} className="border rounded-xl px-3 py-2 w-full" value={radius} onChange={(e)=>setRadius(Number(e.target.value))} />
          </div>
        </div>

        <div className="text-sm font-medium mt-2">Zonas (opcional)</div>
        <div className="grid grid-cols-1 gap-2 max-h-48 overflow-auto pr-1">
          {zones.map((z:any)=>(
            <label key={z.id} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={selectedZones.includes(String(z.id))}
                onChange={(e)=>{
                  const id = String(z.id);
                  setSelectedZones(prev => e.target.checked ? [...prev, id] : prev.filter(x=>x!==id));
                }}
              />
              <span>{z.name}{z.city ? ` — ${z.city}` : ""}</span>
            </label>
          ))}
        </div>

        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          setMsgArea("");
          const r1 = await postJSON("/drivers/preferences", { preferred_city: city || null, service_radius_km: radius });
          const r2 = await postJSON("/drivers/zones", { zone_ids: selectedZones });
          setMsgArea(r1.ok && r2.ok ? "Salvo!" : `Erro: ${r1.error || r2.error || "unknown"}`);
        }}>Salvar área</button>

        {msgArea ? <div className="text-sm opacity-70">{msgArea}</div> : null}
      </div>

      </div>
    </div>
  );
}
