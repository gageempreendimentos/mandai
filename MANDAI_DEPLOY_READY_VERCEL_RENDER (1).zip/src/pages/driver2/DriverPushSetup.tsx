import React, { useState } from "react";

async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method:"POST", headers:{ "content-type":"application/json" }, credentials:"include", body: JSON.stringify(body) });
  return r.json();
}

export default function DriverPushSetup() {
  const [token, setToken] = useState("");
  const [msg, setMsg] = useState("");

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Push (FCM) – Configurar</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <div className="text-sm opacity-70">Cole aqui o token FCM do app mobile (Android).</div>
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="FCM token" value={token} onChange={(e)=>setToken(e.target.value)} />
        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          const r = await postJSON("/fcm/register", { token });
          setMsg(r.ok ? `Salvo ✅ (FCM configurado no servidor: ${r.configured ? "sim" : "não"})` : `Erro: ${r.error||"unknown"}`);
        }}>Salvar</button>
        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>
    </div>
  );
}
