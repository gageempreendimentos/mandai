import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import DashboardSkeleton from "@/components/skeletons/DashboardSkeleton";
import { useWarmStart } from "@/hooks/useWarmStart";
import { isAuthed, logout } from "@/lib/authLite";

import AppHeader from "@/components/layout/AppHeader";
import DraggableBottomSheet from "@/components/layout/DraggableBottomSheet";
import SurfaceCard from "@/components/layout/SurfaceCard";
import MapFull from "@/components/layout/MapFull";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { CreditCard, RotateCcw } from "lucide-react";

import { useRide } from "@/state/useRide";
import { wsResetRide, wsUpdateRide } from "@/lib/wsClient";

export default function ClientDashboard() {
  useEffect(() => {
    window.dispatchEvent(new Event("mandai:app-ready"));
  }, []);

  const navigate = useNavigate();
  const ready = useWarmStart();
  const [placing, setPlacing] = useState(false);
  const ride = useRide();

  if (!ready) return <DashboardSkeleton />;

  if (!isAuthed("client")) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md rounded-3xl shadow-lg border-black/10">
          <CardHeader>
            <CardTitle className="text-center text-3xl font-extrabold tracking-tight">MANDAI</CardTitle>
            <p className="text-center text-sm text-black/60">Entrar como Cliente</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Telefone ou Email</Label>
              <Input placeholder="(xx) xxxxx-xxxx" />
            </div>
            <div className="space-y-2">
              <Label>Senha</Label>
              <Input type="password" placeholder="••••••••" />
            </div>

            <Button
              className="w-full rounded-2xl"
              onClick={() => {
                toast("Bem-vindo!");
              }}
            >
              Entrar
            </Button>

            <Button variant="outline" className="w-full rounded-2xl" asChild>
              <Link to="/entry">Voltar</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusText =
    ride.stage === "offered"
      ? "Procurando entregador…"
      : ride.stage === "accepted"
        ? "Entregador aceitou • preparando rota"
        : ride.stage === "enroute"
          ? `Entregador a caminho • ~${ride.etaMin} min`
          : ride.stage === "completed"
            ? "Entrega finalizada ✅"
            : "—";

  return (
    <div className="min-h-screen bg-white">
      <MapFull stage={ride.stage} />

      <div className="fixed inset-x-0 top-0 z-40">
        <AppHeader
          title="Cliente"
          subtitle={statusText}
          right={
            <Button
              variant="outline"
              className="rounded-2xl"
              onClick={() => {
                logout();
                navigate("/entry", { replace: true });
              }}
            >
              Sair
            </Button>
          }
        />
      </div>

      <DraggableBottomSheet snaps={[240, 520, 740]} initialSnap={1}>
        {ride.stage === "accepted" || ride.stage === "enroute" ? (
          <div className="overflow-hidden rounded-[18px] border border-black/10">
            <div className="flex items-center justify-between px-4 py-3">
              <div className="text-lg font-extrabold tracking-tight">Motorista a Caminho</div>
              <Button
                variant="ghost"
                className="h-9 w-9 rounded-full"
                onClick={() => {
                  wsResetRide();
                  toast("Pedido resetado");
                }}
              >
                <RotateCcw className="h-4 w-4" />
              </Button>
            </div>

            <div className="px-4 pb-3">
              <div className="flex items-center gap-3 py-3 border-t border-black/5">
                <Avatar className="h-12 w-12">
                  <AvatarFallback>JS</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="text-sm font-extrabold">João Silva</div>
                  <div className="text-sm text-black/60">Moto • ABC 1234</div>
                  <div className="text-sm text-black/60">Chega em {Math.max(1, ride.etaMin)} min</div>
                </div>
              </div>

              <div className="flex items-center gap-3 py-3 border-t border-black/5">
                <div className="h-8 w-8 rounded-2xl bg-black/5 flex items-center justify-center">
                  <CreditCard className="h-4 w-4" />
                </div>
                <div className="text-sm text-black/70">Pagamento: Cartão de Crédito</div>
              </div>

              <Button
                className="mt-3 w-full rounded-2xl bg-red-600 text-white hover:bg-red-600/90"
                onClick={() => {
                  wsResetRide();
                  toast("Corrida cancelada");
                }}
              >
                Cancelar Corrida
              </Button>
            </div>
          </div>
        ) : ride.stage === "completed" ? (
          <div className="space-y-4">
            <div>
              <div className="text-sm text-black/60">Entrega concluída</div>
              <div className="text-xl font-extrabold tracking-tight">Obrigado! ✅</div>
            </div>
            <Button
              className="w-full rounded-2xl bg-black text-white hover:bg-black/90"
              onClick={() => {
                wsResetRide();
                toast("Nova entrega");
              }}
            >
              Nova Entrega
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div>
              <div className="text-sm text-black/60">Entrega agora</div>
              <div className="text-xl font-extrabold tracking-tight">Para onde vamos?</div>
            </div>

            <SurfaceCard>
              <div className="text-sm font-semibold">Endereço</div>
              <div className="mt-3 space-y-2">
                <Input placeholder="Retirada" defaultValue={ride.pickup} />
                <Input placeholder="Destino" defaultValue={ride.dropoff} />
              </div>
              <div className="mt-3 flex gap-2">
                <Button
                  className="flex-1 rounded-2xl bg-black text-white hover:bg-black/90"
                  disabled={placing}
                  onClick={() => {
                    setPlacing(true);
                    wsResetRide();
                    wsUpdateRide({ stage: "offered" });
                    setTimeout(() => {
                      setPlacing(false);
                      toast("Pedido enviado!");
                    }, 600);
                  }}
                >
                  {placing ? "Solicitando..." : "Solicitar Entrega"}
                </Button>
                <Button
                  variant="outline"
                  className="rounded-2xl"
                  onClick={() => {
                    wsResetRide();
                    toast("Pedido resetado");
                  }}
                >
                  Reset
                </Button>
              </div>
            </SurfaceCard>

            <SurfaceCard>
              <div className="text-sm font-semibold">Detalhes</div>
              <div className="mt-2 text-sm text-black/60 space-y-1">
                <div>• Status: {statusText}</div>
                <div>• Valor estimado: R$ {ride.price}</div>
              </div>
            </SurfaceCard>
          </div>
        )}
      </DraggableBottomSheet>
    </div>
  );
}
