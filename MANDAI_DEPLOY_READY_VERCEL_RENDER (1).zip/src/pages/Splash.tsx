import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Logo from "@/components/Logo";
import { prefetch } from "@/lib/prefetch";

type Props = {
  to?: string;
  durationMs?: number;
};

/**
 * Premium splash screen: light background, centered logo, subtle fade-in.
 * Respects prefers-reduced-motion.
 */
export default function Splash({ to = "/entry", durationMs = 900 }: Props) {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Prefetch most common routes after first paint (keeps startup snappy)
    prefetch(() => import("@/pages/Entry"));
    prefetch(() => import("@/pages/DashboardReal"));
    prefetch(() => import("@/pages/ClientDashboard"));
    prefetch(() => import("@/pages/RestaurantDashboard"));
    prefetch(() => import("@/pages/admin/AdminDashboard"));

    const prefersReduced = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
    const ms = prefersReduced ? 250 : durationMs;

    setReady(true);

    const t = window.setTimeout(() => {
      navigate(to, { replace: true });
    }, ms);

    return () => window.clearTimeout(t);
  }, [durationMs, navigate, to]);

  return (
    <div className="min-h-screen bg-white flex items-center justify-center">
      <div className={`transition-all duration-700 ${ready ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}>
        <div className="flex flex-col items-center gap-4">
          <Logo size="xl" variant="splash" showText={false} />
          <div className="text-slate-600 text-xs tracking-widest uppercase">Entregador Premium</div>
        </div>
      </div>
    </div>
  );
}
