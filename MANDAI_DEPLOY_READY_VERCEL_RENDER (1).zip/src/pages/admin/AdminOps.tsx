import React from "react";
export default function AdminOps(){
  return (
    <div className="p-4">
      <h1 className="text-2xl font-semibold">Operações</h1>
      <div className="opacity-70">Atrasos • Reatribuir • Mapa • Chat</div>
    </div>
  );
}
