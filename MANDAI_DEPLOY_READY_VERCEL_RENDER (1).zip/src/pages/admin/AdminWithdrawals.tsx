import React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body?: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body||{}) });
  return r.json();
}

export default function AdminWithdrawals() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["withdrawals"], queryFn: () => fetchJSON("/pix/admin/withdrawals") });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Saques PIX</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {(q.data?.withdrawals || []).length===0 ? <div className="opacity-70">Sem solicitações.</div> : null}
            {(q.data?.withdrawals || []).map((w:any)=>(
              <div key={w.id} className="border-b pb-2 last:border-b-0 last:pb-0 flex items-center justify-between gap-3">
                <div className="text-sm">
                  <div className="font-medium">#{w.id} — {w.status} — R$ {(Number(w.amount_cents)/100).toFixed(2)}</div>
                  <div className="text-xs opacity-70">driver: {w.driver_id} | pix: {w.pix_key}</div>
                </div>
                <button
                  className="rounded-xl border px-3 py-2 text-sm"
                  disabled={w.status === "paid"}
                  onClick={async ()=>{
                    await postJSON(`/pix/admin/${w.id}/mark-paid`);
                    qc.invalidateQueries({ queryKey: ["withdrawals"] });
                  }}
                >
                  Marcar pago
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="text-xs opacity-60">
        *Para PIX real, configure PIX_PROVIDER e credenciais no server.
      </div>
    </div>
  );
}
