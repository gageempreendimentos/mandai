import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

export default function AdminReplay() {
  const [rideId, setRideId] = useState("");
  const q = useQuery({ queryKey: ["replay", rideId], queryFn: () => fetchJSON(`/replay/rides/${rideId}`), enabled: !!rideId });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Replay da Corrida</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="Ride ID" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
        <div className="text-xs opacity-70">Mostra eventos + pontos GPS (para suporte/disputa).</div>
      </div>

      {q.isFetching ? <div className="opacity-70">Carregando…</div> : null}

      {q.data ? (
        <div className="grid gap-3 md:grid-cols-2">
          <div className="rounded-2xl border p-4">
            <div className="font-medium mb-2">Eventos</div>
            <div className="space-y-2 max-h-[60vh] overflow-auto">
              {(q.data.events || []).map((e: any, i: number) => (
                <div key={i} className="border-b pb-2 last:border-b-0 last:pb-0">
                  <div className="font-medium text-sm">{e.type}</div>
                  <div className="text-xs opacity-60">{new Date(e.created_at).toLocaleString()}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border p-4">
            <div className="font-medium mb-2">Pontos GPS</div>
            <div className="text-xs opacity-70 mb-2">Total: {(q.data.points || []).length}</div>
            <pre className="text-xs p-2 rounded-xl bg-black/5 overflow-auto max-h-[60vh]">{JSON.stringify((q.data.points || []).slice(0, 100), null, 2)}</pre>
          </div>
        </div>
      ) : null}
    </div>
  );
}
