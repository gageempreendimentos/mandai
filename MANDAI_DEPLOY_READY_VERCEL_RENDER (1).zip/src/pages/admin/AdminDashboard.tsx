import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import DashboardSkeleton from "@/components/skeletons/DashboardSkeleton";
import { useWarmStart } from "@/hooks/useWarmStart";
import { isAuthed, logout } from "@/lib/authLite";

import MapWithSheet from "@/components/layout/MapWithSheet";
import { RotateCcw } from "lucide-react";
import { wsResetRide } from "@/lib/wsClient";

import { useRide } from "@/state/useRide";
import { fetchOnlineDrivers, fetchZones } from "@/services/adminApi";

export default function AdminDashboard() {
  useEffect(() => {
    window.dispatchEvent(new Event("mandai:app-ready"));
  }, []);

  const ready = useWarmStart();
  const ride = useRide();
  const navigate = useNavigate();

  const [drivers, setDrivers] = useState<any[]>([]);
  const [zones, setZones] = useState<any[]>([]);
  const [loadingOps, setLoadingOps] = useState(false);
  const [opsError, setOpsError] = useState<string | null>(null);

  const driversOnline = useMemo(() => drivers.filter((d) => d.is_online !== false), [drivers]);

  if (!ready) return <DashboardSkeleton />;

  useEffect(() => {
    if (!isAuthed("admin")) return;
    let cancelled = false;
    async function load() {
      try {
        setLoadingOps(true);
        setOpsError(null);
        const [d, z] = await Promise.all([fetchOnlineDrivers(), fetchZones()]);
        if (cancelled) return;
        setDrivers(d.drivers || []);
        setZones(z.zones || []);
      } catch (e: any) {
        if (cancelled) return;
        setOpsError(e?.message || "erro");
      } finally {
        if (!cancelled) setLoadingOps(false);
      }
    }
    load();
    const t = window.setInterval(load, 5000);
    return () => {
      cancelled = true;
      window.clearInterval(t);
    };
  }, []);

  if (!isAuthed("admin")) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md rounded-3xl shadow-lg border-black/10">
          <CardHeader>
            <CardTitle className="text-center text-3xl font-extrabold tracking-tight">MANDAI</CardTitle>
            <p className="text-center text-sm text-black/60">Entrar como Admin</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Email</Label>
              <Input placeholder="admin@mandai.com" />
            </div>
            <div className="space-y-2">
              <Label>Senha</Label>
              <Input type="password" placeholder="••••••••" />
            </div>

            <Button className="w-full rounded-2xl" onClick={() => navigate("/login?role=admin")}>
              Entrar
            </Button>

            <Button variant="outline" className="w-full rounded-2xl" asChild>
              <Link to="/entry">Voltar</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusText =
    ride.stage === "offered"
      ? "Chamadas abertas"
      : ride.stage === "accepted"
        ? "Corrida aceita"
        : ride.stage === "enroute"
          ? `Em rota • ~${ride.etaMin} min`
          : ride.stage === "completed"
            ? "Finalizada"
            : "Operação ao vivo";

  return (
    <MapWithSheet
      title="Admin"
      subtitle={statusText}
      stage={ride.stage}
      right={
        <div className="flex items-center gap-2">
          <Button variant="outline" className="rounded-2xl" asChild>
            <Link to="/entry">Trocar área</Link>
          </Button>
          <Button
            variant="outline"
            className="rounded-2xl"
            onClick={() => {
              logout();
              navigate("/entry", { replace: true });
            }}
          >
            Sair
          </Button>
        </div>
      }
    >
      <div className="overflow-hidden rounded-[18px] border border-black/10">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="text-lg font-extrabold tracking-tight">Painel de Controle</div>
          <Button
            variant="ghost"
            className="h-9 w-9 rounded-full"
            onClick={() => {
              wsResetRide();
            }}
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>

        <div className="px-4 pb-3">
          <div className="py-2 border-t border-black/5">
            <div className="flex items-center justify-between py-2">
              <div className="text-sm text-black/70">Motoristas Online</div>
              <div className="text-sm font-extrabold">{driversOnline.length}</div>
            </div>
            <div className="flex items-center justify-between py-2 border-t border-black/5">
              <div className="text-sm text-black/70">Corridas Ativas</div>
              <div className="text-sm font-extrabold">{ride.stage === "completed" ? 4 : 6}</div>
            </div>
            <div className="flex items-center justify-between py-2 border-t border-black/5">
              <div className="text-sm text-black/70">Novos Pedidos</div>
              <div className="text-sm font-extrabold">3</div>
            </div>
          </div>

          {opsError ? (
  <div className="mt-2 rounded-2xl border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
    {opsError}
  </div>
) : null}

<div className="mt-3 grid gap-3">
  <div className="rounded-2xl border border-black/10 p-3">
    <div className="flex items-center justify-between">
      <div className="text-sm font-extrabold">Zonas</div>
      <div className="text-xs text-black/60">{zones.length} cadastradas</div>
    </div>
    <div className="mt-2 space-y-2">
      {loadingOps && zones.length === 0 ? (
        <div className="text-sm text-black/50">Carregando…</div>
      ) : zones.length === 0 ? (
        <div className="text-sm text-black/50">Nenhuma zona cadastrada ainda.</div>
      ) : (
        zones.slice(0, 5).map((z) => (
          <div key={z.id} className="flex items-center justify-between rounded-xl bg-black/[0.03] px-3 py-2">
            <div className="text-sm font-semibold">{z.name}</div>
            <div className="text-xs text-black/60">{z.city || "—"}</div>
          </div>
        ))
      )}
    </div>
  </div>

  <div className="rounded-2xl border border-black/10 p-3">
    <div className="flex items-center justify-between">
      <div className="text-sm font-extrabold">Entregadores Online</div>
      <div className="text-xs text-black/60">atualiza a cada 5s</div>
    </div>
    <div className="mt-2 space-y-2">
      {loadingOps && driversOnline.length === 0 ? (
        <div className="text-sm text-black/50">Carregando…</div>
      ) : driversOnline.length === 0 ? (
        <div className="text-sm text-black/50">Nenhum entregador online agora.</div>
      ) : (
        driversOnline.slice(0, 6).map((d) => (
          <div key={d.id} className="flex items-center justify-between rounded-xl bg-black/[0.03] px-3 py-2">
            <div className="text-sm font-semibold">{d.name || d.id.slice(0, 8)}</div>
            <div className="text-xs text-black/60">score {Number(d.driver_score || 5).toFixed(1)}</div>
          </div>
        ))
      )}
    </div>
  </div>
</div>

<Button className="mt-3 w-full rounded-2xl bg-blue-600 text-white hover:bg-blue-600/90">
  Ver Relatórios
</Button>
        </div>
      </div>
    </MapWithSheet>
  );
}
