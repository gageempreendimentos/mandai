import React from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

const DOW = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];

export default function AdminForecast() {
  const q = useQuery({ queryKey: ["forecast"], queryFn: () => fetchJSON("/forecast") });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Forecast de Demanda (MVP)</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {(q.data?.forecast || []).slice(0, 200).map((f: any, i: number) => (
              <div key={i} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                <div className="text-sm">
                  <div className="font-medium">Zona: {f.zone_id || "global"}</div>
                  <div className="text-xs opacity-70">{DOW[f.dow]} {String(f.hour).padStart(2,"0")}:00</div>
                </div>
                <div className="text-sm text-right">
                  <div className="font-semibold">Pedidos: {Number(f.expected_orders).toFixed(1)}</div>
                  <div className="text-xs opacity-70">Drivers: {Number(f.expected_active_drivers).toFixed(1)} | risco {f.risk_level}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="text-xs opacity-60">
        *MVP baseado em médias históricas. Depois podemos evoluir com sazonalidade e clima.
      </div>
    </div>
  );
}
