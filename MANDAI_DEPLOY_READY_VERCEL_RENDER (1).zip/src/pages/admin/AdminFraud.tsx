import React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body?: any) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: body ? JSON.stringify(body) : "{}",
  });
  return r.json();
}

export default function AdminFraud() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["fraud_flags"], queryFn: () => fetchJSON("/fraud?resolved=false&limit=100"), refetchInterval: 15000 });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Anti-fraude</h1>

      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-3">
            {(q.data?.flags || []).map((f: any) => (
              <div key={f.id} className="border-b pb-3 last:border-b-0 last:pb-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-medium">{f.kind} (sev {f.severity})</div>
                  <div className="flex items-center gap-2">
                    {f.driver_id ? (
                      <>
                        <button
                          className="rounded-xl border px-3 py-1 text-sm"
                          onClick={async ()=>{
                            const reason = window.prompt("Motivo do bloqueio (opcional):") || "";
                            await postJSON(`/admin/users/${f.driver_id}/block`, { reason: reason || null });
                            qc.invalidateQueries({ queryKey: ["fraud_flags"] });
                          }}
                        >
                          Bloquear driver
                        </button>
                        <button
                          className="rounded-xl border px-3 py-1 text-sm"
                          onClick={async ()=>{
                            await postJSON(`/admin/users/${f.driver_id}/unblock`);
                            qc.invalidateQueries({ queryKey: ["fraud_flags"] });
                          }}
                        >
                          Desbloquear
                        </button>
                      </>
                    ) : null}
                    <button
                      className="rounded-xl border px-3 py-1 text-sm"
                      onClick={async ()=>{
                        await postJSON(`/fraud/${f.id}/resolve`);
                        qc.invalidateQueries({ queryKey: ["fraud_flags"] });
                      }}
                    >
                      Resolver
                    </button>
                  </div>
                </div>
                <div className="text-xs opacity-70">ride: {f.ride_id} | driver: {f.driver_id || "—"}</div>
                <pre className="text-xs mt-2 p-2 rounded-xl bg-black/5 overflow-auto">{JSON.stringify(f.details, null, 2)}</pre>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
