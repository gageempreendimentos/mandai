import React from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

export default function AdminAudit() {
  const q = useQuery({ queryKey: ["admin_audit"], queryFn: () => fetchJSON("/admin/audit?limit=100") });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Auditoria</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? (
          <div className="opacity-70">Carregando…</div>
        ) : (
          <div className="space-y-3">
            {(q.data?.audit || []).map((a: any) => (
              <div key={a.id} className="border-b pb-3 last:border-b-0 last:pb-0">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{a.action}</div>
                  <div className="text-xs opacity-60">{a.created_at ? new Date(a.created_at).toLocaleString() : ""}</div>
                </div>
                <div className="text-xs opacity-70">
                  actor: {a.actor_user_id || "—"} | {a.entity_type || ""} {a.entity_id || ""}
                </div>
                {a.payload ? (
                  <pre className="text-xs mt-2 p-2 rounded-xl bg-black/5 overflow-auto">{JSON.stringify(a.payload, null, 2)}</pre>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
