import React from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

export default function AdminHeatmap() {
  const q = useQuery({ queryKey: ["admin_heatmap"], queryFn: () => fetchJSON("/admin/heatmap?since_minutes=180&grid=0.01") });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Heatmap (resumo)</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? (
          <div className="opacity-70">Carregando…</div>
        ) : (
          <div className="space-y-2">
            <div className="text-sm opacity-70">
              grid: {q.data?.grid} | últimas {q.data?.since_minutes} min | drivers online: {q.data?.drivers?.length ?? 0}
            </div>
            <div className="font-medium">Top regiões (pickup)</div>
            <div className="space-y-2">
              {(q.data?.pickups || []).slice(0, 30).map((p: any, i: number) => (
                <div key={i} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                  <div className="text-sm">{Number(p.lat).toFixed(4)}, {Number(p.lng).toFixed(4)}</div>
                  <div className="font-semibold">{p.count}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
