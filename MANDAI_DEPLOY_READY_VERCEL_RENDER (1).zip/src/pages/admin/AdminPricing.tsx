import React, { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  return r.json();
}

export default function AdminPricing() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["pricing_rules"], queryFn: () => fetchJSON("/pricing") });
  const [form, setForm] = useState({ name: "default", base_fee_cents: 500, per_km_cents: 250, min_fee_cents: 800, surge_multiplier: 1.0 });

  const rules = useMemo(() => q.data?.rules || [], [q.data]);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Precificação</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <div className="font-medium">Nova regra (global/default)</div>
        <div className="grid md:grid-cols-5 gap-2">
          <input className="border rounded-xl px-3 py-2" value={form.name} onChange={(e)=>setForm({ ...form, name: e.target.value })} placeholder="name" />
          <input className="border rounded-xl px-3 py-2" value={form.base_fee_cents} onChange={(e)=>setForm({ ...form, base_fee_cents: Number(e.target.value) })} placeholder="base cents" />
          <input className="border rounded-xl px-3 py-2" value={form.per_km_cents} onChange={(e)=>setForm({ ...form, per_km_cents: Number(e.target.value) })} placeholder="per km cents" />
          <input className="border rounded-xl px-3 py-2" value={form.min_fee_cents} onChange={(e)=>setForm({ ...form, min_fee_cents: Number(e.target.value) })} placeholder="min cents" />
          <input className="border rounded-xl px-3 py-2" value={form.surge_multiplier} onChange={(e)=>setForm({ ...form, surge_multiplier: Number(e.target.value) })} placeholder="surge" />
        </div>
        <button
          className="rounded-xl border px-3 py-2"
          onClick={async ()=>{
            await postJSON("/pricing", { ...form, active: true });
            qc.invalidateQueries({ queryKey: ["pricing_rules"] });
          }}
        >
          Salvar
        </button>
      </div>

      <div className="rounded-2xl border p-4">
        <div className="font-medium mb-2">Regras</div>
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {rules.map((r: any) => (
              <div key={r.id} className="border-b pb-2 last:border-b-0 last:pb-0">
                <div className="flex justify-between">
                  <div className="font-medium">{r.name} {r.active ? "" : "(off)"}</div>
                  <div className="text-xs opacity-60">surge {r.surge_multiplier}</div>
                </div>
                <div className="text-xs opacity-70">
                  base {r.base_fee_cents} | km {r.per_km_cents} | min {r.per_min_cents} | minFee {r.min_fee_cents}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
