import React from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

export default function AdminDispatchSim() {
  const q = useQuery({ queryKey: ["dispatch_sim"], queryFn: () => fetchJSON("/dispatch/simulate?limit=25") });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Dispatch Sombra</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {(q.data?.proposals || []).map((p: any, i: number) => (
              <div key={i} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                <div className="text-xs">
                  ride: {p.ride_id}<br/>driver: {p.driver_id}
                </div>
                <div className="font-semibold">{Math.round(p.distance_m)} m</div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="text-xs opacity-60">
        *Este modo não altera corridas. Serve pra testar o algoritmo com segurança.
      </div>
    </div>
  );
}
