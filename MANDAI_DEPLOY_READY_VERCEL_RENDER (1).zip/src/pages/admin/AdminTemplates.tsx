import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function AdminTemplates() {
  const [data, setData] = useState<any>({ driver_quick_messages: [] });
  const [msg, setMsg] = useState("");

  useEffect(()=>{ fetchJSON("/templates").then(setData).catch(()=>{}); }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Templates</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <div className="text-sm font-medium">Mensagens rápidas (driver)</div>
        <textarea className="border rounded-xl w-full p-3 min-h-[220px]" value={(data.driver_quick_messages||[]).join("\n")} onChange={(e)=>setData({ ...data, driver_quick_messages: e.target.value.split("\n").filter(Boolean) })} />
        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          setMsg("");
          const r = await postJSON("/templates", data);
          setMsg(r.ok ? "Salvo!" : "Erro");
        }}>Salvar</button>
        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
      </div>
    </div>
  );
}
