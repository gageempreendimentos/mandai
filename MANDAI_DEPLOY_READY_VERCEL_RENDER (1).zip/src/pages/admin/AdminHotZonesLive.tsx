import React, { useEffect, useState } from "react";

export default function AdminHotZonesLive() {
  const [hot, setHot] = useState<any[]>([]);
  const [last, setLast] = useState<string>("");

  useEffect(() => {
    const wsUrl = (location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/ws";
    const ws = new WebSocket(wsUrl);
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === "HOT_ZONES") {
          setHot(msg.hot_zones || []);
          setLast(msg.at || "");
        }
      } catch {}
    };
    return () => ws.close();
  }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Heatmap ao vivo (Hot Zones)</h1>
      <div className="text-xs opacity-70">Atualizado: {last ? new Date(last).toLocaleTimeString() : "—"}</div>
      <div className="rounded-2xl border p-4">
        {hot.length === 0 ? (
          <div className="opacity-70">Sem dados ainda (aguarde alguns segundos).</div>
        ) : (
          <div className="space-y-2">
            {hot.map((h, i) => (
              <div key={i} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                <div className="text-sm">Zona: {h.zone_id || "global"}</div>
                <div className="font-semibold">{h.orders} pedidos</div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="text-xs opacity-60">
        *MVP: lista de zonas quentes. Depois colocamos overlay no mapa + sugestão pro entregador.
      </div>
    </div>
  );
}
