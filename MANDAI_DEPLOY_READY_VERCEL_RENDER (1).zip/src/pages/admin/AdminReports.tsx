import React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

async function postJSON(url: string, body: any) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  return r.json();
}

export default function AdminReports() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin_reports"], queryFn: () => fetchJSON("/reports-api") });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Relatórios</h1>

      <div className="rounded-2xl border p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-medium">Gerar diário (CSV)</div>
            <div className="text-xs opacity-70">Gera um CSV simples com contagem por status no dia</div>
          </div>
          <button
            className="rounded-xl border px-3 py-2"
            onClick={async ()=>{
              await postJSON("/reports-api/daily", {});
              qc.invalidateQueries({ queryKey: ["admin_reports"] });
            }}
          >
            Gerar agora
          </button>
        </div>
      </div>

      <div className="rounded-2xl border p-4">
        <div className="font-medium mb-2">Arquivos gerados</div>
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {(q.data?.reports || []).map((r: any) => (
              <div key={r.id} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                <div>
                  <div className="font-medium">{r.kind} {r.period_start || ""}</div>
                  <div className="text-xs opacity-60">{new Date(r.created_at).toLocaleString()}</div>
                </div>
                <a className="underline" href={r.file_url} target="_blank" rel="noreferrer">baixar</a>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
