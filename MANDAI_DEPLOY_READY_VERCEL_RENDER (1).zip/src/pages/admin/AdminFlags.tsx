import React, { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

async function postJSON(url: string, body: any) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  return r.json();
}

export default function AdminFlags() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin_flags"], queryFn: () => fetchJSON("/admin/flags") });
  const [key, setKey] = useState("");
  const [enabled, setEnabled] = useState(false);

  const flags = useMemo(() => q.data?.flags || [], [q.data]);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Feature Flags</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <div className="font-medium">Criar/atualizar flag global</div>
        <div className="flex flex-col md:flex-row gap-2">
          <input className="border rounded-xl px-3 py-2 flex-1" placeholder="chave (ex: new_dispatch_ui)" value={key} onChange={(e)=>setKey(e.target.value)} />
          <label className="flex items-center gap-2 border rounded-xl px-3 py-2">
            <input type="checkbox" checked={enabled} onChange={(e)=>setEnabled(e.target.checked)} />
            enabled
          </label>
          <button
            className="rounded-xl border px-3 py-2"
            onClick={async ()=>{
              if (!key) return;
              await postJSON("/admin/flags", { key, scope_kind: "global", scope_value: null, enabled });
              setKey("");
              qc.invalidateQueries({ queryKey: ["admin_flags"] });
            }}
          >
            Salvar
          </button>
        </div>
      </div>

      <div className="rounded-2xl border p-4">
        <div className="font-medium mb-2">Flags atuais</div>
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {flags.map((f: any, i: number) => (
              <div key={`${f.key}-${i}`} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                <div>
                  <div className="font-medium">{f.key}</div>
                  <div className="text-xs opacity-60">{f.scope_kind}{f.scope_value ? `:${f.scope_value}` : ""}</div>
                </div>
                <button
                  className="rounded-xl border px-3 py-2"
                  onClick={async ()=>{
                    await postJSON("/admin/flags", { key: f.key, scope_kind: f.scope_kind, scope_value: f.scope_value, enabled: !f.enabled });
                    qc.invalidateQueries({ queryKey: ["admin_flags"] });
                  }}
                >
                  {f.enabled ? "ON" : "OFF"}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
