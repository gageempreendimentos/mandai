import React, { useMemo, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Lock, Phone } from "lucide-react";
import Logo from "@/components/Logo";
import MapFull from "@/components/layout/MapFull";

function phoneDigits(v: string) {
  return v.replace(/\D/g, "").slice(0, 13); // allow 55 + DDD + 9 digits
}

function formatBRPhone(v: string) {
  const d = phoneDigits(v);
  // Accept either (11 digits) or with country code (13 digits starting with 55)
  const hasCountry = d.startsWith("55") && d.length >= 12;
  const local = hasCountry ? d.slice(2) : d;

  const ddd = local.slice(0, 2);
  const p1 = local.slice(2, 7);
  const p2 = local.slice(7, 11);

  const prefix = hasCountry ? "+55" : "+55";
  if (!local.length) return "";
  if (local.length <= 2) return `${prefix} (${ddd}`;
  if (local.length <= 7) return `${prefix} (${ddd}) ${p1}`;
  return `${prefix} (${ddd}) ${p1}-${p2}`;
}

function toE164(v: string) {
  const d = phoneDigits(v);
  if (!d) return "";
  if (d.startsWith("55") && d.length >= 12) return `+${d}`;
  // assume BR local (DDD + number)
  return `+55${d}`;
}

const ClientLogin: React.FC = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const reduceMotion = useReducedMotion();

  const [telefone, setTelefone] = useState("");
  const [senha, setSenha] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const phoneE164 = useMemo(() => toE164(telefone), [telefone]);

  const handleSubmit = async () => {
    const digits = phoneDigits(telefone);
    if (!digits || digits.length < 10 || !senha) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha telefone e senha",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        phone: phoneE164,
        password: senha,
      });

      if (error) throw error;

      toast({
        title: "Login realizado! ✅",
        description: "Bem-vindo de volta",
      });

      navigate("/client-dashboard");
    } catch (error: any) {
      toast({
        title: "Erro ao fazer login",
        description: error?.message || "Verifique suas credenciais",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background map */}
      <div className="absolute inset-0">
        <div className="absolute inset-0">
          <MapFull stage="idle" />
        </div>
        <div className="absolute inset-0 backdrop-blur-[2px] bg-white/40" />
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 w-[120%] h-48 bg-slate-900/70 blur-0 rounded-b-[60%]" />
      </div>

      <motion.div
        className="relative z-10 min-h-screen flex flex-col items-center"
        initial={reduceMotion ? false : { opacity: 0, y: 10 }}
        animate={reduceMotion ? {} : { opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="pt-10 pb-6">
          <div className="flex justify-center">
            <Logo size="lg" variant="login" />
          </div>
        </div>

        <div className="w-full px-5 pb-10">
          <div className="mx-auto max-w-md rounded-3xl bg-white/90 shadow-[var(--mandai-shadow)] border border-black/10 p-6">
            <div className="text-2xl font-extrabold tracking-tight text-black/80">
              Use seu número de telefone para entrar.
            </div>

            <div className="mt-5 space-y-3">
              <div className="relative">
                <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-black/45" />
                <Input
                  inputMode="tel"
                  placeholder="+55 (11) 98765-4321"
                  value={telefone}
                  onChange={(e) => setTelefone(formatBRPhone(e.target.value))}
                  className="h-12 pl-10 rounded-2xl bg-white/70"
                />
              </div>

              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-black/45" />
                <Input
                  type="password"
                  placeholder="Senha"
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  className="h-12 pl-10 rounded-2xl bg-white/70"
                />
              </div>
            </div>

            <Button
              variant="hero"
              size="lg"
              className="w-full mt-5 rounded-2xl bg-amber-500 hover:bg-amber-500/90 text-white"
              onClick={handleSubmit}
              disabled={isLoading}
            >
              {isLoading ? "Entrando..." : "Entrar"}
            </Button>

            <p className="text-center text-sm text-black/60 mt-4">
              Novo por aqui?{" "}
              <a href="/client-register" className="text-blue-600 hover:underline">
                Cadastre-se
              </a>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ClientLogin;
