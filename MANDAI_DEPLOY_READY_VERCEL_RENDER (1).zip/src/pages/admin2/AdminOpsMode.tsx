import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function AdminOpsMode() {
  const [pauseZone, setPauseZone] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(()=>{ fetchJSON("/ops").catch(()=>{}); }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Modo Operação</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <div className="text-sm font-medium">Pausar dispatch por zona</div>
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="zone_id" value={pauseZone} onChange={(e)=>setPauseZone(e.target.value)} />
        <div className="flex gap-2">
          <button className="rounded-xl border px-3 py-2" onClick={async()=>{
            setMsg("");
            const r = await postJSON("/ops/paused_zones", { zones: pauseZone ? [pauseZone] : [] });
            setMsg(r.ok ? "Salvo!" : "Erro");
          }}>Salvar</button>
          <button className="rounded-xl border px-3 py-2" onClick={async()=>{
            await postJSON("/ops/paused_zones", { zones: [] });
            setMsg("Removido");
          }}>Limpar</button>
        </div>
        {msg ? <div className="text-sm opacity-70">{msg}</div> : null}
        <div className="text-xs opacity-60">
          *MVP: grava uma lista. O dispatch pode ser estendido para respeitar isso por zona.
        </div>
      </div>
    </div>
  );
}
