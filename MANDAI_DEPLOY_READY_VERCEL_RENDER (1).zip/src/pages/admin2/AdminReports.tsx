import React, { useState } from "react";

export default function AdminReports() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const qs = new URLSearchParams();
  if (from) qs.set("from", from);
  if (to) qs.set("to", to);
  const q = qs.toString() ? `?${qs.toString()}` : "";

  return (
    <div className="p-4 max-w-2xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Relatórios</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <input className="border rounded-xl px-3 py-2" placeholder="De (AAAA-MM-DD)" value={from} onChange={(e)=>setFrom(e.target.value)} />
          <input className="border rounded-xl px-3 py-2" placeholder="Até (AAAA-MM-DD)" value={to} onChange={(e)=>setTo(e.target.value)} />
        </div>
        <div className="flex gap-2 flex-wrap">
          <a className="rounded-xl border px-3 py-2 text-sm" href={`/reports/rides.csv${q}`}>Baixar rides.csv</a>
          <a className="rounded-xl border px-3 py-2 text-sm" href={`/reports/companies.csv${q}`}>Baixar companies.csv</a>
        </div>
        <div className="text-xs opacity-60">Precisa estar logado como admin.</div>
      </div>
    </div>
  );
}
