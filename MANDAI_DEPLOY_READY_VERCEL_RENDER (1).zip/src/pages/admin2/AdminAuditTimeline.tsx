import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

export default function AdminAuditTimeline() {
  const [rideId, setRideId] = useState("");
  const q = useQuery({ queryKey: ["audit", rideId], queryFn: () => fetchJSON(`/audit-timeline/rides/${rideId}`), enabled: !!rideId });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Timeline (Auditoria)</h1>
      <div className="rounded-2xl border p-4 space-y-2">
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="ride_id" value={rideId} onChange={(e)=>setRideId(e.target.value)} />
      </div>

      {q.isLoading ? <div className="opacity-70">Carregando…</div> : null}

      {q.data?.ride ? (
        <div className="rounded-2xl border p-4">
          <div className="font-medium mb-2">Ride: {q.data.ride.id}</div>
          <div className="text-xs opacity-70">status: {q.data.ride.status} | created: {new Date(q.data.ride.created_at).toLocaleString()}</div>
          {q.data.ride.scheduled_for ? <div className="text-xs opacity-70">scheduled_for: {new Date(q.data.ride.scheduled_for).toLocaleString()} ({q.data.ride.schedule_status})</div> : null}
        </div>
      ) : null}

      <div className="rounded-2xl border p-4">
        <div className="font-medium mb-2">Eventos</div>
        <div className="space-y-2 max-h-[60vh] overflow-auto">
          {(q.data?.timeline || []).map((e:any, i:number)=>(
            <div key={i} className="border-b pb-2 last:border-b-0 last:pb-0">
              <div className="font-medium text-sm">{e.type}</div>
              <div className="text-xs opacity-70">{new Date(e.created_at).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
