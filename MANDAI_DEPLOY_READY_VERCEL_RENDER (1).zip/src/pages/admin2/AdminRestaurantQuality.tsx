import React from "react";
import { useQuery } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}

export default function AdminRestaurantQuality() {
  const q = useQuery({ queryKey: ["rest_quality"], queryFn: () => fetchJSON("/restaurants2/quality"), refetchInterval: 60000 });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Qualidade do Restaurante</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {(q.data?.restaurants || []).map((r:any)=>(
              <div key={r.restaurant_id} className="flex items-center justify-between border-b pb-2 last:border-b-0 last:pb-0">
                <div>
                  <div className="font-medium">{r.name || r.restaurant_id}</div>
                  <div className="text-xs opacity-70">Pedidos 7d: {r.orders_7d || 0}</div>
                </div>
                <div className="text-sm text-right">
                  <div>Prep: {Number(r.avg_prep_minutes||0).toFixed(1)} min</div>
                  <div className="text-xs opacity-70">Cancel: {(Number(r.cancel_rate||0)*100).toFixed(1)}%</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
