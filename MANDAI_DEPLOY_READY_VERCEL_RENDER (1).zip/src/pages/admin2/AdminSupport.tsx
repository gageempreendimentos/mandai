import React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function AdminSupport() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["tickets"], queryFn: () => fetchJSON("/support") });

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Suporte (Tickets)</h1>
      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {(q.data?.tickets || []).length===0 ? <div className="opacity-70">Sem tickets.</div> : null}
            {(q.data?.tickets || []).map((t:any)=>(
              <div key={t.id} className="border-b pb-2 last:border-b-0 last:pb-0">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium">#{t.id} — {t.subject}</div>
                    <div className="text-xs opacity-70">{t.role} • {new Date(t.created_at).toLocaleString()}</div>
                  </div>
                  <div className="flex gap-2">
                    <select className="border rounded-xl px-2 py-1 text-sm" defaultValue={t.status}
                      onChange={async(e)=>{
                        await postJSON(`/support/${t.id}/status`, { status: e.target.value });
                        qc.invalidateQueries({ queryKey:["tickets"] });
                      }}>
                      <option value="open">open</option>
                      <option value="in_progress">in_progress</option>
                      <option value="resolved">resolved</option>
                      <option value="closed">closed</option>
                    </select>
                  </div>
                </div>
                <div className="text-sm mt-2 whitespace-pre-wrap">{t.message}</div>
                {t.ride_id ? <div className="text-xs opacity-70 mt-1">ride: {t.ride_id}</div> : null}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
