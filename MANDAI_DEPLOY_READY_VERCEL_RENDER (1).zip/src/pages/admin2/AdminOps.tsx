import React, { useEffect, useState } from "react";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials:"include" });
  return r.json();
}

export default function AdminOps() {
  const [ov, setOv] = useState<any>(null);
  const [late, setLate] = useState<any[]>([]);

  const load = async ()=>{
    const o = await fetchJSON("/adminops/overview");
    const l = await fetchJSON("/adminops/late");
    setOv(o); setLate(l.rides||[]);
  };

  useEffect(()=>{ load(); const t=setInterval(load, 10000); return ()=>clearInterval(t); }, []);

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Operações</h1>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border p-4">
          <div className="text-xs opacity-70">Entregas atrasadas</div>
          <div className="text-3xl font-semibold">{ov?.late ?? "—"}</div>
        </div>
        <div className="rounded-2xl border p-4">
          <div className="text-xs opacity-70">Drivers online</div>
          <div className="text-3xl font-semibold">{ov?.online_drivers ?? "—"}</div>
        </div>
      </div>

      <div className="rounded-2xl border overflow-hidden">
        <div className="p-3 font-medium border-b">Atrasadas</div>
        {late.length===0 ? <div className="p-4 opacity-70">Nenhuma agora.</div> : null}
        {late.map((r)=>(
          <div key={r.id} className="p-4 border-b last:border-b-0">
            <div className="font-medium">{r.kind} • {r.status}</div>
            <div className="text-xs opacity-70">{r.pickup?.address || "Coleta"} → {r.dropoff?.address || "Entrega"}</div>
            <div className="text-xs opacity-60">Atualizado: {new Date(r.updated_at).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
