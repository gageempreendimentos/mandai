import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

async function fetchJSON(url: string) {
  const r = await fetch(url, { credentials: "include" });
  return r.json();
}
async function postJSON(url: string, body: any) {
  const r = await fetch(url, { method: "POST", headers: { "content-type":"application/json" }, credentials: "include", body: JSON.stringify(body) });
  return r.json();
}

export default function AdminZonePolicies() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["zone_policies"], queryFn: () => fetchJSON("/zone-policies") });

  const [zoneId, setZoneId] = useState("");
  const [kind, setKind] = useState<"forbidden"|"premium">("forbidden");
  const [mult, setMult] = useState(1.2);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Políticas de Zona</h1>

      <div className="rounded-2xl border p-4 space-y-2">
        <div className="font-medium text-sm">Criar política</div>
        <input className="border rounded-xl px-3 py-2 w-full" placeholder="zone_id" value={zoneId} onChange={(e)=>setZoneId(e.target.value)} />
        <select className="border rounded-xl px-3 py-2 w-full" value={kind} onChange={(e)=>setKind(e.target.value as any)}>
          <option value="forbidden">forbidden</option>
          <option value="premium">premium</option>
        </select>
        {kind==="premium" ? (
          <input className="border rounded-xl px-3 py-2 w-full" type="number" step="0.05" value={mult} onChange={(e)=>setMult(Number(e.target.value))} />
        ) : null}
        <button className="rounded-xl border px-3 py-2" onClick={async()=>{
          await postJSON("/zone-policies", { zone_id: zoneId, kind, payload: kind==="premium" ? { multiplier: mult } : {} });
          qc.invalidateQueries({ queryKey: ["zone_policies"] });
        }}>Criar</button>
      </div>

      <div className="rounded-2xl border p-4">
        {q.isLoading ? <div className="opacity-70">Carregando…</div> : (
          <div className="space-y-2">
            {(q.data?.policies || []).map((p:any)=>(
              <div key={p.id} className="border-b pb-2 last:border-b-0 last:pb-0 flex items-center justify-between">
                <div className="text-sm">
                  <div className="font-medium">#{p.id} — {p.kind} — {p.zone_id}</div>
                  <div className="text-xs opacity-70">active: {String(p.active)} {p.payload?.multiplier ? `| mult: ${p.payload.multiplier}` : ""}</div>
                </div>
                <button className="rounded-xl border px-3 py-2 text-sm" onClick={async()=>{
                  await postJSON(`/zone-policies/${p.id}`, { active: !p.active });
                  qc.invalidateQueries({ queryKey: ["zone_policies"] });
                }}>{p.active ? "Desativar" : "Ativar"}</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
