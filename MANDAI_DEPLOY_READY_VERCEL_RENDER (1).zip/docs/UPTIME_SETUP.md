# Monitoramento externo (Uptime)

Você já tem endpoints:
- GET /health
- GET /metrics-lite

## Opção rápida (UptimeRobot - grátis)
1. Crie conta no UptimeRobot
2. Add New Monitor -> HTTP(s)
3. URL: https://SEU-DOMINIO/health
4. Interval: 1 minuto
5. Alerta: Email/Telegram/WhatsApp (via integração)

## Opção profissional (Better Stack)
- Monitor HTTP em /health
- Monitor de logs (se quiser)
- Status page pública (opcional)

## Sugestão
- Configure também monitor em /metrics-lite (a cada 5 min) para ver tendências.
