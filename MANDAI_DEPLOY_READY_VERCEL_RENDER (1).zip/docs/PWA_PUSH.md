# PWA + Push (pack 5)

## PWA
- public/manifest.json
- public/sw.js
- Registro no main.tsx

## Push
- Endpoint: POST /push2/register (salva token)
- Para push real: configurar provedor (FCM) e usar token salvo em push_tokens.
