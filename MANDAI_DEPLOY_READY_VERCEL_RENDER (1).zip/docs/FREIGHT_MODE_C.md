# Frete (Modo C): preço automático + ofertas (leilão)

## Cliente
- Cria frete em /client/freight/new
- Sistema calcula um preço base (quote)
- Motoristas podem enviar ofertas (bid)
- Cliente aceita a melhor oferta e o frete vira ASSIGNED

## Entregador
- Configura veículo em /driver/settings (carro/van/caminhão)
- Vê lista em /driver/freight
- Envia oferta em R$

## Backend
- POST /freight/create
- GET /freight/available (driver)
- POST /freight/:rideId/bid (driver)
- GET /freight/:rideId/bids (client)
- POST /freight/:rideId/accept-bid/:bidId (client)

## Observação
- Moto não vê frete.
- Preço base é apenas referência; a oferta aceita define fare_cents final.
