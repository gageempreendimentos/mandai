# OPS Pack 1–9 (Implementado)

1) POD + Checklist com upload real (usa /uploads-api)
2) Listas unificadas:
   - Cliente: pedidos/fretes
   - Driver: minhas entregas
   - Restaurante: pedidos por status
3) Pagamentos (stub):
   - Webhook PIX/cartão
   - Estados: pending/paid/refunded
4) Admin Ops Dashboard (stub):
   - atrasos
   - reatribuição
   - mapa (hook)
5) Relatórios:
   - CSV/PDF (stub)
6) Rate limit:
   - middleware preparado
7) Logs externos:
   - hook Sentry/BetterStack
8) Backup:
   - instruções cron
9) Push real (FCM):
   - wiring + envs
