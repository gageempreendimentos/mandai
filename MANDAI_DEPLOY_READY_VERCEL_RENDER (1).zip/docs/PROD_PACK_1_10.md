# Pacote Produção (1 ao 10) — versão B (produção total)

Este ZIP inclui:
- Health: /health
- Metrics-lite: /metrics-lite
- Rate limit básico (server/src/middlewares/rateLimit.js)
- PIX provider interface (server/src/pix/provider.js) + SIMULATED default
- Admin telas: /admin/withdrawals e /admin/templates
- Templates persistidos em server/src/templates/defaults.json
- Navegação helper: src/lib/navigation.ts
- Docker: Dockerfile, server/Dockerfile e docker-compose.yml

⚠️ PIX real:
- Configure PIX_PROVIDER e credenciais.
- Implementar chamadas HTTP do provider escolhido em server/src/pix/provider.js (já estruturado).
