# Branding MANDAI

- Nome do app: MANDAI
- Logo: `public/logo-mandai.svg`
- Tema: primária laranja (HSL 24 95% 53%)

Se quiser ajustar o laranja, edite as variáveis CSS `--primary/--ring/--accent` em src/index.css.
