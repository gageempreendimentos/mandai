# 1-4: Termos + Onboarding + Landing + Uptime

## Rotas novas (frontend)
- /terms
- /onboarding
- /landing
- /landing/restaurante
- /landing/entregador

## Backend
- /terms/current
- /terms/accept
- /terms/admin (admin)
- /onboarding/me

## Banco
- terms_versions
- user_terms_acceptance
- users.onboarding_step / onboarding_done

## Observação
Textos de termos são base; ideal revisar com advogado.
