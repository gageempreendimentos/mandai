# Pacote Avançado implementado: 1,2,3,4,6

## 1) Redispatch inteligente
- Worker `dispatch_scan` roda a cada `DISPATCH_SCAN_SECONDS` (padrão 5s)
- Seleciona ride sem driver (status created/preparing) com pickup_lat/lng
- Filtra drivers online + ping recente + (opcional) mesma zona do ride
- Escolhe o mais próximo por Haversine e atribui `assigned`

> Para melhorar mais: considerar score, recusas, cooldown, limite de tarefas.

## 2) Dead-man switch (offline automático)
- Worker `deadman_scan` marca driver `is_online=false` se não pingar em `DEADMAN_SECONDS`
- Ping é atualizado via endpoint `/rides/driver/location`

## 3) Geofence pickup/dropoff
- `POST /rides/:id/pickup` exige lat/lng e valida distância do pickup (padrão 200m)
- `POST /rides/:id/complete` valida distância do dropoff (padrão 250m)
- Configs: `GEOFENCE_PICKUP_METERS`, `GEOFENCE_DROPOFF_METERS`

## 4) Histórico de localização (replay)
- Endpoint `/rides/driver/location` pode receber `ride_id`
- Salva pontos em `ride_location_points` no máximo a cada `LOCATION_ARCHIVE_EVERY_SECONDS` (padrão 10s)

## 6) Notificações por template
- CRUD simples:
  - `GET /notifications/templates`
  - `POST /notifications/templates`
- Envio:
  - `POST /notifications/send-template` (renderiza {{vars}})
  - `POST /notifications/drivers` (broadcast rápido)
- Outbox: `notifications_outbox` + job `send_notification` (placeholder de entrega: você pode integrar FCM/Supabase push)
