# Publicação PWA / Play Store – Checklist (MANDAI)

## PWA (Web)
- [ ] Domínio HTTPS
- [ ] `manifest.webmanifest` com name/short_name/start_url/display=standalone
- [ ] Ícones 192/512 + maskable
- [ ] `<meta name="theme-color">` no `index.html`
- [ ] Testar instalação Android/iOS
- [ ] Testar offline (app shell)
- [ ] Testar push em background (firebase-messaging-sw.js gerado)

## Produção (Backend)
- [ ] `DATABASE_URL`, `JWT_*`, `REDIS_URL`, `SENTRY_DSN` (opcional)
- [ ] Subir 2 processos:
  - API: `cd server && npm run start`
  - Worker: `cd server && npm run worker`
- [ ] Redis no ar (ex.: `docker compose -f server/docker-compose.redis.yml up -d`)
