# Pacote implementado: 1) Precificação dinâmica 2) Dispatch sombra 4) Anti-fraude

## 1) Precificação dinâmica
- Tabela: pricing_rules
- Quote:
  - POST /pricing/quote { zone_id?, distance_km, duration_min? }
- Admin gerencia regras:
  - GET /pricing
  - POST /pricing (create/update)
Campos principais:
- base_fee_cents, per_km_cents, min_fee_cents, surge_multiplier

## 2) Dispatch simulador (modo sombra)
- Endpoint admin:
  - GET /dispatch/simulate?limit=25
Retorna propostas { ride_id, driver_id, distance_m } sem alterar o banco.

## 4) Anti-fraude
- Tabela: fraud_flags
- Worker job: fraud_scan (a cada 5 min)
Sinais:
- gps_teleport (distância grande em pouco tempo)
- speed_anomaly (> ~162 km/h)
- pod_outside_geofence (POD muito longe do dropoff)

Admin:
- GET /fraud?resolved=false
- POST /fraud/:id/resolve
