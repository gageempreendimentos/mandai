# MVP implementado: 1) Forecast 2) Heatmap ao vivo 3) Voz no chat 4) PIX simulado

## 1) Forecast
- Job: forecast_compute (a cada 15 min)
- API admin: GET /forecast
- Tela: /admin/forecast

## 2) Heatmap ao vivo (Hot Zones)
- Job: hotzones_broadcast (a cada 15s)
- WS envia: { type: "HOT_ZONES", hot_zones: [{zone_id, orders}], at }
- Tela admin: /admin/hotzones

## 3) Voz no chat (MVP)
- Upload de anexos já existente suporta agora attachment_type=audio/*
- Extensão default audio: .webm
- Client pode enviar usando MediaRecorder ou input de arquivo e enviar base64 no endpoint de attachments.

## 4) PIX (MVP simulado)
- Tabela: withdraw_requests
- Driver:
  - POST /pix/withdraw { pix_key, amount_cents }
  - GET /pix/me/withdrawals
  - Tela: /driver/withdraw
- Admin:
  - GET /pix/admin/withdrawals
  - POST /pix/admin/:id/mark-paid (simula pagamento)
