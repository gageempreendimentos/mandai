# Produção: 2 + 4 + 5 + 6

## 2) Migrações + Seed
- Rodar:
  - `cd server`
  - `npm run migrate`
  - `npm run seed:admin`
- Variáveis:
  - `DATABASE_URL`
  - `SEED_ADMIN_EMAIL`, `SEED_ADMIN_PASSWORD`

## 4) Observabilidade
- Logs de acesso: habilitado no backend (console)
- Métricas: `GET /metrics`
- Healthcheck: `GET /health`
- Sentry:
  - defina `SENTRY_DSN` (opcional)

## 5) Segurança
- Helmet habilitado
- CORS configurável via `CORS_ORIGIN`
- Auth antifraude: `x-device-id` obrigatório em login/cadastro

## 6) Performance
- Índices via migration `001_indexes.sql`
- Paginação:
  - `GET /audit/events?limit=200&cursor=<timestamptz>`
  - `GET /adminops/late?limit=200&cursor=<timestamptz>`
