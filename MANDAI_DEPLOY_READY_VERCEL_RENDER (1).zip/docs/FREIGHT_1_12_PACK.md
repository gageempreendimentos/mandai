# Frete 1–12 (Pack completo)

## 1) Cliente: Ofertas + aceitar (UI)
- /client/freight/bids (buscar ride_id e aceitar oferta)

## 2) Chat + foto (URL)
- /client/freight/chat (cliente e driver)
- GET/POST /freight/:rideId/chat
- Campo image_url (por enquanto URL; fácil evoluir para upload real)

## 3) Extras pagos
- wait_minutes, insurance, declared_value, priority, fragile, helpers, stairs
- entra no cálculo do preço base e na recomendação de min/max.

## 4) Agendamento com janela
- rides.pickup_window_start / pickup_window_end

## 5) Multi-paradas
- tabela freight_stops
- UI no /client/freight/new (até 3 paradas MVP)

## 6) Regras por zona/veículo
- tabela freight_vehicle_rules (min/max por km + mínimo)
- hoje zone_id é best-effort (pronto para integrar geofence/zonas)

## 7) POD
- /driver/freight/pod
- POST /freight/:rideId/pod
- salva receiver_name, photo_url, signature_svg (opcional)

## 8) Disputas
- /client/freight/disputes
- POST /freight/:rideId/disputes
- admin resolve: POST /freight/admin/disputes/:id/resolve

## 9) Leilão com tempo
- bids com expires_at (5 min)
- endpoint: POST /freight/admin/expire (pode chamar via cron/uptime)

## 10) Anti-golpe: limites de oferta
- servidor valida bid dentro de recommended min/max

## 11) Match inteligente (próximo passo)
- base pronta: use pickup lat/lng + driver_locations para priorizar (a implementar no dispatch)

## 12) Cancelamento com taxa
- POST /freight/:rideId/cancel
- aplica fee se já assigned/accepted/enroute
