# FCM (Firebase Cloud Messaging) – Backend Setup

## 1) Criar Service Account
No Firebase Console → Project Settings → Service accounts → Generate new private key.

## 2) Configurar no server/.env
Opção A (recomendado em produção): arquivo + path
- Coloque o arquivo JSON em um local seguro
- Defina:
  MANDAIGLE_APPLICATION_CREDENTIALS=/caminho/para/serviceAccount.json

Opção B (facil para testes): JSON inline (1 linha)
- FIREBASE_SERVICE_ACCOUNT_JSON='{"type":"service_account", ... }'

## 3) Ativar envio
- Para realmente enviar, configure:
  FCM_DRY_RUN=false

## 4) Registrar token no app (frontend/mobile)
Chame:
POST /devices/register
{ token: "<FCM_TOKEN>", platform: "android" }

Depois o admin pode enviar com channel 'fcm' no template.
