# Pacote 1 ao 8 (Enterprise)

1) RBAC/Permissões
- Tabelas: permissions, role_permissions, user_permissions
- Middleware: requirePermission(permissionKey)
- Seed: db/seed_permissions.sql

2) Auditoria imutável
- Tabela: audit_log (append-only)
- Middleware audit(action, entityType, entityIdFn, payloadFn)

3) ETA inteligente (heurístico)
- Colunas em rides: eta_seconds, eta_updated_at, is_at_risk
- Worker job eta_scan (a cada ETA_SCAN_SECONDS)
- Heurística: distância até dropoff / 8m/s

4) Heatmap
- Endpoint: GET /admin/heatmap?since_minutes=180&grid=0.01
- Retorna buckets de pickup + drivers online para overlay no mapa

5) Chat por corrida (melhorado)
- WS:
  - CHAT_SEND com attachment_url/attachment_type (opcional)
  - CHAT_READ para read receipt
- HTTP:
  - POST /rides/chat/:rideId/attachments (base64 -> uploads)
  - POST /rides/chat/:rideId/messages/:messageId/read

6) Feature Flags
- Tabela: feature_flags
- Endpoints:
  - GET /admin/flags
  - POST /admin/flags

7) Relatórios automáticos
- CSV diário:
  - POST /reports-api/daily
  - GET /reports-api
- Arquivos em /reports (static)

8) Modo crise / contingência
- system_state.crisis_mode + middleware crisisGuard()
- Endpoint:
  - POST /admin/system/crisis { value: true/false }
- Frontend: banner avisando crise
