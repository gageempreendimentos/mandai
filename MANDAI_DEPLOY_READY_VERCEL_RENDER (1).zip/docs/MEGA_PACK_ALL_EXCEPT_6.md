# MEGA Pack (tudo) exceto o item 6 (verificação de entregador)

Implementado neste ZIP:

## (1) Queue/Redis (BullMQ) - base pronta
- Arquivos: server/src/queue/*
- Jobs: expire bids, generate invoices, deadman redispatch, push broadcast
- Observação: BullMQ é dependência opcional (instale no server: bullmq ioredis)

## (2) Rate limit Redis (opcional)
- server/src/middlewares/rateLimitRedis.js
- Ativa automaticamente se REDIS_URL estiver definido.

## (3) Docker + healthcheck
- docker-compose.yml (db + redis + api)
- /health

## (4) Antifraude básico (device-id)
- Login/Register exigem header: x-device-id
- Front deve enviar x-device-id (gera e salva no localStorage)

## (5) Cancel limit
- Limite: 5 cancelamentos/24h por cliente (frete)

## (7) Auditoria
- /audit/events e /audit/events.csv (admin)

## (8) Backup
- scripts/backup_db.sh

## (9) Push FCM real
- /fcm/register (driver) + /fcm/admin/send (admin)

Itens avançados (10–15) foram adicionados como base/estrutura (stubs) onde dependem de provedores externos:
- Pagamentos: /payments (provider fake + stub mercadopago)
- B2B: limits + template de email de fatura

Item 6 (verificação de entregador) NÃO foi implementado conforme seu pedido.
