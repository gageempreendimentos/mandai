# Pack 1–9 (Produção)

## 1) Upload real (Chat + POD + Checklist)
- POST /uploads-api/base64
- Serve estático: /uploads/*
- Chat: /client/freight/chat (agora com arquivo)
- POD: /driver/freight/pod (agora com arquivo)
- Checklist: /driver/freight/checklist (com foto)

## 2) Listas sem ID (UX)
- Cliente: /client/freight (Meus fretes)
- Driver: /driver/rides (Minhas corridas)
- Restaurante: /restaurant/orders (Pedidos)
- Admin: /admin/ops (Operações)

## 3) Pagamento + Webhook (skeleton)
- POST /payments/create { ride_id }
- POST /payments/webhook/:provider
- Provider default: fake (pago instantâneo dev)
- MercadoPago: stub (precisa token e chamadas)

## 4) Admin Ops
- /adminops/overview e /adminops/late
- UI: /admin/ops

## 5) Relatórios CSV
- /admin/reports
- GET /reports/rides.csv?from=YYYY-MM-DD&to=YYYY-MM-DD
- GET /reports/companies.csv

## 6) Rate limit
- Middleware in-memory (MVP). Recomenda Redis em prod.

## 7) Sentry (opcional)
- Configure SENTRY_DSN e instale @sentry/node no server.

## 8) Backup
- scripts/backup_db.sh (usa pg_dump)

## 9) FCM Push (real - legacy key)
- env: FCM_SERVER_KEY
- Driver registra: POST /fcm/register
- UI: /driver/push (colar token FCM)
- Admin teste: POST /fcm/admin/send
