# Pack implementado: 1,2,3,4,5

## 1) Upload real (POD/Chat)
- Endpoint: POST /uploads-api/base64
- Salva arquivo em ./uploads e serve em /uploads/<file>
- Front: chat agora permite selecionar imagem (upload real)

## 2) Rota e preço automático
- Endpoint: GET /maps/route?from_lat&from_lng&to_lat&to_lng
- Usa OSRM público por padrão. Configure:
  - OSRM_URL=https://router.project-osrm.org (default) ou seu OSRM.
- Front: em /client/freight/new você pode preencher lat/lng e clicar para calcular km.

## 3) “Meus fretes” (cliente)
- UI: /client/freight
- Backend: GET /freight/my

## 4) Match inteligente (best-effort)
- Driver envia localização:
  - POST /drivers/me/location { lat, lng }
- /freight/available ordena fretes por distância até pickup (se pickup tiver lat/lng).

## 5) B2B (empresas + fatura)
- Backend:
  - POST /b2b/companies (admin)
  - POST /b2b/companies/:id/users (admin)
  - GET /b2b/my (usuário)
  - POST /b2b/rides/:rideId/attach (cliente)
  - POST /b2b/companies/:id/invoice (admin)

Notas:
- Upload atual é local (perfeito para MVP e servidor próprio). Para Supabase/S3 basta trocar o adapter.
- Match depende de lat/lng no pickup e do driver enviar localização (pode ser automatizado pelo app).
