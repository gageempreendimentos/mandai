# Branding MANDAI (fundo claro)
- splash_mandai_light.svg: base do splash (referencia logo do projeto)
- icon_mandai.svg: base do ícone

Para gerar PNGs (Android/iOS):
- Use qualquer editor (Figma/Illustrator) ou conversor SVG->PNG.
- Gere: 1024, 512, 192, 180, 167, 152, 120.
