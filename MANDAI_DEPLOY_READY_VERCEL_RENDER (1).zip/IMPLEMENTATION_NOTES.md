# MANDAI Pack (1–4)

Contains:
1) Real Auth (JWT access + refresh): /auth/login, /auth/refresh, /auth/logout
2) WebSocket ACL rooms: ride:<id>, user:<id>, restaurant:<id>, admin
3) Normalized Postgres schema: db/schema.sql
4) GitHub Actions CI: .github/workflows/ci.yml

Run:
- Apply db/schema.sql to your Postgres
- Configure server/.env (copy server/.env.example)
- cd server && npm install && npm run dev
