# MANDAI Patch Bundle (Robustness Pack)

This bundle includes:
- Single Service Worker registration for push + PWA cache
- Firebase SW health check helper
- OSRM route fetch with cache + fallback + retry
- Production-friendly logger (localStorage + DEV-only debug)
- Suggested shared barrels (types + ui)
- Supabase migration template for RLS + indexes

## How to apply
1) Copy `src/` files into your project (merge folders).
2) Ensure your `src/main.tsx` calls `registerServiceWorker()` from `src/lib/serviceWorker.ts`.
3) Update `scripts/generate-firebase-sw.cjs` to include the PWA cache block inside the generated SW output.
4) Apply the Supabase migration (adjust table names if your schema differs).
