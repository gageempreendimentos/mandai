import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "localhost",
    port: 8080,
  },
  plugins: [react()].filter(Boolean),

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },

  // Faster dev startup (pre-bundle the things we always use)
  optimizeDeps: {
    include: [
      "react",
      "react-dom",
      "react-router-dom",
      "@tanstack/react-query",
      "sonner",
    ],
  },

  // Build optimizations (smaller initial load + better caching)
  build: {
    target: "es2018",
    minify: "esbuild",
    sourcemap: false,
    assetsInlineLimit: 0,
    cssCodeSplit: true,
    esbuild: { drop: ["console", "debugger"] },
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (!id.includes("node_modules")) return;

          // Core React stack
          if (id.includes("react") || id.includes("react-dom")) return "react-vendor";

          // Router + data fetching
          if (id.includes("react-router") || id.includes("@tanstack")) return "app-vendor";

          // UI libraries (Radix / shadcn / icons)
          if (id.includes("@radix-ui") || id.includes("lucide-react")) return "ui-vendor";

          // Heavy optional chunks
          if (id.includes("framer-motion")) return "motion";
          if (id.includes("maplibre-gl")) return "maps";

          // Supabase / Firebase integrations
          if (id.includes("@supabase") || id.includes("supabase") || id.includes("firebase"))
            return "integrations";

          return "vendor";
        },
      },
    },
  },
}));
