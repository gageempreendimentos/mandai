# MANDAI - Dashboard Real

## 🚀 Configuração do Sistema Real

### 1. Supabase (Banco de Dados) - **URGENTE**

Crie um projeto Supabase em [supabase.com](https://supabase.com) e configure:

**Tabelas necessárias:**
```sql
-- Entregas
create table deliveries (
  id uuid default uuid_generate_v4() primary key,
  pickup_address text not null,
  delivery_address text not null,
  customer_name text not null,
  value numeric,
  status text default 'pending',
  driver_id uuid,
  pickup_lat double precision,
  pickup_lng double precision,
  delivery_lat double precision,
  delivery_lng double precision,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Coordenadas (para cache)
create table delivery_coordinates (
  id uuid default uuid_generate_v4() primary key,
  delivery_id uuid references deliveries(id),
  type text, -- 'pickup' ou 'dropoff'
  lat double precision,
  lng double precision,
  created_at timestamp with time zone default now()
);

-- Perfis
create table profiles (
  id uuid primary key references auth.users,
  email text,
  cpf text unique,
  nome_completo text,
  telefone text,
  status text default 'pending', -- pending, approved, rejected
  push_token text,
  overlay_enabled boolean default false,
  created_at timestamp with time zone default now()
);

-- User roles
create table user_roles (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references profiles(id),
  role text, -- 'driver' ou 'admin'
  created_at timestamp with time zone default now()
);
```

**RLS (Row Level Security):**
- Ative RLS nas tabelas
- Permissões para motoristas verem apenas deliveries pending ou suas próprias

### 2. Variáveis de Ambiente

Crie arquivo `.env` na raiz do projeto:
```env
# Supabase (OBRIGATÓRIO)
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your_anon_key

# Mandaigle Maps (OPCIONAL - para rotas reais)
VITE_MANDAIGLE_MAPS_API_KEY=your_mandaigle_maps_key

# Firebase (OPCIONAL - para push notifications)
VITE_FIREBASE_API_KEY=your_firebase_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
VITE_FIREBASE_VAPID_KEY=your_vapid_key
```

## 🎯 Como Testar o Sistema Real

### 1. Inserir Entregas Reais

Use o Supabase SQL Editor:
```sql
INSERT INTO deliveries (
  pickup_address, 
  delivery_address, 
  customer_name, 
  value,
  status
) VALUES 
('Rua das Flores, 123 - Centro, São Paulo/SP',
 'Av. Brasil, 456 - Jardim América, São Paulo/SP',
 'Maria Silva',
 15.50,
 'pending'),
('Restaurante Sabor Caseiro, Rua Augusta, 1000',
 'Av. Paulista, 2000 - Bela Vista, São Paulo/SP',
 'João Santos',
 12.00,
 'pending');
```

### 2. Ver em Tempo Real

1. Abra o app em 2 navegadores
2. Em um, faça login como motorista e fique online
3. No outro, insira uma entrega via SQL
4. O motorista deve receber notificação instantânea

### 3. Testar Rotas Reais (Mandaigle Maps)

1. Adicione sua API Key do Mandaigle Maps no `.env`
2. Insira endereços completos em São Paulo
3. O sistema calculará a distância real

### 4. Testar Push Notifications (Firebase)

1. Configure Firebase Cloud Messaging
2. Adicione as chaves no `.env`
3. O app pedirá permissão ao ficar online
4. Notificações funcionam com app fechado

## 📋 Checklist de Configuração

- [ ] Supabase criado e tabelas configuradas
- [ ] Variáveis de ambiente `.env` preenchidas
- [ ] Testar conexão Supabase
- [ ] Inserir 2-3 entregas de teste via SQL
- [ ] Fazer login e ficar online
- [ ] Ver entregas aparecerem em tempo real

## 🎯 Próximos Passos

1. **Configurar Supabase** (URGENTE - sem isso não funciona)
2. **Criar arquivo `.env`** com as credenciais
3. **Inserir entregas de teste** via SQL
4. **Testar o app** abrindo em 2 navegadores

## 🚀 Funcionalidades Implementadas

✅ **Entregas Reais** - Busca direto do Supabase  
✅ **Realtime** - Atualizações instantâneas  
✅ **Notificações** - Toasts + som (Firebase opcional)  
✅ **Mapa** - Placeholder (Mandaigle Maps opcional)  
✅ **Rota Combinada** - Agrupa entregas próximas  
✅ **Timers** - Contagem regressiva para coleta/entrega  
✅ **Validação** - CNH, comprovante, documento do veículo  

## 💡 Dicas Importantes

- **Sem Supabase?** O app mostra "Erro de Conexão" e não funciona
- **Sem Mandaigle Maps?** Usa cálculo aproximado de distância
- **Sem Firebase?** Notificações funcionam via toast apenas
- **Tudo configurado?** App funciona 100% em produção

**O app está pronto! Configure o Supabase e teste! 🚀**

## Robustez (implementado)

- RLS no Supabase (profiles, deliveries, notifications)
- Máquina de estados para `deliveries.status` + timestamps automáticos (migração)
- `audit_logs` para auditoria (via Edge Functions)
- Push notifications (FCM) para 1 entregador ou todos (broadcast), com log em `notifications`
- Tela oculta no Admin: `/admin/logs` (logs locais) e `/admin/flags` (feature flags)


---

## ⏱️ Timeout de aceitação + redistribuição automática

Este projeto inclui o fluxo de **oferta com timeout**:

- Entrega criada: `status = pending` e `driver_id = null`
- Backend oferece a entrega para um entregador online (preenche `driver_id` + cria um registro em `delivery_offers`)
- Se o entregador não aceitar em **X segundos** (padrão 20s), a oferta expira e a entrega é redistribuída

### Componentes

- Migração: `supabase/migrations/20260124101000_delivery_offers_timeout.sql`
- Edge Function: `supabase/functions/dispatch-offers`

### Como ativar o "cron" no Supabase

No painel do Supabase:
1. Vá em **Edge Functions** → escolha `dispatch-offers`
2. Crie um **Scheduled Trigger** (ex.: a cada 1 minuto)
3. Body sugerido:

```json
{
  "timeout_seconds": 20,
  "limit": 25
}
```

> Dica: você pode diminuir o intervalo (ex.: 30s) se o volume crescer.


---

## ⏱️ Timeout de aceitação + redistribuição automática

Este projeto inclui o fluxo de **oferta com timeout**:

- Entrega criada: `status = pending` e `driver_id = null`
- Backend oferece a entrega para um entregador online (preenche `driver_id` + cria um registro em `delivery_offers`)
- Se o entregador não aceitar em **X segundos** (padrão 20s), a oferta expira e a entrega é redistribuída para outro entregador

### Componentes

- Migration: `supabase/migrations/20260124101000_delivery_offers_timeout.sql`
- Edge Function: `supabase/functions/dispatch-offers`

### Como ativar o cron no Supabase

No painel do Supabase:

1. Vá em **Edge Functions** → selecione `dispatch-offers`
2. Crie um **Scheduled Trigger** (Schedule) para rodar a cada 1 minuto
3. Body sugerido:

```json
{"timeout_seconds":20,"limit":25}
```

### Observações

- O entregador vê a entrega quando `deliveries.driver_id` aponta para ele.
- O botão **Aceitar** altera o status para `accepted`.
- Depois o entregador confirma **Coleta** (`picked_up`) e então **Em trânsito** (`in_transit`).


## Extras adicionados (POD / Disputas / Geofence / Anti-fraude / PWA)

### Proof of Delivery (foto)
- Bucket: `delivery-proofs`
- Ao confirmar entrega, o app faz upload da foto (se capturada) e salva em `deliveries.photo_url`.

### Disputas / Suporte por entrega
- Tabelas: `delivery_disputes`, `delivery_dispute_messages`
- Admin (oculto): `/admin/disputes`
- Entregador: botão **Reportar problema** na entrega ativa.

### Geofence + anti-fraude no status
- Edge Function: `update-delivery-status`
- Para `picked_up` e `delivered`, o app envia `lat/lng` e o backend valida distância (default 300m).
- Bloqueia mudanças de status muito rápidas (< 5s) e incrementa `deliveries.suspicious_flags`.

### PWA (instalável)
- Manifest: `public/manifest.webmanifest`
- Service Worker: `public/sw.js`


## Splash Screen

O projeto inclui um splash instantâneo (HTML/CSS no `index.html`) que aparece antes do React carregar e é removido automaticamente em `src/main.tsx`.
