# Deploy com Docker (1 comando)

## Subir tudo local
1) Na raiz do projeto:
```bash
docker compose up --build
```

2) Aplicar schema no Postgres (primeira vez):
```bash
docker exec -i $(docker ps -qf name=postgres) psql -U mandai -d mandai < db/schema.sql
```

Frontend:
- http://localhost:8081

Backend:
- http://localhost:8080/health

Worker roda automático no container `worker`.
