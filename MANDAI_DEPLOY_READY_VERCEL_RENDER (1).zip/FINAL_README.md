# MANDAI Projeto Completo (Frontend + Backend) – ZIP Final

Inclui:
- Frontend completo (admin/cliente/restaurante/entregador)
- Backend Node/Express + JWT (login/refresh) + WebSocket (rooms com ACL)
- Banco Postgres normalizado (db/schema.sql)
- Pacote de robustez (SW único, OSRM robusto, logger)
- CI GitHub Actions

## Rodar Frontend
Na raiz:
- npm install
- npm run dev

## Rodar Backend
1) Aplique db/schema.sql em um Postgres
2) Copie server/.env.example para server/.env e configure
3) cd server && npm install && npm run dev

## WebSocket
Conectar: ws://HOST:8080?token=ACCESS_TOKEN
SUBSCRIBE: { "type":"SUBSCRIBE", "room":"ride:<id>" }
CHAT_SEND: { "type":"CHAT_SEND", "ride_id":"<id>", "message":"..." }


## Queue/Cron (BullMQ + Redis)
- Suba Redis: `docker compose -f server/docker-compose.redis.yml up -d`
- Rode worker: `cd server && npm run worker`

## Idempotência
Envie header `Idempotency-Key` em POST/PATCH/PUT para evitar duplicidade.
