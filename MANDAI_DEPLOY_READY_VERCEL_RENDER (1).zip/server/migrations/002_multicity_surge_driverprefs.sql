-- Multi-city + driver service area prefs + surge config + ranking helpers
-- 2026-01-28

create table if not exists cities (
  id bigserial primary key,
  name text not null unique,
  state text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Driver preferences / service area
alter table users add column if not exists preferred_city text;
alter table users add column if not exists service_radius_km int not null default 8;

-- Optional: store last known city for a driver (derived from zone/city), can be used for filters
alter table users add column if not exists current_city text;

-- System-wide surge defaults are stored in system_state:
--  - surge_enabled: true/false
--  - surge_max_multiplier: e.g. 2.0
--  - surge_sensitivity: e.g. 0.6

-- Ranking view (best-effort; safe if metrics tables are empty)
create or replace view driver_ranking_view as
select
  u.id as driver_id,
  u.name,
  u.phone,
  u.preferred_city,
  u.driver_score,
  coalesce(dm.offers,0) as offers,
  coalesce(dm.accepts,0) as accepts,
  coalesce(dm.refuses,0) as refuses,
  coalesce(dm.acceptance_rate,0) as acceptance_rate,
  coalesce(df.earned_cents_7d,0) as earned_cents_7d,
  coalesce(df.rides_7d,0) as rides_7d,
  coalesce(df.score,0) as finance_score,
  -- Composite score (tweak in code if needed)
  (coalesce(u.driver_score,5.0) * 10.0)
  + (coalesce(dm.acceptance_rate,0) * 5.0)
  + (least(200, coalesce(df.rides_7d,0)) * 0.5)
  + (least(1000000, coalesce(df.earned_cents_7d,0)) / 100000.0)
  as composite_score
from users u
left join driver_metrics dm on dm.driver_id=u.id
left join driver_finance_metrics df on df.driver_id=u.id
where u.role='driver';
