-- Performance indexes
create index if not exists rides_status_created_idx on rides(status, created_at desc);
create index if not exists rides_driver_created_idx on rides(driver_id, created_at desc);
create index if not exists rides_company_created_idx on rides(company_id, created_at desc);
create index if not exists ride_events_ride_created_idx on ride_events(ride_id, created_at desc);
create index if not exists ride_events_type_created_idx on ride_events(type, created_at desc);

-- Optional: drivers online
create index if not exists drivers_status_idx on drivers(status);
