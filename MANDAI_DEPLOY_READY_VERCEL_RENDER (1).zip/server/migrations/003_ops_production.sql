-- 003_ops_production.sql
-- Adds production-grade fields: docs verification, ride lock, driver levels, ledger (append-only)

alter table if exists users
  add column if not exists docs_verified boolean default false,
  add column if not exists docs_status jsonb,
  add column if not exists driver_level text default 'bronze',
  add column if not exists max_active_rides int default 1;

alter table if exists rides
  add column if not exists locked_at timestamptz;

create table if not exists ledger_entries (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  entry_type text not null,
  ride_id text,
  restaurant_id int,
  driver_id text,
  amount_cents int not null,
  meta jsonb not null default '{}'::jsonb
);

create index if not exists ledger_entries_driver_created_at_idx on ledger_entries (driver_id, created_at desc);
create index if not exists ledger_entries_ride_idx on ledger_entries (ride_id);

-- optional: simple view for driver levels (for admin dashboards)
create or replace view driver_levels_view as
select id as driver_id, driver_level, max_active_rides, docs_verified
from users
where role='driver';
