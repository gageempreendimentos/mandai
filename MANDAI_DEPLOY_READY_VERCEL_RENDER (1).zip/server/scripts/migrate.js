import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import pg from "pg";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const { Client } = pg;

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("Missing DATABASE_URL");
  process.exit(1);
}

const client = new Client({ connectionString: DATABASE_URL });

async function ensureMigrationsTable() {
  await client.query(`
    create table if not exists _migrations (
      id text primary key,
      applied_at timestamptz not null default now()
    )
  `);
}

async function applySQL(id, sql) {
  const already = await client.query("select 1 from _migrations where id=$1", [id]);
  if (already.rowCount) return false;
  await client.query("begin");
  try {
    await client.query(sql);
    await client.query("insert into _migrations(id) values ($1)", [id]);
    await client.query("commit");
    return true;
  } catch (e) {
    await client.query("rollback");
    throw e;
  }
}

async function main() {
  await client.connect();
  await ensureMigrationsTable();

  // baseline schema
  const schemaPath = path.resolve(__dirname, "../db/schema.sql");
  if (fs.existsSync(schemaPath)) {
    const schema = fs.readFileSync(schemaPath, "utf-8");
    await applySQL("000_schema_sql", schema);
  }

  const migDir = path.resolve(__dirname, "../migrations");
  const files = fs.readdirSync(migDir).filter(f => f.endsWith(".sql")).sort();
  for (const f of files) {
    const id = f;
    const sql = fs.readFileSync(path.join(migDir, f), "utf-8");
    const applied = await applySQL(id, sql);
    if (applied) console.log("Applied", id);
  }

  await client.end();
  console.log("Migrations complete");
}

main().catch((e)=>{ console.error(e); process.exit(1); });
