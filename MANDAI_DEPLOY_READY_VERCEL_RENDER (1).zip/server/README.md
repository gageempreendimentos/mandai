# MANDAI WebSocket Server (MVP)

## Rodar local
```bash
cd server
npm install
npm run dev
```

- Health: http://localhost:8787/health
- Ride (GET): http://localhost:8787/ride
- Ride (POST): http://localhost:8787/ride
- WebSocket: ws://localhost:8787
