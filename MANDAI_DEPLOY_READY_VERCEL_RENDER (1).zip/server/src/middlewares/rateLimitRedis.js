import { redis } from "../queue/redis.js";

const r = redis();

export function rateLimitRedis({ name="api", windowSec=60, max=600 } = {}) {
  return async (req,res,next)=>{
    try {
      const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "ip").toString().split(",")[0].trim();
      const key = `rl:${name}:${ip}:${Math.floor(Date.now()/1000/windowSec)}`;
      const n = await r.incr(key);
      if (n===1) await r.expire(key, windowSec);
      if (n > max) return res.status(429).json({ error:"rate_limited" });
    } catch {
      // fallback silently
    }
    next();
  };
}
