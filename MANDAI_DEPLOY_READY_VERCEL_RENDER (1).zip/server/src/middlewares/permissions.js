import { q } from "../db.js";

async function hasPermission(userId, role, permissionKey) {
  if (!userId || !role) return false;
  if (role === "admin") return true;

  // user override
  const u = await q(
    `select allowed from user_permissions where user_id=$1 and permission_key=$2`,
    [userId, permissionKey]
  );
  if (u.rows[0]) return u.rows[0].allowed === true;

  // role permission
  const r = await q(
    `select 1 from role_permissions where role=$1 and permission_key=$2`,
    [role, permissionKey]
  );
  return !!r.rows[0];
}

export function requirePermission(permissionKey) {
  return async (req, res, next) => {
    const userId = req.user?.sub;
    const role = req.user?.role;
    const ok = await hasPermission(userId, role, permissionKey);
    if (!ok) return res.status(403).json({ error: "missing_permission", permission: permissionKey });
    next();
  };
}
