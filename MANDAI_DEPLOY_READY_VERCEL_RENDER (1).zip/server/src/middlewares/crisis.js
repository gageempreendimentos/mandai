import { q } from "../db.js";

// If crisis mode is enabled, block non-critical routes (except health/auth/admin toggle)
export function crisisGuard() {
  return async (req, res, next) => {
    const envFlag = String(process.env.CRISIS_MODE || "false").toLowerCase() === "true";

    let dbFlag = false;
    try {
      const r = await q("select value from system_state where key='crisis_mode'");
      dbFlag = String(r.rows[0]?.value || "false").toLowerCase() === "true";
    } catch {}

    const crisis = envFlag || dbFlag;
    if (!crisis) return next();

    const path = req.path || req.url || "";
    const allow = [
      "/health",
      "/auth/login",
      "/auth/refresh",
      "/admin/system/crisis",
      "/admin/system/status"
    ];
    if (allow.some((p) => path.startsWith(p))) return next();

    return res.status(503).json({ error: "crisis_mode", message: "Sistema em modo de contingência. Tente novamente em instantes." });
  };
}
