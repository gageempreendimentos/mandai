const buckets = new Map();

function keyOf(req, name) {
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "ip").toString().split(",")[0].trim();
  return `${name}:${ip}`;
}

export function rateLimit({ name="default", windowMs=60_000, max=120 } = {}) {
  return (req,res,next)=>{
    const k = keyOf(req, name);
    const now = Date.now();
    const b = buckets.get(k) || { start: now, count: 0 };
    if (now - b.start > windowMs) { b.start = now; b.count = 0; }
    b.count += 1;
    buckets.set(k, b);
    if (b.count > max) {
      return res.status(429).json({ error:"rate_limited", retry_in_ms: windowMs - (now - b.start) });
    }
    next();
  };
}
