import { q } from "../db.js";

// Minimal idempotency for POST/PUT/PATCH
export function idempotency() {
  return async (req, res, next) => {
    const method = req.method.toUpperCase();
    if (!["POST", "PUT", "PATCH"].includes(method)) return next();

    const key = req.headers["idempotency-key"];
    if (!key) return next();

    const userId = req.user?.sub || null;
    const route = req.originalUrl || req.url;

    const found = await q(
      `select status_code, response_body
       from idempotency_keys
       where idem_key = $1 and user_id is not distinct from $2 and route = $3`,
      [String(key), userId, route]
    );

    if (found.rows[0]) {
      return res.status(found.rows[0].status_code).json(found.rows[0].response_body);
    }

    const oldJson = res.json.bind(res);
    res.json = async (body) => {
      try {
        await q(
          `insert into idempotency_keys (idem_key, user_id, route, method, status_code, response_body)
           values ($1, $2, $3, $4, $5, $6)
           on conflict do nothing`,
          [String(key), userId, route, method, res.statusCode, body]
        );
      } catch {}
      return oldJson(body);
    };

    next();
  };
}
