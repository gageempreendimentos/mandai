import { q } from "../db.js";

export function audit(action, entityType = null, entityIdFn = null, payloadFn = null) {
  return async (req, res, next) => {
    // capture response status only; payload stored from payloadFn (not response body)
    res.on("finish", async () => {
      try {
        const actor = req.user?.sub || null;
        const entityId = typeof entityIdFn === "function" ? String(entityIdFn(req) ?? "") : (entityIdFn ? String(entityIdFn) : null);
        const payload = typeof payloadFn === "function" ? (payloadFn(req) ?? {}) : (payloadFn ?? {});
        await q(
          `insert into audit_log (actor_user_id, action, entity_type, entity_id, ip, user_agent, payload)
           values ($1,$2,$3,$4,$5,$6,$7)`,
          [
            actor,
            action,
            entityType,
            entityId,
            req.ip || null,
            req.headers["user-agent"] || null,
            payload
          ]
        );
      } catch {}
    });
    next();
  };
}
