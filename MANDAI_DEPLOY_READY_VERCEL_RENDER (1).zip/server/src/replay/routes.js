import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const replayRouter = express.Router();

replayRouter.get("/rides/:id", requireAuth, requireRole("admin"), async (req, res) => {
  const id = req.params.id;

  const events = await q(
    `select type, payload, created_at, actor_user_id
     from ride_events where ride_id=$1
     order by created_at asc`,
    [id]
  );

  const points = await q(
    `select lat, lng, heading, speed, created_at
     from ride_location_points
     where ride_id=$1
     order by created_at asc
     limit 5000`,
    [id]
  );

  res.json({ ride_id: id, events: events.rows, points: points.rows });
});
