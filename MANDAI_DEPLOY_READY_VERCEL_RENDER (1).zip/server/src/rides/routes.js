import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";
import { requireRideForDriver, setRideStatus, geofenceCheck } from "./actions.js";

export const ridesRouter = express.Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// local uploads (swap to object storage later)
const uploadsDir = path.join(__dirname, "..", "..", "uploads");
fs.mkdirSync(uploadsDir, { recursive: true });

/**
 * Driver ping/location update
 * POST /rides/driver/location
 * body: { lat, lng, heading?, speed?, ride_id? , is_online? }
 */
ridesRouter.post("/driver/location", requireAuth, idempotency(), async (req, res) => {
  if (req.user.role !== "driver" && req.user.role !== "admin") return res.status(403).json({ error: "forbidden" });

  const { lat, lng, heading, speed, ride_id, is_online } = req.body || {};
  if (lat == null || lng == null) return res.status(400).json({ error: "missing_lat_lng" });

  const driverId = req.user.sub;

  // block check
  const st = await q(`select is_disabled from users where id=$1`, [driverId]).catch(()=>({rows:[]}));
  if (st.rows[0]?.is_disabled) return res.status(403).json({ error: "driver_blocked" });

  // upsert SSOT last location + ping
  await q(
    `insert into driver_locations (driver_id, lat, lng, heading, speed, updated_at, last_ping_at, is_online)
     values ($1,$2,$3,$4,$5, now(), now(), coalesce($6,true))
     on conflict (driver_id) do update set
       lat=excluded.lat,
       lng=excluded.lng,
       heading=excluded.heading,
       speed=excluded.speed,
       updated_at=excluded.updated_at,
       last_ping_at=excluded.last_ping_at,
       is_online=excluded.is_online`,
    [driverId, lat, lng, heading || null, speed || null, is_online]
  );

  // Location history (replay) – store at most every N seconds per driver
  const every = Number(process.env.LOCATION_ARCHIVE_EVERY_SECONDS || 10);
  if (ride_id) {
    const check = await q(
      `select last_archive_at from driver_locations where driver_id=$1`,
      [driverId]
    );
    const last = check.rows[0]?.last_archive_at;
    const should = !last || (Date.now() - new Date(last).getTime()) > every * 1000;
    if (should) {
      await q(
        `insert into ride_location_points (ride_id, driver_id, lat, lng, heading, speed)
         values ($1,$2,$3,$4,$5,$6)`,
        [ride_id, driverId, lat, lng, heading || null, speed || null]
      );
      await q(`update driver_locations set last_archive_at=now() where driver_id=$1`, [driverId]);
    }
  }

  return res.json({ ok: true });
});


/**
 * Driver accepts an offered ride
 * POST /rides/:id/accept
 */
ridesRouter.post("/:id/accept", requireAuth, idempotency(), async (req,res)=>{
  if (req.user.role !== "driver" && req.user.role !== "admin") return res.status(403).json({ error:"forbidden" });
  const rideId = req.params.id;
  const driverId = req.user.role === "admin" && req.body?.driver_id ? String(req.body.driver_id) : req.user.sub;

  // Driver doc verification + block
  const userRow = await q(`select is_disabled, coalesce(docs_verified,false) as docs_verified, coalesce(max_active_rides,1) as max_active_rides from users where id=$1`, [driverId]).catch(()=>({rows:[]}));
  if (!userRow.rows[0]) return res.status(404).json({ error:"driver_not_found" });
  if (userRow.rows[0].is_disabled) return res.status(403).json({ error:"driver_blocked" });
  if (!userRow.rows[0].docs_verified) return res.status(400).json({ error:"docs_not_verified" });

  // Limit simultaneous active rides
  const active = await q(
    `select count(*)::int as n
     from rides
     where driver_id=$1 and status in ('accepted','picked_up','enroute','assigned')`,
    [driverId]
  ).catch(()=>({rows:[{n:0}]}));
  const max = Number(userRow.rows[0].max_active_rides||1);
  if (Number(active.rows[0].n||0) >= max) {
    return res.status(400).json({ error:"driver_capacity_reached", message:`Limite de ${max} entregas simultâneas atingido.` });
  }

  // Accept only if still offerable
  const ride = await q(`select id, status, driver_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  if (!ride.rows[0]) return res.status(404).json({ error:"ride_not_found" });

  const st = String(ride.rows[0].status||"");
  if (!["offered","assigned","created"].includes(st)) {
    return res.status(400).json({ error:"invalid_status", status: st });
  }

  const upd = await q(
    `update rides
     set driver_id=$2,
         status='accepted',
         locked_at=coalesce(locked_at, now()),
         updated_at=now()
     where id=$1
       and status in ('offered','assigned','created')
       and (driver_id is null or driver_id=$2)`,
    [rideId, driverId]
  );

  if (upd.rowCount === 0) {
    return res.status(409).json({ error: "ride_already_taken" });
  }

  await q(
    `insert into ride_events (ride_id, type, actor_user_id, payload)
     values ($1,'ride.accepted',$2, jsonb_build_object('driver_id',$2))`,
    [rideId, driverId]
  ).catch(()=>{});

  res.json({ ok:true, ride_id: rideId, driver_id: driverId, status: "accepted" });
});

/**
 * Driver confirms pickup (geofence)
 * POST /rides/:id/pickup
 * body: { lat, lng }
 */
ridesRouter.post("/:id/pickup", requireAuth, idempotency(), async (req, res) => {
  if (req.user.role !== "driver" && req.user.role !== "admin") return res.status(403).json({ error: "forbidden" });
  const rideId = req.params.id;
  const { lat, lng } = req.body || {};
  if (lat == null || lng == null) return res.status(400).json({ error: "missing_lat_lng" });

  const { ride, error, code } = await requireRideForDriver(rideId, req.user.sub);
  if (error) return res.status(code).json({ error });

  const meters = Number(process.env.GEOFENCE_PICKUP_METERS || 200);
  const chk = geofenceCheck("pickup", ride, lat, lng, meters);
  if (!chk.ok) return res.status(400).json({ error: "geofence_failed", where: "pickup", distance_m: chk.distance_m, allowed_m: meters });

  await setRideStatus(rideId, "picked_up", req.user.sub, { lat, lng });
  return res.json({ ok: true });
});

/**
 * Driver completes delivery (geofence)
 * POST /rides/:id/complete
 * body: { lat, lng }
 */
ridesRouter.post("/:id/complete", requireAuth, idempotency(), async (req, res) => {
  if (req.user.role !== "driver" && req.user.role !== "admin") return res.status(403).json({ error: "forbidden" });
  const rideId = req.params.id;
  const { lat, lng } = req.body || {};
  if (lat == null || lng == null) return res.status(400).json({ error: "missing_lat_lng" });

  const { ride, error, code } = await requireRideForDriver(rideId, req.user.sub);
  if (error) return res.status(code).json({ error });

  const meters = Number(process.env.GEOFENCE_DROPOFF_METERS || 250);
  const chk = geofenceCheck("dropoff", ride, lat, lng, meters);
  if (!chk.ok) return res.status(400).json({ error: "geofence_failed", where: "dropoff", distance_m: chk.distance_m, allowed_m: meters });

  await setRideStatus(rideId, "completed", req.user.sub, { lat, lng });
  return res.json({ ok: true });
});

/**
 * POD upload (base64 png/jpg)
 * POST /rides/:id/pod  body: { image_base64, note? }
 */
ridesRouter.post("/:id/pod", requireAuth, idempotency(), async (req, res) => {
  const rideId = req.params.id;
  const { image_base64, note } = req.body || {};
  if (!image_base64) return res.status(400).json({ error: "missing_image_base64" });

  const rideRes = await q("select id, driver_id from rides where id=$1", [rideId]);
  const ride = rideRes.rows[0];
  if (!ride) return res.status(404).json({ error: "ride_not_found" });

  if (req.user.role !== "admin" && ride.driver_id !== req.user.sub) {
    return res.status(403).json({ error: "forbidden" });
  }

  const match = String(image_base64).match(/^data:(image\/png|image\/jpeg);base64,(.+)$/);
  const raw = match ? match[2] : image_base64;
  const buf = Buffer.from(raw, "base64");

  const filename = `pod_${rideId}_${Date.now()}.png`;
  const filePath = path.join(uploadsDir, filename);
  fs.writeFileSync(filePath, buf);

  const publicUrl = `/uploads/${filename}`;

  await q(
    `update rides
     set pod_url=$2, pod_note=$3, pod_created_at=now(), updated_at=now()
     where id=$1`,
    [rideId, publicUrl, note || null]
  );

  await q(
    `insert into ride_events (ride_id, type, actor_user_id, payload)
     values ($1, 'ride.pod_uploaded', $2, jsonb_build_object('pod_url',$3))`,
    [rideId, req.user.sub, publicUrl]
  );

  return res.json({ ok: true, pod_url: publicUrl });
});
