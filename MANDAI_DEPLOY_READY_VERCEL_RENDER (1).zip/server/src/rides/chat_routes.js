import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const rideChatRouter = express.Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadsDir = path.join(__dirname, "..", "..", "uploads");
fs.mkdirSync(uploadsDir, { recursive: true });

rideChatRouter.post("/:rideId/attachments", requireAuth, idempotency(), async (req, res) => {
  const { rideId } = req.params;
  const { file_base64, attachment_type } = req.body || {};
  if (!file_base64) return res.status(400).json({ error: "missing_file_base64" });

  const rideRes = await q(`select id, client_id, driver_id, restaurant_id from rides where id=$1`, [rideId]);
  const ride = rideRes.rows[0];
  if (!ride) return res.status(404).json({ error: "ride_not_found" });

  // permission: admin or participant
  const role = req.user.role;
  const uid = req.user.sub;
  const ok =
    role === "admin" ||
    (role === "driver" && ride.driver_id === uid) ||
    (role === "client" && ride.client_id === uid) ||
    (role === "restaurant" && String(req.user.restaurant_id || "") === String(ride.restaurant_id || ""));
  if (!ok) return res.status(403).json({ error: "forbidden" });

  const match = String(file_base64).match(/^data:(.+);base64,(.+)$/);
  const raw = match ? match[2] : file_base64;
  const buf = Buffer.from(raw, "base64");

  let ext = "bin";
  const at = String(attachment_type || "");
  if (at.includes("image")) ext = "png";
  else if (at.includes("audio")) ext = "webm";
  else if (at.includes("video")) ext = "mp4";
  const filename = `chat_${rideId}_${Date.now()}.${ext}`;
  const filePath = path.join(uploadsDir, filename);
  fs.writeFileSync(filePath, buf);

  const publicUrl = `/uploads/${filename}`;
  res.json({ ok: true, attachment_url: publicUrl, attachment_type: attachment_type || "application/octet-stream" });
});

rideChatRouter.post("/:rideId/messages/:messageId/read", requireAuth, idempotency(), async (req, res) => {
  const { messageId } = req.params;
  await q(
    `insert into ride_message_reads (message_id, user_id)
     values ($1, $2)
     on conflict do nothing`,
    [messageId, req.user.sub]
  );
  res.json({ ok: true });
});
