import { q } from "../db.js";
import { haversineMeters } from "../lib/geo.js";

export async function requireRideForDriver(rideId, driverId) {
  const r = await q(
    `select id, driver_id, status,
            pickup_lat, pickup_lng,
            dropoff_lat, dropoff_lng
     from rides where id=$1`,
    [rideId]
  );
  const ride = r.rows[0];
  if (!ride) return { error: "ride_not_found", code: 404 };
  if (ride.driver_id !== driverId) return { error: "forbidden", code: 403 };
  return { ride };
}

export async function setRideStatus(rideId, nextStatus, actorUserId, payload = {}) {
  await q(
    `update rides
     set status=$2, updated_at=now(),
         picked_up_at = case when $2='picked_up' then now() else picked_up_at end,
         completed_at = case when $2='completed' then now() else completed_at end,
         locked_at = case when $2 in ('accepted','picked_up') then coalesce(locked_at, now()) else locked_at end
     where id=$1`,
    [rideId, nextStatus]
  );

  await q(
    `insert into ride_events (ride_id, type, actor_user_id, payload)
     values ($1, $2, $3, $4)`,
    [rideId, `ride.${nextStatus}`, actorUserId, payload]
  );
}

export function geofenceCheck(kind, ride, lat, lng, metersAllowed) {
  const targetLat = kind === "pickup" ? ride.pickup_lat : ride.dropoff_lat;
  const targetLng = kind === "pickup" ? ride.pickup_lng : ride.dropoff_lng;
  if (targetLat == null || targetLng == null) return { ok: true }; // no coords => allow
  const d = haversineMeters(Number(lat), Number(lng), Number(targetLat), Number(targetLng));
  return { ok: d <= metersAllowed, distance_m: d };
}
