import { q } from "../db.js";
import { sendFCM, isFCMConfigured } from "../push_fcm/fcm.js";

export async function sendBroadcastToDrivers({ title="MANDAI", body="Mensagem", data={} }={}) {
  if (!isFCMConfigured()) return { ok:false, error:"fcm_not_configured" };
  const tokens = await q(`select token from driver_push_tokens`).catch(()=>({rows:[]}));
  let ok=0, fail=0;
  for (const t of tokens.rows) {
    try {
      const out = await sendFCM({ token: t.token, title, body, data });
      if (out.ok) ok++; else fail++;
    } catch { fail++; }
  }
  return { ok:true, ok_count: ok, fail_count: fail };
}
