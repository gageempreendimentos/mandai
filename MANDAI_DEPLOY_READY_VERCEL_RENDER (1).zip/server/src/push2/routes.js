import express from "express";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const push2Router = express.Router();

push2Router.post("/register", requireAuth, idempotency(), async (req,res)=>{
  const token = req.body?.token;
  const platform = req.body?.platform || "web";
  if (!token) return res.status(400).json({ error:"missing_token" });
  await q(
    `insert into push_tokens (user_id, token, platform, updated_at)
     values ($1,$2,$3, now())
     on conflict (user_id, token) do update set platform=excluded.platform, updated_at=now()`,
    [req.user.sub, token, platform]
  ).catch(async()=>{
    // table may be named differently in older packs; create minimal fallback
    await q(`create table if not exists push_tokens (user_id uuid, token text, platform text, updated_at timestamptz default now(), unique(user_id, token))`);
    await q(
      `insert into push_tokens (user_id, token, platform, updated_at)
       values ($1,$2,$3, now())
       on conflict (user_id, token) do update set platform=excluded.platform, updated_at=now()`,
      [req.user.sub, token, platform]
    );
  });
  res.json({ ok:true });
});
