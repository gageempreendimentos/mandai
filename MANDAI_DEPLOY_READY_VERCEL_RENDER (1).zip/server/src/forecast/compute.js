import { q } from "../db.js";

export async function forecastCompute() {
  // MVP: average created rides per zone/dow/hour over last 28 days
  const rides = await q(
    `select zone_id,
            extract(dow from created_at)::int as dow,
            extract(hour from created_at)::int as hour,
            count(*)::int as n
     from rides
     where created_at > now() - interval '28 days'
     group by zone_id, dow, hour`
  ).catch(()=>({rows:[]}));

  const drivers = await q(
    `select uz.zone_id,
            extract(dow from dl.last_ping_at)::int as dow,
            extract(hour from dl.last_ping_at)::int as hour,
            count(distinct dl.driver_id)::int as n
     from driver_locations dl
     left join user_zones uz on uz.user_id = dl.driver_id
     where dl.last_ping_at > now() - interval '7 days'
       and coalesce(dl.is_online,true)=true
     group by uz.zone_id, dow, hour`
  ).catch(()=>({rows:[]}));

  const driverMap = new Map();
  for (const d of drivers.rows) {
    const key = `${d.zone_id||"null"}:${d.dow}:${d.hour}`;
    driverMap.set(key, Number(d.n||0));
  }

  for (const r of rides.rows) {
    const key = `${r.zone_id||"null"}:${r.dow}:${r.hour}`;
    const expectedOrders = Number(r.n||0) / 4; // 4 weeks
    const expectedDrivers = driverMap.get(key) || 0;

    let risk = 0;
    if (expectedDrivers <= 0 && expectedOrders > 2) risk = 2;
    else if (expectedOrders > expectedDrivers * 2) risk = 2;
    else if (expectedOrders > expectedDrivers * 1.2) risk = 1;

    await q(
      `insert into demand_forecast (zone_id, dow, hour, expected_orders, expected_active_drivers, risk_level, computed_at)
       values ($1,$2,$3,$4,$5,$6, now())
       on conflict (zone_id, dow, hour) do update set
         expected_orders=excluded.expected_orders,
         expected_active_drivers=excluded.expected_active_drivers,
         risk_level=excluded.risk_level,
         computed_at=now()`,
      [r.zone_id, r.dow, r.hour, expectedOrders, expectedDrivers, risk]
    ).catch(()=>{});
  }
}
