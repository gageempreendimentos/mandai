import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const forecastRouter = express.Router();

forecastRouter.get("/", requireAuth, requireRole("admin"), async (req, res) => {
  const zone_id = req.query.zone_id || null;
  const r = await q(
    `select zone_id, dow, hour, expected_orders, expected_active_drivers, risk_level, computed_at
     from demand_forecast
     where ($1::uuid is null or zone_id=$1)
     order by risk_level desc, expected_orders desc
     limit 500`,
    [zone_id]
  ).catch(()=>({rows:[]}));

  res.json({ forecast: r.rows });
});
