import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";
import { audit } from "../middlewares/audit.js";
import { haversineMeters } from "../lib/geo.js";

export const adminRouter = express.Router();

adminRouter.get("/system/status", requireAuth, requireRole("admin"), async (req, res) => {
  // quick health snapshot
  const crisis = await q("select value from system_state where key='crisis_mode'").catch(()=>({rows:[]}));
  const driversOnline = await q(
    `select count(*)::int as n from driver_locations
     where coalesce(is_online,true)=true and now() - last_ping_at < interval '2 minutes'`
  ).catch(()=>({rows:[{n:0}]}));

  const pendingNotif = await q(
    `select count(*)::int as n from notifications_outbox where status='pending'`
  ).catch(()=>({rows:[{n:0}]}));

  res.json({
    crisis_mode: String(crisis.rows[0]?.value || "false").toLowerCase() === "true",
    drivers_online: driversOnline.rows[0]?.n ?? 0,
    notifications_pending: pendingNotif.rows[0]?.n ?? 0
  });
});

adminRouter.post(
  "/system/crisis",
  requireAuth,
  requireRole("admin"),
  requirePermission("system.crisis_toggle"),
  idempotency(),
  audit("system.crisis_toggle", "system_state", "crisis_mode", (req)=>({ value: req.body?.value })),
  async (req, res) => {
    const value = String(req.body?.value ?? "false").toLowerCase() === "true" ? "true" : "false";
    await q(
      `insert into system_state (key, value, updated_at)
       values ('crisis_mode',$1, now())
       on conflict (key) do update set value=excluded.value, updated_at=now()`,
      [value]
    );
    res.json({ ok: true, crisis_mode: value === "true" });
  }
);

// Audit log
adminRouter.get(
  "/audit",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.view_audit"),
  async (req, res) => {
    const limit = Math.min(200, Number(req.query.limit || 100));
    const r = await q(
      `select id, actor_user_id, action, entity_type, entity_id, ip, user_agent, payload, created_at
       from audit_log
       order by created_at desc
       limit $1`,
      [limit]
    );
    res.json({ audit: r.rows });
  }
);

// Feature flags
adminRouter.get(
  "/flags",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.manage_flags"),
  async (req, res) => {
    const r = await q(`select key, scope_kind, scope_value, enabled, updated_at from feature_flags order by key, scope_kind`);
    res.json({ flags: r.rows });
  }
);

adminRouter.post(
  "/flags",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.manage_flags"),
  idempotency(),
  audit("flags.upsert", "feature_flags", (req)=>`${req.body?.key}:${req.body?.scope_kind}:${req.body?.scope_value}`, (req)=>req.body||{}),
  async (req, res) => {
    const { key, scope_kind, scope_value, enabled } = req.body || {};
    if (!key) return res.status(400).json({ error: "missing_key" });
    const sk = scope_kind || "global";
    const sv = scope_value ?? null;
    const en = !!enabled;

    const r = await q(
      `insert into feature_flags (key, scope_kind, scope_value, enabled, updated_at)
       values ($1,$2,$3,$4, now())
       on conflict (key, scope_kind, scope_value) do update set enabled=excluded.enabled, updated_at=now()
       returning key, scope_kind, scope_value, enabled, updated_at`,
      [key, sk, sv, en]
    );
    res.json({ flag: r.rows[0] });
  }
);

// Drivers online (ops card)
adminRouter.get(
  "/drivers/online",
  requireAuth,
  requireRole("admin"),
  async (req, res) => {
    const r = await q(
      `select u.id, u.name, u.phone, dl.lat, dl.lng, dl.updated_at, dl.last_ping_at
       from users u
       join driver_locations dl on dl.driver_id = u.id
       where u.role='driver'
         and coalesce(dl.is_online,true)=true
         and now() - dl.last_ping_at < interval '2 minutes'
       order by dl.last_ping_at desc
       limit 500`
    );
    res.json({ drivers: r.rows });
  }
);

// Heatmap (simple grid buckets)
adminRouter.get(
  "/heatmap",
  requireAuth,
  requireRole("admin"),
  async (req, res) => {
    const grid = Number(req.query.grid || 0.01); // ~1km
    const sinceMin = Math.min(1440, Number(req.query.since_minutes || 180));
    const r = await q(
      `select pickup_lat, pickup_lng
       from rides
       where pickup_lat is not null and pickup_lng is not null
         and created_at > now() - (interval '1 minute' * $1)`,
      [sinceMin]
    );

    const buckets = new Map();
    for (const p of r.rows) {
      const lat = Number(p.pickup_lat), lng = Number(p.pickup_lng);
      const key = `${Math.round(lat / grid) * grid}:${Math.round(lng / grid) * grid}`;
      buckets.set(key, (buckets.get(key) || 0) + 1);
    }
    const points = [...buckets.entries()].map(([k, count]) => {
      const [lat, lng] = k.split(":").map(Number);
      return { lat, lng, count };
    }).sort((a,b)=>b.count-a.count).slice(0, 300);

    // drivers for overlay
    const d = await q(
      `select lat, lng from driver_locations
       where coalesce(is_online,true)=true and now() - last_ping_at < interval '2 minutes'`
    ).catch(()=>({rows:[]}));

    res.json({ grid, since_minutes: sinceMin, pickups: points, drivers: d.rows });
  }
);


// Block/unblock users (admin optional)
adminRouter.post(
  "/users/:userId/block",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.manage_users"),
  idempotency(),
  audit("user.block", "users", (req)=>req.params.userId, (req)=>({ reason: req.body?.reason || null })),
  async (req, res) => {
    const { userId } = req.params;
    const reason = req.body?.reason ? String(req.body.reason) : null;
    await q(`update users set is_disabled=true where id=$1`, [userId]);
    await q(
      `insert into audit_log (actor_user_id, action, entity_type, entity_id, payload, ip, user_agent)
       values ($1,'user.block','users',$2,jsonb_build_object('reason',$3),$4,$5)`,
      [req.user.sub, userId, reason, req.ip, req.headers["user-agent"] || null]
    ).catch(()=>{});
    res.json({ ok: true });
  }
);

adminRouter.post(
  "/users/:userId/unblock",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.manage_users"),
  idempotency(),
  audit("user.unblock", "users", (req)=>req.params.userId, (req)=>({})),
  async (req, res) => {
    const { userId } = req.params;
    await q(`update users set is_disabled=false where id=$1`, [userId]);
    await q(
      `insert into audit_log (actor_user_id, action, entity_type, entity_id, payload, ip, user_agent)
       values ($1,'user.unblock','users',$2,'{}'::jsonb,$3,$4)`,
      [req.user.sub, userId, req.ip, req.headers["user-agent"] || null]
    ).catch(()=>{});
    res.json({ ok: true });
  }
);

// Idle drivers list (for ops)
adminRouter.get(
  "/drivers/idle",
  requireAuth,
  requireRole("admin"),
  async (req, res) => {
    const minutes = Math.min(60, Math.max(1, Number(req.query.minutes || 10)));
    const r = await q(
      `select u.id, u.name, u.phone, u.is_disabled, dl.lat, dl.lng, dl.last_ping_at
       from users u
       join driver_locations dl on dl.driver_id=u.id
       where u.role='driver'
         and coalesce(dl.is_online,true)=true
         and now() - dl.last_ping_at >= (interval '1 minute' * $1)
       order by dl.last_ping_at asc
       limit 500`,
      [minutes]
    ).catch(()=>({rows:[]}));
    res.json({ minutes, drivers: r.rows });
  }
);

// Driver ranking (admin view)
adminRouter.get(
  "/drivers/ranking",
  requireAuth,
  requireRole("admin"),
  async (req, res) => {
    const city = req.query.city ? String(req.query.city) : null;
    const limit = Math.min(200, Number(req.query.limit || 100));
    const r = await q(
      `select * from driver_ranking_view
       where ($1::text is null or preferred_city=$1)
       order by composite_score desc
       limit $2`,
      [city, limit]
    ).catch(()=>({rows:[]}));
    res.json({ city, ranking: r.rows });
  }
);



// Surge controls (system_state)
adminRouter.post(
  "/system/surge",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.manage_flags"),
  idempotency(),
  audit("system.surge_update", "system_state", "surge", (req)=>req.body||{}),
  async (req, res) => {
    const enabled = String(req.body?.enabled ?? "false").toLowerCase() === "true" ? "true" : "false";
    const max = Math.max(1.0, Math.min(5.0, Number(req.body?.max_multiplier ?? 2.0)));
    const sens = Math.max(0.05, Math.min(3.0, Number(req.body?.sensitivity ?? 0.6)));

    const up = async (key, value) => q(
      `insert into system_state (key, value, updated_at)
       values ($1,$2, now())
       on conflict (key) do update set value=excluded.value, updated_at=now()`,
      [key, String(value)]
    );

    await up("surge_enabled", enabled);
    await up("surge_max_multiplier", max);
    await up("surge_sensitivity", sens);

    res.json({ ok: true, surge: { enabled: enabled==="true", max_multiplier: max, sensitivity: sens } });
  }
);

adminRouter.get(
  "/system/surge",
  requireAuth,
  requireRole("admin"),
  async (req, res) => {
    const r = await q(`select key, value from system_state where key in ('surge_enabled','surge_max_multiplier','surge_sensitivity')`).catch(()=>({rows:[]}));
    const map = new Map(r.rows.map(x=>[x.key, x.value]));
    res.json({
      surge: {
        enabled: String(map.get("surge_enabled") || "false").toLowerCase() === "true",
        max_multiplier: Number(map.get("surge_max_multiplier") || 2.0),
        sensitivity: Number(map.get("surge_sensitivity") || 0.6)
      }
    });
  }
);

