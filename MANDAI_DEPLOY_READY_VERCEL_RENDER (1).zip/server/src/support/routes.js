import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";

export const supportRouter = express.Router();

// Anyone authenticated can create a ticket
supportRouter.post("/", requireAuth, idempotency(), async (req, res) => {
  const { subject, message, priority, ride_id, attachments } = req.body || {};
  if (!subject || !message) return res.status(400).json({ error: "missing_fields" });
  const r = await q(
    `insert into support_tickets (created_by, role, subject, message, priority, ride_id, attachments)
     values ($1,$2,$3,$4,$5,$6,$7)
     returning id, status`,
    [req.user.sub, req.user.role, subject, message, Number(priority||2), ride_id||null, JSON.stringify(attachments||[])]
  );
  res.json({ ok: true, id: r.rows[0].id, status: r.rows[0].status });
});

// Admin list
supportRouter.get("/", requireAuth, requireRole("admin"), requirePermission("support.manage"), async (req, res) => {
  const status = req.query.status || null;
  const r = await q(
    `select id, created_by, role, subject, message, status, priority, ride_id, attachments, created_at, updated_at
     from support_tickets
     where ($1::text is null or status=$1)
     order by updated_at desc
     limit 300`,
    [status]
  );
  res.json({ tickets: r.rows });
});

supportRouter.post("/:id/status", requireAuth, requireRole("admin"), requirePermission("support.manage"), idempotency(), async (req,res)=>{
  const id = Number(req.params.id);
  const status = String(req.body?.status || "open");
  await q(`update support_tickets set status=$2, updated_at=now() where id=$1`, [id, status]);
  res.json({ ok:true });
});
