import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";
import { jobsQueue } from "../queue/queues.js";

export const notificationsRouter = express.Router();

notificationsRouter.get("/templates", requireAuth, requireRole("admin"), async (req, res) => {
  const r = await q("select key, title, body, channel, created_at, updated_at from notification_templates order by key asc");
  res.json({ templates: r.rows });
});

notificationsRouter.post("/templates", requireAuth, requireRole("admin"), idempotency(), async (req, res) => {
  const { key, title, body, channel } = req.body || {};
  if (!key || !title || !body) return res.status(400).json({ error: "missing_fields" });

  const r = await q(
    `insert into notification_templates (key, title, body, channel, updated_at)
     values ($1,$2,$3,coalesce($4,'ws'), now())
     on conflict (key) do update set title=excluded.title, body=excluded.body, channel=excluded.channel, updated_at=now()
     returning key, title, body, channel, created_at, updated_at`,
    [key, title, body, channel || "ws"]
  );

  res.json({ template: r.rows[0] });
});

/**
 * Broadcast from template:
 * POST /notifications/send-template
 * { template_key, target_kind, target_value?, vars? }
 */
notificationsRouter.post("/send-template", requireAuth, requireRole("admin"), idempotency(), async (req, res) => {
  const { template_key, target_kind, target_value, vars } = req.body || {};
  if (!template_key || !target_kind) return res.status(400).json({ error: "missing_fields" });

  const t = await q("select key, title, body, channel from notification_templates where key=$1", [template_key]);
  const tpl = t.rows[0];
  if (!tpl) return res.status(404).json({ error: "template_not_found" });

  const render = (s) => String(s).replace(/\{\{(\w+)\}\}/g, (_, k) => (vars?.[k] ?? ""));
  const title = render(tpl.title);
  const body = render(tpl.body);
  const channel = tpl.channel || "ws";

  const r = await q(
    `insert into notifications_outbox (target_kind, target_value, title, body, channel)
     values ($1,$2,$3,$4,$5)
     returning id`,
    [target_kind, target_value || null, title, body, channel]
  );

  await jobsQueue.add("send_notification", { outbox_id: r.rows[0].id }, { removeOnComplete: true, removeOnFail: 100 });

  res.json({ ok: true, outbox_id: r.rows[0].id });
});

/**
 * Quick broadcast to ALL drivers:
 * POST /notifications/drivers
 * { title, body }
 */
notificationsRouter.post("/drivers", requireAuth, requireRole("admin"), idempotency(), async (req, res) => {
  const { title, body } = req.body || {};
  if (!title || !body) return res.status(400).json({ error: "missing_fields" });

  const r = await q(
    `insert into notifications_outbox (target_kind, target_value, title, body, channel)
     values ('all_drivers', null, $1, $2, 'ws')
     returning id`,
    [title, body]
  );
  await jobsQueue.add("send_notification", { outbox_id: r.rows[0].id }, { removeOnComplete: true, removeOnFail: 100 });
  res.json({ ok: true, outbox_id: r.rows[0].id });
});
