import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";

export const zonePoliciesRouter = express.Router();

zonePoliciesRouter.get("/", requireAuth, requireRole("admin"), requirePermission("zones.manage"), async (req,res)=>{
  const r = await q(
    `select id, zone_id, kind, payload, active, created_at, updated_at
     from zone_policies
     order by updated_at desc
     limit 500`
  ).catch(()=>({rows:[]}));
  res.json({ policies: r.rows });
});

zonePoliciesRouter.post("/", requireAuth, requireRole("admin"), requirePermission("zones.manage"), idempotency(), async (req,res)=>{
  const { zone_id, kind, payload, active } = req.body || {};
  if (!zone_id || !kind) return res.status(400).json({ error: "missing_fields" });
  const r = await q(
    `insert into zone_policies (zone_id, kind, payload, active)
     values ($1,$2,$3::jsonb,$4)
     returning *`,
    [zone_id, kind, JSON.stringify(payload||{}), active ?? true]
  );
  res.json({ policy: r.rows[0] });
});

zonePoliciesRouter.post("/:id", requireAuth, requireRole("admin"), requirePermission("zones.manage"), idempotency(), async (req,res)=>{
  const id = Number(req.params.id);
  const { active, payload } = req.body || {};
  const r = await q(
    `update zone_policies set active=coalesce($2,active), payload=coalesce($3::jsonb,payload), updated_at=now()
     where id=$1 returning *`,
    [id, active, payload ? JSON.stringify(payload) : null]
  );
  res.json({ policy: r.rows[0] });
});
