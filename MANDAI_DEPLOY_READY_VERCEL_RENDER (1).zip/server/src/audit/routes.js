import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const auditRouter = express.Router();

auditRouter.get("/events", requireAuth, requireRole("admin"), async (req,res)=>{
  const limit = Math.min(Number(req.query.limit||200), 2000);
  const cursor = req.query.cursor ? String(req.query.cursor) : null;
  const r = await q(
    `select id, ride_id, type, created_at, payload
     from ride_events
     where ($2::timestamptz is null or created_at < $2::timestamptz)
     order by created_at desc
     limit $1`,
    [limit, cursor]
  ).catch(()=>({rows:[]}));
  const next_cursor = r.rows.length ? r.rows[r.rows.length-1].created_at : null;
  res.json({ events: r.rows, next_cursor });
});

auditRouter.get("/events.csv", requireAuth, requireRole("admin"), async (req,res)=>{
  const r = await q(
    `select id, ride_id, type, created_at, payload
     from ride_events
     order by created_at desc
     limit 5000`
  ).catch(()=>({rows:[]}));
  const cols=["id","ride_id","type","created_at","payload"];
  const head=cols.join(",");
  const lines=r.rows.map(x=>cols.map(c=>('"'+String((typeof x[c]==="object")?JSON.stringify(x[c]):(x[c]??"")).replace(/"/g,'""'))+'"').join(","));
  res.setHeader("content-type","text/csv; charset=utf-8");
  res.setHeader("content-disposition","attachment; filename=audit_events.csv");
  res.send([head,...lines].join("\n"));
});
