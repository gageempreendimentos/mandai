const metrics = {
  requests_total: 0,
  requests_by_route: {},
  status_by_route: {},
  avg_latency_ms_by_route: {},
};

function key(req) {
  const p = req.route?.path || req.path || "unknown";
  const base = req.baseUrl || "";
  return (base + p) || "unknown";
}

export function metricsMiddleware(req,res,next) {
  const start = Date.now();
  metrics.requests_total += 1;
  const k = key(req);
  metrics.requests_by_route[k] = (metrics.requests_by_route[k] || 0) + 1;

  res.on("finish", ()=>{
    const ms = Date.now() - start;
    const sk = `${k}:${res.statusCode}`;
    metrics.status_by_route[sk] = (metrics.status_by_route[sk] || 0) + 1;

    const prev = metrics.avg_latency_ms_by_route[k] || { n: 0, avg: 0 };
    const n = prev.n + 1;
    const avg = prev.avg + (ms - prev.avg) / n;
    metrics.avg_latency_ms_by_route[k] = { n, avg: Math.round(avg) };
  });

  next();
}

export function getMetrics() {
  return metrics;
}
