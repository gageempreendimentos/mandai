export function initSentry(app) {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return { enabled:false };
  try {
    // optional dependency
    // eslint-disable-next-line global-require
    const Sentry = require("@sentry/node");
    Sentry.init({ dsn, tracesSampleRate: 0.1 });
    app.use(Sentry.Handlers.requestHandler());
    app.use(Sentry.Handlers.tracingHandler());
    return { enabled:true, Sentry };
  } catch {
    return { enabled:false };
  }
}

export function sentryErrorHandler(app, sentry) {
  if (!sentry?.enabled || !sentry.Sentry) return;
  app.use(sentry.Sentry.Handlers.errorHandler());
}
