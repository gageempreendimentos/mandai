export function accessLog(req,res,next) {
  const start = Date.now();
  res.on("finish", ()=>{
    const ms = Date.now() - start;
    const line = `${new Date().toISOString()} ${res.statusCode} ${req.method} ${req.originalUrl} ${ms}ms`;
    // eslint-disable-next-line no-console
    console.log(line);
  });
  next();
}
