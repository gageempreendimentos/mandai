import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";

export const reports2Router = express.Router();

function toCSV(rows) {
  if (!rows || rows.length === 0) return "";
  const cols = Object.keys(rows[0]);
  const esc = (v) => {
    const s = (v===null||v===undefined) ? "" : String(v);
    if (/[",\n]/.test(s)) return '"' + s.replace(/"/g,'""') + '"';
    return s;
  };
  const lines = [cols.join(",")];
  for (const r of rows) lines.push(cols.map(c=>esc(r[c])).join(","));
  return lines.join("\n");
}

reports2Router.get("/rides.csv", requireAuth, requireRole("admin"), requirePermission("reports.export"), async (req,res)=>{
  const from = req.query.from || null;
  const to = req.query.to || null;

  const r = await q(
    `select id, status, created_at, updated_at, driver_id, client_id, restaurant_id, zone_id, fare_cents, distance_km, duration_min
     from rides
     where ($1::timestamptz is null or created_at >= $1)
       and ($2::timestamptz is null or created_at <= $2)
     order by created_at desc
     limit 5000`,
    [from, to]
  ).catch(()=>({rows:[]}));

  res.setHeader("content-type","text/csv; charset=utf-8");
  res.setHeader("content-disposition","attachment; filename=rides.csv");
  res.send(toCSV(r.rows));
});
