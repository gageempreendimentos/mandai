import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";

export const termsRouter = express.Router();

// Get active docs (public once authed)
termsRouter.get("/current", requireAuth, async (req,res)=>{
  const docs = await q(
    `select doc_type, version, title, content_md
     from terms_versions where active=true
     order by doc_type, created_at desc`
  ).catch(()=>({rows:[]}));
  res.json({ docs: docs.rows });
});

termsRouter.post("/accept", requireAuth, idempotency(), async (req,res)=>{
  const accept = req.body?.accept || [];
  const ip = req.headers["x-forwarded-for"]?.toString()?.split(",")[0]?.trim() || req.ip;
  const ua = req.headers["user-agent"] || "";
  for (const a of accept) {
    if (!a?.doc_type || !a?.version) continue;
    await q(
      `insert into user_terms_acceptance (user_id, doc_type, version, ip, user_agent)
       values ($1,$2,$3,$4,$5)
       on conflict do nothing`,
      [req.user.sub, a.doc_type, a.version, ip, ua]
    ).catch(()=>{});
  }
  res.json({ ok:true });
});

// Admin manage docs
termsRouter.get("/admin", requireAuth, requireRole("admin"), requirePermission("terms.manage"), async (req,res)=>{
  const r = await q(
    `select id, doc_type, version, title, active, created_at
     from terms_versions
     order by created_at desc
     limit 200`
  ).catch(()=>({rows:[]}));
  res.json({ versions: r.rows });
});

termsRouter.post("/admin", requireAuth, requireRole("admin"), requirePermission("terms.manage"), idempotency(), async (req,res)=>{
  const { doc_type, version, title, content_md, active } = req.body || {};
  if (!doc_type || !version || !title || !content_md) return res.status(400).json({ error:"missing_fields" });
  const r = await q(
    `insert into terms_versions (doc_type, version, title, content_md, active)
     values ($1,$2,$3,$4,$5)
     returning id`,
    [doc_type, version, title, content_md, active ?? true]
  );
  res.json({ ok:true, id: r.rows[0].id });
});

termsRouter.post("/admin/:id/toggle", requireAuth, requireRole("admin"), requirePermission("terms.manage"), idempotency(), async (req,res)=>{
  const id = Number(req.params.id);
  const r = await q(`update terms_versions set active=not active where id=$1 returning active`, [id]);
  res.json({ ok:true, active: r.rows[0]?.active });
});
