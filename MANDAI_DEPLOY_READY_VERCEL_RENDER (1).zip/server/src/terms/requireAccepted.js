import { q } from "../db.js";

/**
 * Blocks protected routes until user accepts active terms+privacy.
 * Exclude /terms/* routes themselves.
 */
export function requireTermsAccepted() {
  return async (req, res, next) => {
    try {
      const userId = req.user?.sub;
      if (!userId) return res.status(401).json({ error: "unauthorized" });

      const active = await q(`select doc_type, version from terms_versions where active=true and doc_type in ('terms','privacy')`);
      for (const d of active.rows) {
        const ok = await q(
          `select 1 from user_terms_acceptance where user_id=$1 and doc_type=$2 and version=$3 limit 1`,
          [userId, d.doc_type, d.version]
        );
        if (!ok.rows[0]) return res.status(428).json({ error: "terms_required", required: active.rows });
      }
      next();
    } catch (e) {
      return res.status(500).json({ error: "terms_check_failed" });
    }
  };
}
