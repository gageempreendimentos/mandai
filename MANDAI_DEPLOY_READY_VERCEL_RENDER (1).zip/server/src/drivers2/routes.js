import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const drivers2Router = express.Router();

drivers2Router.get("/me", requireAuth, requireRole("driver"), async (req,res)=>{
  const r = await q(
    `select d.id, d.vehicle_type, d.capacity_kg, d.capacity_volume, d.online, d.cooldown_until
     from drivers d
     where d.user_id=$1`,
    [req.user.sub]
  ).catch(()=>({rows:[]}));
  res.json({ driver: r.rows[0] || null });
});

drivers2Router.post("/me/vehicle", requireAuth, requireRole("driver"), idempotency(), async (req,res)=>{
  const { vehicle_type, capacity_kg, capacity_volume } = req.body || {};
  const vt = String(vehicle_type||"moto");
  const kg = Math.max(1, Number(capacity_kg||20));
  const vol = String(capacity_volume||"P");
  await q(
    `update drivers set vehicle_type=$2, capacity_kg=$3, capacity_volume=$4, updated_at=now()
     where user_id=$1`,
    [req.user.sub, vt, kg, vol]
  ).catch(()=>{});
  res.json({ ok:true });
});

drivers2Router.post("/me/location", requireAuth, requireRole("driver"), idempotency(), async (req,res)=>{
  const { lat, lng } = req.body || {};
  const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  if (!d.rows[0]) return res.status(400).json({ error:"no_driver" });
  await q(
    `insert into driver_last_location (driver_id, lat, lng, updated_at)
     values ($1,$2,$3, now())
     on conflict (driver_id) do update set lat=excluded.lat, lng=excluded.lng, updated_at=now()`,
    [d.rows[0].id, Number(lat||0), Number(lng||0)]
  ).catch(()=>{});
  res.json({ ok:true });
});


drivers2Router.get("/me/rides", requireAuth, requireRole("driver"), async (req,res)=>{
  const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  if (!d.rows[0]) return res.json({ rides: [] });
  const r = await q(
    `select id, kind, status, pickup, dropoff, fare_cents, created_at, updated_at
     from rides
     where driver_id=$1
     order by created_at desc
     limit 150`,
    [d.rows[0].id]
  ).catch(()=>({rows:[]}));
  res.json({ rides: r.rows });
});
