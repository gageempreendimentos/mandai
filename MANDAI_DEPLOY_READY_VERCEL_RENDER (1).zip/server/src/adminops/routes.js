import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const adminOpsRouter = express.Router();

adminOpsRouter.get("/overview", requireAuth, requireRole("admin"), async (req,res)=>{
  const late = await q(`select count(*)::int as n from rides where status in ('assigned','accepted','enroute') and updated_at < now() - interval '20 minutes'`).catch(()=>({rows:[{n:0}]}));
  const onlineDrivers = await q(`select count(*)::int as n from drivers where status='online'`).catch(()=>({rows:[{n:0}]}));
  res.json({ late: late.rows[0].n, online_drivers: onlineDrivers.rows[0].n });
});

adminOpsRouter.get("/late", requireAuth, requireRole("admin"), async (req,res)=>{
  const limit = Math.min(Number(req.query.limit||200), 500);
  const cursor = req.query.cursor ? String(req.query.cursor) : null;
  const r = await q(
    `select id, kind, status, pickup, dropoff, driver_id, client_id, updated_at
     from rides
     where status in ('assigned','accepted','enroute')
       and updated_at < now() - interval '20 minutes'
       and ($1::timestamptz is null or updated_at > $1::timestamptz)
     order by updated_at asc
     limit $2`
  , [cursor, limit]
  ).catch(()=>({rows:[]}));
  const next_cursor = r.rows.length ? r.rows[r.rows.length-1].updated_at : null;
  res.json({ rides: r.rows, next_cursor });
});
