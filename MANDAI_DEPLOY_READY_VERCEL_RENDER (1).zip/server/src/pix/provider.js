/**
 * Provider interface (produção)
 * Configure:
 *  - PIX_PROVIDER=SIMULATED|OPENPIX|GERENCIANET|MERCADOPAGO (exemplos)
 *  - PIX_API_KEY / PIX_CLIENT_ID / PIX_CLIENT_SECRET etc (conforme provider)
 *
 * MVP aqui retorna simulado. Integração real: implementar chamadas HTTP do provider escolhido.
 */
import crypto from "crypto";

export async function payPix({ amount_cents, pix_key, request_id }) {
  const provider = (process.env.PIX_PROVIDER || "SIMULATED").toUpperCase();
  if (provider === "SIMULATED") {
    return { ok: true, provider_ref: "pix_sim_" + crypto.randomBytes(6).toString("hex") };
  }
  // TODO: Implement provider HTTP calls here
  // Keep safe: return not configured
  return { ok: false, error: "pix_provider_not_configured" };
}
