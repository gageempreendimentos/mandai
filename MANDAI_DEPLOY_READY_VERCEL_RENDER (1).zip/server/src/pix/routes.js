import express from "express";
import crypto from "crypto";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";
import { payPix } from "./provider.js";

export const pixRouter = express.Router();

// Driver requests withdraw (simulated)
pixRouter.post("/withdraw", requireAuth, idempotency(), async (req, res) => {
  if (req.user.role !== "driver") return res.status(403).json({ error: "forbidden" });
  const amount_cents = Number(req.body?.amount_cents || 0);
  const pix_key = String(req.body?.pix_key || "").trim();
  if (!pix_key) return res.status(400).json({ error: "missing_pix_key" });
  if (amount_cents <= 0) return res.status(400).json({ error: "invalid_amount" });

  const r = await q(
    `insert into withdraw_requests (driver_id, amount_cents, pix_key, status)
     values ($1,$2,$3,'pending')
     returning id, status`,
    [req.user.sub, amount_cents, pix_key]
  );
  res.json({ ok: true, request_id: r.rows[0].id, status: r.rows[0].status });
});

pixRouter.get("/me/withdrawals", requireAuth, async (req, res) => {
  if (req.user.role !== "driver") return res.status(403).json({ error: "forbidden" });
  const r = await q(
    `select id, amount_cents, pix_key, status, provider_ref, created_at, updated_at
     from withdraw_requests
     where driver_id=$1
     order by created_at desc
     limit 200`,
    [req.user.sub]
  );
  res.json({ withdrawals: r.rows });
});

pixRouter.get("/admin/withdrawals", requireAuth, requireRole("admin"), async (req, res) => {
  const status = req.query.status;
  const where = status ? "where status=$1" : "";
  const params = status ? [status] : [];
  const r = await q(
    `select id, driver_id, amount_cents, pix_key, status, provider_ref, created_at, updated_at
     from withdraw_requests
     ${where}
     order by created_at desc
     limit 200`,
    params
  );
  res.json({ withdrawals: r.rows });
});

pixRouter.post("/admin/:id/mark-paid", requireAuth, requireRole("admin"), idempotency(), async (req, res) => {
  const id = Number(req.params.id);
  const row = await q(`select id, amount_cents, pix_key from withdraw_requests where id=$1`, [id]);
  if (!row.rows[0]) return res.status(404).json({ error: 'not_found' });
  const p = await payPix({ amount_cents: row.rows[0].amount_cents, pix_key: row.rows[0].pix_key, request_id: id });
  if (!p.ok) return res.status(400).json({ error: p.error || 'pix_failed' });
  await q(`update withdraw_requests set status='paid', provider_ref=$2, updated_at=now() where id=$1`, [id, p.provider_ref]);
  res.json({ ok: true, provider_ref: p.provider_ref });
});
