import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";
import { audit } from "../middlewares/audit.js";

export const campaignsRouter = express.Router();

campaignsRouter.get("/", requireAuth, async (req, res) => {
  const r = await q(
    `select id, name, zone_id, start_at, end_at, target_rides, bonus_cents, active
     from campaigns
     where active=true and now() between start_at and end_at
     order by start_at desc`
  );
  res.json({ campaigns: r.rows });
});

campaignsRouter.post(
  "/",
  requireAuth,
  requireRole("admin"),
  requirePermission("campaign.manage"),
  idempotency(),
  audit("campaign.upsert", "campaigns", (req)=>String(req.body?.id||""), (req)=>req.body||{}),
  async (req, res) => {
    const b = req.body || {};
    const { id, name, zone_id, start_at, end_at, target_rides, bonus_cents, active } = b;
    if (!name || !start_at || !end_at) return res.status(400).json({ error: "missing_fields" });

    if (id) {
      const r = await q(
        `update campaigns set name=$2, zone_id=$3, start_at=$4, end_at=$5, target_rides=$6, bonus_cents=$7, active=$8, updated_at=now()
         where id=$1 returning *`,
        [id, name, zone_id||null, start_at, end_at, target_rides||0, bonus_cents||0, active ?? true]
      );
      return res.json({ campaign: r.rows[0] });
    }

    const r = await q(
      `insert into campaigns (name, zone_id, start_at, end_at, target_rides, bonus_cents, active)
       values ($1,$2,$3,$4,$5,$6,$7) returning *`,
      [name, zone_id||null, start_at, end_at, target_rides||0, bonus_cents||0, active ?? true]
    );
    res.json({ campaign: r.rows[0] });
  }
);

// Driver claims (if progress reached)
campaignsRouter.post("/:id/claim", requireAuth, idempotency(), async (req, res) => {
  if (req.user.role !== "driver") return res.status(403).json({ error: "forbidden" });
  const cid = Number(req.params.id);

  const claim = await q(
    `select cc.id, cc.progress, cc.claimed, c.bonus_cents
     from campaigns c
     left join campaign_claims cc on cc.campaign_id=c.id and cc.driver_id=$2
     where c.id=$1`,
    [cid, req.user.sub]
  );
  const row = claim.rows[0];
  if (!row) return res.status(404).json({ error: "not_found" });
  if (row.claimed) return res.json({ ok: true, already: true });

  const prog = Number(row.progress || 0);
  // get target
  const c2 = await q(`select target_rides from campaigns where id=$1`, [cid]);
  const target = Number(c2.rows[0]?.target_rides || 0);
  if (target > 0 && prog < target) return res.status(400).json({ error: "not_eligible", progress: prog, target });

  await q(
    `update campaign_claims set claimed=true, claimed_at=now() where campaign_id=$1 and driver_id=$2`,
    [cid, req.user.sub]
  );
  if (Number(row.bonus_cents) > 0) {
    await q(
      `insert into wallet_ledger (user_id, kind, amount_cents, details)
       values ($1,'bonus',$2, jsonb_build_object('campaign_id',$3))`,
      [req.user.sub, Number(row.bonus_cents), cid]
    );
  }
  res.json({ ok: true });
});
