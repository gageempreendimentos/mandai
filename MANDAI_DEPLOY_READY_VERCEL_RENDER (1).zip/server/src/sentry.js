import * as Sentry from "@sentry/node";

export function initSentry(app) {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;

  Sentry.init({
    dsn,
    environment: process.env.SENTRY_ENV || process.env.NODE_ENV || "development",
    tracesSampleRate: 0.05,
  });

  app.use(Sentry.Handlers.requestHandler());
  app.use(Sentry.Handlers.tracingHandler());
}

export function sentryErrorHandler(app) {
  if (!process.env.SENTRY_DSN) return;
  app.use(Sentry.Handlers.errorHandler());
}
