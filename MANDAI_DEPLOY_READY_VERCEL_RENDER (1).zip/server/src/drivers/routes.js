import express from "express";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const driversRouter = express.Router();

driversRouter.post("/duty", requireAuth, idempotency(), async (req, res) => {
  if (req.user.role !== "driver") return res.status(403).json({ error: "forbidden" });
  const on_duty = !!req.body?.on_duty;
  const st = await q(`select is_disabled from users where id=$1`, [req.user.sub]).catch(()=>({rows:[]}));

  // Documents verification check (driver must be verified before going online)
  if (on_duty) {
    const docs = await q(`select coalesce(docs_verified,false) as docs_verified, docs_status from users where id=$1`, [req.user.sub]).catch(()=>({rows:[{docs_verified:false,docs_status:null}]}));
    if (!docs.rows[0]?.docs_verified) {
      return res.status(400).json({
        error: "docs_not_verified",
        message: "Envie/valide seus documentos antes de ficar online.",
        required: ["cnh", "documento_moto", "foto_rosto"],
        status: docs.rows[0]?.docs_status || null
      });
    }
  }

  if (st.rows[0]?.is_disabled) {
    // Force off-duty if blocked
    await q(`update users set on_duty=false where id=$1`, [req.user.sub]).catch(()=>{});
    return res.status(403).json({ error: "driver_blocked", message: "Seu acesso foi bloqueado temporariamente. Fale com o suporte/admin." });
  }
  await q(`update users set on_duty=$2 where id=$1`, [req.user.sub, on_duty]);
  res.json({ ok: true, on_duty });
});

driversRouter.get("/me/metrics", requireAuth, async (req, res) => {
  if (req.user.role !== "driver") return res.status(403).json({ error: "forbidden" });
  const m = await q(`select * from driver_metrics where driver_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  const f = await q(`select * from driver_finance_metrics where driver_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  res.json({ metrics: m.rows[0] || null, finance: f.rows[0] || null });
});

// Driver profile/preferences
driversRouter.get("/me", requireAuth, async (req,res)=>{
  const r = await q(
    `select id, name, phone, role, is_disabled, on_duty, preferred_city, service_radius_km, driver_score
     from users where id=$1`,
    [req.user.sub]
  ).catch(()=>({rows:[]}));
  const u = r.rows[0];
  if (!u) return res.status(404).json({ error:"user_not_found" });
  return res.json({ user: u });
});

driversRouter.post("/preferences", requireAuth, idempotency(), async (req,res)=>{
  if (req.user.role !== "driver") return res.status(403).json({ error:"forbidden" });
  const preferred_city = req.body?.preferred_city ? String(req.body.preferred_city) : null;
  const service_radius_km = req.body?.service_radius_km != null ? Math.max(1, Math.min(50, Number(req.body.service_radius_km))) : null;

  const r = await q(
    `update users
     set preferred_city=coalesce($2, preferred_city),
         service_radius_km=coalesce($3, service_radius_km)
     where id=$1
     returning id, preferred_city, service_radius_km`,
    [req.user.sub, preferred_city, service_radius_km]
  ).catch(()=>({rows:[]}));
  return res.json({ ok: true, preferences: r.rows[0] || null });
});

// Driver can manage their own zones (optional filter for dispatch)
driversRouter.get("/zones", requireAuth, async (req,res)=>{
  if (req.user.role !== "driver") return res.status(403).json({ error:"forbidden" });
  const zones = await q(`select id, name, city from zones order by city nulls last, name asc`).catch(()=>({rows:[]}));
  const mine = await q(`select zone_id from user_zones where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  return res.json({ zones: zones.rows, selected_zone_ids: mine.rows.map(x=>x.zone_id) });
});

driversRouter.post("/zones", requireAuth, idempotency(), async (req,res)=>{
  if (req.user.role !== "driver") return res.status(403).json({ error:"forbidden" });
  const ids = Array.isArray(req.body?.zone_ids) ? req.body.zone_ids.map(String) : [];
  // reset
  await q(`delete from user_zones where user_id=$1`, [req.user.sub]);
  for (const zid of ids.slice(0, 20)) {
    await q(`insert into user_zones (user_id, zone_id) values ($1,$2) on conflict do nothing`, [req.user.sub, zid]);
  }
  return res.json({ ok: true, zone_ids: ids.slice(0,20) });
});


// Driver submits documents (URLs). Admin can verify later.
driversRouter.post("/documents", requireAuth, idempotency(), async (req,res)=>{
  if (req.user.role !== "driver") return res.status(403).json({ error:"forbidden" });
  const { cnh_url, vehicle_doc_url, selfie_url } = req.body || {};
  const docs_status = {
    cnh_url: cnh_url || null,
    vehicle_doc_url: vehicle_doc_url || null,
    selfie_url: selfie_url || null,
    submitted_at: new Date().toISOString()
  };
  await q(
    `update users set docs_status=$2::jsonb, docs_verified=false where id=$1`,
    [req.user.sub, JSON.stringify(docs_status)]
  ).catch(()=>{});
  res.json({ ok:true, status: docs_status });
});

driversRouter.get("/documents", requireAuth, async (req,res)=>{
  if (req.user.role !== "driver" && req.user.role !== "admin") return res.status(403).json({ error:"forbidden" });
  const uid = req.user.role === "admin" && req.query.user_id ? String(req.query.user_id) : req.user.sub;
  const r = await q(`select id, docs_verified, docs_status from users where id=$1`, [uid]).catch(()=>({rows:[]}));
  if (!r.rows[0]) return res.status(404).json({ error:"user_not_found" });
  res.json({ user_id: uid, docs_verified: r.rows[0].docs_verified, docs_status: r.rows[0].docs_status });
});
