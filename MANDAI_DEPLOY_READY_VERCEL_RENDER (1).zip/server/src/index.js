import "dotenv/config";
import http from "http";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import compression from "compression";
import path from "path";

import { initSentry, sentryErrorHandler } from "./sentry.js";
import { metricsMiddleware, getMetrics } from "./observability/metrics.js";
import { accessLog } from "./observability/accesslog.js";
import { rateLimit } from "./middlewares/rateLimit.js";
import { rateLimitRedis } from "./middlewares/rateLimitRedis.js";
import { crisisGuard } from "./middlewares/crisis.js";

import { authRouter } from "./auth/routes.js";
import { ridesRouter } from "./rides/routes.js";
import { zonesRouter } from "./zones/routes.js";
import { notificationsRouter } from "./notifications/routes.js";
import { devicesRouter } from "./devices/routes.js";
import { adminRouter } from "./admin/routes.js";
import { dispatchRouter } from "./dispatch/routes.js";
import { createWsServer } from "./ws/server.js";

// Extra routers (explicitly mounted to avoid ESM/CJS require issues)
import { driversRouter } from "./drivers/routes.js";
import { fraudRouter } from "./fraud/routes.js";
import { pricingRouter } from "./pricing/routes.js";
import { reportsRouter } from "./reports/routes.js";
import { opsRouter } from "./ops/routes.js";
import { reports2Router } from "./reports2/routes.js";
import { batchRouter } from "./batch/routes.js";
import { campaignsRouter } from "./campaigns/routes.js";
import { replayRouter } from "./replay/routes.js";
import { forecastRouter } from "./forecast/routes.js";
import { pixRouter } from "./pix/routes.js";
import { templatesRouter } from "./templates/routes.js";
import { supportRouter } from "./support/routes.js";
import { zonePoliciesRouter } from "./zones2/routes.js";
import { restaurants2Router } from "./restaurants2/routes.js";
import { auditTimelineRouter } from "./audit_timeline/routes.js";
import { termsRouter } from "./terms/routes.js";
import { onboardingRouter } from "./onboarding/routes.js";
import { freightRouter } from "./freight/routes.js";
import { push2Router } from "./push2/routes.js";
import { drivers2Router } from "./drivers2/routes.js";
import { uploadsRouter } from "./uploads/routes.js";
import { mapsRouter } from "./maps/routes.js";
import { b2bRouter } from "./b2b/routes.js";
import { paymentsRouter } from "./payments/routes.js";
import { adminOpsRouter } from "./adminops/routes.js";
import { fcmRouter } from "./push_fcm/routes.js";
import { auditRouter } from "./audit/routes.js";
import { ledgerRouter } from "./ledger/routes.js";

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));

// gzip/brotli-friendly compression (helps a lot on slower mobile networks)
app.use(compression());

// CORS: allow a single origin or a comma-separated allowlist via CORS_ORIGIN.
const corsOriginEnv = (process.env.CORS_ORIGIN || "").trim();
const corsAllowlist = corsOriginEnv
  ? corsOriginEnv.split(",").map((s) => s.trim()).filter(Boolean)
  : null;

app.use(
  cors({
    origin: (origin, cb) => {
      // Non-browser clients (mobile apps / curl) may not send Origin.
      if (!origin) return cb(null, true);
      if (!corsAllowlist) return cb(null, true);
      return cb(null, corsAllowlist.includes(origin));
    },
    credentials: true,
  })
);
app.use(cookieParser());
app.use(express.json({ limit: "10mb" }));

// Global rate limit (fallback in-memory) + optional Redis limiter
app.use(rateLimit({ name: "api", windowMs: 60_000, max: 800 }));
if (process.env.REDIS_URL) {
  app.use(rateLimitRedis({ name: "api", windowSec: 60, max: 1200 }));
}

app.use(accessLog);
app.use(metricsMiddleware);

initSentry(app);

// Crisis/maintenance mode guard (DB + env flag)
app.use(crisisGuard());

app.get("/health", async (req, res) => {
  const started = Date.now();
  const out = { ok: true, ts: new Date().toISOString(), version: process.env.APP_VERSION || null, checks: {} };
  // DB
  try {
    const { q } = await import("./db.js");
    const t0 = Date.now();
    await q("select 1 as ok");
    out.checks.db = { ok: true, ms: Date.now() - t0 };
  } catch (e) {
    out.ok = false;
    out.checks.db = { ok: false };
  }
  // Redis (optional)
  if (process.env.REDIS_URL) {
    try {
      const t0 = Date.now();
      const { pingRedis } = await import("./lib/redis.js");
      await pingRedis();
      out.checks.redis = { ok: true, ms: Date.now() - t0 };
    } catch {
      out.ok = false;
      out.checks.redis = { ok: false };
    }
  } else {
    out.checks.redis = { ok: null };
  }
  out.ms = Date.now() - started;
  res.status(out.ok ? 200 : 503).json(out);
});
app.get("/metrics", (req, res) => res.json(getMetrics()));

// static
const uploadsDir = path.resolve(process.cwd(), "uploads");
const reportsDir = path.resolve(process.cwd(), "reports");
app.use("/uploads", express.static(uploadsDir));
app.use("/reports-static", express.static(reportsDir));

// core routes
app.use("/auth", rateLimit({ name: "auth", windowMs: 60_000, max: 120 }), authRouter);
app.use("/rides", ridesRouter);
app.use("/zones", zonesRouter);
app.use("/notifications", notificationsRouter);
app.use("/devices", devicesRouter);
app.use("/admin", adminRouter);
app.use("/dispatch", dispatchRouter);
app.use("/ledger", ledgerRouter);

// feature routes used by the app
app.use("/drivers", driversRouter);
app.use("/fraud", fraudRouter);
app.use("/pricing", pricingRouter);
app.use("/reports", reportsRouter);
app.use("/ops", opsRouter);
app.use("/reports2", reports2Router);
app.use("/batch", batchRouter);
app.use("/campaigns", campaignsRouter);
app.use("/replay", replayRouter);
app.use("/forecast", forecastRouter);
app.use("/pix", pixRouter);
app.use("/templates", templatesRouter);
app.use("/support", supportRouter);
app.use("/zone-policies", zonePoliciesRouter);
app.use("/restaurants2", restaurants2Router);
app.use("/audit-timeline", auditTimelineRouter);
app.use("/terms", termsRouter);
app.use("/onboarding", onboardingRouter);
app.use("/freight", freightRouter);
app.use("/push2", push2Router);
app.use("/drivers2", drivers2Router);
app.use("/uploads-api", uploadsRouter);
app.use("/maps", mapsRouter);
app.use("/b2b", b2bRouter);
app.use("/payments", paymentsRouter);
app.use("/adminops", adminOpsRouter);
app.use("/fcm", fcmRouter);
app.use("/audit", auditRouter);

const server = http.createServer(app);
createWsServer(server);

const port = Number(process.env.PORT || 8080);
sentryErrorHandler(app);

server.listen(port, () => console.log(`MANDAI backend listening on :${port}`));
