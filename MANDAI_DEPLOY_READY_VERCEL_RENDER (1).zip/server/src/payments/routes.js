import express from "express";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";
import { getProvider } from "./provider.js";
import * as Fake from "./fake.js";
import * as MP from "./mercadopago.js";

export const paymentsRouter = express.Router();

async function providerImpl() {
  const p = getProvider();
  return p === "mercadopago" ? MP : Fake;
}

paymentsRouter.post("/create", requireAuth, idempotency(), async (req,res)=>{
  const { ride_id } = req.body || {};
  if (!ride_id) return res.status(400).json({ error:"missing_ride_id" });

  const ride = await q(`select id, client_id, fare_cents from rides where id=$1`, [ride_id]).catch(()=>({rows:[]}));
  if (!ride.rows[0]) return res.status(404).json({ error:"ride_not_found" });
  if (ride.rows[0].client_id !== req.user.sub && req.user.role !== "admin") return res.status(403).json({ error:"forbidden" });

  const amount = Number(ride.rows[0].fare_cents||0);
  const impl = await providerImpl();
  const pay = await impl.createPayment({ amount_cents: amount, reference: ride_id });

  await q(
    `insert into ride_events (ride_id, type, payload) values ($1,'payment_created', jsonb_build_object('provider',$2,'status',$3,'provider_id',$4))`,
    [ride_id, pay.provider, pay.status, pay.id]
  ).catch(()=>{});

  res.json({ ok:true, payment: pay });
});

paymentsRouter.post("/webhook/:provider", async (req,res)=>{
  const provider = String(req.params.provider||"");
  let out = { ok:true };
  try {
    if (provider === "mercadopago") out = await MP.handleWebhook(req);
    else out = await Fake.handleWebhook(req);
  } catch {}
  res.json(out);
});
