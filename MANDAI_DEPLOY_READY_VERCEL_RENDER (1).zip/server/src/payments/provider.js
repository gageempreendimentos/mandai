export function getProvider() {
  const p = (process.env.PAYMENT_PROVIDER || "fake").toLowerCase();
  if (p === "mercadopago") return "mercadopago";
  return "fake";
}
