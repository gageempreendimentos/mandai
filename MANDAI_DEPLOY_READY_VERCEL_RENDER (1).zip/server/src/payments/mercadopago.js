// Placeholder integration (requires MERCADOPAGO_ACCESS_TOKEN)
export async function createPayment({ amount_cents, reference }) {
  // TODO: call Mercado Pago API to create PIX payment
  return { provider:"mercadopago", id:null, status:"pending", qr_code:null, reference };
}
export async function handleWebhook(req) {
  // TODO: validate signature and update payment status
  return { ok:true };
}
