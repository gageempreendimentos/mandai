import express from "express";

export const paymentsWebhook = express.Router();

/**
 * Webhook endpoint (production-safe):
 * - If PAYMENTS_WEBHOOK_SECRET is set, requires header "x-webhook-secret" to match.
 * - If not set, webhook is disabled (501) to avoid accepting spoofed callbacks.
 *
 * Integrations can extend this to validate provider signatures (Mercado Pago, etc).
 */
paymentsWebhook.post("/webhook", async (req, res) => {
  const secret = process.env.PAYMENTS_WEBHOOK_SECRET;
  if (!secret) {
    return res.status(501).json({ error: "webhook_disabled" });
  }
  const got = String(req.headers["x-webhook-secret"] || "");
  if (got !== String(secret)) {
    return res.status(401).json({ error: "invalid_signature" });
  }

  // TODO: provider-specific verification + idempotency
  // For now, acknowledge only verified callbacks.
  return res.json({ ok: true });
});
