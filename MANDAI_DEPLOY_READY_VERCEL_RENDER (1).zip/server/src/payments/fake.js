export async function createPayment({ amount_cents, reference }) {
  // Instant "paid" for dev/test
  return { provider:"fake", id:`fake_${Date.now()}`, status:"paid", qr_code:null, reference };
}
export async function handleWebhook() {
  return { ok:true };
}
