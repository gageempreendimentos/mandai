import express from "express";
import fs from "fs";
import path from "path";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const templatesRouter = express.Router();
const filePath = path.join(process.cwd(), "server", "src", "templates", "defaults.json");

templatesRouter.get("/", requireAuth, async (req,res)=>{
  const raw = fs.readFileSync(filePath, "utf-8");
  res.json(JSON.parse(raw));
});

templatesRouter.post("/", requireAuth, requireRole("admin"), async (req,res)=>{
  fs.writeFileSync(filePath, JSON.stringify(req.body||{}, null, 2), "utf-8");
  res.json({ ok:true });
});
