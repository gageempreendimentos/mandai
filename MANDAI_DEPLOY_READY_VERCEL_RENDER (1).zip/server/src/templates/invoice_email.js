export function invoiceEmail({ company_name, period_start, period_end, total_cents }) {
  const total = (Number(total_cents||0)/100).toFixed(2);
  return {
    subject: `Fatura MANDAI - ${company_name} (${period_start} a ${period_end})`,
    html: `
      <h2>Fatura MANDAI</h2>
      <p><b>Empresa:</b> ${company_name}</p>
      <p><b>Período:</b> ${period_start} a ${period_end}</p>
      <p><b>Total:</b> R$ ${total}</p>
      <p>Obrigado por usar a MANDAI.</p>
    `
  };
}
