import express from "express";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const devicesRouter = express.Router();

/**
 * Register FCM token (client/driver/admin)
 * POST /devices/register { token, platform? }
 */
devicesRouter.post("/register", requireAuth, idempotency(), async (req, res) => {
  const { token, platform } = req.body || {};
  if (!token) return res.status(400).json({ error: "missing_token" });

  await q(
    `insert into device_tokens (user_id, token, platform, last_seen_at)
     values ($1,$2,$3,now())
     on conflict (user_id, token) do update set last_seen_at=now(), platform=excluded.platform`,
    [req.user.sub, String(token), platform || null]
  );

  res.json({ ok: true });
});

/**
 * Unregister
 * POST /devices/unregister { token }
 */
devicesRouter.post("/unregister", requireAuth, idempotency(), async (req, res) => {
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ error: "missing_token" });

  await q(`delete from device_tokens where user_id=$1 and token=$2`, [req.user.sub, String(token)]);
  res.json({ ok: true });
});
