import express from "express";

export const mapsRouter = express.Router();

const OSRM_URL = process.env.OSRM_URL || "https://router.project-osrm.org";

mapsRouter.get("/route", async (req,res)=>{
  const { from_lat, from_lng, to_lat, to_lng } = req.query;
  const a = [Number(from_lng), Number(from_lat)];
  const b = [Number(to_lng), Number(to_lat)];
  if (!a.every(Number.isFinite) || !b.every(Number.isFinite)) return res.status(400).json({ error:"invalid_coords" });

  const url = `${OSRM_URL}/route/v1/driving/${a[0]},${a[1]};${b[0]},${b[1]}?overview=false&alternatives=false&steps=false`;
  try {
    const r = await fetch(url);
    const j = await r.json();
    const route = j?.routes?.[0];
    const distance_m = route?.distance ?? null;
    const duration_s = route?.duration ?? null;
    if (!distance_m) return res.status(502).json({ error:"no_route" });
    res.json({ ok:true, distance_m, duration_s, distance_km: distance_m/1000, duration_min: duration_s/60 });
  } catch (e) {
    res.status(502).json({ error:"route_provider_failed" });
  }
});
