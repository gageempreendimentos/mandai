import { q } from "../db.js";

export async function computeHotZones() {
  const r = await q(
    `select zone_id, count(*)::int as n
     from rides
     where created_at > now() - interval '30 minutes'
       and status in ('created','preparing','assigned')
     group by zone_id
     order by n desc
     limit 20`
  ).catch(()=>({rows:[]}));

  return r.rows.map(x=>({ zone_id: x.zone_id, orders: x.n }));
}
