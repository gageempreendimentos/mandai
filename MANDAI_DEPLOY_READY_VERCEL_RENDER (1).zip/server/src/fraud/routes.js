import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";
import { audit } from "../middlewares/audit.js";

export const fraudRouter = express.Router();

fraudRouter.get("/", requireAuth, requireRole("admin"), requirePermission("admin.view_audit"), async (req, res) => {
  const resolved = req.query.resolved;
  const limit = Math.min(200, Number(req.query.limit || 100));
  const where = resolved == null ? "" : "where resolved = " + (String(resolved) === "true" ? "true" : "false");
  const r = await q(
    `select id, ride_id, driver_id, kind, severity, details, created_at, resolved, resolved_at
     from fraud_flags
     ${where}
     order by created_at desc
     limit $1`,
    [limit]
  );
  res.json({ flags: r.rows });
});

fraudRouter.post(
  "/:id/resolve",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.view_audit"),
  idempotency(),
  audit("fraud.resolve", "fraud_flags", (req)=>req.params.id, (req)=>({})),
  async (req, res) => {
    const id = Number(req.params.id);
    await q(`update fraud_flags set resolved=true, resolved_at=now() where id=$1`, [id]);
    res.json({ ok: true });
  }
);
