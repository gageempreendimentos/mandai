import { q } from "../db.js";
import { haversineMeters } from "../lib/geo.js";

export async function fraudScan() {
  // GPS teleport / speed anomaly
  const res = await q(
    `select ride_id, driver_id, lat, lng, created_at
     from ride_location_points
     where created_at > now() - interval '6 hours'
     order by ride_id, driver_id, created_at asc
     limit 10000`
  );

  const last = new Map();
  for (const p of res.rows) {
    const key = `${p.ride_id}:${p.driver_id}`;
    const prev = last.get(key);
    if (prev) {
      const dt = (new Date(p.created_at).getTime() - new Date(prev.created_at).getTime()) / 1000;
      if (dt > 0) {
        const dist = haversineMeters(prev.lat, prev.lng, p.lat, p.lng); // meters
        const speed = dist / dt; // m/s
        // flag if > 45 m/s (~162 km/h) for bike/car delivery or teleport > 5km in < 2min
        if (speed > 45 || (dist > 5000 && dt < 120)) {
          await q(
            `insert into fraud_flags (ride_id, driver_id, kind, severity, details)
             values ($1,$2,$3,$4,$5)
             on conflict do nothing`,
            [p.ride_id, p.driver_id, speed > 45 ? "speed_anomaly" : "gps_teleport", speed > 45 ? 3 : 4, { dist_m: dist, dt_s: dt, speed_mps: speed }]
          ).catch(()=>{});
        }
      }
    }
    last.set(key, p);
  }

  // POD outside geofence (if ride has dropoff coords)
  const pod = await q(
    `select r.id as ride_id, r.driver_id, r.pod_created_at, r.dropoff_lat, r.dropoff_lng, p.lat as last_lat, p.lng as last_lng
     from rides r
     left join lateral (
       select lat, lng
       from ride_location_points
       where ride_id=r.id and driver_id=r.driver_id
       order by created_at desc
       limit 1
     ) p on true
     where r.pod_created_at is not null
       and r.dropoff_lat is not null and r.dropoff_lng is not null
       and r.pod_created_at > now() - interval '6 hours'
     limit 500`
  );

  const allowed = Number(process.env.GEOFENCE_DROPOFF_METERS || 250);
  for (const row of pod.rows) {
    if (row.last_lat == null || row.last_lng == null) continue;
    const d = haversineMeters(Number(row.last_lat), Number(row.last_lng), Number(row.dropoff_lat), Number(row.dropoff_lng));
    if (d > allowed * 2) {
      await q(
        `insert into fraud_flags (ride_id, driver_id, kind, severity, details)
         values ($1,$2,'pod_outside_geofence',4,$3)`,
        [row.ride_id, row.driver_id, { distance_m: d, allowed_m: allowed }]
      ).catch(()=>{});
    }
  }
}
