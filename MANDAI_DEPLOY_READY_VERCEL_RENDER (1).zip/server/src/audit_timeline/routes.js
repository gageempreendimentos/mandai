import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const auditTimelineRouter = express.Router();

auditTimelineRouter.get("/rides/:id", requireAuth, requireRole("admin"), async (req,res)=>{
  const id = req.params.id;
  const ev = await q(
    `select type, payload, created_at, actor_user_id
     from ride_events where ride_id=$1
     order by created_at asc`,
    [id]
  ).catch(()=>({rows:[]}));

  // include important timestamps from rides
  const ride = await q(`select id, status, created_at, assigned_at, accepted_at, enroute_at, completed_at, canceled_at, scheduled_for, schedule_status from rides where id=$1`, [id]).catch(()=>({rows:[]}));

  res.json({ ride: ride.rows[0] || null, timeline: ev.rows });
});
