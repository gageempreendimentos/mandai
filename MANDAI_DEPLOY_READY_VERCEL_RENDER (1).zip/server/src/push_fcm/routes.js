import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";
import { sendFCM, isFCMConfigured } from "./fcm.js";

export const fcmRouter = express.Router();

// Driver registers token
fcmRouter.post("/register", requireAuth, requireRole("driver"), idempotency(), async (req,res)=>{
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ error:"missing_token" });
  const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  if (!d.rows[0]) return res.status(400).json({ error:"no_driver" });
  await q(
    `insert into driver_push_tokens (driver_id, token)
     values ($1,$2)
     on conflict (driver_id, token) do nothing`,
    [d.rows[0].id, String(token)]
  ).catch(()=>{});
  res.json({ ok:true, configured: isFCMConfigured() });
});

// Admin: send test push to one driver
fcmRouter.post("/admin/send", requireAuth, requireRole("admin"), idempotency(), async (req,res)=>{
  const { driver_id, title="MANDAI", body="Mensagem", data={} } = req.body || {};
  const t = await q(`select token from driver_push_tokens where driver_id=$1 order by created_at desc limit 1`, [driver_id]).catch(()=>({rows:[]}));
  if (!t.rows[0]) return res.status(404).json({ error:"no_token" });
  const out = await sendFCM({ token: t.rows[0].token, title, body, data });
  res.json({ ok:true, out });
});
