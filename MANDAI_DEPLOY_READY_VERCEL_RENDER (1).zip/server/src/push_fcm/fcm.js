import crypto from "crypto";

export function isFCMConfigured() {
  return !!process.env.FCM_SERVER_KEY || !!process.env.FCM_SERVICE_ACCOUNT_JSON;
}

// Minimal legacy server key sender (easiest)
export async function sendFCM({ token, title, body, data={} }) {
  const key = process.env.FCM_SERVER_KEY;
  if (!key) throw new Error("FCM_SERVER_KEY missing");
  const r = await fetch("https://fcm.mandaigleapis.com/fcm/send", {
    method:"POST",
    headers:{
      "content-type":"application/json",
      "authorization": `key=${key}`
    },
    body: JSON.stringify({
      to: token,
      notification: { title, body },
      data
    })
  });
  const j = await r.json().catch(()=>null);
  return { ok: r.ok, response: j };
}
