import { q } from "../db.js";
import { expireFreightBids } from "../freight/expire.js";
import { sendBroadcastToDrivers } from "../push2/broadcast.js";

export async function jobExpireBids() {
  await expireFreightBids();
}

export async function jobGenerateInvoices({ period_start, period_end } = {}) {
  if (!period_start || !period_end) return;
  // issue invoices for all companies (simple)
  const companies = await q(`select id from companies order by id asc`).catch(()=>({rows:[]}));
  for (const c of companies.rows) {
    const sum = await q(
      `select coalesce(sum(fare_cents),0)::int as total
       from rides where company_id=$1 and created_at::date between $2::date and $3::date`,
      [c.id, period_start, period_end]
    ).catch(()=>({rows:[{total:0}]}));
    const total = Number(sum.rows[0]?.total||0);
    await q(
      `insert into company_invoices (company_id, period_start, period_end, total_cents, status)
       values ($1,$2::date,$3::date,$4,'issued')
       on conflict (company_id, period_start, period_end)
       do update set total_cents=excluded.total_cents, status='issued'`,
      [c.id, period_start, period_end, total]
    ).catch(()=>{});
  }
}

export async function jobDeadmanRedispatch() {
  // mark rides stale and ready to reassign (MVP)
  await q(
    `update rides set status='reassign_needed'
     where status in ('assigned','accepted') and updated_at < now() - interval '8 minutes'`
  ).catch(()=>{});
}

export async function jobPushBroadcast({ title, body, data } = {}) {
  await sendBroadcastToDrivers({ title, body, data });
}
