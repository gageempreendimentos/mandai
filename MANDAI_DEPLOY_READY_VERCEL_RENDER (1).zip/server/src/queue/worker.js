import { getBull } from "./index.js";
import { jobExpireBids, jobGenerateInvoices, jobDeadmanRedispatch, jobPushBroadcast } from "./jobs.js";

export async function startWorker() {
  const bull = await getBull();
  if (!bull) return { enabled:false };

  const connection = bull.redis();
  const Worker = bull.Worker;

  new Worker("mandai-jobs", async (job) => {
    switch (job.name) {
      case "expire_bids": return jobExpireBids();
      case "generate_invoices": return jobGenerateInvoices(job.data||{});
      case "deadman_redispatch": return jobDeadmanRedispatch();
      case "push_broadcast": return jobPushBroadcast(job.data||{});
      default: return null;
    }
  }, { connection });

  return { enabled:true };
}
