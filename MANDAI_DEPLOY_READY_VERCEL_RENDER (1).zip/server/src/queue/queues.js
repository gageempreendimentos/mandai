import { Queue } from "bullmq";
import { getRedis } from "./redis.js";

const connection = getRedis();
export const jobsQueue = new Queue("mandai:jobs", { connection });

export async function ensureRepeatableJobs() {
  await jobsQueue.add("sla_scan", {}, { repeat: { every: 60_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("accept_timeout_scan", {}, { repeat: { every: 10_000 }, removeOnComplete: true, removeOnFail: 100 });

  const dispatchEvery = Number(process.env.DISPATCH_SCAN_SECONDS || 5) * 1000;
  await jobsQueue.add("dispatch_scan", {}, { repeat: { every: dispatchEvery }, removeOnComplete: true, removeOnFail: 100 });

  const etaEvery = Number(process.env.ETA_SCAN_SECONDS || 60) * 1000;
  await jobsQueue.add("eta_scan", {}, { repeat: { every: etaEvery }, removeOnComplete: true, removeOnFail: 100 });

  await jobsQueue.add("fraud_scan", {}, { repeat: { every: 300_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("forecast_compute", {}, { repeat: { every: 900_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("restaurant_quality_scan", {}, { repeat: { every: 900_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("schedule_release_scan", {}, { repeat: { every: 30_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("hotzones_broadcast", {}, { repeat: { every: 15_000 }, removeOnComplete: true, removeOnFail: 100 });

  await jobsQueue.add("driver_metrics_scan", {}, { repeat: { every: 300_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("driver_finance_scan", {}, { repeat: { every: 600_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("campaign_progress_scan", {}, { repeat: { every: 300_000 }, removeOnComplete: true, removeOnFail: 100 });
  await jobsQueue.add("sla_auto_scan", {}, { repeat: { every: 600_000 }, removeOnComplete: true, removeOnFail: 100 });

  const deadmanEvery = Math.max(10_000, Number(process.env.DEADMAN_SECONDS || 120) * 1000 / 6);
  await jobsQueue.add("deadman_scan", {}, { repeat: { every: deadmanEvery }, removeOnComplete: true, removeOnFail: 100 });
}