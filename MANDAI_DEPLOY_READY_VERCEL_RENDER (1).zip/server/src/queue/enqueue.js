import { getBull } from "./index.js";

export async function enqueue(name, data={}, opts={}) {
  const bull = await getBull();
  if (!bull) return { ok:false, error:"bullmq_not_installed" };
  const connection = bull.redis();
  const Queue = bull.Queue;
  const q = new Queue("mandai-jobs", { connection });
  await q.add(name, data, { removeOnComplete:true, removeOnFail: 1000, ...opts });
  return { ok:true };
}
