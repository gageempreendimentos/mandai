let bullmq = null;

export async function getBull() {
  if (bullmq) return bullmq;
  try {
    // optional dependency
    // eslint-disable-next-line global-require
    const { Queue, Worker } = require("bullmq");
    // eslint-disable-next-line global-require
    const { redis } = require("./redis.js");
    bullmq = { Queue, Worker, redis };
    return bullmq;
  } catch {
    return null;
  }
}
