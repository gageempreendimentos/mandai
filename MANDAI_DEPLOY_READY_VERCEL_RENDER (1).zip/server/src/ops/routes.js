import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";

export const opsRouter = express.Router();

// Get current ops settings
opsRouter.get("/", requireAuth, requireRole("admin"), requirePermission("ops.manage"), async (req,res)=>{
  const r = await q(`select key, value, updated_at from ops_settings`, []).catch(()=>({rows:[]}));
  res.json({ settings: r.rows });
});

// Upsert a key
opsRouter.post("/:key", requireAuth, requireRole("admin"), requirePermission("ops.manage"), idempotency(), async (req,res)=>{
  const key = req.params.key;
  const value = req.body || {};
  await q(
    `insert into ops_settings (key, value, updated_at) values ($1,$2::jsonb, now())
     on conflict (key) do update set value=excluded.value, updated_at=now()`,
    [key, JSON.stringify(value)]
  );
  res.json({ ok:true });
});
