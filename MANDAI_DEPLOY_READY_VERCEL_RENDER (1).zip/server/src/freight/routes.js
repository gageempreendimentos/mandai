import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole, requireRoleOrAdmin } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";
import { freightQuote } from "./pricing.js";

export const freightRouter = express.Router();

function nowPlusMinutes(m) {
  return new Date(Date.now() + m*60*1000).toISOString();
}

/**
 * 1) Create freight ride (client) with extras + windows + multi-stops
 * Option C: store auto quote and allow bids.
 */
freightRouter.post("/create", requireAuth, requireRole("client"), idempotency(), async (req,res)=>{
  const b = req.body || {};
  const {
    pickup, dropoff, stops=[],
    distance_km, duration_min,
    cargo_type, weight_kg, helpers_needed, stairs, notes,
    scheduled_for, pickup_window_start, pickup_window_end,
    vehicle_type_hint,
    wait_minutes, insurance, declared_value_cents, priority, fragile
  } = b;

  const vehicle_type = String(vehicle_type_hint || "carro");
  const quote = await freightQuote({
    pickup,
    km: Number(distance_km||0),
    vehicle_type,
    weight_kg: Number(weight_kg||0),
    helpers_needed: Number(helpers_needed||0),
    stairs: !!stairs,
    wait_minutes: Number(wait_minutes||0),
    insurance: !!insurance,
    declared_value_cents: Number(declared_value_cents||0),
    priority: !!priority,
    fragile: !!fragile,
    stops_count: Array.isArray(stops) ? stops.length : 0
  });

  const ride = await q(
    `insert into rides (kind, status, client_id, pickup, dropoff, distance_km, duration_min, fare_cents, scheduled_for, schedule_status,
                       pickup_window_start, pickup_window_end)
     values ('freight','created',$1,$2::jsonb,$3::jsonb,$4,$5,$6,$7, case when $7 is null then 'none' else 'scheduled' end, $8, $9)
     returning id, fare_cents`,
    [
      req.user.sub,
      JSON.stringify(pickup||{}),
      JSON.stringify(dropoff||{}),
      Number(distance_km||0),
      Number(duration_min||0),
      Number(quote.total_cents||0),
      scheduled_for||null,
      pickup_window_start||null,
      pickup_window_end||null
    ]
  );

  await q(
    `insert into freight_details (ride_id, cargo_type, weight_kg, helpers_needed, stairs, notes, wait_minutes, insurance, declared_value_cents, priority, fragile)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     on conflict (ride_id) do update set cargo_type=excluded.cargo_type, weight_kg=excluded.weight_kg, helpers_needed=excluded.helpers_needed,
       stairs=excluded.stairs, notes=excluded.notes, wait_minutes=excluded.wait_minutes, insurance=excluded.insurance,
       declared_value_cents=excluded.declared_value_cents, priority=excluded.priority, fragile=excluded.fragile`,
    [
      ride.rows[0].id,
      cargo_type||null,
      Number(weight_kg||0),
      Number(helpers_needed||0),
      !!stairs,
      notes||null,
      Number(wait_minutes||0),
      !!insurance,
      Number(declared_value_cents||0),
      !!priority,
      !!fragile
    ]
  ).catch(()=>{});

  // multi-stops
  if (Array.isArray(stops) && stops.length) {
    for (let i=0;i<stops.length;i++) {
      const s = stops[i] || {};
      await q(
        `insert into freight_stops (ride_id, stop_order, address, lat, lng, notes)
         values ($1,$2,$3,$4,$5,$6)
         on conflict (ride_id, stop_order) do update set address=excluded.address, lat=excluded.lat, lng=excluded.lng, notes=excluded.notes`,
        [ride.rows[0].id, i+1, s.address||null, s.lat||null, s.lng||null, s.notes||null]
      ).catch(()=>{});
    }
  }

  await q(
    `insert into ride_events (ride_id, type, payload)
     values ($1,'freight_created', jsonb_build_object('quote',$2::jsonb,'vehicle_type',$3,'recommended',$4::jsonb))`,
    [ride.rows[0].id, JSON.stringify(quote), vehicle_type, JSON.stringify(quote.recommended||{})]
  ).catch(()=>{});

  res.json({ ok:true, ride_id: ride.rows[0].id, quote });
});

// Client: my freights list
freightRouter.get("/my", requireAuth, requireRole("client"), async (req,res)=>{
  const r = await q(
    `select id, status, pickup, dropoff, fare_cents, distance_km, duration_min, created_at, updated_at
     from rides
     where kind='freight' and client_id=$1
     order by created_at desc
     limit 100`,
    [req.user.sub]
  ).catch(()=>({rows:[]}));
  // distance sort (best-effort)
const loc = await q(
  `select lat, lng from driver_last_location dl
   join drivers d on d.id=dl.driver_id
   where d.user_id=$1`,
  [req.user.sub]
).catch(()=>({rows:[]}));
const dlat = Number(loc.rows[0]?.lat);
const dlng = Number(loc.rows[0]?.lng);

function hav(lat1,lng1,lat2,lng2){
  const R=6371;
  const toRad=(x)=>x*Math.PI/180;
  const dLat=toRad(lat2-lat1), dLng=toRad(lng2-lng1);
  const a=Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLng/2)**2;
  return 2*R*Math.asin(Math.sqrt(a));
}

let rides = r.rows;
if (Number.isFinite(dlat) && Number.isFinite(dlng)) {
  rides = rides
    .map(x=>{
      const plat=Number(x.pickup?.lat), plng=Number(x.pickup?.lng);
      const dist = (Number.isFinite(plat)&&Number.isFinite(plng)) ? hav(dlat,dlng,plat,plng) : 1e9;
      return { ...x, _dist_km: dist };
    })
    .sort((a,b)=> (a._dist_km||1e9)-(b._dist_km||1e9));
}

res.json({ rides });
return;

});

// Freight details (client owner / assigned driver / admin)
freightRouter.get("/:rideId/details", requireAuth, async (req,res)=>{
  const rideId = req.params.rideId;
  const ride = await q(`select * from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  const row = ride.rows[0];
  if (!row) return res.status(404).json({ error:"not_found" });
  const role = req.user.role;
  if (role==="client" && row.client_id!==req.user.sub) return res.status(403).json({ error:"forbidden" });
  if (role==="driver") {
    const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
    if (!d.rows[0] || row.driver_id!==d.rows[0].id) return res.status(403).json({ error:"forbidden" });
  }
  const fd = await q(`select * from freight_details where ride_id=$1`, [rideId]).catch(()=>({rows:[]}));
  const stops = await q(`select stop_order, address, lat, lng, notes from freight_stops where ride_id=$1 order by stop_order asc`, [rideId]).catch(()=>({rows:[]}));
  res.json({ ride: row, freight: fd.rows[0]||null, stops: stops.rows||[] });
});

// Driver: list available freight rides (filters by vehicle compatibility)
freightRouter.get("/available", requireAuth, requireRole("driver"), async (req,res)=>{
  const d = await q(`select vehicle_type, capacity_kg, cooldown_until from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  const vt = d.rows[0]?.vehicle_type || "moto";

  if (vt === "moto") return res.json({ rides: [] });

  const r = await q(
    `select r.id, r.pickup, r.dropoff, r.fare_cents, r.distance_km, r.duration_min, r.created_at,
            fd.weight_kg, fd.helpers_needed, fd.stairs, fd.priority, fd.fragile
     from rides r
     left join freight_details fd on fd.ride_id=r.id
     where r.kind='freight' and r.status='created'
     order by r.created_at desc
     limit 50`
  ).catch(()=>({rows:[]}));

  // distance sort (best-effort)
const loc = await q(
  `select lat, lng from driver_last_location dl
   join drivers d on d.id=dl.driver_id
   where d.user_id=$1`,
  [req.user.sub]
).catch(()=>({rows:[]}));
const dlat = Number(loc.rows[0]?.lat);
const dlng = Number(loc.rows[0]?.lng);

function hav(lat1,lng1,lat2,lng2){
  const R=6371;
  const toRad=(x)=>x*Math.PI/180;
  const dLat=toRad(lat2-lat1), dLng=toRad(lng2-lng1);
  const a=Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLng/2)**2;
  return 2*R*Math.asin(Math.sqrt(a));
}

let rides = r.rows;
if (Number.isFinite(dlat) && Number.isFinite(dlng)) {
  rides = rides
    .map(x=>{
      const plat=Number(x.pickup?.lat), plng=Number(x.pickup?.lng);
      const dist = (Number.isFinite(plat)&&Number.isFinite(plng)) ? hav(dlat,dlng,plat,plng) : 1e9;
      return { ...x, _dist_km: dist };
    })
    .sort((a,b)=> (a._dist_km||1e9)-(b._dist_km||1e9));
}

res.json({ rides });
return;

});

// Driver: place/replace bid (with min/max guard) + expiry
freightRouter.post("/:rideId/bid", requireAuth, requireRole("driver"), idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
  const cents = Number(req.body?.bid_cents||0);
  if (cents <= 0) return res.status(400).json({ error:"invalid_bid" });

  const d = await q(`select id, vehicle_type from drivers where user_id=$1`, [req.user.sub]);
  if (!d.rows[0]) return res.status(400).json({ error:"no_driver" });
  if (d.rows[0].vehicle_type === "moto") return res.status(403).json({ error:"not_allowed" });

  const ride = await q(`select pickup, distance_km from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  const km = Number(ride.rows[0]?.distance_km||0);
  const quote = await freightQuote({ pickup: ride.rows[0]?.pickup, km, vehicle_type: d.rows[0].vehicle_type });
  const minBid = Number(quote.recommended?.min_bid_cents||0);
  const maxBid = Number(quote.recommended?.max_bid_cents||0);

  if (minBid && cents < minBid) return res.status(400).json({ error:"bid_too_low", min_bid_cents: minBid });
  if (maxBid && cents > maxBid) return res.status(400).json({ error:"bid_too_high", max_bid_cents: maxBid });

  const expiresAt = nowPlusMinutes(5); // auction time 5 min

  await q(
    `insert into freight_bids (ride_id, driver_id, bid_cents, status, expires_at)
     values ($1,$2,$3,'pending',$4)
     on conflict (ride_id, driver_id) do update set bid_cents=excluded.bid_cents, status='pending', created_at=now(), expires_at=excluded.expires_at`,
    [rideId, d.rows[0].id, cents, expiresAt]
  );
  await q(`insert into ride_events (ride_id, type, payload) values ($1,'freight_bid', jsonb_build_object('driver_id',$2,'bid_cents',$3,'expires_at',$4))`, [rideId, d.rows[0].id, cents, expiresAt]).catch(()=>{});
  res.json({ ok:true, expires_at: expiresAt, recommended: quote.recommended });
});

// Client: list bids (filters expired)
freightRouter.get("/:rideId/bids", requireAuth, requireRole("client"), async (req,res)=>{
  const rideId = req.params.rideId;
  const r = await q(
    `select b.id, b.driver_id, b.bid_cents, b.status, b.created_at, b.expires_at
     from freight_bids b
     join rides r on r.id=b.ride_id
     where b.ride_id=$1 and r.client_id=$2
       and (b.expires_at is null or b.expires_at > now())
     order by b.created_at desc`,
    [rideId, req.user.sub]
  ).catch(()=>({rows:[]}));
  res.json({ bids: r.rows });
});

// Client: accept a bid (Option C) + set cancel fee (if cancel after assigned/enroute)
freightRouter.post("/:rideId/accept-bid/:bidId", requireAuth, requireRole("client"), idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
  const bidId = Number(req.params.bidId);

  const ride = await q(`select id, client_id, status, distance_km from rides where id=$1`, [rideId]);
  if (!ride.rows[0] || ride.rows[0].client_id !== req.user.sub) return res.status(404).json({ error:"not_found" });
  if (ride.rows[0].status !== "created") return res.status(400).json({ error:"invalid_status" });

  const bid = await q(`select id, driver_id, bid_cents from freight_bids where id=$1 and ride_id=$2 and (expires_at is null or expires_at>now())`, [bidId, rideId]);
  if (!bid.rows[0]) return res.status(404).json({ error:"bid_not_found_or_expired" });

  await q(`update freight_bids set status='rejected' where ride_id=$1 and status='pending'`, [rideId]).catch(()=>{});
  await q(`update freight_bids set status='accepted' where id=$1`, [bidId]).catch(()=>{});

  // cancellation fee: 10% of fare, min R$5
  const fee = Math.max(500, Math.round(Number(bid.rows[0].bid_cents||0) * 0.1));

  await q(`update rides set driver_id=$2, fare_cents=$3, cancel_fee_cents=$4, status='assigned', assigned_at=now(), updated_at=now() where id=$1`,
          [rideId, bid.rows[0].driver_id, bid.rows[0].bid_cents, fee]);
  await q(`insert into ride_events (ride_id, type, payload) values ($1,'freight_bid_accepted', jsonb_build_object('bid_id',$2,'driver_id',$3,'fare_cents',$4,'cancel_fee_cents',$5))`,
          [rideId, bidId, bid.rows[0].driver_id, bid.rows[0].bid_cents, fee]).catch(()=>{});

  res.json({ ok:true, cancel_fee_cents: fee });
});

// Cancel ride (client) with fee rules (12)
freightRouter.post("/:rideId/cancel", requireAuth, requireRole("client"), idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
// Anti-abuse: limit cancellations per 24h (client)
if (req.user.role === "client") {
  const c = await q(
    `select count(*)::int as n from ride_events 
     where type='freight_cancelled' and payload->>'by'='client' 
       and created_at > now() - interval '24 hours'
       and ride_id in (select id from rides where client_id=$1)`,
    [req.user.sub]
  ).catch(()=>({rows:[{n:0}]}));
  if (Number(c.rows[0]?.n||0) >= 5) return res.status(429).json({ error:"cancel_limit_reached" });
}

  const reason = String(req.body?.reason||"client_cancel");
  const r = await q(`select id, client_id, status, cancel_fee_cents from rides where id=$1`, [rideId]);
  if (!r.rows[0] || r.rows[0].client_id !== req.user.sub) return res.status(404).json({ error:"not_found" });

  // fee applies if already assigned or beyond
  const st = r.rows[0].status;
  const fee = (st==="assigned"||st==="accepted"||st==="enroute") ? Number(r.rows[0].cancel_fee_cents||0) : 0;

  await q(`update rides set status='canceled', cancel_reason=$2, updated_at=now() where id=$1`, [rideId, reason]).catch(()=>{});
  await q(`insert into ride_events (ride_id, type, payload) values ($1,'freight_canceled', jsonb_build_object('reason',$2,'fee_cents',$3))`, [rideId, reason, fee]).catch(()=>{});
  res.json({ ok:true, fee_cents: fee });
});

/* 2) Freight chat (text + image_url) */
freightRouter.get("/:rideId/chat", requireAuth, async (req,res)=>{
  const rideId = req.params.rideId;
  // Access check: client owner, driver assigned, admin
  const ride = await q(`select client_id, driver_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  const row = ride.rows[0];
  if (!row) return res.status(404).json({ error:"not_found" });
  const role = req.user.role;
  if (role==="client" && row.client_id!==req.user.sub) return res.status(403).json({ error:"forbidden" });
  if (role==="driver") {
    // driver_id is in drivers table, check user_id match
    const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
    if (!d.rows[0] || row.driver_id!==d.rows[0].id) return res.status(403).json({ error:"forbidden" });
  }
  const msgs = await q(`select id, sender_role, message, image_url, created_at from freight_chat_messages where ride_id=$1 order by created_at asc limit 200`, [rideId]).catch(()=>({rows:[]}));
  res.json({ messages: msgs.rows });
});

freightRouter.post("/:rideId/chat", requireAuth, idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
  const message = req.body?.message ? String(req.body.message) : null;
  const image_url = req.body?.image_url ? String(req.body.image_url) : null;
  if (!message && !image_url) return res.status(400).json({ error:"empty" });

  const ride = await q(`select client_id, driver_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  const row = ride.rows[0];
  if (!row) return res.status(404).json({ error:"not_found" });

  const role = req.user.role;
  if (role==="client" && row.client_id!==req.user.sub) return res.status(403).json({ error:"forbidden" });
  if (role==="driver") {
    const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
    if (!d.rows[0] || row.driver_id!==d.rows[0].id) return res.status(403).json({ error:"forbidden" });
  }

  await q(
    `insert into freight_chat_messages (ride_id, sender_user_id, sender_role, message, image_url)
     values ($1,$2,$3,$4,$5)`,
    [rideId, req.user.sub, role, message, image_url]
  ).catch(()=>{});
  res.json({ ok:true });
});

/* 7) POD */
freightRouter.post("/:rideId/pod", requireAuth, requireRole("driver"), idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
  const { receiver_name, signature_svg, photo_url, notes } = req.body || {};
  // verify driver owns ride
  const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  const ride = await q(`select driver_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  if (!d.rows[0] || !ride.rows[0] || ride.rows[0].driver_id!==d.rows[0].id) return res.status(403).json({ error:"forbidden" });

  await q(
    `insert into freight_pod (ride_id, delivered_at, receiver_name, signature_svg, photo_url, notes)
     values ($1, now(), $2, $3, $4, $5)
     on conflict (ride_id) do update set delivered_at=excluded.delivered_at, receiver_name=excluded.receiver_name, signature_svg=excluded.signature_svg, photo_url=excluded.photo_url, notes=excluded.notes`,
    [rideId, receiver_name||null, signature_svg||null, photo_url||null, notes||null]
  ).catch(()=>{});
  await q(`insert into ride_events (ride_id, type, payload) values ($1,'freight_pod', jsonb_build_object('receiver_name',$2,'photo_url',$3))`, [rideId, receiver_name||null, photo_url||null]).catch(()=>{});
  res.json({ ok:true });
});

/* 4) Pickup Checklist */
freightRouter.post("/:rideId/checklist", requireAuth, requireRole("driver"), idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
  const { confirmed_items=false, confirmed_weight=false, photo_url=null, notes=null } = req.body || {};
  const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
  const ride = await q(`select driver_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  if (!d.rows[0] || !ride.rows[0] || ride.rows[0].driver_id!==d.rows[0].id) return res.status(403).json({ error:"forbidden" });

  await q(
    `insert into freight_pickup_checklist (ride_id, confirmed_items, confirmed_weight, photo_url, notes)
     values ($1,$2,$3,$4,$5)
     on conflict (ride_id) do update set confirmed_items=excluded.confirmed_items, confirmed_weight=excluded.confirmed_weight, photo_url=excluded.photo_url, notes=excluded.notes`,
    [rideId, !!confirmed_items, !!confirmed_weight, photo_url, notes]
  ).catch(()=>{});
  await q(`insert into ride_events (ride_id, type, payload) values ($1,'freight_pickup_checklist', jsonb_build_object('photo_url',$2))`, [rideId, photo_url]).catch(()=>{});
  res.json({ ok:true });
});

freightRouter.get("/:rideId/checklist", requireAuth, async (req,res)=>{
  const rideId = req.params.rideId;
  const ride = await q(`select client_id, driver_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  const row = ride.rows[0];
  if (!row) return res.status(404).json({ error:"not_found" });
  const role=req.user.role;
  if (role==="client" && row.client_id!==req.user.sub) return res.status(403).json({ error:"forbidden" });
  if (role==="driver") {
    const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
    if (!d.rows[0] || row.driver_id!==d.rows[0].id) return res.status(403).json({ error:"forbidden" });
  }
  const c = await q(`select * from freight_pickup_checklist where ride_id=$1`, [rideId]).catch(()=>({rows:[]}));
  res.json({ checklist: c.rows[0]||null });
});

freightRouter.get("/:rideId/pod", requireAuth, async (req,res)=>{
  const rideId = req.params.rideId;
  const pod = await q(`select * from freight_pod where ride_id=$1`, [rideId]).catch(()=>({rows:[]}));
  res.json({ pod: pod.rows[0] || null });
});

/* 8) Disputes */
freightRouter.post("/:rideId/disputes", requireAuth, idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
  const reason = String(req.body?.reason||"other");
  const details = req.body?.details ? String(req.body.details) : null;

  const ride = await q(`select client_id, driver_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  const row = ride.rows[0];
  if (!row) return res.status(404).json({ error:"not_found" });

  const role = req.user.role;
  if (role==="client" && row.client_id!==req.user.sub) return res.status(403).json({ error:"forbidden" });
  if (role==="driver") {
    const d = await q(`select id from drivers where user_id=$1`, [req.user.sub]).catch(()=>({rows:[]}));
    if (!d.rows[0] || row.driver_id!==d.rows[0].id) return res.status(403).json({ error:"forbidden" });
  }

  const r = await q(
    `insert into freight_disputes (ride_id, opened_by_user_id, reason, details)
     values ($1,$2,$3,$4)
     returning id`,
    [rideId, req.user.sub, reason, details]
  ).catch(()=>({rows:[]}));
  await q(`insert into ride_events (ride_id, type, payload) values ($1,'freight_dispute_opened', jsonb_build_object('reason',$2,'dispute_id',$3))`, [rideId, reason, r.rows[0]?.id||null]).catch(()=>{});
  res.json({ ok:true, id: r.rows[0]?.id });
});

freightRouter.get("/:rideId/disputes", requireAuth, async (req,res)=>{
  const rideId = req.params.rideId;
  const r = await q(`select id, reason, details, status, resolution, created_at from freight_disputes where ride_id=$1 order by created_at desc`, [rideId]).catch(()=>({rows:[]}));
  res.json({ disputes: r.rows });
});

freightRouter.post("/admin/disputes/:id/resolve", requireAuth, requireRole("admin"), idempotency(), async (req,res)=>{
  const id = Number(req.params.id);
  const resolution = String(req.body?.resolution||"resolved");
  await q(`update freight_disputes set status='resolved', resolution=$2 where id=$1`, [id, resolution]).catch(()=>{});
  res.json({ ok:true });
});
