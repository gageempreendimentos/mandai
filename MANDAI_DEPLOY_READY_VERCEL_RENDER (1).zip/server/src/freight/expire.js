import { q } from "../db.js";

export async function expireFreightBids() {
  // Expire bids older than expires_at
  await q(`update freight_bids set status='expired' where status='active' and expires_at < now()`).catch(()=>{});
}
