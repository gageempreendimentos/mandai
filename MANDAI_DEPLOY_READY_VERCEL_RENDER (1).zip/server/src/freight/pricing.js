import { q } from "../db.js";

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

// Determine zone_id (best-effort): uses ride pickup lat/lng and zone_policies table if available.
// If no zones, returns null.
async function inferZoneId(pickup) {
  try {
    const lat = Number(pickup?.lat);
    const lng = Number(pickup?.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    // If you have a zones table/polygons you can do point-in-polygon. MVP: no-op.
    return null;
  } catch { return null; }
}

export async function getFreightRule({ zone_id=null, vehicle_type="carro" }) {
  try {
    const r = await q(
      `select min_cents_per_km, max_cents_per_km, min_fare_cents
       from freight_vehicle_rules
       where (zone_id is null or zone_id=$1) and vehicle_type=$2
       order by zone_id nulls last, created_at desc
       limit 1`,
      [zone_id, vehicle_type]
    );
    if (r.rows[0]) return r.rows[0];
  } catch {}
  return { min_cents_per_km: 200, max_cents_per_km: 1200, min_fare_cents: 1500 };
}

export async function freightQuote({
  pickup=null,
  km=0,
  vehicle_type="carro",
  weight_kg=0,
  helpers_needed=0,
  stairs=false,
  wait_minutes=0,
  insurance=false,
  declared_value_cents=0,
  priority=false,
  fragile=false,
  stops_count=0
}) {
  const base = { carro: 1200, van: 2500, caminhao: 4500 }[vehicle_type] ?? 1200; // cents
  const perKm = { carro: 260, van: 420, caminhao: 650 }[vehicle_type] ?? 260;

  const weight = Math.max(0, weight_kg || 0);
  const weightFee = weight > 100 ? Math.round((weight-100) * 5) : 0; // +5 cents/kg over 100kg
  const helpersFee = (helpers_needed||0) * 1500;
  const stairsFee = stairs ? 800 : 0;

  const waitFee = Math.max(0, Math.round((wait_minutes||0) * 60)); // R$0,60/min
  const priorityFee = priority ? 900 : 0;
  const fragileFee = fragile ? 500 : 0;
  const stopsFee = Math.max(0, Math.round((stops_count||0) * 400)); // extra per stop

  const insuranceFee = insurance ? Math.max(300, Math.round((declared_value_cents||0) * 0.008)) : 0; // 0.8% min R$3
  const zone_id = await inferZoneId(pickup);
  const rule = await getFreightRule({ zone_id, vehicle_type });

  const raw = Math.round(base + km*perKm + weightFee + helpersFee + stairsFee + waitFee + insuranceFee + priorityFee + fragileFee + stopsFee);
  // enforce min fare
  const minFare = Number(rule.min_fare_cents || 0);
  const total = Math.max(minFare, raw);

  // publish recommended min/max bid (anti-golpe)
  const minBid = Math.max(minFare, Math.round((rule.min_cents_per_km||200) * km));
  const maxBid = Math.max(minBid, Math.round((rule.max_cents_per_km||1200) * km));

  return {
    total_cents: total,
    recommended: { min_bid_cents: minBid, max_bid_cents: maxBid },
    breakdown: {
      base_cents: base,
      per_km_cents: perKm,
      km,
      weight_fee_cents: weightFee,
      helpers_fee_cents: helpersFee,
      stairs_fee_cents: stairsFee,
      wait_fee_cents: waitFee,
      insurance_fee_cents: insuranceFee,
      priority_fee_cents: priorityFee,
      fragile_fee_cents: fragileFee,
      stops_fee_cents: stopsFee,
      min_fare_cents: minFare
    }
  };
}
