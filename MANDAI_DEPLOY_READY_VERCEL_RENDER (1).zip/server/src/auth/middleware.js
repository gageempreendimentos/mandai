import { verifyAccessToken } from "./jwt.js";

/**
 * Require a valid JWT access token.
 * - Accepts Authorization: Bearer <token>
 * - Accepts cookie access_token (for browser sessions)
 */
export function requireAuth(req, res, next) {
  try {
    const h = req.headers.authorization || "";
    const headerToken = h.startsWith("Bearer ") ? h.slice(7) : null;
    const cookieToken = req.cookies?.access_token;
    const token = headerToken || cookieToken;

    if (!token) return res.status(401).json({ error: "unauthorized" });

    const payload = verifyAccessToken(token);
    req.user = payload;
    return next();
  } catch {
    return res.status(401).json({ error: "unauthorized" });
  }
}

export function requireRole(role) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: "unauthorized" });
    if (req.user.role !== role) return res.status(403).json({ error: "forbidden" });
    return next();
  };
}

export function requireDeviceId(req, res, next) {
  const d = req.headers["x-device-id"];
  if (!d) return res.status(400).json({ error: "missing_device_id" });
  req.device_id = String(d);
  return next();
}
