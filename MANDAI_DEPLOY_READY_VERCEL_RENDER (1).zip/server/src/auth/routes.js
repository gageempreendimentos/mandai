import express from "express";
import { signAccessToken } from "./jwt.js";
import { requireAuth } from "./middleware.js";

const router = express.Router();

// Simple auth: issue signed JWTs for the app.
// - driver/client/restaurant: identifier (cpf/phone/email) required
// - admin: requires pin (ADMIN_PIN env) if set
router.post("/login", async (req, res) => {
  const { role, identifier, pin } = req.body || {};
  if (!role) return res.status(400).json({ error: "missing_role" });

  const allowed = ["driver","client","restaurant","admin"];
  if (!allowed.includes(role)) return res.status(400).json({ error: "invalid_role" });

  if (role === "admin") {
    const expected = process.env.ADMIN_PIN;
    if (expected && String(pin || "") !== String(expected)) {
      return res.status(401).json({ error: "invalid_pin" });
    }
  } else {
    if (!identifier) return res.status(400).json({ error: "missing_identifier" });
  }

  // Use stable subject derived from role+identifier when provided.
  const sub = role === "admin"
    ? "admin"
    : `${role}:${String(identifier).trim()}`;

  const token = signAccessToken({ sub, role });
  return res.json({ access_token: token, role, sub });
});

router.get("/me", requireAuth, (req, res) => {
  // This requiresAuth should already have set req.user
  const u = req.user || null;
  return res.json({ user: u });
});

export default router;
