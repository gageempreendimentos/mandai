import { q } from "../db.js";
import { haversineMeters } from "../lib/geo.js";

// Shadow dispatcher: doesn't change assignments; returns proposed match list
export async function simulateDispatch(limit = 25) {
  const ridesRes = await q(
    `select id, pickup_lat, pickup_lng, zone_id
     from rides
     where status in ('created','preparing')
       and driver_id is null
       and pickup_lat is not null and pickup_lng is not null
     order by created_at asc
     limit $1`,
    [limit]
  );

  const deadSec = Number(process.env.DEADMAN_SECONDS || 120);

  const driversRes = await q(
    `select u.id as driver_id, dl.lat, dl.lng, uz.zone_id
     from users u
     join driver_locations dl on dl.driver_id=u.id
     left join user_zones uz on uz.user_id=u.id
     where u.role='driver'
       and coalesce(dl.is_online,true)=true
       and now() - dl.last_ping_at < (interval '1 second' * $1)
       and u.is_disabled=false
     limit 500`,
    [deadSec]
  );

  const drivers = driversRes.rows;

  const proposals = [];
  for (const ride of ridesRes.rows) {
    let best = null;
    for (const d of drivers) {
      if (ride.zone_id && d.zone_id && String(d.zone_id) != String(ride.zone_id)) continue;
      const dist = haversineMeters(ride.pickup_lat, ride.pickup_lng, d.lat, d.lng);
      if (!best || dist < best.distance_m) best = { ride_id: ride.id, driver_id: d.driver_id, distance_m: dist, zone_ok: true };
    }
    if (best) proposals.push(best);
  }
  proposals.sort((a,b)=>a.distance_m-b.distance_m);
  return proposals.slice(0, limit);
}
