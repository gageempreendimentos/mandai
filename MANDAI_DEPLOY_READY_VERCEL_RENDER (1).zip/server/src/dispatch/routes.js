import express from "express";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";
import { simulateDispatch } from "./simulate.js";

export const dispatchRouter = express.Router();

// Admin can run a "shadow" simulation
dispatchRouter.get("/simulate", requireAuth, requireRole("admin"), requirePermission("ride.reassign"), async (req, res) => {
  const limit = Math.min(100, Number(req.query.limit || 25));
  const proposals = await simulateDispatch(limit);
  res.json({ proposals });
});

// Driver refuse exists in previous ultra; keep separate route if already exists elsewhere.
