import express from "express";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const onboardingRouter = express.Router();

onboardingRouter.get("/me", requireAuth, async (req,res)=>{
  const r = await q(`select onboarding_step, onboarding_done from users where id=$1`, [req.user.sub]);
  res.json({ onboarding_step: r.rows[0]?.onboarding_step ?? 0, onboarding_done: r.rows[0]?.onboarding_done ?? false });
});

onboardingRouter.post("/me", requireAuth, idempotency(), async (req,res)=>{
  const step = Number(req.body?.onboarding_step ?? 0);
  const done = !!req.body?.onboarding_done;
  await q(`update users set onboarding_step=$2, onboarding_done=$3 where id=$1`, [req.user.sub, step, done]);
  res.json({ ok:true });
});
