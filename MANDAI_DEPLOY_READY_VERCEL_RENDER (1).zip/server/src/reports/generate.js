import fs from "fs";
import path from "path";
import { q } from "../db.js";

export async function generateDailyReport(date = new Date()) {
  const day = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const start = new Date(day);
  const end = new Date(day);
  end.setUTCDate(end.getUTCDate() + 1);

  const res = await q(
    `select status, count(*)::int as count
     from rides
     where created_at >= $1 and created_at < $2
     group by status
     order by status`,
    [start.toISOString(), end.toISOString()]
  );

  const reportsDir = path.join(process.cwd(), "server", "reports");
  fs.mkdirSync(reportsDir, { recursive: true });
  const filename = `daily_${start.toISOString().slice(0,10)}.csv`;
  const filePath = path.join(reportsDir, filename);

  const header = "status,count\n";
  const lines = res.rows.map((r)=>`${r.status},${r.count}`).join("\n");
  fs.writeFileSync(filePath, header + (lines ? lines + "\n" : ""), "utf-8");

  const url = `/reports/${filename}`;

  await q(
    `insert into generated_reports (kind, period_start, period_end, file_url)
     values ('daily', $1::date, $2::date, $3)
     returning id`,
    [start.toISOString().slice(0,10), end.toISOString().slice(0,10), url]
  );

  return { url };
}
