import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const reportsRouter = express.Router();

function toCSV(rows, cols) {
  const head = cols.join(",");
  const lines = rows.map(r => cols.map(c => {
    const v = r[c];
    const s = v === null || v === undefined ? "" : (typeof v === "object" ? JSON.stringify(v) : String(v));
    return '"' + s.replace(/"/g,'""') + '"';
  }).join(","));
  return [head, ...lines].join("\n");
}

reportsRouter.get("/rides.csv", requireAuth, requireRole("admin"), async (req,res)=>{
  const from = req.query.from ? String(req.query.from) : null;
  const to = req.query.to ? String(req.query.to) : null;

  const r = await q(
    `select id, kind, status, fare_cents, company_id, created_at, updated_at
     from rides
     where ($1::date is null or created_at::date >= $1::date)
       and ($2::date is null or created_at::date <= $2::date)
     order by created_at desc
     limit 5000`,
    [from, to]
  ).catch(()=>({rows:[]}));

  const cols = ["id","kind","status","fare_cents","company_id","created_at","updated_at"];
  const csv = toCSV(r.rows, cols);
  res.setHeader("content-type","text/csv; charset=utf-8");
  res.setHeader("content-disposition","attachment; filename=rides.csv");
  res.send(csv);
});

reportsRouter.get("/companies.csv", requireAuth, requireRole("admin"), async (req,res)=>{
  const r = await q(
    `select c.id, c.name, c.document, c.billing_email, c.created_at,
            coalesce(sum(r.fare_cents),0)::int as total_cents
     from companies c
     left join rides r on r.company_id=c.id
     group by c.id
     order by c.id desc
     limit 5000`
  ).catch(()=>({rows:[]}));
  const cols = ["id","name","document","billing_email","created_at","total_cents"];
  const csv = toCSV(r.rows, cols);
  res.setHeader("content-type","text/csv; charset=utf-8");
  res.setHeader("content-disposition","attachment; filename=companies.csv");
  res.send(csv);
});
