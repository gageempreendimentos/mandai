import { WebSocketServer } from "ws";
import { verifyAccessToken } from "../auth/jwt.js";
import { q } from "../db.js";

function parseToken(req) {
  const header = req.headers["authorization"] || "";
  if (header.startsWith("Bearer ")) return header.slice(7);
  const url = new URL(req.url, "http://localhost");
  return url.searchParams.get("token");
}

export function createWsServer(httpServer) {
  const wss = new WebSocketServer({ server: httpServer });

  const rooms = new Map();

  function join(ws, room) {
    if (!rooms.has(room)) rooms.set(room, new Set());
    rooms.get(room).add(ws);
    ws._rooms.add(room);
  }

  function leaveAll(ws) {
    for (const room of ws._rooms) {
      const set = rooms.get(room);
      if (set) {
        set.delete(ws);
        if (set.size === 0) rooms.delete(room);
      }
    }
    ws._rooms.clear();
  }

  function broadcast(room, msgObj) {
    const set = rooms.get(room);
    if (!set) return;
    const data = JSON.stringify(msgObj);
    for (const client of set) {
      if (client.readyState === 1) client.send(data);
    }
  }

  async function canJoinRoom(user, room) {
    if (room === "admin") return user.role === "admin";

    const [kind, id] = room.split(":");
    if (!kind || !id) return false;

    if (kind === "user") {
      return user.role === "admin" || user.sub === id;
    }

    if (kind === "restaurant") {
      if (user.role === "admin") return true;
      if (user.role !== "restaurant") return false;
      return String(user.restaurant_id || "") === id;
    }

    if (kind === "ride") {
      if (user.role === "admin") return true;

      const rideRes = await q(
        `select id, client_id, driver_id, restaurant_id
         from rides where id = $1`,
        [id]
      );
      const ride = rideRes.rows[0];
      if (!ride) return false;

      if (user.role === "driver") return ride.driver_id === user.sub;
      if (user.role === "client") return ride.client_id === user.sub;
      if (user.role === "restaurant") return String(user.restaurant_id || "") === String(ride.restaurant_id || "");
      return false;
    }

    return false;
  }

  wss.on("connection", async (ws, req) => {
    ws._rooms = new Set();
    ws._user = null;

    const token = parseToken(req);
    if (!token) return ws.close(4401, "missing_token");

    try {
      const claims = verifyAccessToken(token);
      ws._user = claims;

      join(ws, `user:${claims.sub}`);
      if (claims.role === "admin") join(ws, "admin");
      if (claims.role === "restaurant" && claims.restaurant_id) join(ws, `restaurant:${claims.restaurant_id}`);
    } catch {
      return ws.close(4401, "invalid_token");
    }

    ws.on("message", async (buf) => {
      let msg;
      try { msg = JSON.parse(buf.toString()); } catch { return; }

      if (msg?.type === "SUBSCRIBE" && typeof msg.room === "string") {
        const ok = await canJoinRoom(ws._user, msg.room);
        if (!ok) return ws.send(JSON.stringify({ type: "ERROR", error: "forbidden_room", room: msg.room }));
        join(ws, msg.room);
        return ws.send(JSON.stringify({ type: "SUBSCRIBED", room: msg.room }));
      }

      if (msg?.type === "CHAT_READ" && msg.message_id) {
  // mark read
  try {
    await q(
      `insert into ride_message_reads (message_id, user_id)
       values ($1, $2)
       on conflict do nothing`,
      [msg.message_id, ws._user.sub]
    );
  } catch {}
  ws.send(JSON.stringify({ type: "chat.read.ack", message_id: msg.message_id, ts: Date.now() }));
  return;
}

if (msg?.type === "CHAT_SEND" && msg.ride_id && typeof msg.message === "string") {
        const rideRoom = `ride:${msg.ride_id}`;
        const ok = await canJoinRoom(ws._user, rideRoom);
        if (!ok) return;

        await q(
          `insert into ride_messages (ride_id, sender_user_id, message, attachment_url, attachment_type)
           values ($1, $2, $3, $4, $5)`,
          [msg.ride_id, ws._user.sub, msg.message.slice(0, 2000), msg.attachment_url || null, msg.attachment_type || null]
        );

        broadcast(rideRoom, {
          type: "chat.message",
          ride_id: msg.ride_id,
          sender_user_id: ws._user.sub,
          message: msg.message,
          attachment_url: msg.attachment_url || null,
          attachment_type: msg.attachment_type || null,
          ts: Date.now()
        });
      }
    });

    ws.on("close", () => leaveAll(ws));
  });

  return { wss, broadcast };
}
