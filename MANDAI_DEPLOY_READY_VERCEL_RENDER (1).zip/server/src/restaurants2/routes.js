import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";

export const restaurantQualityRouter = express.Router();

restaurantQualityRouter.get("/quality", requireAuth, requireRole("admin"), async (req,res)=>{
  const r = await q(
    `select r.id as restaurant_id, r.name, m.avg_prep_minutes, m.cancel_rate, m.rating_avg, m.orders_7d, m.updated_at
     from restaurants r
     left join restaurant_quality_metrics m on m.restaurant_id = r.id
     order by m.orders_7d desc nulls last
     limit 300`
  ).catch(()=>({rows:[]}));
  res.json({ restaurants: r.rows });
});

restaurants2Router.get("/me/orders", requireAuth, requireRole("restaurant"), async (req,res)=>{
  // If you have restaurants table mapping user->restaurant_id, plug here.
  // MVP: return recent delivery rides (placeholder).
  const r = await q(
    `select id, status, pickup, dropoff, created_at
     from rides
     where kind='delivery'
     order by created_at desc
     limit 100`
  ).catch(()=>({rows:[]}));
  res.json({ orders: r.rows });
});
