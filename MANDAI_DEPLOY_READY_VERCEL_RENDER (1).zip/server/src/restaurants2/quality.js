import { q } from "../db.js";

export async function computeRestaurantQuality() {
  // avg prep = preparing_at - created_at (or confirmed/preparing timestamps if exist)
  const r = await q(
    `select restaurant_id,
            count(*)::int as n,
            avg(extract(epoch from (preparing_at - created_at))/60)::numeric as avg_prep
     from rides
     where created_at > now() - interval '7 days'
       and restaurant_id is not null
       and preparing_at is not null
     group by restaurant_id`
  ).catch(()=>({rows:[]}));

  const canc = await q(
    `select restaurant_id,
            count(*) filter (where status='canceled')::int as cancels,
            count(*)::int as total
     from rides
     where created_at > now() - interval '7 days'
       and restaurant_id is not null
     group by restaurant_id`
  ).catch(()=>({rows:[]}));

  const cancMap = new Map();
  for (const c of canc.rows) {
    const rate = Number(c.total||0) > 0 ? Number(c.cancels||0)/Number(c.total) : 0;
    cancMap.set(String(c.restaurant_id), { rate, total: Number(c.total||0) });
  }

  for (const row of r.rows) {
    const cm = cancMap.get(String(row.restaurant_id)) || { rate: 0, total: Number(row.n||0) };
    await q(
      `insert into restaurant_quality_metrics (restaurant_id, avg_prep_minutes, cancel_rate, orders_7d, updated_at)
       values ($1,$2,$3,$4, now())
       on conflict (restaurant_id) do update set
         avg_prep_minutes=excluded.avg_prep_minutes,
         cancel_rate=excluded.cancel_rate,
         orders_7d=excluded.orders_7d,
         updated_at=now()`,
      [row.restaurant_id, Number(row.avg_prep||0), Number(cm.rate||0), Number(cm.total||0)]
    ).catch(()=>{});
  }
}
