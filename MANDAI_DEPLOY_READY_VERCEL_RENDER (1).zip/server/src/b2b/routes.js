import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const b2bRouter = express.Router();

// Admin: create company
b2bRouter.post("/companies", requireAuth, requireRole("admin"), idempotency(), async (req,res)=>{
  const { name, document, billing_email } = req.body || {};
  if (!name) return res.status(400).json({ error:"missing_name" });
  const r = await q(
    `insert into companies (name, document, billing_email) values ($1,$2,$3) returning id`,
    [String(name), document||null, billing_email||null]
  );
  res.json({ ok:true, id: r.rows[0].id });
});

// Admin: add user to company
b2bRouter.post("/companies/:id/users", requireAuth, requireRole("admin"), idempotency(), async (req,res)=>{
  const company_id = Number(req.params.id);
  const { user_id, role="member" } = req.body || {};
  if (!user_id) return res.status(400).json({ error:"missing_user_id" });
  await q(
    `insert into company_users (company_id, user_id, role) values ($1,$2,$3)
     on conflict (company_id, user_id) do update set role=excluded.role`,
    [company_id, user_id, String(role)]
  ).catch(()=>{});
  res.json({ ok:true });
});

// Company user: list my companies
b2bRouter.get("/my", requireAuth, async (req,res)=>{
  const r = await q(
    `select c.id, c.name, cu.role
     from company_users cu join companies c on c.id=cu.company_id
     where cu.user_id=$1
     order by c.id desc`,
    [req.user.sub]
  ).catch(()=>({rows:[]}));
  res.json({ companies: r.rows });
});

// Attach company to ride (client)
b2bRouter.post("/rides/:rideId/attach", requireAuth, idempotency(), async (req,res)=>{
  const rideId = req.params.rideId;
  const { company_id, cost_center_id } = req.body || {};
  // must be owner of ride and member of company
  const ride = await q(`select client_id from rides where id=$1`, [rideId]).catch(()=>({rows:[]}));
  if (!ride.rows[0] || ride.rows[0].client_id !== req.user.sub) return res.status(403).json({ error:"forbidden" });
  const mem = await q(`select 1 from company_users where company_id=$1 and user_id=$2`, [Number(company_id), req.user.sub]).catch(()=>({rows:[]}));
  if (!mem.rows[0]) return res.status(403).json({ error:"not_company_member" });

  // Enforce basic company limits (optional)
const lim = await q(`select daily_limit_cents, monthly_limit_cents from company_limits where company_id=$1`, [Number(company_id)]).catch(()=>({rows:[]}));
if (lim.rows[0]) {
  const day = await q(
    `select coalesce(sum(fare_cents),0)::int as total from rides
     where company_id=$1 and created_at::date = now()::date`,
    [Number(company_id)]
  ).catch(()=>({rows:[{total:0}]}));
  const month = await q(
    `select coalesce(sum(fare_cents),0)::int as total from rides
     where company_id=$1 and date_trunc('month', created_at) = date_trunc('month', now())`,
    [Number(company_id)]
  ).catch(()=>({rows:[{total:0}]}));
  const next = await q(`select fare_cents from rides where id=$1`, [rideId]).catch(()=>({rows:[{fare_cents:0}]}));
  const add = Number(next.rows[0]?.fare_cents||0);
  if (lim.rows[0].daily_limit_cents && Number(day.rows[0]?.total||0)+add > Number(lim.rows[0].daily_limit_cents)) {
    return res.status(400).json({ error:"company_daily_limit" });
  }
  if (lim.rows[0].monthly_limit_cents && Number(month.rows[0]?.total||0)+add > Number(lim.rows[0].monthly_limit_cents)) {
    return res.status(400).json({ error:"company_monthly_limit" });
  }
}

await q(`update rides set company_id=$2, cost_center_id=$3 where id=$1`, [rideId, Number(company_id), cost_center_id?Number(cost_center_id):null]).catch(()=>{});
  res.json({ ok:true });
});

// Admin: generate invoice (stub sum of rides)
b2bRouter.post("/companies/:id/invoice", requireAuth, requireRole("admin"), idempotency(), async (req,res)=>{
  const company_id = Number(req.params.id);
  const { period_start, period_end } = req.body || {};
  if (!period_start || !period_end) return res.status(400).json({ error:"missing_period" });

  const sum = await q(
    `select coalesce(sum(fare_cents),0)::int as total
     from rides
     where company_id=$1 and created_at::date between $2::date and $3::date`,
    [company_id, period_start, period_end]
  ).catch(()=>({rows:[{total:0}]}));

  const total = Number(sum.rows[0]?.total||0);
  const inv = await q(
    `insert into company_invoices (company_id, period_start, period_end, total_cents, status)
     values ($1,$2::date,$3::date,$4,'issued')
     on conflict (company_id, period_start, period_end)
     do update set total_cents=excluded.total_cents, status='issued'
     returning id`,
    [company_id, period_start, period_end, total]
  ).catch(()=>({rows:[]}));

  res.json({ ok:true, invoice_id: inv.rows[0]?.id, total_cents: total });
});
