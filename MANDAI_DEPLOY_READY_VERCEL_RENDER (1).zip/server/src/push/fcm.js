export async function sendFCM(token, payload){
  // TODO: integrate Firebase Admin SDK
}
