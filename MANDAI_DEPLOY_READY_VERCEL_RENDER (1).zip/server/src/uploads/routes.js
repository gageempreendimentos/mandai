import express from "express";
import fs from "fs";
import path from "path";
import { q } from "../db.js";
import { requireAuth } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const uploadsRouter = express.Router();

function ensureUploadsDir() {
  const dir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

uploadsRouter.post("/base64", requireAuth, idempotency(), async (req,res)=>{
  const { kind="chat", filename="image.jpg", base64_data } = req.body || {};
  if (!base64_data) return res.status(400).json({ error:"missing_base64_data" });

  const dir = ensureUploadsDir();
  const safeName = `${Date.now()}_${Math.random().toString(16).slice(2)}_${String(filename).replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  const full = path.join(dir, safeName);

  const data = String(base64_data).split(",").pop(); // allow data URL
  const buf = Buffer.from(data, "base64");
  fs.writeFileSync(full, buf);

  const url = `/uploads/${safeName}`;

  await q(`insert into uploads (user_id, kind, url) values ($1,$2,$3)`, [req.user.sub, kind, url]).catch(()=>{});
  res.json({ ok:true, url });
});
