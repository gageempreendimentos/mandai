import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";
import { audit } from "../middlewares/audit.js";

export const ledgerRouter = express.Router();

// Admin: list ledger entries
ledgerRouter.get("/", requireAuth, requireRole("admin"), async (req,res)=>{
  const limit = Math.min(Number(req.query.limit||200), 1000);
  const r = await q(
    `select id, created_at, entry_type, ride_id, restaurant_id, driver_id, amount_cents, meta
     from ledger_entries
     order by created_at desc
     limit $1`, [limit]
  ).catch(()=>({rows:[]}));
  res.json({ entries: r.rows });
});

// Admin: create manual ledger entry (immutable append-only)
ledgerRouter.post("/manual", requireAuth, requireRole("admin"), idempotency(), audit("ledger.manual", "ledger_entries"), async (req,res)=>{
  const { entry_type, ride_id, restaurant_id, driver_id, amount_cents, meta } = req.body || {};
  if (!entry_type) return res.status(400).json({ error:"missing_entry_type" });
  if (amount_cents == null) return res.status(400).json({ error:"missing_amount_cents" });

  const r = await q(
    `insert into ledger_entries (entry_type, ride_id, restaurant_id, driver_id, amount_cents, meta)
     values ($1,$2,$3,$4,$5,$6::jsonb)
     returning id, created_at`,
    [
      String(entry_type),
      ride_id || null,
      restaurant_id != null ? Number(restaurant_id) : null,
      driver_id || null,
      Number(amount_cents),
      JSON.stringify(meta || {})
    ]
  );
  res.json({ ok:true, id: r.rows[0].id, created_at: r.rows[0].created_at });
});

// Driver: wallet summary (credits - debits)
ledgerRouter.get("/driver/me", requireAuth, async (req,res)=>{
  if (req.user.role !== "driver" && req.user.role !== "admin") return res.status(403).json({ error:"forbidden" });
  const driver_id = req.user.role === "admin" && req.query.driver_id ? String(req.query.driver_id) : req.user.sub;
  const sum = await q(
    `select
        coalesce(sum(case when amount_cents > 0 then amount_cents else 0 end),0)::int as credits,
        coalesce(sum(case when amount_cents < 0 then -amount_cents else 0 end),0)::int as debits
     from ledger_entries
     where driver_id=$1`, [driver_id]
  ).catch(()=>({rows:[{credits:0,debits:0}]}));
  const credits = Number(sum.rows[0].credits||0);
  const debits = Number(sum.rows[0].debits||0);
  res.json({ driver_id, credits_cents: credits, debits_cents: debits, balance_cents: credits - debits });
});
