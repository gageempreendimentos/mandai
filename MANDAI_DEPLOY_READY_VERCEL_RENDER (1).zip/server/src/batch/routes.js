import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";
import { audit } from "../middlewares/audit.js";

import crypto from "crypto";

export const batchRouter = express.Router();

const OSRM_URL = process.env.OSRM_URL || "https://router.project-osrm.org";

function toRad(deg) {
  return (deg * Math.PI) / 180;
}

function haversineKm(a, b) {
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

async function optimizeBatchOrder(batchId) {
  // Fetch rides with coords (pickup assumed same for restaurant batches)
  const rides = await q(
    `select id, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng
     from rides where batch_id=$1`,
    [batchId]
  );

  const rows = rides.rows || [];
  if (rows.length < 2) return { ok: true, order: rows.map((r) => r.id) };

  // Ensure coords
  const valid = rows.filter(
    (r) =>
      Number.isFinite(Number(r.pickup_lat)) &&
      Number.isFinite(Number(r.pickup_lng)) &&
      Number.isFinite(Number(r.dropoff_lat)) &&
      Number.isFinite(Number(r.dropoff_lng))
  );
  if (valid.length < 2) return { ok: true, order: rows.map((r) => r.id) };

  // Start at pickup of first
  const start = { lat: Number(valid[0].pickup_lat), lng: Number(valid[0].pickup_lng) };
  const unvisited = valid.map((r) => ({
    id: r.id,
    to: { lat: Number(r.dropoff_lat), lng: Number(r.dropoff_lng) },
  }));

  const order = [];
  let cur = start;
  while (unvisited.length) {
    let bestIdx = 0;
    let best = Number.POSITIVE_INFINITY;
    for (let i = 0; i < unvisited.length; i++) {
      const d = haversineKm(cur, unvisited[i].to);
      if (d < best) {
        best = d;
        bestIdx = i;
      }
    }
    const nxt = unvisited.splice(bestIdx, 1)[0];
    order.push(nxt.id);
    cur = nxt.to;
  }

  // Persist as batch_order
  let idx = 1;
  for (const rid of order) {
    await q(`update rides set batch_order=$2 where id=$1`, [rid, idx++]);
  }

  return { ok: true, order };
}

// Admin creates a batch from ride ids (must be unbatched)
batchRouter.post(
  "/create",
  requireAuth,
  requireRole("admin"),
  requirePermission("batch.manage"),
  idempotency(),
  audit("batch.create", "ride_batches"),
  async (req, res) => {
    const ride_ids = req.body?.ride_ids || [];
    if (!Array.isArray(ride_ids) || ride_ids.length < 2) return res.status(400).json({ error: "need_at_least_2_rides" });

    const id = req.body?.id || crypto.randomUUID?.() || (await import("crypto")).randomUUID();

    await q(`insert into ride_batches (id, status) values ($1,'open') on conflict do nothing`, [id]);

    let order = 1;
    for (const rid of ride_ids) {
      await q(
        `update rides set batch_id=$2, batch_order=$3 where id=$1 and batch_id is null`,
        [rid, id, order++]
      );
    }

    // Auto optimize order (restaurant premium: múltiplas entregas no mesmo entregador)
    try {
      if (req.body?.optimize !== false) await optimizeBatchOrder(id);
    } catch {}

    res.json({ ok: true, batch_id: id });
  }
);

// Admin can re-optimize the order at any time
batchRouter.post(
  "/:id/optimize",
  requireAuth,
  requireRole("admin"),
  requirePermission("batch.manage"),
  idempotency(),
  audit("batch.optimize", "ride_batches", (req) => req.params.id),
  async (req, res) => {
    const id = req.params.id;
    const r = await optimizeBatchOrder(id);
    res.json(r);
  }
);

batchRouter.post(
  "/:id/assign",
  requireAuth,
  requireRole("admin"),
  requirePermission("batch.manage"),
  idempotency(),
  audit("batch.assign", "ride_batches", (req)=>req.params.id, (req)=>req.body||{}),
  async (req, res) => {
    const { driver_id } = req.body || {};
    if (!driver_id) return res.status(400).json({ error: "missing_driver_id" });
    const id = req.params.id;

    await q(`update ride_batches set driver_id=$2, status='assigned' where id=$1`, [id, driver_id]);
    await q(`update rides set driver_id=$2, status='assigned', assigned_at=now(), updated_at=now() where batch_id=$1 and driver_id is null`, [id, driver_id]);

    res.json({ ok: true });
  }
);

batchRouter.get("/:id", requireAuth, async (req, res) => {
  const id = req.params.id;
  const b = await q(`select * from ride_batches where id=$1`, [id]);
  if (!b.rows[0]) return res.status(404).json({ error: "not_found" });

  // permission: admin or driver assigned
  if (req.user.role !== "admin" && !(req.user.role === "driver" && b.rows[0].driver_id === req.user.sub)) {
    return res.status(403).json({ error: "forbidden" });
  }

  const rides = await q(
    `select id, status, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng, batch_order
     from rides where batch_id=$1 order by batch_order asc`,
    [id]
  );

  res.json({ batch: b.rows[0], rides: rides.rows });
});
