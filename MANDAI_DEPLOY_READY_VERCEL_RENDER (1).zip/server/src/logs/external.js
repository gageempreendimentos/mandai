export function logExternal(err, ctx={}){
  if (process.env.SENTRY_DSN){
    // send to sentry
  }
}
