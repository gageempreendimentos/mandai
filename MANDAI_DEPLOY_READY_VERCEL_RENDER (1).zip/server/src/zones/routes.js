import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { idempotency } from "../middlewares/idempotency.js";

export const zonesRouter = express.Router();

zonesRouter.get("/", requireAuth, requireRole("admin"), async (req, res) => {
  const r = await q("select id, name, city, polygon, created_at from zones order by created_at desc");
  res.json({ zones: r.rows });
});

zonesRouter.post("/", requireAuth, requireRole("admin"), idempotency(), async (req, res) => {
  const { name, city, polygon } = req.body || {};
  if (!name) return res.status(400).json({ error: "missing_name" });

  const r = await q(
    "insert into zones (name, city, polygon) values ($1,$2,$3) returning id, name, city, polygon, created_at",
    [name, city || null, polygon || null]
  );

  res.json({ zone: r.rows[0] });
});

zonesRouter.post("/:zoneId/assign-user/:userId", requireAuth, requireRole("admin"), idempotency(), async (req, res) => {
  const { zoneId, userId } = req.params;
  await q("insert into user_zones (user_id, zone_id) values ($1,$2) on conflict do nothing", [userId, zoneId]);
  res.json({ ok: true });
});
