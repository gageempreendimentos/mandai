import { q } from "../db.js";

export async function applyRefusal(driverId) {
  // increment refusal_count and apply cooldown if too many
  const r = await q(`update drivers set refusal_count=refusal_count+1 where id=$1 returning refusal_count`, [driverId]).catch(()=>({rows:[]}));
  const count = Number(r.rows[0]?.refusal_count||0);
  if (count >= 10) {
    await q(`update drivers set cooldown_until = now() + interval '15 minutes', refusal_count=0 where id=$1`, [driverId]).catch(()=>{});
    await q(`insert into driver_penalties (driver_id, kind, points, details) values ($1,'refusal_spam',2,jsonb_build_object('threshold',10))`, [driverId]).catch(()=>{});
  }
}

export async function applyCancel(driverId) {
  const r = await q(`update drivers set cancel_count_24h=cancel_count_24h+1 where id=$1 returning cancel_count_24h`, [driverId]).catch(()=>({rows:[]}));
  const count = Number(r.rows[0]?.cancel_count_24h||0);
  if (count >= 5) {
    await q(`update drivers set cooldown_until = now() + interval '30 minutes', cancel_count_24h=0 where id=$1`, [driverId]).catch(()=>{});
    await q(`insert into driver_penalties (driver_id, kind, points, details) values ($1,'cancel_spam',3,jsonb_build_object('threshold',5))`, [driverId]).catch(()=>{});
  }
}

export async function applyOfflineOnJob(driverId, rideId) {
  await q(`update drivers set cooldown_until = now() + interval '20 minutes' where id=$1`, [driverId]).catch(()=>{});
  await q(`insert into driver_penalties (driver_id, kind, points, details) values ($1,'offline_on_job',3,jsonb_build_object('ride_id',$2))`, [driverId, rideId]).catch(()=>{});
}

export async function driverIsOnCooldown(driverId) {
  const r = await q(`select cooldown_until from drivers where id=$1`, [driverId]).catch(()=>({rows:[]}));
  const until = r.rows[0]?.cooldown_until;
  if (!until) return false;
  return new Date(until).getTime() > Date.now();
}
