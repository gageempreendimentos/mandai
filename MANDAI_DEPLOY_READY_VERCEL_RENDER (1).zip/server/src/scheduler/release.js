import { q } from "../db.js";

export async function releaseScheduledRides() {
  const r = await q(
    `select id from rides
     where schedule_status='scheduled'
       and scheduled_for <= now()
     limit 200`
  ).catch(()=>({rows:[]}));

  for (const row of r.rows) {
    await q(
      `update rides set schedule_status='released', status='created', updated_at=now()
       where id=$1`,
      [row.id]
    ).catch(()=>{});
    await q(
      `insert into ride_events (ride_id, type, payload)
       values ($1,'scheduled_released', jsonb_build_object('at',now()))`,
      [row.id]
    ).catch(()=>{});
  }
}
