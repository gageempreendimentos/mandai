import express from "express";
import { q } from "../db.js";
import { requireAuth, requireRole } from "../auth/middleware.js";
import { requirePermission } from "../middlewares/permissions.js";
import { idempotency } from "../middlewares/idempotency.js";
import { audit } from "../middlewares/audit.js";
import { calcFareCents } from "./calc.js";

export const pricingRouter = express.Router();

// list rules
pricingRouter.get("/", requireAuth, requireRole("admin"), requirePermission("admin.manage_zones"), async (req, res) => {
  const r = await q(
    `select id, zone_id, name, base_fee_cents, per_km_cents, per_min_cents, min_fee_cents, max_fee_cents, surge_multiplier, active, updated_at
     from pricing_rules
     order by active desc, updated_at desc`
  );
  res.json({ rules: r.rows });
});

// upsert rule
pricingRouter.post(
  "/",
  requireAuth,
  requireRole("admin"),
  requirePermission("admin.manage_zones"),
  idempotency(),
  audit("pricing.upsert", "pricing_rules", (req)=>String(req.body?.id||""), (req)=>req.body||{}),
  async (req, res) => {
    const b = req.body || {};
    const {
      id, zone_id, name,
      base_fee_cents, per_km_cents, per_min_cents,
      min_fee_cents, max_fee_cents, surge_multiplier,
      active
    } = b;

    if (id) {
      const r = await q(
        `update pricing_rules
         set zone_id=$2, name=coalesce($3,name),
             base_fee_cents=coalesce($4,base_fee_cents),
             per_km_cents=coalesce($5,per_km_cents),
             per_min_cents=coalesce($6,per_min_cents),
             min_fee_cents=coalesce($7,min_fee_cents),
             max_fee_cents=$8,
             surge_multiplier=coalesce($9,surge_multiplier),
             active=coalesce($10,active),
             updated_at=now()
         where id=$1
         returning *`,
        [id, zone_id||null, name||null, base_fee_cents, per_km_cents, per_min_cents, min_fee_cents, max_fee_cents, surge_multiplier, active]
      );
      return res.json({ rule: r.rows[0] });
    }

    const r = await q(
      `insert into pricing_rules (zone_id, name, base_fee_cents, per_km_cents, per_min_cents, min_fee_cents, max_fee_cents, surge_multiplier, active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       returning *`,
      [
        zone_id||null,
        name || "default",
        base_fee_cents ?? 500,
        per_km_cents ?? 250,
        per_min_cents ?? 0,
        min_fee_cents ?? 800,
        max_fee_cents ?? null,
        surge_multiplier ?? 1.0,
        active ?? true
      ]
    );
    return res.json({ rule: r.rows[0] });
  }
);

// Quote endpoint (client/restaurant/admin)
pricingRouter.post("/quote", requireAuth, idempotency(), async (req, res) => {
  const { zone_id, distance_km, duration_min } = req.body || {};
  if (distance_km == null) return res.status(400).json({ error: "missing_distance_km" });

  const pr = await q(
    `select *
     from pricing_rules
     where active=true and (zone_id is not distinct from $1)
     order by updated_at desc
     limit 1`,
    [zone_id || null]
  );
  const rule = pr.rows[0] || { base_fee_cents: 500, per_km_cents: 250, per_min_cents: 0, min_fee_cents: 800, max_fee_cents: null, surge_multiplier: 1.0 };

  // Dynamic surge (optional): based on demand/supply in zone (pending rides / online drivers)
  let dynamicSurge = 1.0;
  try {
    const st = await q(`select key, value from system_state where key in ('surge_enabled','surge_max_multiplier','surge_sensitivity')`);
    const map = new Map(st.rows.map(r=>[r.key, r.value]));
    const enabled = String(map.get('surge_enabled') || 'false').toLowerCase() === 'true';
    if (enabled) {
      const max = Math.max(1.0, Math.min(5.0, Number(map.get('surge_max_multiplier') || 2.0)));
      const sens = Math.max(0.05, Math.min(3.0, Number(map.get('surge_sensitivity') || 0.6)));

      const deadSec = Number(process.env.DEADMAN_SECONDS || 120);
      const driversOnlineRes = await q(
        `select count(*)::int as n
         from users u
         join driver_locations dl on dl.driver_id=u.id
         left join user_zones uz on uz.user_id=u.id
         where u.role='driver'
           and u.is_disabled=false
           and u.on_duty=true
           and coalesce(dl.is_online,true)=true
           and now() - dl.last_ping_at < (interval '1 second' * $1)
           and ($2::uuid is null or uz.zone_id is not distinct from $2::uuid)`,
        [deadSec, zone_id || null]
      ).catch(()=>({rows:[{n:0}]}));

      const pendingRes = await q(
        `select count(*)::int as n
         from rides
         where status in ('created','preparing')
           and driver_id is null
           and ($1::uuid is null or zone_id is not distinct from $1::uuid)`,
        [zone_id || null]
      ).catch(()=>({rows:[{n:0}]}));

      const driversOnline = Math.max(0, Number(driversOnlineRes.rows[0]?.n || 0));
      const pending = Math.max(0, Number(pendingRes.rows[0]?.n || 0));

      // ratio=1 => 1.0. If pending > drivers -> surge increases smoothly.
      const ratio = driversOnline > 0 ? (pending / driversOnline) : (pending > 0 ? 5 : 0);
      dynamicSurge = Math.min(max, Math.max(1.0, 1.0 + sens * Math.max(0, ratio - 1.0)));
      if (!isFinite(dynamicSurge)) dynamicSurge = 1.0;
    }
  } catch {}

  const combinedRule = { ...rule, surge_multiplier: Number(rule.surge_multiplier || 1) * dynamicSurge };
  const out = calcFareCents(combinedRule, distance_km, duration_min || 0);

  res.json({
    fare_cents: out.fare_cents,
    breakdown: { ...out.breakdown, dynamic_surge: dynamicSurge },
    rule_id: rule.id || null
  });
});
