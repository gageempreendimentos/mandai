export function calcFareCents({ base_fee_cents, per_km_cents, per_min_cents, min_fee_cents, max_fee_cents, surge_multiplier }, distance_km, duration_min) {
  const base = Number(base_fee_cents || 0);
  const km = Math.max(0, Number(distance_km || 0));
  const mins = Math.max(0, Number(duration_min || 0));
  const perKm = Number(per_km_cents || 0);
  const perMin = Number(per_min_cents || 0);
  const surge = Number(surge_multiplier || 1);

  let fare = base + Math.round(km * perKm) + Math.round(mins * perMin);
  fare = Math.round(fare * surge);

  if (min_fee_cents != null) fare = Math.max(fare, Number(min_fee_cents));
  if (max_fee_cents != null) fare = Math.min(fare, Number(max_fee_cents));

  return { fare_cents: fare, breakdown: { base, km, mins, perKm, perMin, surge, computed: fare } };
}
