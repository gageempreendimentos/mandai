import pg from "pg";
import crypto from "crypto";

const { Client } = pg;

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) { console.error("Missing DATABASE_URL"); process.exit(1); }

const email = process.env.SEED_ADMIN_EMAIL || "admin@mandai.local";
const password = process.env.SEED_ADMIN_PASSWORD || "admin123";
const role = "admin";

function hash(pw) {
  // simple sha256 (replace with bcrypt if you add it)
  return crypto.createHash("sha256").update(pw).digest("hex");
}

async function main() {
  const client = new Client({ connectionString: DATABASE_URL });
  await client.connect();

  // best-effort: adapt to your schema
  const users = await client.query("select to_regclass('public.users') as t");
  if (!users.rows[0]?.t) {
    console.log("No users table found, skipping seed.");
    await client.end();
    return;
  }

  const existing = await client.query("select id from users where email=$1", [email]).catch(()=>({rows:[]}));
  if (existing.rows[0]) {
    console.log("Admin already exists:", email);
    await client.end();
    return;
  }

  // Try common columns: email, password_hash, role
  await client.query(
    "insert into users (email, password_hash, role) values ($1,$2,$3)",
    [email, hash(password), role]
  );

  console.log("Seeded admin:", email, "password:", password);
  await client.end();
}

main().catch(e=>{ console.error(e); process.exit(1); });
