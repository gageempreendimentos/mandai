import express from "express";
import cors from "cors";
import http from "http";
import { WebSocketServer } from "ws";
import pg from "pg";

const { Pool } = pg;

const PORT = process.env.PORT || 8787;
const ORIGIN = process.env.CORS_ORIGIN || "*";

// Auth tokens per role (optional). If not set, any non-empty token is accepted.
// Recommended to set in production:
// DRIVER_TOKEN, CLIENT_TOKEN, ADMIN_TOKEN, RESTAURANT_TOKEN
const ROLE_TOKENS = {
  driver: process.env.DRIVER_TOKEN,
  client: process.env.CLIENT_TOKEN,
  admin: process.env.ADMIN_TOKEN,
  restaurant: process.env.RESTAURANT_TOKEN,
};

// Postgres connection (Supabase Postgres uses DATABASE_URL)
const DATABASE_URL = process.env.DATABASE_URL || process.env.SUPABASE_DB_URL || "";

const app = express();
app.use(cors({ origin: ORIGIN }));
app.use(express.json());

// ------------------------
// DB (optional)
// ------------------------
let pool = null;

async function dbInit() {
  if (!DATABASE_URL) return false;
  pool = new Pool({ connectionString: DATABASE_URL, ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : undefined });

  // Create table if needed
  await pool.query(`
    create table if not exists public.rides (
      id text primary key,
      data jsonb not null,
      updated_at timestamptz not null default now()
    );
  `);

  return true;
}

async function dbGetRide(id) {
  if (!pool) return null;
  const { rows } = await pool.query("select data from public.rides where id=$1", [id]);
  return rows[0]?.data ?? null;
}

async function dbUpsertRide(id, data) {
  if (!pool) return;
  await pool.query(
    `
    insert into public.rides (id, data, updated_at)
    values ($1, $2, now())
    on conflict (id)
    do update set data = excluded.data, updated_at = now()
    `,
    [id, data]
  );
}

// ------------------------
// In-memory fallback ride
// ------------------------
const DEFAULT_RIDE_ID = "1029";

// When DB is enabled, we keep a small in-memory cache for performance.
const rideCache = new Map();

function makeDefaultRide() {
  return {
    id: DEFAULT_RIDE_ID,
    pickup: "Centro",
    dropoff: "Santa Luzia",
    price: 18,
    stage: "offered", // offered | accepted | enroute | completed | idle
    etaMin: 7,
    pickupLatLng: { lat: -19.938, lng: -43.937 }, // BH approx (placeholder)
    dropoffLatLng: { lat: -19.928, lng: -43.925 },
    updatedAt: new Date().toISOString(),
  };
}

async function getRideState(id = DEFAULT_RIDE_ID) {
  if (rideCache.has(id)) return rideCache.get(id);
  const fromDb = await dbGetRide(id);
  const ride = fromDb || makeDefaultRide();
  rideCache.set(id, ride);
  return ride;
}

async function setRideState(id, patch) {
  const cur = await getRideState(id);
  const next = { ...cur, ...patch, id, updatedAt: new Date().toISOString() };
  rideCache.set(id, next);
  await dbUpsertRide(id, next);
  return next;
}

// ------------------------
// REST endpoints
// ------------------------
app.get("/health", (req, res) => res.json({ ok: true }));

app.get("/ride", async (req, res) => {
  const id = String(req.query.id || DEFAULT_RIDE_ID);
  const ride = await getRideState(id);
  res.json(ride);
});

app.post("/ride", async (req, res) => {
  const id = String(req.body?.id || req.query.id || DEFAULT_RIDE_ID);
  const ride = await setRideState(id, req.body || {});
  broadcastToRoom(`ride:${id}`, { type: "RIDE_UPDATE", payload: ride });
  res.json({ ok: true, ride });
});

// ------------------------
// WebSocket
// ------------------------
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Room management
const roomMembers = new Map(); // room -> Set(ws)

function joinRoom(ws, room) {
  if (!room) return;
  if (!ws.rooms) ws.rooms = new Set();
  ws.rooms.add(room);
  if (!roomMembers.has(room)) roomMembers.set(room, new Set());
  roomMembers.get(room).add(ws);
}

function leaveRoom(ws, room) {
  if (!room) return;
  try {
    ws.rooms?.delete(room);
  } catch {}
  const set = roomMembers.get(room);
  if (!set) return;
  set.delete(ws);
  if (set.size === 0) roomMembers.delete(room);
}

function broadcastToRoom(room, msg) {
  const raw = JSON.stringify(msg);
  const set = roomMembers.get(room);
  if (!set) return;
  for (const ws of set) {
    try { ws.send(raw); } catch {}
  }
}

function send(ws, msg) {
  try { ws.send(JSON.stringify(msg)); } catch {}
}

function isTokenValid(role, token) {
  if (!token) return false;
  const expected = ROLE_TOKENS[role];
  if (!expected) return true; // dev mode: accept any token
  return token === expected;
}

function parseUrlQuery(reqUrl) {
  try {
    const u = new URL(reqUrl, "http://localhost");
    const token = u.searchParams.get("token") || "";
    const role = u.searchParams.get("role") || "";
    const userId = u.searchParams.get("userId") || "";
    return { token, role, userId };
  } catch {
    return { token: "", role: "", userId: "" };
  }
}

wss.on("connection", async (ws, req) => {
  const { token, role, userId } = parseUrlQuery(req.url || "");

  // Auth handshake
  if (!role || !userId || !isTokenValid(role, token)) {
    send(ws, { type: "ERROR", payload: { code: "UNAUTHORIZED" } });
    try { ws.close(1008, "unauthorized"); } catch {}
    return;
  }

  ws.userId = userId;
  ws.role = role;
  ws.rooms = new Set();

  // default rooms: user + role
  joinRoom(ws, `user:${userId}`);
  joinRoom(ws, `role:${role}`);

  // send current default ride state (client can subscribe to ride rooms after open)
  const ride = await getRideState(DEFAULT_RIDE_ID);
  send(ws, { type: "RIDE_STATE", payload: ride });

  ws.on("message", async (data) => {
    try {
      const msg = JSON.parse(String(data));
      if (!msg?.type) return;

      // Protocol:
      // SUBSCRIBE { rooms: string[] }
      // UNSUBSCRIBE { rooms: string[] }
      // RIDE_UPDATE { payload: partial ride, rideId?: string }
      // RIDE_RESET { rideId?: string }
      if (msg.type === "SUBSCRIBE") {
        const rooms = msg.payload?.rooms || [];
        for (const r of rooms) joinRoom(ws, String(r));
        return;
      }

      if (msg.type === "UNSUBSCRIBE") {
        const rooms = msg.payload?.rooms || [];
        for (const r of rooms) leaveRoom(ws, String(r));
        return;
      }

      // Only driver can mutate ride (simple rule)
      if (msg.type === "RIDE_UPDATE") {
        if (ws.role !== "driver") return;
        const rideId = String(msg.payload?.id || msg.payload?.rideId || DEFAULT_RIDE_ID);
        const patch = msg.payload || {};
        delete patch.rideId;
        const next = await setRideState(rideId, patch);
        broadcastToRoom(`ride:${rideId}`, { type: "RIDE_UPDATE", payload: next });
        // also inform driver role room
        broadcastToRoom("role:driver", { type: "RIDE_UPDATE", payload: next });
        return;
      }

      if (msg.type === "RIDE_RESET") {
        if (ws.role !== "driver") return;
        const rideId = String(msg.payload?.rideId || DEFAULT_RIDE_ID);
        const next = await setRideState(rideId, { stage: "offered", etaMin: 7 });
        broadcastToRoom(`ride:${rideId}`, { type: "RIDE_UPDATE", payload: next });
        broadcastToRoom("role:driver", { type: "RIDE_UPDATE", payload: next });
        return;
      }
    } catch {}
  });

  ws.on("close", () => {
    // Remove from rooms
    if (ws.rooms) {
      for (const room of Array.from(ws.rooms)) {
        leaveRoom(ws, room);
      }
    }
  });
});

// ------------------------
// Start
// ------------------------
(async () => {
  const dbOn = await dbInit().catch(() => false);
  const ride = await getRideState(DEFAULT_RIDE_ID);
  if (dbOn) {
    console.log("✅ Postgres persistence enabled");
  } else {
    console.log("⚠️ Postgres not configured (DATABASE_URL). Using in-memory store.");
  }
  console.log("Current ride:", ride);
  server.listen(PORT, () => {
    console.log(`MANDAI WS Server on http://localhost:${PORT}`);
  });
})();
