// Placeholder file.
// It will be overwritten automatically by `scripts/generate-firebase-sw.cjs` when you run `npm run dev` or `npm run build`
// after setting the required VITE_FIREBASE_* env vars.
//
// If you are seeing this file in production, push notifications in background/offline will NOT work.
