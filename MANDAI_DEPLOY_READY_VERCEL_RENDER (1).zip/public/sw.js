self.addEventListener("install", (event) => {
  self.skipWaiting();
});
self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// Minimal cache for offline shell (optional)
const CACHE = "mandai-shell-v1";
const ASSETS = ["/", "/manifest.json", "/icons/icon.svg"];

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== "GET") return;
  if (url.origin !== location.origin) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(event.request);
    if (cached) return cached;
    try {
      const res = await fetch(event.request);
      if (ASSETS.includes(url.pathname)) cache.put(event.request, res.clone());
      return res;
    } catch (e) {
      return cached || new Response("Offline", { status: 200 });
    }
  })());
});
